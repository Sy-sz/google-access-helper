Cerdo Design

## 框架介绍


## 开发指引

### 常用命令

1. `npm install`  # 安装依赖
2. `npm start`    # runing development mode
3. `npm run dist` # runing production mode

### 注意事项
#### 命令行提示内存溢出(JavaScript heap out of memory)解决方式：

1. 解除 v8 对 node 内存使用限制

```shell
# linux/macos
export NODE_OPTIONS=--max_old_space_size=8192

# windows
set NODE_OPTIONS=--max_old_space_size=8192
```
### 设置registry地址
1. npm config set registry https://registry.npm.taobao.org  
2. npm config set registry https://nexusdev.fsfund.com/repository/npm-group/

### node.js
1. 下载地址：http://172.30.86.63/3.%E5%89%8D%E7%AB%AF%E5%BC%80%E5%8F%91/

### python下载安装并配置环境变量
1. 下载地址：https://www.python.org/downloads/windows/
2. 参考地址：https://www.cnblogs.com/huangbiquan/p/7784533.html

### node-sass安装
1. 下载地址：https://github.com/sass/node-sass/releases
2. 设置node-sass离线包：npm config set SASS_BINARY_PATH D:\\Soft\\win32-x64-83_binding.node
