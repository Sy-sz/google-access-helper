const path = require('path');
const projectConfig = require('./config/config');
const scriptsPath = projectConfig.webpackConfig.resolveAlias['cerdo-scripts'];

process.env.CONFIG_FILE = path.resolve('config/config');
const config = require(`${scriptsPath}/config/base.js`);

module.exports = {
  env: {
    browser: true,
    amd: true,
    es6: true,
    node: true,
    mocha: true,
  },
  // 以当前目录为根目录，不再向上查找 .eslintrc.js
  root: true,
  extends: ['plugin:react/recommended', 'alloy', 'alloy/react'],
  globals: {
    process: true,
    this: true,
    React: true,
    NodeJS: true,
  },
  // "parser": "babel-eslint",
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaFeatures: {
      experimentalObjectRestSpread: true,
      jsx: true,
    },
    allowImportExportEverywhere: false,
    sourceType: 'module',
    ecmaVersion: 7,
  },
  plugins: ['@typescript-eslint', 'react', 'react-hooks', 'prettier'],
  rules: {
    // 重写 alloy react 的规则
    'react/no-find-dom-node': 1, // 允许使用 findDOMNode
    'react/jsx-fragments': 0, // 规定使用 Fragment 的方式 React.Fragment <>
    'react/self-closing-comp': 0, // 不含子元素的元素必须使用单标签模式
    'react/no-unsafe': 1, // 警告使用不安全的生命周期
    'react/static-property-placement': 0, // 不检查类静态属性的位置
    'react/jsx-uses-react': 2, // 防止React被错误地标记为未使用
    'react/jsx-uses-vars': 1, // 防止将JSX中使用的变量错误地标记为未使用

    // 重写 alloy base 的规则
    complexity: ['error', { max: 25 }], // 禁止函数的循环复杂度超过 25
    eqeqeq: 1, // 使用不安全的等式操作符时警告
    'func-name-matching': 1, // 允许使用函数声明表达式时函数名与变量名不一致
    'guard-for-in': 1, // forin会变量原型中的属性，警告意外行为
    'no-eq-null': 1, // null 比较不允许使用 ==
    'no-param-reassign': 1, // 禁止对 function 的参数进行重新赋值
    'no-async-promise-executor': 'off', // 允许在promise执行函数中使用异步函数async
    'no-promise-executor-return': 'off',
    'no-debugger': 1, // 使用 debugger 警告
    'no-case-declarations': 1, // 允许在case/default 使用声明（let，const，function和class）
    'max-params': ['error', { max: 10 }], // 最大参数 00
    'max-nested-callbacks': ['error', { max: 5 }], // 回调函数嵌套禁止超过 3 层，多了请用 async await 替代
    'prefer-object-spread': 1, // 不强制使用 ...操作符
    'prefer-regex-literals': 1, // 不强制使用 字面量正则

    // 新增eslint规则
    curly: 2, // 不允许在条件语句和循环语句中省略花括号
    quotes: ['error', 'single', { allowTemplateLiterals: true }], // 只允许使用单引号 和 反引号
    'no-plusplus': 1, // 使用 ++ -- 警告，建议使用 += -=
    'default-case': 2, // switch语句最后必须有default
    'no-invalid-this': 'off',
    'no-multi-spaces': 2, // 不使用多个空格
    'no-caller': 2, // 禁用 arguments.caller 或 arguments.callee
    'prefer-rest-params': 2, // 标记arguments变量的使用
    'no-else-return': 2, // 禁止 if 语句中 return 语句之后有 else 块
    'no-trailing-spaces': ['error', { skipBlankLines: true }], // 不允许空行上的尾随空白
    'no-alert': 1, // 允许在代码中使用 alert confirm prompt
    'no-prototype-builtins': 1, // 禁止直接调用 Object.prototypes 的内置属性
    'no-console': ['warn', { allow: ['warn', 'error', 'log'] }], //  允许使用console 的 warn ，error 时警告
    'prefer-template': 1, // 使用字符串拼接时警告，建议使用字符串模板
    'prefer-promise-reject-errors': 0,

    'no-use-before-define': 'off',
    '@typescript-eslint/no-use-before-define': ['error'],
  },
  settings: {
    'import/ignore': ['node_modules'],
    // 解决webpack别名找不到
    'import/resolver': {
      webpack: {
        config: {
          resolve: {
            extensions: config.resolve.extensions,
            alias: { ...config.resolve.alias, ...projectConfig.webpackConfig.resolveAlias },
          },
        },
      },
    },
    react: {
      version: 'detect',
    },
  },
};
