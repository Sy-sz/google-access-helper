# 🌟 Cerdo Design

设计解决方案

### 2.1.0

* 主题切换事件增加 `EventCetner.puslish` 推送

### 2.1.1

* 增加 /single/app 单页面路由，切换为只展示 layout 布局 content 部分内容