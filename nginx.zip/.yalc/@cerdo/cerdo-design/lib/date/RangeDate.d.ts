import React, { Component } from 'react';
import { DatePickerProps } from 'antd';
import type { Moment } from 'moment';
export interface IRangeDateProps<DateType = Moment | null> extends Omit<DatePickerProps, 'placeholder' | 'disabledDate' | 'onChange' | 'value'> {
    placeholder?: string[];
    value?: [DateType, DateType];
    disabledDate?: [(currentDate: Moment) => boolean, (currentDate: Moment) => boolean];
    onChange?: (dateArr: [DateType, DateType], dateStringArr: [string, string]) => void;
}
export interface IRangeDateState<DateType = Moment | null> {
    startDate?: DateType;
    endDate?: DateType;
    startDateString?: String | null;
    endDateString?: String | null;
}
declare class RangeDate extends Component<IRangeDateProps, IRangeDateState> {
    constructor(props: any);
    onChange: () => void;
    render(): React.JSX.Element;
}
export default RangeDate;
