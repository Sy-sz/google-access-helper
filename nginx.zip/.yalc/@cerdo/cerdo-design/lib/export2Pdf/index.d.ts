export interface IExport2PdfProps {
    target?: HTMLElement;
    fileName?: string;
    fileType?: string;
    backgroundColor?: string;
    isPage?: boolean;
}
declare const _default: ({ target, fileName, fileType, backgroundColor, isPage }: IExport2PdfProps) => Promise<void>;
export default _default;
