import React, { Component } from 'react';
export interface LoadingProps {
    msg?: string;
    loading?: boolean;
}
declare class Loading extends Component<LoadingProps> {
    render(): React.JSX.Element;
}
export default Loading;
