/// <reference types="react" />
export declare const FormDictCheckbox: import("react").ForwardRefExoticComponent<Partial<import("../../checkbox/DictCheckbox").IDictSelectProps & {
    children?: import("react").ReactNode;
}> & import("react").RefAttributes<unknown>>;
export default FormDictCheckbox;
