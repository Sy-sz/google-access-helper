import React from 'react';
import { IDictSelectPlusProps } from '../../select/DictSelectPlus';
import { IDictSelectProps } from '../../checkbox/DictCheckbox';
import { IDictCascaderPlusProps } from '../../cascader/DictCascaderPlus';
import type { DictTreeSelectProps } from '../../tree/DictTreeSelect';
declare const _default: {
    DictSelect: React.FC<IDictSelectPlusProps<any>>;
    DictCheckbox: React.FC<IDictSelectProps>;
    DictCascader: React.FC<IDictCascaderPlusProps>;
    DictTreeSelect: React.FC<DictTreeSelectProps<any>>;
};
export default _default;
