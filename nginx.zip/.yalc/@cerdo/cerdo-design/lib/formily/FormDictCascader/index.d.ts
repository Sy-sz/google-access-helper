/// <reference types="react" />
export declare const FormDictCascader: import("react").ForwardRefExoticComponent<Partial<import("../../cascader/DictCascaderPlus").IDictCascaderPlusProps & {
    children?: import("react").ReactNode;
}> & import("react").RefAttributes<unknown>>;
export default FormDictCascader;
