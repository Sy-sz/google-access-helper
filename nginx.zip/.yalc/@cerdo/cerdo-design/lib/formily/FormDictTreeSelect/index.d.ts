import React from 'react';
export declare const FormDictTreeSelect: React.ForwardRefExoticComponent<Partial<import("../../tree/DictTreeSelect").DictTreeSelectProps<any> & {
    children?: React.ReactNode;
}> & React.RefAttributes<unknown>>;
export default FormDictTreeSelect;
