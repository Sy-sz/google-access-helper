import React from 'react';
import { IDictSelectPlusProps } from '../../select/DictSelectPlus';
import { GeneralField } from '@formily/core';
export interface IFormDictSelectPlusProps extends Omit<IDictSelectPlusProps, 'dropdownRender' | 'onChange'> {
    dropdownRender?: (menu: React.ReactElement, self: GeneralField) => React.ReactElement;
    onChange?: (value: any, option: any, self?: GeneralField) => void;
}
export declare const FormDictSelectPlus: React.FC<IFormDictSelectPlusProps>;
export declare const FormDictSelect: React.ForwardRefExoticComponent<Omit<Partial<IFormDictSelectPlusProps & {
    children?: React.ReactNode;
}>, "ref"> & React.RefAttributes<unknown>>;
export default FormDictSelect;
