/// <reference types="react" />
export declare const FormUploadFile: import("react").ForwardRefExoticComponent<Omit<Partial<any>, "ref"> & import("react").RefAttributes<unknown>>;
export default FormUploadFile;
