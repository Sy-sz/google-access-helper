import React from 'react';
import { TabsProps } from 'antd/lib/tabs';
export interface IFormilyArrayTabsProps extends TabsProps {
    addCopy?: boolean;
    filtterCopy?: (data: any) => any;
    onGetCurData?: (data: any) => any;
}
export declare const FormilyArrayTabs: React.FC<React.PropsWithChildren<IFormilyArrayTabsProps>>;
export default FormilyArrayTabs;
