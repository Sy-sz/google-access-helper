declare const exportExcel: (headers: any[], data: any[], fileName?: string) => void;
export default exportExcel;
