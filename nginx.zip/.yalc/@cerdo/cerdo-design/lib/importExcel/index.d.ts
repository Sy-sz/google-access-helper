declare const importExcel: (file: any) => void;
export default importExcel;
