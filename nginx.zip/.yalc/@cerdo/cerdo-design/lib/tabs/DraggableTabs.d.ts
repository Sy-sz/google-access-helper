import React, { Component } from "react";
import type { TabsProps } from 'antd/es/tabs';
export interface ITabNodeProps {
    connectDragSource?: (params: any) => any;
    connectDropTarget?: (params: any) => any;
}
export interface IDraggableTabsState {
    order?: any[];
}
declare class DraggableTabs extends Component<TabsProps, IDraggableTabsState> {
    constructor(props: any);
    moveTabNode: (dragKey: any, hoverKey: any) => void;
    renderTabBar: (props: any, DefaultTabBar: any) => React.JSX.Element;
    render(): React.JSX.Element;
}
export default DraggableTabs;
