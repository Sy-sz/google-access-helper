import type { UploadProps } from 'antd/es/upload';
import type { UploadFile as UploadFileProps, UploadFileStatus } from 'antd/es/upload/interface';
import type { SizeType } from 'antd/es/config-provider/SizeContext';
import type { ButtonType } from 'antd/es/button';
import React, { Component } from 'react';
type IUploadFileProps<T = any> = UploadProps<T> & {
    showProcess?: string;
    uploadUrl?: string;
    onChange?: (value: any, list: any) => void;
    defaultFileList?: Array<any>;
    singleMode?: boolean;
    downloadUrl?: string;
    downloadMethod?: 'get' | 'post';
    value?: Array<any>;
    data?: T;
    size?: SizeType;
    type?: ButtonType;
    textContent?: string;
};
interface IUploadFileState {
    fileList?: UploadFileProps[];
}
declare class UploadFile extends Component<IUploadFileProps, IUploadFileState> {
    static defaultProps: {
        defaultFileList: any[];
        singleMode: boolean;
    };
    constructor(props: any);
    convertToAttachments: (fileList: any) => any[];
    convertToFileList: (attachments: any) => {
        uid: any;
        name: any;
        url: any;
        size: any;
        status: UploadFileStatus;
        response: {
            data: any;
        };
    }[];
    handleFileChange: (info: any) => void;
    render(): React.JSX.Element;
}
export default UploadFile;
