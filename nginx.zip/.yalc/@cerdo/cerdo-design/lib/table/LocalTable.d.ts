import React from 'react';
import BaseTable from './BaseTable';
import { noop } from '@cerdo/cerdo-utils/lib/fn';
declare class LocalTable extends BaseTable {
    static defaultProps: {
        pagination: {};
        getList: any;
        onFullScreen: any;
        disableInitReload: boolean;
        reload: typeof noop;
        onSave: any;
        onAdd: any;
        title: any;
        onExport: any;
        onSync: any;
    };
    list: any;
    constructor(props: any);
    deleteLine: (value: any, record: any, index: any) => void;
    addLine: (params?: {}) => void;
    inputChange: () => void;
    lineChange: (index: any, obj: any) => void;
    onSave: () => void;
    tableChange: ({ pageInfo, filter, sorter, columns }: {
        pageInfo: any;
        filter: any;
        sorter: any;
        columns: any;
    }) => void;
    render(): React.JSX.Element;
}
export default LocalTable;
