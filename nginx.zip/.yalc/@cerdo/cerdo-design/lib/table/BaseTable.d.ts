import React, { CSSProperties } from 'react';
import type { PaginationProps } from 'antd/es/pagination';
interface IBaseTableType {
    tableSize?: 'small' | 'middle' | 'large';
    scroll?: any;
    pagination?: PaginationProps;
}
interface AutoHeightType {
    blankHeight?: number;
    columnHeight?: number;
    minLines?: number;
}
export interface IBaseTableProps extends IBaseTableType {
    dataSource?: object[];
    getList: () => Promise<any>;
    autoHeight?: AutoHeightType;
    disableInitReload?: boolean;
    getThreshold?: any;
    events?: (...args: any) => void;
    onExport?: (p: Array<string | number>, s: Array<string | number>) => void;
    onSync?: (p: any) => void;
    onFullScreen?: (p: any) => void;
    showOnExport?: boolean;
    titleSort?: any;
    adjustTool?: boolean;
    showTools?: boolean;
    attachSum?: any;
    rowKey?: any;
    columns?: any;
    sortColumns?: number;
    loading?: boolean;
    onSave?: (p: any) => void;
    [key: string]: any;
}
export interface IBaseTableState<T = any> extends IBaseTableType {
    list?: any;
    fullScreen?: boolean;
    selectedRowKeys?: Array<string | number>;
    selectedRows?: Array<string | number>;
    tableLoading?: boolean;
    thresholdList?: T[];
    adjustVisible?: boolean;
    scrollXOffset?: number;
    scrollYOffset?: number;
    count?: number;
    orgList?: any[];
    [key: string]: any;
}
declare class BaseTable extends React.Component<IBaseTableProps, IBaseTableState> {
    tableSizeType: string[];
    getList: () => Promise<any>;
    sortTable: any;
    renderDate: any;
    renderPercent: any;
    renderTime: any;
    getThresholdColumns: any;
    convertColumns: any;
    tableContainer: any;
    reloadAndRest: () => void;
    loadCounter: number;
    timer: any;
    role: string;
    tableChange: any;
    columns: any;
    offsetKey: string;
    toolStyle: CSSProperties;
    tableSyncInterval: any;
    constructor(props: any);
    componentDidMount(): void;
    componentWillUnmount(): void;
    autoPageSize: () => void;
    tableChangeEvent: () => void;
    formatScroll: () => any;
    setScrollY: (y: any) => void;
    formatDateTime: (values: any, dateFormat?: string) => false | Error;
    dataSourceChange: (res: any, tableLoading?: boolean) => Promise<unknown>;
    emptyExpandedRow: () => React.JSX.Element;
    copyOrgList: (list?: any) => void;
    getFormParams: (pageContext: any, dateType?: string) => Promise<unknown>;
    getPageInfo: () => any;
    tablePageCount: (res: any) => {
        total: any;
        current: any;
        showTotal: (t: any, range: any) => string;
        defaultCurrent?: number;
        disabled?: boolean;
        defaultPageSize?: number;
        pageSize?: number;
        onChange?: (page: number, pageSize?: number) => void;
        hideOnSinglePage?: boolean;
        showSizeChanger?: boolean;
        pageSizeOptions?: string[];
        onShowSizeChange?: (current: number, size: number) => void;
        showQuickJumper?: boolean | {
            goButton?: React.ReactNode;
        };
        showTitle?: boolean;
        size?: "small" | "default";
        responsive?: boolean;
        simple?: boolean;
        style?: React.CSSProperties;
        locale?: Object;
        className?: string;
        prefixCls?: string;
        selectPrefixCls?: string;
        itemRender?: (page: number, type: "page" | "prev" | "next" | "jump-prev" | "jump-next", originalElement: React.ReactElement<HTMLElement, string | React.JSXElementConstructor<any>>) => React.ReactNode;
        role?: string;
        showLessItems?: boolean;
        totalBoundaryShowSizeChanger?: number;
    };
    tablePageChange: (pagination: any, filter: any, sorter: any) => Promise<unknown>;
    getTableData: () => {
        data: any;
        count: number;
    };
    getRowSelections: () => {
        onChange: (keys: any, rows: any) => void;
        selectedRowKeys: (string | number)[];
        selectedRows: (string | number)[];
    };
    reload: () => void;
    reloadAndReset: () => void;
    attachSum: (list: any) => any;
    fetch: (loading?: boolean) => Promise<unknown>;
    renderConfigList: () => any[];
    plusScrollHeight: () => void;
    subScrollHeight: () => void;
    plusScrollWidth: () => void;
    subScrollWidth: () => void;
    saveScrollOffset: () => void;
    showAdjustTitle: () => void;
    renderTableUtils: (config: any) => React.JSX.Element;
    columnsSorter: (columns: any, sortColumns: any) => any;
    sortColumns: (columns?: any) => any;
    calcSum: (columns: any) => any;
    sumColumns: (columns: any, list: any) => {
        columns: any;
        list: any;
    };
    getSortTitle: (columns: any) => any;
    renderSorter: (columns: any) => React.JSX.Element;
    render(): React.JSX.Element;
}
export default BaseTable;
