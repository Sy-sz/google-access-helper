export declare const TABLE_EVENT: {
    DID_MOUNT: string;
    WILL_UNMOUNT: string;
    LOAD_DATA: string;
    TABLE_CHANGE: string;
};
export declare const TABLE_TYPE: {
    SIMPLE: string;
    FETCH: string;
    LOCAL: string;
};
export declare const TT = "TT";
