import React, { Component } from 'react';
import { SizeType } from 'antd/es/config-provider/SizeContext';
import type { PaginationProps } from 'antd/es/pagination';
export interface ISearchTableBaseType {
    autoRefresh?: number;
    pagination?: false | PaginationProps;
}
export interface ISearchTableProps extends ISearchTableBaseType {
    getData?: (params: any) => Promise<any>;
    columns?: any[];
    defalutSize?: SizeType;
    getRefreshData?: (params: any) => Promise<any>;
    loading?: boolean;
    dataSource?: any;
    onRefreshData?: (...args: any[]) => void;
}
export interface ISearchTableState extends ISearchTableBaseType {
    size?: SizeType;
    autoRefreshLoading?: boolean;
    data?: any[];
}
declare class SearchTable extends Component<ISearchTableProps, ISearchTableState> {
    static defaultProps: {
        getData: any;
        columns: any[];
        defalutSize: string;
        autoRefresh: number;
        getRefreshData: any;
    };
    params: {
        direction?: string;
        sort?: any;
        page?: number;
        size?: number;
    };
    arraySort: any;
    autoRefreshTimer: any;
    constructor(props: ISearchTableProps);
    componentDidMount(): void;
    shouldComponentUpdate(nextProps: any): boolean;
    componentWillUnmount(): void;
    arraySortList: (list: any) => (sorter: any, data: any, column: any) => any;
    addAutoRefresh: () => void;
    removeAutoRefresh: () => void;
    getData: () => void;
    getRefreshData: () => void;
    tableChange: (pagination: any, filters: any, sorter: any) => void;
    renderTableTitle: () => React.JSX.Element;
    render(): React.JSX.Element;
}
export default SearchTable;
