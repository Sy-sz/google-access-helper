import React from 'react';
export interface IAdjustOrderProps<T = any, U = any> {
    saveSuccess?: (columns: T[]) => any;
    clear?: (...args: U[]) => any;
    close?: (...args: U[]) => any;
    visible?: boolean;
    columns?: T[];
}
export interface IAdjustOrderState<T = any> {
    columns?: T[];
    current?: number;
    visible?: boolean;
}
declare class AdjustOrder extends React.Component<IAdjustOrderProps, IAdjustOrderState> {
    constructor(props: any);
    componentDidMount(): void;
    componentWillUnmount(): void;
    keyDown: (event: any) => void;
    sortFields: (columns: any) => any;
    adjust: (index: any, offset: any) => void;
    save: () => void;
    render(): React.JSX.Element;
}
export default AdjustOrder;
