import React from 'react';
import BaseTable from './BaseTable';
import { noop } from '@cerdo/cerdo-utils/lib/fn';
declare class FetchTable extends BaseTable {
    static defaultProps: {
        pagination: {};
        getList: any;
        onExport: any;
        onFullScreen: any;
        onSync: any;
        sortColumns: any;
        disableInitReload: boolean;
        reload: typeof noop;
        reloadAndRest: typeof noop;
        getThreshold: any;
    };
    list: any[];
    constructor(props: any);
    tableChange: (pageInfo: any, filter: any, sorter: any) => void;
    render(): React.JSX.Element;
}
export default FetchTable;
