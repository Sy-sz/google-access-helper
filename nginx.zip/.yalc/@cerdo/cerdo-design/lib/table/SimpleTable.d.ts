import React from 'react';
import BaseTable from './BaseTable';
import { noop } from '@cerdo/cerdo-utils/lib/fn';
declare class SimpleTable extends BaseTable {
    static defaultProps: {
        pagination: {};
        getList: any;
        onExport: any;
        onFullScreen: any;
        onSync: any;
        sortColumns: any;
        disableInitReload: boolean;
        reload: typeof noop;
        attachSum: any;
        reloadAndRest: typeof noop;
        getThreshold: any;
        showOnExport: boolean;
    };
    list: any;
    constructor(props: any);
    tableChange: ({ pageInfo, filter, sorter, columns }: {
        pageInfo: any;
        filter: any;
        sorter: any;
        columns: any;
    }) => void;
    render(): React.JSX.Element;
}
export default SimpleTable;
