import React, { Component } from 'react';
declare class Develop extends Component {
    render(): React.JSX.Element;
}
export default Develop;
