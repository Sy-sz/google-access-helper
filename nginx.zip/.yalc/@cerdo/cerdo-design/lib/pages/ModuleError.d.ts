import React from 'react';
export interface ModuleErrorProps {
    title?: string;
}
declare const ModuleError: React.FC<ModuleErrorProps>;
export default ModuleError;
