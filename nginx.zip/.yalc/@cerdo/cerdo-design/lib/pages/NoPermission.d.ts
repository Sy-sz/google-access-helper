import React, { Component } from 'react';
declare class NoPermission extends Component {
    render(): React.JSX.Element;
}
export default NoPermission;
