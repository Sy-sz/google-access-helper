import React, { Component } from 'react';
interface WebViewProps {
    webUrl: string;
    onLoad?: () => void;
}
interface WebViewState {
    webUrl: string;
    isLoaded: boolean;
    timeStamp: number;
    sessionId?: string;
}
declare class WebView extends Component<WebViewProps, WebViewState> {
    static getDerivedStateFromProps(props: WebViewProps, state: WebViewState): {
        webUrl: string;
        timeStamp: number;
    };
    constructor(props: WebViewProps);
    handleLoad: () => void;
    render(): React.JSX.Element;
}
export default WebView;
