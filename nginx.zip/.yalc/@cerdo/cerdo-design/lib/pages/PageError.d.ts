import React, { Component } from 'react';
export interface PageErrorProps {
    title?: string;
}
declare class PageError extends Component<PageErrorProps> {
    render(): React.JSX.Element;
}
export default PageError;
