import React, { Component } from 'react';
declare class NotFound extends Component {
    render(): React.JSX.Element;
}
export default NotFound;
