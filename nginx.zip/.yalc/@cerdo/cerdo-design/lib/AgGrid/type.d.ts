import React from 'react';
import { AgGridReactProps } from 'ag-grid-react';
import { ColGroupDef, ITooltipParams } from 'ag-grid-community';
import type { PaginationProps } from 'antd/lib/pagination';
declare module 'ag-grid-react' {
    interface TableConfig extends AgGridReactProps {
        tableId?: string;
        inlineLoading?: boolean;
        classNames?: string;
        autoHeight?: boolean;
        agTheme?: string;
        className?: string;
        height?: number | string;
        isSideBar?: boolean;
        paginationHeight?: number;
        paginationConfig?: PaginationProps;
        bandedRows?: boolean;
        size?: 'tiny' | 'small' | 'middle' | 'large';
    }
    interface TableState {
        autoSaveColumnState?: boolean;
        enableBackendColumnState?: boolean;
    }
    type ColType = 'date' | 'datetime' | 'time' | 'number' | 'integer' | 'percent' | 'hundred' | 'tenThousand' | 'hundredMillion' | 'numberEditor' | 'integerEditor' | 'tenThousandEditor' | 'percentEditor' | 'hundredEditor' | 'hundredMillionEditor' | 'selectEditor' | 'dateEditor' | 'timeEditor' | 'datetimeEditor';
}
declare module 'ag-grid-community' {
    interface ColDefExtension {
        formatterParams?: FormatterParams;
        valueGetterTemp?: Function;
        dict?: ColDefDict;
        tooltip?: (params: ITooltipParams) => string;
        headerAlign?: 'left' | 'right' | 'center';
    }
    interface ColDef extends ColDefExtension {
        getHide?: Function;
        dictId?: string;
    }
    type ColumnDefs = (ColDef | ColGroupDef)[];
    interface ColDefDict {
        dictId?: string;
        dictDataConfig?: {
            dictKey: string;
            dictValue: string;
        };
        dictData?: ColDefDictData[];
    }
    interface ColDefDictData {
        key: string;
        value: string;
    }
    interface ColumnTypes {
        [key: string]: ColDef;
    }
    interface FormatterParams {
        format?: string;
        value?: string | number;
        prefix?: string | React.ReactNode;
        suffix?: string | React.ReactNode;
        precision?: number;
        nullValueContent?: string;
        nullValueCondition?: Function;
        trimZero?: boolean;
    }
}
