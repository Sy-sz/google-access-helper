import React from 'react';
import "./type";
import { TableProps } from './Table';
declare const AgGrid: (props: TableProps) => React.JSX.Element;
export default AgGrid;
