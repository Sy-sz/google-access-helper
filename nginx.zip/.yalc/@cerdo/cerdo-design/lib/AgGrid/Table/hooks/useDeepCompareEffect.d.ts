declare function useDeepCompareEffect(callback: any, dependencies: any): void;
export default useDeepCompareEffect;
