import React from 'react';
import { TableConfig, TableState } from 'ag-grid-react';
import 'ag-grid-enterprise';
export interface TableProps {
    tableConfig: TableConfig;
    dictConfig?: any;
    tableState?: TableState;
}
export interface IPaginationValueConfig {
    total?: number;
    pageSize?: number;
    currentPage?: number;
}
declare const AgGrid: React.FC<TableProps>;
export default AgGrid;
