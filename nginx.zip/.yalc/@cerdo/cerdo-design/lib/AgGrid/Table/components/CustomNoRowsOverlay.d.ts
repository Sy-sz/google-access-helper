declare class CustomNoRowsOverlay {
    eGui: HTMLElement;
    init(): void;
    getGui(): HTMLElement;
    refresh(): boolean;
}
export default CustomNoRowsOverlay;
