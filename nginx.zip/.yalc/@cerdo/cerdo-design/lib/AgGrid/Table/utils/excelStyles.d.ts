import { ExcelStyle } from 'ag-grid-community';
declare const defaultExcelStyles: ExcelStyle[];
export default defaultExcelStyles;
