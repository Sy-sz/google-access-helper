import { GridReadyEvent } from 'ag-grid-community';
declare const getDictColumnDefsRefData: (gridEvent: GridReadyEvent) => string[];
export { getDictColumnDefsRefData };
