import { ColumnDefs } from 'ag-grid-community';
declare const handleColumnTooltip: (columnDefs: ColumnDefs) => ColumnDefs;
export default handleColumnTooltip;
