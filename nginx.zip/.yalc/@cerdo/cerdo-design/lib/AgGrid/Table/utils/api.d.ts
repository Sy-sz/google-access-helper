import { ResponseDataType } from "@cerdo/cerdo-utils/lib/upmHttp";
export interface IGetUserTableConfig {
    tableId: string;
}
export interface ISaveUserTableConfig {
    tableId: string;
    content: string;
}
export declare const getUserTableConfig: (data: IGetUserTableConfig) => Promise<ResponseDataType>;
export declare const saveUserTableConfig: (data: ISaveUserTableConfig) => Promise<ResponseDataType>;
