import { ColumnTypes } from 'ag-grid-community';
declare function handleColumnTypes(columnTypes: ColumnTypes): ColumnTypes;
export default handleColumnTypes;
