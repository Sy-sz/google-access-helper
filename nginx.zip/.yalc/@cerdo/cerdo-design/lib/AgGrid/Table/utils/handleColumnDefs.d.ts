import { ColumnDefs, ColumnTypes } from 'ag-grid-community';
declare function handleColumnDefs(columnDefs: ColumnDefs, customColumnTypes: ColumnTypes): ColumnDefs;
export default handleColumnDefs;
