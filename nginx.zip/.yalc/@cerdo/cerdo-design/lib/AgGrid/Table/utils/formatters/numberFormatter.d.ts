import { ValueFormatterParams } from 'ag-grid-community';
declare const numberFormatter: (params: ValueFormatterParams) => string;
export default numberFormatter;
