export interface SaveIndexDBParams {
    tableId: string;
    config: object;
    rowCount?: number;
    columnCount?: number;
}
declare function getContextMenuItems(params: any): any;
export default getContextMenuItems;
