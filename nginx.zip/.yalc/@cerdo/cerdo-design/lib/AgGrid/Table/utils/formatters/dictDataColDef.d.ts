import { ColumnDefs } from 'ag-grid-community';
declare const dictDataColDef: (columnDefs: ColumnDefs) => ColumnDefs;
export default dictDataColDef;
