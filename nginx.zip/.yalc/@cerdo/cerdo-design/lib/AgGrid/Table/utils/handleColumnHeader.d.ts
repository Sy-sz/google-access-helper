import 'tippy.js/dist/tippy.css';
import 'tippy.js/themes/material.css';
export declare function generateString(length: number): string;
export declare function bindingTooltip(tableClassName: string): void;
export declare const handleColumnHeader: (columnDefs: any) => void;
declare const _default: {
    handleColumnHeader: (columnDefs: any) => void;
    bindingTooltip: typeof bindingTooltip;
    generateString: typeof generateString;
};
export default _default;
