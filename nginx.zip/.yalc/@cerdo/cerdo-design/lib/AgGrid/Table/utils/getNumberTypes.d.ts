declare const numberTypes: string[];
export default numberTypes;
