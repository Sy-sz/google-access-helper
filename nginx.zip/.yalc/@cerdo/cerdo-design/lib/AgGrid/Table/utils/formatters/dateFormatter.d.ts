import { ValueFormatterParams } from 'ag-grid-community';
declare const dateFormatter: (params: ValueFormatterParams) => string;
export default dateFormatter;
