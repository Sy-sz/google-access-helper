import { ColDef } from 'ag-grid-community';
export default function handleClassName(colDef: ColDef, key: string, mergedClass: string): void;
