import { ExcelExportParams } from 'ag-grid-community';
declare const handleDefaultExportParams: (params?: any) => ExcelExportParams;
export default handleDefaultExportParams;
