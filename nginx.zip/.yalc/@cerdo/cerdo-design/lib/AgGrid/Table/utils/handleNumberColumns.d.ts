import { ColumnDefs } from 'ag-grid-community';
export default function handleNumberColumns(columnDefs: ColumnDefs): void;
