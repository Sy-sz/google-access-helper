import { ColDef } from 'ag-grid-community';
declare function handleColumnValueGetter(colDef: ColDef): void;
export { handleColumnValueGetter };
