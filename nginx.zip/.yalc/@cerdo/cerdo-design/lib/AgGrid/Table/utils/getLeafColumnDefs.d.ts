import { ColDef, ColumnDefs } from 'ag-grid-community';
declare function getLeafColumnDefs(columnDefs: ColumnDefs): ColDef<any, any>[];
export { getLeafColumnDefs };
