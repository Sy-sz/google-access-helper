import type { GridReadyEvent, ColumnApi } from 'ag-grid-community';
import type { TableState } from 'ag-grid-react';
export interface SaveIndexDBParams {
    tableId: string;
    config: object;
}
declare function saveIndexDB(params: SaveIndexDBParams): Promise<void>;
declare function handleColumnEvent(params: GridReadyEvent, tableId: string, tableState?: TableState): any;
declare function setColumnState(columnApi: ColumnApi, tableId: string, tableState?: TableState, newColumnState?: any[]): Promise<void>;
export { handleColumnEvent, saveIndexDB, setColumnState };
