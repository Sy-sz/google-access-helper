declare class DataState {
    dictDataState: {};
    setDictDataState: (key: string, value: any) => void;
    getDictDataState: (key: string) => any;
}
declare const _default: DataState;
export default _default;
