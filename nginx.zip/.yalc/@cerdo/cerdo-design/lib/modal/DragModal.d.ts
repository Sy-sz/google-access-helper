import React, { Component } from 'react';
import { ModalProps } from 'antd';
interface IDragModalState {
    disabled: boolean;
    bounds: {
        [key: string]: number;
    };
}
export interface IDragModalProps extends ModalProps {
    title: string;
}
declare class DragModal extends Component<IDragModalProps, IDragModalState> {
    draggleRef: React.RefObject<HTMLDivElement>;
    constructor(props: any);
    onStart: (event: any, uiData: any) => void;
    render(): React.JSX.Element;
}
export default DragModal;
