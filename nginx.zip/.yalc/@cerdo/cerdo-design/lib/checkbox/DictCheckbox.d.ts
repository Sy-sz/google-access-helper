import React from 'react';
import { CheckboxOptionType } from 'antd';
import { CheckboxGroupProps } from 'antd/lib/checkbox/index';
export interface IDictSelectProps extends CheckboxGroupProps {
    defaultCheckedAll?: string[];
    dictid?: string;
    onLoad?: (data: any[]) => void;
}
export interface DataType {
    id?: string;
    name?: string;
}
export declare const useDictCheckbox: (props: IDictSelectProps) => {
    options: CheckboxOptionType[];
};
declare const DictSelect: React.FC<IDictSelectProps>;
export default DictSelect;
