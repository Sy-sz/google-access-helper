import React, { MouseEvent } from 'react';
import type { ProColumnType, ProTableProps, ActionType, RequestData } from '@ant-design/pro-table';
import type { SortOrder } from 'antd/es/table/interface';
declare const Summary: typeof import("rc-table/lib/Footer/Summary").default;
declare const Column: typeof import("antd/lib/table/Column").default, ColumnGroup: typeof import("antd/lib/table/ColumnGroup").default;
export interface IHTMLElement extends React.HTMLAttributes<HTMLElement> {
    width?: string | number;
    onResizeStart?: (e: MouseEvent<HTMLButtonElement>) => void;
    onResize?: Function;
    onResizeStop?: (e: MouseEvent<HTMLButtonElement>) => void;
}
export interface IProColumnType extends ProColumnType {
    onHeaderCell?: (data: any, index?: number) => IHTMLElement;
}
export type ICerdoTableProps = ProTableProps<any, any, any> & {
    downloadFile?: boolean;
    fetchDownload?: boolean;
    toolBarRender?: false | ((action: ActionType) => React.ReactNode[]);
    request?: (params: any, sort: Record<string, SortOrder>, filter: Record<string, React.ReactText[]>, isDownload: boolean) => Promise<Partial<RequestData<any>>>;
};
interface CerdoTableComponent extends React.ForwardRefExoticComponent<ICerdoTableProps & React.RefAttributes<HTMLElement>> {
    Column: typeof Column;
    ColumnGroup: typeof ColumnGroup;
    Summary: typeof Summary;
}
declare const CerdoTable: CerdoTableComponent;
export default CerdoTable;
