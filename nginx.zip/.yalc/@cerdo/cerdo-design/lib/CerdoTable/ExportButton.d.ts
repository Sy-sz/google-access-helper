import React from 'react';
import type { ProColumns, RequestData } from '@ant-design/pro-table';
import type { SortOrder } from 'antd/es/table/interface';
export interface IDownloadButtonProps {
    request?: ({ isDownload, params, sort, filter, }: {
        isDownload: boolean;
        params?: any;
        sort?: Record<string, SortOrder>;
        filter?: Record<string, React.ReactText[]>;
    }) => Promise<Partial<RequestData<any>>> | null;
    dataSource?: any[];
    columns?: ProColumns<any, any>[];
    fetchDownload?: boolean;
}
declare const ExportButton: React.FC<IDownloadButtonProps>;
export default ExportButton;
