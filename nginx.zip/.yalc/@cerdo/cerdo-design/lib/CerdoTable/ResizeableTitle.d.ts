import React, { MouseEvent } from 'react';
export interface IResizeableTitleProps {
    width?: string | number;
    onResizeStart?: (e: MouseEvent<HTMLButtonElement>) => void;
    onResize?: Function;
    onResizeStop?: (e: MouseEvent<HTMLButtonElement>) => void;
}
declare const ResizeableTitle: React.FC<IResizeableTitleProps>;
export default ResizeableTitle;
