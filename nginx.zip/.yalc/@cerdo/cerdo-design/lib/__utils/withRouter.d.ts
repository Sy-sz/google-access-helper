import React from 'react';
export declare function withRouter(Component: any): (props: any) => React.JSX.Element;
