import { ReactNode } from 'react';
import { IDictSelectPlusProps } from '../select/DictSelectPlus';
export declare const formatOptions: (options: any[], labelKey: IDictSelectPlusProps['labelKey'], isTree?: boolean) => any[];
export declare const getLabelByLabelKey: (option: any, labelKey: IDictSelectPlusProps['labelKey']) => ReactNode;
export declare const getLabelTextByLabelKey: (option: any, labelKey: IDictSelectPlusProps['labelKey']) => string;
export declare const getChooseOptions: (value: string | string[], options: any[]) => any[];
export declare const getSelectTag: (maxTagCount: number | string, chooseOptions: any[], readPretty?: boolean) => {
    readPrettyText: ReactNode;
    maxTagPlaceholder: ReactNode;
};
export declare const isStrIncludesValue: (str: string, value: string, regRule?: string) => boolean;
