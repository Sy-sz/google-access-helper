import React from 'react';
import { PopconfirmProps, ButtonProps } from 'antd';
export interface IConfirmButton extends Omit<PopconfirmProps, 'title'> {
    link?: boolean;
    actionText?: string;
    btnProps?: ButtonProps;
    [key: string]: any;
}
declare const ConfirmButton: React.FC<IConfirmButton>;
export default ConfirmButton;
