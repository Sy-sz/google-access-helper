import React from 'react';
import { ButtonProps } from 'antd';
export interface IDownloadButtonProps extends ButtonProps {
    onDownload?: () => void;
    url: string;
    getParams?: () => Promise<any>;
    filename?: string | ((name: string) => string);
    btnName?: string;
    formName?: string;
}
declare const DownloadButton: React.FC<IDownloadButtonProps>;
export default DownloadButton;
