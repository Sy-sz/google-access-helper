import React, { MouseEvent, MouseEventHandler } from 'react';
export interface IOperateButtonProps {
    type: string;
    onDelete?: (e?: MouseEvent<HTMLElement>) => void;
    onEdit?: MouseEventHandler<HTMLElement>;
    onAdjust?: MouseEventHandler<HTMLElement>;
    onSave?: MouseEventHandler<HTMLElement>;
    onCancel?: MouseEventHandler<HTMLElement>;
    onCopy?: MouseEventHandler<HTMLElement>;
    onDetail?: MouseEventHandler<HTMLElement>;
    otherRender?: (index: number) => any;
}
declare const OperateButton: React.FC<IOperateButtonProps>;
export default OperateButton;
