import React, { MouseEvent } from 'react';
import { ButtonProps } from 'antd';
export interface ISearchButtonProps extends Pick<ButtonProps, 'size'> {
    onReset?: (e: MouseEvent<HTMLButtonElement>) => void;
    searchLabel?: string;
}
declare const SearchButton: React.FC<ISearchButtonProps>;
export default SearchButton;
