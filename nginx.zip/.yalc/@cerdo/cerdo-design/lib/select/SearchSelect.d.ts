import type { IFetchSelectProps } from './FetchSelect';
import type { BaseSelectComponent } from './interface';
export interface ISearchSelectProps<T = any, R = any, ValueType = any, OptionType = any> extends IFetchSelectProps {
    onLoad?: (data: Array<any>) => void;
}
export interface ISearchSelectState {
    data?: any[];
}
declare const SearchSelect: BaseSelectComponent<ISearchSelectProps<any, any, any, any>>;
export default SearchSelect;
