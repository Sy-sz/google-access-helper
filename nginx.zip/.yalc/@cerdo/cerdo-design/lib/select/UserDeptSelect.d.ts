import React, { Component } from 'react';
import { EventDataNode } from 'rc-tree/lib/interface';
export interface IUserDeptSelectEventDataNode extends EventDataNode {
    [key: string | number]: any;
}
export interface IUserDeptSelectProps {
    title?: string;
    singleMode?: boolean;
    deptable?: boolean;
    userable?: boolean;
    positionable?: boolean;
    roleable?: boolean;
    visible: boolean;
    onSave: (...args: Array<number | string>[]) => any;
    onCancel: () => any;
    selectUserKeys?: any[];
    selectDeptKeys?: any[];
    selectPositionKeys?: any[];
    selectRoleKeys?: any[];
}
export interface IUserDeptSelectState<T = any[], U = Array<number | string>> {
    treeLoading?: boolean;
    deptTreeData?: T;
    deptExpandedKeys?: string[];
    roleTreeData?: T;
    roleExpandedKeys?: T;
    userLoading?: boolean;
    userData?: T;
    selectUsers?: T;
    selectUsersKey?: U;
    selectDepts?: T;
    selectDeptsKey?: U;
    selectPositions?: T;
    selectPositionsKey?: U;
    selectRoles?: T;
    selectRolesKey?: U;
}
declare class UserDeptSelect extends Component<IUserDeptSelectProps, IUserDeptSelectState> {
    static defaultProps: {
        title: string;
        singleMode: boolean;
        deptable: boolean;
        userable: boolean;
        positionable: boolean;
        roleable: boolean;
    };
    params: {
        userList: any[];
        allUserList: any[];
        allPositionList: any[];
        allDeptsList: any[];
        allRoleList: any[];
    };
    constructor(props: any);
    componentDidMount(): void;
    shouldComponentUpdate(nextProps: any): boolean;
    getSelectItemData: (key: string, nextProps: any) => any;
    getTreeData: () => Promise<void>;
    getDeptsData: () => Promise<void>;
    deptTreeToArray: (tree: any) => any[];
    getRolesData(): Promise<void>;
    roleTreeToArray: (tree: any) => any[];
    getUserData(): void;
    getUserDataByDeptId(id: any): void;
    getUserDataByRoleId(id: any): void;
    handleDeptSelect: (value: any, selected: any) => void;
    handleRoleSelect: (value: any, selected: any) => void;
    handleDeptCheck: (checkedKeys: any) => void;
    handleRoleCheck: (checkedKeys: any) => void;
    handleTagUserClose: (key: any) => void;
    handleTagPositionClose: (key: any) => void;
    handleTagDeptClose: (key: any) => void;
    handleTagRoleClose: (key: any) => void;
    handleUserChange: (e: any) => void;
    handleOkClick: () => void;
    handleCancelClick: () => void;
    getColumns: () => ({
        title: string;
        dataIndex: string;
        key: string;
        width: number;
        render(text: any, record: any): React.JSX.Element;
    } | {
        title: string;
        dataIndex: string;
        key: string;
        width?: undefined;
    })[];
    render(): React.JSX.Element;
}
export default UserDeptSelect;
