import React from 'react';
import type { SelectProps } from 'antd/es/select/index';
export interface IDictSelectPlusProps<T = any> extends SelectProps<T> {
    dictId?: string;
    queryParams?: Record<string, any>;
    isRemoteSearch?: boolean;
    debounceTimeout?: number;
    onDataLoad?: (data: any[]) => void;
    labelKey?: string | {
        left: string;
        right: string;
    };
    separator?: string;
    [key: string]: any;
}
export type valueType = string | string[] | undefined;
declare const DictSelectPlus: React.FC<IDictSelectPlusProps>;
export default DictSelectPlus;
