import type { SelectProps, SelectValue } from 'antd/es/select/index';
import type { BaseSelectComponent } from './interface';
export interface IDictSelectProps<ValueType = any, OptionType = any> extends Omit<SelectProps<SelectValue>, 'onChange'> {
    dictid?: string;
    onLoad?: (data: Array<any>) => void;
    onChange?: (value: ValueType, option: OptionType | OptionType[], data: ValueType) => void;
}
export interface IDictSelectState {
    data?: IDictSelectDataItem[];
}
export interface IDictSelectDataItem {
    id?: string;
    value?: string;
    name?: string;
    [key: string]: any;
}
declare const DictSelect: BaseSelectComponent<IDictSelectProps<any, any>>;
export default DictSelect;
