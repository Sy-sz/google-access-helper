import React, { Component } from 'react';
import { IFetchSelectProps } from './FetchSelect';
declare class UserSelect extends Component<Omit<IFetchSelectProps, 'getData'>> {
    render(): React.JSX.Element;
}
export default UserSelect;
