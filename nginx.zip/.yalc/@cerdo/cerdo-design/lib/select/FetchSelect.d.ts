import React from 'react';
import type { SelectProps } from 'antd/es/select/index';
import type { BaseSelectComponent } from './interface';
export interface IFetchSelectProps<T = any, R = any, ValueType = any, OptionType = any> extends Omit<SelectProps<T>, 'onChange'> {
    getData: (params: T) => Promise<any>;
    getParams?: (value: string) => void;
    firstInit?: boolean;
    defaultOptions?: any[];
    onDataLoad?: (data: any, id: number) => void;
    optionLabel?: (item: R) => React.ReactNode;
    optionTitle?: (item: R) => string;
    optionValue?: (item: R) => string | number | null;
    onChange?: (value: ValueType, option: OptionType | OptionType[], data: ValueType) => void;
}
export interface IFetchSelectState {
    data?: any[];
    loading?: boolean;
}
declare const FetchSelect: BaseSelectComponent<IFetchSelectProps<any, any, any, any>>;
export default FetchSelect;
