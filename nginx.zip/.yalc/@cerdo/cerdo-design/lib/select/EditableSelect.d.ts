import React from "react";
import type { SelectValue, SelectProps } from "antd/es/select/index";
export interface IEditableSelectProps<ValueType = any, OptionType = any> extends Omit<SelectProps<ValueType>, "onChange"> {
    defaultOptions?: Array<object>;
    optionLabel?: Function;
    optionValue?: Function;
    firstFetch?: boolean;
    optionTitle?: Function;
    initEdit?: boolean;
    text?: SelectValue;
    getData?: (params: object) => Promise<any>;
    getParams?: (value: string) => object;
    onChange?: (value: ValueType, option: OptionType | OptionType[], data: ValueType) => void;
}
interface IEditableSelectState {
    editing?: boolean;
    text?: SelectValue;
    optionList?: Array<object>;
    loading?: boolean;
}
declare class EditableSelect extends React.Component<IEditableSelectProps, IEditableSelectState> {
    constructor(props: IEditableSelectProps);
    componentDidMount(): void;
    search: (value?: string) => void;
    render(): React.JSX.Element;
}
export default EditableSelect;
