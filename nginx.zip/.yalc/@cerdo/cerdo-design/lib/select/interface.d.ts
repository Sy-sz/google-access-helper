import React from 'react';
import { Select } from 'antd';
export interface BaseSelectComponent<T = any> extends React.ForwardRefExoticComponent<T & React.RefAttributes<HTMLElement>> {
    Option: typeof Select.Option;
    OptGroup: typeof Select.OptGroup;
}
