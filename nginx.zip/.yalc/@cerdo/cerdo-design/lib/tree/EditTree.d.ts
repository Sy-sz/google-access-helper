/// <reference types="lodash" />
import React, { Component } from 'react';
import type { TreeProps } from 'antd/es/tree';
interface IEditTreeProps<ValueType = any, OptionType = any> extends TreeProps {
    loading: boolean;
    gData: any[];
    draggable?: boolean;
    rootid?: string;
    showSearch?: boolean;
    allowEdit?: boolean;
    onItemAdd?: (item: object) => any;
    onItemEdit?: (item: object) => any;
    onItemDelete?: (item: object) => any;
    onItemDrop?: (item: object) => any;
    expandedKeys?: string[];
}
interface IEditTreeState {
    expandedKeys?: string[];
    searchValue?: string;
    autoExpandParent?: boolean;
    treeData: any[];
}
declare class EditTree extends Component<IEditTreeProps, IEditTreeState> {
    static defaultProps: {
        draggable: boolean;
        showSearch: boolean;
        allowEdit: boolean;
        rootid: any;
        onItemAdd: any;
        onItemEdit: any;
        onItemDelete: any;
        onItemDrop: any;
        expandedKeys: any[];
    };
    dataList: any[];
    constructor(props: any);
    shouldComponentUpdate(nextProps: any): boolean;
    getDataList: (data: any) => void;
    reload: (data: any[]) => void;
    onDrop: (info: any) => void;
    onChange: ({ target: { value } }: {
        target: {
            value: any;
        };
    }) => void;
    OnDebounceChange: import("lodash").DebouncedFunc<({ target: { value } }: {
        target: {
            value: any;
        };
    }) => void>;
    getParentKey: (key: any, tree: any) => any;
    onAdd: (item: any) => void;
    onAddOneClass: () => void;
    onEdit: (item: any) => void;
    arrDeleteObj: (arr: any, obj: any) => void;
    arrOtherInput: (arr: any, id: any) => void;
    onItemSubmit: (item: any) => void;
    loop: (data: any) => any;
    getTitle: (item: any) => React.JSX.Element;
    onExpand: (expandedKeys: any) => void;
    render(): React.JSX.Element;
}
export default EditTree;
