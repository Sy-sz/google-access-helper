import React from 'react';
import type { TreeSelectProps } from 'antd/lib/tree-select';
import type { DataNode } from 'rc-tree-select/lib/interface';
export interface DictTreeSelectProps<T = any> extends TreeSelectProps<T> {
    dictId?: string;
}
export declare const formatTreeData: (treeData: any[]) => DataNode[];
declare const DictTreeSelect: React.FC<DictTreeSelectProps>;
export default DictTreeSelect;
