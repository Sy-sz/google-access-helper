import React from 'react';
import type { TreeSelectProps } from 'antd/es/tree-select';
import BaseOptionType from 'rc-tree-select/lib/TreeSelect';
type IDeptTreeSelectProps<ValueType = any> = TreeSelectProps<ValueType> & {
    children?: BaseOptionType[] | Function;
};
declare const SHOW_ALL: "SHOW_ALL", SHOW_PARENT: "SHOW_PARENT";
interface DeptTreeSelectComponent extends React.ForwardRefExoticComponent<IDeptTreeSelectProps & React.RefAttributes<HTMLElement>> {
    SHOW_ALL: typeof SHOW_ALL;
    SHOW_PARENT: typeof SHOW_PARENT;
}
declare const DeptTreeSelect: DeptTreeSelectComponent;
export default DeptTreeSelect;
