import { Field } from '@formily/core';
declare const defaultScope: {
    formilyGet: ({ api, data }: {
        api: any;
        data: any;
    }) => Promise<import("@cerdo/cerdo-utils/lib/upmHttp").ResponseDataType<any>>;
    formilyPost: ({ api, data }: {
        api: any;
        data: any;
    }) => Promise<import("@cerdo/cerdo-utils/lib/upmHttp").ResponseDataType<any>>;
    formilyDownload: ({ api, data }: {
        api: any;
        data: any;
    }) => Promise<boolean | import("@cerdo/cerdo-utils/lib/upmHttp").ResponseDataType<any>>;
    useDataSource: (service: any, params: any) => (field: any) => void;
    getUploadValues: (field: Field, file: {
        [key: string]: any;
        fileid?: string;
        fileId?: string;
        status: string;
    }) => any;
    iconFeedBack: (field: Field) => void;
};
export default defaultScope;
