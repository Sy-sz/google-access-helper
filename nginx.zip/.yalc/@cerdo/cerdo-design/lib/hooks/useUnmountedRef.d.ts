declare const useUnmountedRef: () => import('react').MutableRefObject<boolean>;
export default useUnmountedRef;
