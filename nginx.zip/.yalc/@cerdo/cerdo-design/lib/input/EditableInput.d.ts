import React from 'react';
import type { InputProps } from 'antd';
interface IEditableInputProps extends Omit<InputProps, 'onChange'> {
    disabled: boolean;
    type?: 'number' | 'integer';
    onChange?: (text: string) => {};
}
declare const EditableInput: React.FC<IEditableInputProps>;
export default EditableInput;
