import React from 'react';
import type { InputNumberProps } from 'antd';
interface IAutoNumberProps extends InputNumberProps {
    type?: 'amount' | 'percent';
}
declare const AutoNumber: React.FC<IAutoNumberProps>;
export default AutoNumber;
