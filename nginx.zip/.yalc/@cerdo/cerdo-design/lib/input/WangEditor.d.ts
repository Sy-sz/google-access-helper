import React, { Component } from 'react';
import { ConfigType } from 'wangeditor/dist/config';
interface IWangEditorProps extends ConfigType {
    id: string;
    value: string;
    uploadImgShowBase64: boolean;
    showFullScreen: boolean;
    width: string | number;
    onChange: (html: string) => void;
    disabled: boolean;
    autoFocus: boolean;
}
declare class WangEditor extends Component<IWangEditorProps> {
    private changeHtml;
    private editor;
    private timer;
    componentDidMount(): void;
    initEditor: () => void;
    customerAlert: () => void;
    customUpload: () => void;
    render(): React.JSX.Element;
}
export default WangEditor;
