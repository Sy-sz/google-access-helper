import React from 'react';
export interface IErrorBoundaryState {
    hasError: boolean;
}
declare class ErrorBoundary extends React.Component<React.PropsWithChildren<any>, IErrorBoundaryState> {
    static getDerivedStateFromError(): {
        hasError: boolean;
    };
    constructor(props: any);
    componentDidCatch(error: any, info: any): void;
    render(): React.ReactNode;
}
export default ErrorBoundary;
