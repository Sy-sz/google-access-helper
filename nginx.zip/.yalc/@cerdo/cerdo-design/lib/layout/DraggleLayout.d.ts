import React from 'react';
export interface IDraggleLayoutProps {
    left?: number | string;
    right?: number | string;
    top?: number | string;
    bottom?: number | string;
    style?: React.CSSProperties;
    leftStyle?: React.CSSProperties;
    rightStyle?: React.CSSProperties;
    topStyle?: React.CSSProperties;
    bottomStyle?: React.CSSProperties;
    onDrag?: () => void;
}
declare const DraggleLayout: React.FC<IDraggleLayoutProps>;
export default DraggleLayout;
