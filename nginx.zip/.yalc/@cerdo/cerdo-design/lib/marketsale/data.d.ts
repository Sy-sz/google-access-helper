export declare const formatColumns: ({ data, handleTop }: {
    data: any;
    handleTop: any;
}) => any;
