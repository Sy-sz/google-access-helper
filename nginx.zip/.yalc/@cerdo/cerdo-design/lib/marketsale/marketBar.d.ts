import React from 'react';
interface Props {
    data: Record<string, any>;
}
declare const _default: React.NamedExoticComponent<Props>;
export default _default;
