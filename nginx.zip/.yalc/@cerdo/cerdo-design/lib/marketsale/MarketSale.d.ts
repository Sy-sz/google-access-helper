import React from 'react';
declare const MarketSale: React.FC;
export default MarketSale;
