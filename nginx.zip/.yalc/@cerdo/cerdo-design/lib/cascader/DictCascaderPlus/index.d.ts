import React from 'react';
import type { CascaderProps, CascaderOptionType } from 'antd/lib/cascader';
export interface IDictCascaderPlusProps extends Omit<CascaderProps, 'options'> {
    dictId?: string;
    labelKey?: string;
    options?: CascaderOptionType[];
    onDataLoad?: (data: any[]) => void;
}
export declare const useDictCascaderPlus: (props: IDictCascaderPlusProps) => {
    options: any[];
    loading: boolean;
};
declare const DictCascaderPlus: React.FC<IDictCascaderPlusProps>;
export default DictCascaderPlus;
