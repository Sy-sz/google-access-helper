import React from 'react';
import type { CascaderProps, CascaderOptionType } from 'antd/lib/cascader';
export interface IDictCascaderProps extends Omit<CascaderProps, 'options'> {
    dictid?: string;
    options?: CascaderOptionType[];
}
declare const DictCascader: React.FC<IDictCascaderProps>;
export default DictCascader;
