import React from 'react';
import { formComponentMap as TableComponent } from './components/SearchForm';
import { ISearchAgGridTable, ISize, IMethod, renderType } from './type';
import useRenderColumnDict, { renderTypeEnum as TableRenderType } from './components/useRenderColumnDict';
export * from './type';
declare const SearchAgGridTable: React.FC<ISearchAgGridTable>;
export default SearchAgGridTable;
export { TableComponent, TableRenderType, useRenderColumnDict };
export declare const TableSize: {
    small: ISize;
    middle: ISize;
    large: ISize;
};
export declare const TableMethod: {
    get: IMethod;
    post: IMethod;
};
export declare const formatDictArr: (dictArr?: any[]) => any[];
export declare const getRenderNodeByValue: ({ value, options, renderType, separator, }: {
    value: string | any[];
    options: any[];
    renderType: renderType;
    separator?: string;
}) => string | React.JSX.Element;
