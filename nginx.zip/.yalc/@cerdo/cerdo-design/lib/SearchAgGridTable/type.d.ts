import React from 'react';
import { FormProps } from 'antd/lib/form/Form';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { ColProps } from 'antd/lib/col';
import { FormItemProps } from 'antd/lib/form';
import { TableProps } from '../AgGrid/Table';
import { TableConfig } from 'ag-grid-react';
interface SearchResponseType<T = any> {
    dataList: T[];
    total: number;
}
export interface ISearchAgGridTable extends Omit<SearchTableConfig, 'tableConfig'> {
    searchFormConfig?: SearchFormConfig;
    tableConfig?: ITableConfig;
    searchOnReady?: boolean;
    resetAutoQuery?: boolean;
    [key: string]: any;
}
export type renderType = 'tag' | 'text' | 'badge';
export interface ITableConfig extends Omit<TableConfig, 'columnDefs'> {
    columnDefs?: IColumnDefs;
}
export type IColumnDefs = ((ColDef | ColGroupDef) & ISearchFormItemNode & {
    hideInSearch?: boolean;
    hideInTable?: boolean;
    valueEnum?: {
        dictLabel: string;
        dictValue: string;
    }[];
    dictId?: string;
    renderType?: renderType;
    separator?: string;
    children?: IColumnDefs;
})[];
export type ISize = 'tiny' | 'small' | 'middle' | 'large';
export type IMethod = 'get' | 'post';
export interface SearchTableConfig extends TableProps {
    size?: ISize;
    url?: string;
    method?: IMethod;
    actionBtns?: any[];
    onFormatRowData?: (rowData: any[]) => any[];
    onFormatParams?: (params: any) => any;
    onFormatResponse?: (response: any) => SearchResponseType;
    onLoadData?: (rowData: any[], total: number) => void;
    [key: string]: any;
}
export interface ISearchConfig {
    form: any;
    loading: boolean;
    onSearch: (params?: any) => void;
    onReset: () => void;
}
export interface SearchFormConfig {
    formProps?: FormProps;
    initialValues?: any;
    searchNodeList?: ISearchFormItemNode[];
    defaultCollapsed?: boolean;
    searchColNum?: 4 | 6;
    optionRender?: (searchConfig: ISearchConfig, btnArr: React.ReactNode[]) => React.ReactNode[];
    [key: string]: any;
}
export interface ISearchFormItemNode {
    colProps?: ColProps;
    formItemProps?: FormItemProps;
    component?: React.ReactNode | string;
    componentProps?: any;
    transform?: (value: any) => any;
}
export {};
