import React from 'react';
import { renderType } from '../type';
export interface IRenderColumnDict {
    value?: any;
    dictId?: string;
    type?: renderType;
    previewTextPlaceholder?: any;
    separator?: string;
    [key: string]: any;
}
declare const useRenderColumnDict: (props: IRenderColumnDict) => React.ReactNode;
export default useRenderColumnDict;
export declare const renderTypeEnum: {
    text: renderType;
    badge: renderType;
    tag: renderType;
};
