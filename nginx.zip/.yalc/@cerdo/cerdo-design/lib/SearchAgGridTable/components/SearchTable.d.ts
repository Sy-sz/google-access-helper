import React from 'react';
import { SearchTableConfig } from '../type';
declare const SearchTable: React.FC<SearchTableConfig>;
export default SearchTable;
