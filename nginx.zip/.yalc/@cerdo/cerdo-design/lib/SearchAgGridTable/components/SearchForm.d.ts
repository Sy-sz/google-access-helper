import React, { ReactNode } from 'react';
import { SearchFormConfig } from '../type';
export declare const formComponentMap: {
    [key: string]: ReactNode;
};
declare const SearchForm: React.FC<SearchFormConfig>;
export default SearchForm;
