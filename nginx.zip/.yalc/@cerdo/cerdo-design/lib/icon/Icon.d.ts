import React from 'react';
interface IIConFontProps {
    type: string;
    className?: string;
    style?: React.CSSProperties;
    onClick?: () => void;
}
declare const Icon: React.FC<IIConFontProps>;
export default Icon;
