import type { ModalStaticFunctions } from 'antd/es/modal/confirm';
import type { MessageInstance } from 'antd/lib/message/interface';
import type { NotificationInstance } from 'antd/lib/notification/interface';
interface AntdInstance {
    message: MessageInstance;
    notification: NotificationInstance;
    modal: Omit<ModalStaticFunctions, 'warn'>;
}
export declare const setAntdInstance: (instance: any) => void;
export declare const getAntdInstance: () => AntdInstance;
declare const AntdInstanceInitializer: () => any;
export default AntdInstanceInitializer;
