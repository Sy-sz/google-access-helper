const MonacoWebpackPlugin = require('monaco-editor-webpack-plugin');
const npmScope = '@cerdo'; // 私有npm依赖的scope

const config = {
  systemConfig: {
    devServerPort: 8885, // dev server 端口
    isMain: false,
    npmScope,
  },
  layoutConfig: {
    MARKETSALE: true,
  },
  apiConfig: {
    domain: {
      '/cerdo/upm-api': 'https://apptest.fsfund.com/cerdo/upm-api',
      '/cerdo/oss-api': 'https://apptest.fsfund.com/cerdo/oss-api',
      '/apps/cerdo/ups-api': 'https://apptest.fsfund.com/apps/cerdo/ups-api',

      '/cerdo/bpm-purus-api': 'https://apptest.fsfund.com/cerdo/bpm-purus-api',
      '/fscy/pdt-api': 'https://apptest.fsfund.com/fscy/pdt-api',

      // 李红坤
      // '/cerdo/bpm-purus-api': 'http://172.30.112.98:8882/cerdo/bpm-purus-api',
      // '/fscy/pdt-api': 'http://172.30.112.98:9300/fscy/pdt-api',

      // 郑超琪
      // '/cerdo/bpm-purus-api': 'http://172.30.112.80:8882/cerdo/bpm-purus-api',
      // '/fscy/pdt-api': 'http://172.30.112.80:9300/fscy/pdt-api',

      // 何耀东
      // '/cerdo/bpm-purus-api': 'http://172.30.112.175:8882/cerdo/bpm-purus-api',
      // '/fscy/pdt-api': 'http://172.30.112.175:9300/fscy/pdt-api',

      // '/fscy/pdt-api': 'http://localhost:9300/fscy/pdt-api',
    },
  },
  definePlugin: {
    APP_ID: JSON.stringify('fscy-pdt-backend'), // 应用ID
    APP_SECRET: JSON.stringify('ece76fe87e8845359eb7f4bb28294d9a'),
    PROJECT_NAME: JSON.stringify('华宝基金'), // 应用名称
    // HISTORY_PUBLIC_PATH: JSON.stringify(isDev ? '/fscy/pdt-web/' : '/fscy/pdt-web-preprod/'),
    HISTORY_PUBLIC_PATH: JSON.stringify('/fscy/pdt-web/'),
    DEFAULT_THEME: JSON.stringify('light'),
    // PUBLIC_PATH: JSON.stringify(isDev ? '/fscy/pdt-web/' : '/fscy/pdt-web-preprod/'),
    PUBLIC_PATH: JSON.stringify('/fscy/pdt-web/'),
    IS_EVENT_REPORT: true,
  },
  webpackConfig: {
    chainWebpack: (config) => {
      config.plugins.push(new MonacoWebpackPlugin());
    },
    resolveAlias: {
      'cerdo-utils': `${npmScope}/cerdo-utils`,
      'cerdo-design': `${npmScope}/cerdo-design`,
      'cerdo-scripts': `${npmScope}/cerdo-scripts`,
      'formily-antd': `@chinahorm/web-components/node_modules/@formily/antd`,
      crypto: false,
    },
  },
};

module.exports = config;
