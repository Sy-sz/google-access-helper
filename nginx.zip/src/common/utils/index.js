/**
 * 获取baseUrl
 * @param {string} sys 系统标识
 */
const apiConfig = {
  hr: '/fsyy/imp-hr-api',
  fin: '/fsyy/imp-fin-api',
  oa: '/fsyy/imp-oa-api',
  bpm: '/cerdo/bpm-purus-api',
  oss: '/cerdo/oss-api',
  upm: '/cerdo/upm-api',
  ups: '/apps/cerdo/ups-api',
  pdt: '/fscy/pdt-api',
};
export const getBaseUrl = (sys) => {
  return apiConfig[sys] || '';
};

export const hrBaseApi = getBaseUrl('hr');
export const finBaseApi = getBaseUrl('fin');
export const oaBaseApi = getBaseUrl('oa');
export const impBaseApi = getBaseUrl('bpm');
export const ossBaseApi = getBaseUrl('oss');
export const upmBaseApi = getBaseUrl('upm');
export const pdtBaseApi = getBaseUrl('pdt');
export const upsBaseApi = getBaseUrl('ups');
