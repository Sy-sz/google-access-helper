import * as config from './config';
import { upmHttp, array } from '@cerdo/cerdo-utils';

const { get, post, download } = upmHttp;

export function dictList(params) {
  return get({ url: config.dictList, data: params });
}

export function agencyList(params) {
  return get({ url: config.agencyList, data: params });
}

export function managerList(params) {
  return get({ url: config.managerList, data: params });
}

export function userList(params) {
  return new Promise((resolve, reject) => {
    get({ url: config.userList, data: params })
      .then((res) => {
        if (res && res.data && res.data.length > 0) {
          array.handleUserTree(res.data);
        }
        resolve(res);
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function userDetail(params) {
  return get({ url: config.userDetail, data: params });
}

export function fundList(params) {
  return get({ url: config.fundList, data: params });
}

export function fundFullList(params) {
  return get({ url: config.fundFullList, data: params });
}

export function shareList(params) {
  return get({ url: config.shareList, data: params });
}

export function bpmShareList(params) {
  return get({ url: config.bpmShareList, data: params });
}

export function initAgencyUpload(params) {
  return get({ url: config.initAgencyUpload, data: params });
}
export function periodList(params) {
  return get({ url: config.periodList, data: params });
}
export function genAgencyNotice(params) {
  return post({ url: config.genAgencyNotice, data: params });
}

export function pubAgencyNotice(params) {
  return get({ url: config.pubAgencyNotice, data: params });
}

export function pubNotice(params) {
  return get({ url: config.pubNotice, data: params });
}

export function dividendDate(params) {
  return get({ url: config.dividendDate, data: params });
}

export function subRedProjectUpload(params) {
  return post({ url: config.subRedProjectUpload, data: params });
}

export function subredapplyProjectUpload(params) {
  return post({ url: config.subredapplyProjectUpload, data: params });
}

export function subRedProjectRelease(params) {
  return get({ url: config.subRedProjectRelease, data: params });
}

export function sharebonusList(params) {
  return get({ url: config.sharebonusList, data: params });
}

export function dividendNotice(params) {
  return get({ url: config.dividendNotice, data: params });
}

export function dividendFundday(params) {
  return get({ url: config.dividendFundday, data: params });
}

export function dividendcount(params) {
  return get({ url: config.dividendcount, data: params });
}

export function dividendDates(params) {
  return get({ url: config.dividendDates, data: params });
}

export function fundDataList(params) {
  return get({ url: config.fundDataList, data: params });
}

export function fundEtfList(params) {
  return get({ url: config.fundEtfList, data: params });
}

export function agencyInformationNotice(params) {
  return get({ url: config.agencyInformationNotice, data: params });
}

export function agencyListedNotice(params) {
  return get({ url: config.agencyListedNotice, data: params });
}

export function changeImportFile(params) {
  return post({ url: config.changeImportFile, data: params.data });
}
export function dividendPurchase(params) {
  return get({ url: config.dividendPurchase, data: params });
}

export function listFuturesAccount(params) {
  return get({ url: config.listFuturesAccount, data: params });
}

export function dividendSignPeople(params) {
  return get({ url: config.dividendSignPeople, data: params });
}

export function listFuturesCompany(params) {
  return get({ url: config.listFuturesCompany, data: params });
}

export function getWorkDay(params) {
  return get({ url: config.getWorkDayApi, data: params });
}

export function getWorkDate(params) {
  return get({ url: config.getWorkDateApi, data: params });
}

export function agencyRelease(params) {
  return get({ url: config.agencyRelease, data: params });
}

export function importAgency(params) {
  return post({ url: config.importAgency, data: params.data });
}

export function generateAgencyList(params) {
  const request = params.type === 1 ? download : post;
  return request({ url: config.generateAgencyList, data: params, method: 'post' });
}

export function getFundFee(params) {
  return get({ url: config.getFundFeeApi, data: params });
}

export function seatapplydoc(params) {
  return get({ url: config.seatapplydocApi, data: params });
}
