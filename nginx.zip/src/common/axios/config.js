import { pdtBaseApi, upmBaseApi, impBaseApi, ossBaseApi } from 'common/utils';
export { config as commonUrl } from '@cerdo/cerdo-utils';

export const ossBaseFileApi = `${ossBaseApi}/oss/file/v1/upload`; // oss文件上传
export const ossBaseFileInfoListApi = `${pdtBaseApi}/file/queryOssFileInfoList`; // oss文件列表查询
export const uploadFileApi = `${pdtBaseApi}/file/upload`; // 上传附件统一接口api
export const downloadFileApi = `${pdtBaseApi}/file/download`; // 下载附件统一接口api
export const downloadBatchFileApi = `${pdtBaseApi}/file/download/batch`; // 下载附件统一接口api

export const getUserApi = `${pdtBaseApi}/orgsystem/user/list`;
export const getWorkDayApi = `${pdtBaseApi}/common/getworkday`;
export const getWorkDateApi = `${pdtBaseApi}/common/getworkdate`;
export const getdesigndateApi = `${pdtBaseApi}/common/getdesigndate`;
export const getConfigListApi = `${pdtBaseApi}/common/configlist`;
export const getAllFundsApi = `${pdtBaseApi}/common/allfunds`;
export const getMarketSaleApi = `${pdtBaseApi}/fundinfo/marketsale`;
export const fuzzysearchApi = `${pdtBaseApi}/fundinfo/fuzzysearch`; // 基金模糊查询
export const listFundShareApi = `${pdtBaseApi}/fundinfo/sharelist`; // 基金份额
export const getStatisticsApi = `${pdtBaseApi}/fundinfo/statistics`; // 基金数据统计

// 公募产品 --------------------------------------------------------------------------start
export const listFundInfoApi = `${pdtBaseApi}/fundinfo/list`; // 列表
export const detailFundInfoApi = `${pdtBaseApi}/fundinfo/detail`; // 详情
export const saveFundInfoApi = `${pdtBaseApi}/fundinfo/save`; // 保存
export const removeFundInfoApi = `${pdtBaseApi}/fundinfo/remove`; // 删除
export const syncFundContractApi = `${pdtBaseApi}/fundinfo/syncdata`; // 同步
export const saveLiquidationApi = `${pdtBaseApi}/fundinfo/liquidation/save`; // 保存清算参数

export const listOpenRecordApi = `${pdtBaseApi}/openrecord/list`; // 开放记录列表
export const saveOpenRecordApi = `${pdtBaseApi}/openrecord/save`; // 开放记录保存

export const listEditRecordApi = `${pdtBaseApi}/adjust/list`; // 修改记录

export const listGuideTreeApi = `${pdtBaseApi}/guidetree/list`; // 产品编辑向导
export const detailGuideTreeApi = `${pdtBaseApi}/guidetree/detail`;

export const listFundAccountApi = `${pdtBaseApi}/fundacc/list`; // 基金交易账户信息
export const saveFundAccountApi = `${pdtBaseApi}/fundacc/save`;
export const removeFundAccountApi = `${pdtBaseApi}/fundacc/remove`;
// 公募产品 --------------------------------------------------------------------------end

// 专户产品 --------------------------------------------------------------------------start
export const listSpecialFundInfoApi = `${pdtBaseApi}/specialfundinfo/list`;
export const listshareApi = `${pdtBaseApi}/specialfundinfo/listshare`;
export const detailSpecialFundInfoApi = `${pdtBaseApi}/specialfundinfo/detail`;
export const saveSpecialFundInfoApi = `${pdtBaseApi}/specialfundinfo/save`;
export const specialfundeventListApi = `${pdtBaseApi}/specialfundevent/eventlist`;
export const detailSpecialfundeventListApi = `${pdtBaseApi}/specialfundevent/detail`; // 产品专户开放日详情页
export const saveSpecialfundeventListApi = `${pdtBaseApi}/specialfundevent/savevent`; // 产品专户开放日保存配置信息
export const setSpecialfundeventCronlistApi = `${pdtBaseApi}/specialfundevent/cronlist`; // 产品专户开放日设置时间的列表
export const createSpecialfundeventtApi = `${pdtBaseApi}/specialfundevent/generatecron`; // 产品专户开放日生成时间的规则命名
export const listAllocationFundeventtApi = `${pdtBaseApi}/specialfundevent/mappinglist`; // 产品专户开放日配置列表
export const detailEventListApi = `${pdtBaseApi}/specialfundevent/eventdetail`; // 产品专户开放日配置表单详情
export const saveSpecialresultsListApi = `${pdtBaseApi}/specialfundevent/achivessave`; // 产品专户业绩保存配置信息
export const listAchieveFundeventtApi = `${pdtBaseApi}/specialfundevent/achievemappinglist`; // 产品业绩配置信息列表页面
export const listResultMessageFundeventtApi = `${pdtBaseApi}/specialfundevent/achieveventlist`; // 产品业绩信息列表页
export const saveachieveFundeventtApi = `${pdtBaseApi}/specialfundevent/achievemappingsave`; // 产品业绩信息列表页编辑保存
export const exportSpecialfundeventApi = `${pdtBaseApi}/specialfundevent/exportevent`; // 专户开放日列表导出
export const generateSpecialfundeventApi = `${pdtBaseApi}/specialfundevent/generateann`; // 专户开放日生成公告
export const exportSpecialResultsApi = `${pdtBaseApi}/specialfundevent/exportachieve`; // 专户业绩开放日信息列表导出
export const exportTASpecialfundeventApi = `${pdtBaseApi}/specialfundevent/taexportevent`; // 专户开放日列表导出TA文件

export const specialfundinfoxbrlApi = `${pdtBaseApi}/specialfundinfoxbrl/list`; // 专户投资策略列表
export const initSpecialfundinfoxbrlApi = `${pdtBaseApi}/specialfundinfoxbrl/init`; // 专户投资策略开始新一期
export const detailSpecialfundinfoxbrlApi = `${pdtBaseApi}/specialfundinfoxbrl/detail`; // 专户投资策略详情
export const saveSpecialfundinfoxbrlApi = `${pdtBaseApi}/specialfundinfoxbrl/save`; // 专户投资策略保存
export const exportSpecialfundinfoxbrlApi = `${pdtBaseApi}/specialfundinfoxbrl/export`; // 专户投资策略导出

// 专户产品 --------------------------------------------------------------------------end

// 信息维护 --------------------------------------------------------------------------start
export const listAgencyApi = `${pdtBaseApi}/organinfo/queryorganlist`; // 机构信息
export const detailAgencyApi = `${pdtBaseApi}/organinfo/queryorganbyid`;
export const delAgencyApi = `${pdtBaseApi}/organinfo/deleteorgan`;
export const saveAgencyApi = `${pdtBaseApi}/organinfo/saveorgan`;
export const exportAgencyApi = `${pdtBaseApi}/organinfo/exportorganfundsbyid`;
export const listFundListByIdApi = `${pdtBaseApi}/organinfo/queryorganfundsbyid`;
export const removeAgencyMappingApi = `${pdtBaseApi}/organinfo/removeorgfundmapping`;
export const saveAgencyMappingApi = `${pdtBaseApi}/organinfo/addorgfundmapping`;

export const listAgencyFundsApi = `${pdtBaseApi}/organinfo/searchfundorganlist`;
export const fundInfoShareListApi = `${pdtBaseApi}/fundinfo/bpm/sharelist`;
export const bpmFundlistApi = `${pdtBaseApi}/fundinfo/bpm/fundlist`;
export const exportAgencyFundsApi = `${pdtBaseApi}/organinfo/exportfundorganlist`;
export const importAgencyFundsApi = `${pdtBaseApi}/organinfo/initorgan`;
export const saveAgencyFundsApi = `${pdtBaseApi}/organinfo/savefundorganmap`;

export const listManagementApi = `${pdtBaseApi}/management/list`; // 管理人员信息
export const detailManagementApi = `${pdtBaseApi}/management/detail`;
export const saveManagementApi = `${pdtBaseApi}/management/save`;
export const removeManagementApi = `${pdtBaseApi}/management/remove`;
export const listManagementDayApi = `${pdtBaseApi}/management/his/list`;
export const getManagementDayApi = `${pdtBaseApi}/management/his/detail`;
export const saveManagementDayApi = `${pdtBaseApi}/management/his/save`;
export const removeManagementDayApi = `${pdtBaseApi}/management/his/remove`;

export const listManagerApi = `${pdtBaseApi}/fundmanager/queryfundmanagerlist`; // 基金经理 投资经理
export const exportfundinfobyfundmanagerApi = `${pdtBaseApi}/fundmanager/exportfundinfobyfundmanagerid`; // 所管理基金导出
export const importnewfundinfobyfundmanageridApi = `${pdtBaseApi}/fundmanager/importnewfundinfobyfundmanagerid`; // 所管理基金导入并回显
export const addmappinglistApi = `${pdtBaseApi}/fundmanager/addmappinglist`; // 所管理基金最终确认导入
export const detailManagerApi = `${pdtBaseApi}/fundmanager/queryfundmanagerbyid`;
export const delManagerApi = `${pdtBaseApi}/fundmanager/deletefundmanager`;
export const saveManagerApi = `${pdtBaseApi}/fundmanager/save`;
export const queryFundListByFundManagerIdApi = `${pdtBaseApi}/fundmanager/queryfundinfobyfundmanagerid`;
export const annoQueryfundinfobyfundmanageridApi = `${pdtBaseApi}/fundmanager/anno/queryfundinfobyfundmanagerid`;
export const removeManagerMappingApi = `${pdtBaseApi}/fundmanager/removefundmanagermapping`;
export const saveManagerMappingApi = `${pdtBaseApi}/fundmanager/addfundmanagermapping`;
export const syncFundManagerApi = `${pdtBaseApi}/fundmanager/syncfundmanager`;
export const queryFundManagerByFundIdApi = `${pdtBaseApi}/fundmanager/querybyfundid`;
export const saveFundMappingByXmlApi = `${pdtBaseApi}/fundmanager/savefundmappingbyxml`;
export const exportManagerApi = `${pdtBaseApi}/fundmanager/exportfundmanagerlist`;
export const queryManagerAmountApi = `${pdtBaseApi}/fundmanager/onmanageramount`;
export const managersysprvlgreclistApi = `${pdtBaseApi}/fundmanager/managersysprvlgreclist`;

export const listFundInfoXbrlApi = `${pdtBaseApi}/fundinfoxbrl/list`; // 通过基金经理 生成xml文件
export const initFundInfoXbrlApi = `${pdtBaseApi}/fundinfoxbrl/init`;
export const detailFundInfoXbrlApi = `${pdtBaseApi}/fundinfoxbrl/detail`;
export const saveFundInfoXbrlApi = `${pdtBaseApi}/fundinfoxbrl/save`;
export const exportFundInfotXbrlApi = `${pdtBaseApi}/fundinfoxbrl/export`;
export const saveFundInfoXbrlAgencyApi = `${pdtBaseApi}/fundinfoxbrl/saveagency`;

export const listEtfApi = `${pdtBaseApi}/fundinfo/etflist`; // EFT申赎变更
export const listEtfUnitApi = `${pdtBaseApi}/fundinfo/etfunit`;

export const listFundManagerChangeApi = `${pdtBaseApi}/sysapply/list`; // 基金信息变更维护列表
export const doFundApplyApi = `${pdtBaseApi}/sysapply/dosubmit`; // 基金信息变更维护申请

export const listMiniFundApi = `${pdtBaseApi}/minifund/report/list`; // 迷你基金列表
export const detailMiniFundApi = `${pdtBaseApi}/minifund/report/detail`; // 迷你基金列表
export const downloadMiniFundFileApi = `${pdtBaseApi}/minifund/report/download`; // 迷你下载文件
export const saveEmailConfigApi = `${pdtBaseApi}/minifund/emailconfig/save`; // 迷你基金发送邮件配置保存
export const detailEamilConfigApi = `${pdtBaseApi}/minifund/emailconfig/detail`; // 迷你基金发送邮件配置详情
export const saveIspubweekApi = `${pdtBaseApi}/minifund/ispubweek/save`; // 迷你基金保存本周内是否发布迷你性提示公告接口
export const saveRemarkApi = `${pdtBaseApi}/minifund/remark/save`; // 迷你基金保存备注接口
export const detailLiquidationApi = `${pdtBaseApi}/minifund/fund/detail`; // 迷你基金合同中约定自动清盘详情
export const updateListApi = `${pdtBaseApi}/minifund/dailydata/update`; // 迷你基金合同更新
export const downloadMiniFundDocApi = `${pdtBaseApi}/minifund/generate/doc`; // 迷你基金合同更新

export const listFuturesWhiteApi = `${pdtBaseApi}/futures/mappinglist`; // 期货白名单
export const saveFuturesWhiteApi = `${pdtBaseApi}/futures/savemapping`; // 期货白名单保存

export const listSpecialSeatsApi = `${pdtBaseApi}/specialfundinfo/seatlist`; // 专户席位信息列表
export const detailSpecialSeatsApi = `${pdtBaseApi}/specialfundinfo/seatdetail`; // 专户席位信息设置
export const saveSpecialSeatsApi = `${pdtBaseApi}/specialfundinfo/seatsave`; // 专户席位信息保存
export const listSpecialSeatsLetterApi = `${pdtBaseApi}/specialfundinfo/showset`; // 专户信披配置列表

export const listSpecialClientmapApi = `${pdtBaseApi}/specialfundinfo/clientmap`; // 专户客户投资信息列表
export const reviewSpecialClientmapApi = `${pdtBaseApi}/specialfundinfo/reviewclient`; // 专户客户复核接口
export const saveSpecialClientmapApi = `${pdtBaseApi}/specialfundinfo/sacveclient`; // 专户客户投资信息保存
export const detailSpecialClientmapApi = `${pdtBaseApi}/specialfundinfo/clientdetail`; // 专户客户投资信息详情
export const searchSpecialClientmapApi = `${pdtBaseApi}/specialfundinfo/searchinfo`; // 专户客户投资信息查询

export const listAssetManagementApi = `${pdtBaseApi}/specialfundinfoxbrl/asset/list`; // 资产管理列表
export const importAssetManagementApi = `${pdtBaseApi}/specialfundinfoxbrl/asset/management`; // 资产管理文件导入
export const delAssetManagementApi = `${pdtBaseApi}/specialfundinfoxbrl/asset/del`; // 资产管理列表删除

export const listDividendInformationApi = `${pdtBaseApi}/fund/dividend/sharebonus/list`; // 分红信息列表
export const detailDividendInformationApi = `${pdtBaseApi}/fund/dividend/sharebonus/detail`; // 分红信息列表详情
export const listDividendConfigApi = `${pdtBaseApi}/fund/dividend/config/list`; // 分红配置列表
export const saveDividendConfigApi = `${pdtBaseApi}/fund/dividend/config/save`; // 分红配置列表保存
export const updateDividendConfigApi = `${pdtBaseApi}/fund/dividend/config/update`; // 分红配置列表编辑保存
export const delDividendConfigApi = `${pdtBaseApi}/fund/dividend/config/delete`; // 分红配置列表删除
export const exportDividendFileApi = `${pdtBaseApi}/fund/dividend/sharebonus/export`; // 分红信息导出
// 信息维护 --------------------------------------------------------------------------end

// 公募信息 --------------------------------------------------------------------------start
export const tradeseatList = `${pdtBaseApi}/prod/bpm/tradeseat/list`; // 获取新增的席位列表
export const tradeseatContractlist = `${pdtBaseApi}/prod/tradeseat/contractlist`; // 获取新增的席位列表
export const pdmpcommonList = `${pdtBaseApi}/pdmpcommon/yiye/list`; // 产品生成文档
export const pdmpcommonGenerate = `${pdtBaseApi}/pdmpcommon/yiye/generate`; // 产品生成文档 生成文档
export const generateAll = `${pdtBaseApi}/pdmpcommon/yiye/generate/all`; // 产品生成文档 生成全部文档
export const yiyeExport = `${pdtBaseApi}/pdmpcommon/yiye/export`; // 产品生成文档 导出
export const yiyePreview = `${pdtBaseApi}/pdmpcommon/yiye/preview`; // 产品生成文档 查看
export const pdoneList = `${pdtBaseApi}/directory/pdone/list`; // 产品生成文档 数据
export const pdmpcommonCopytree = `${pdtBaseApi}/pdmpcommon/copytree`; // 产品生成文档 复制
export const attachmentSave = `${pdtBaseApi}/attachment/save`; // 产品生成文档 上传(保存)文件
export const attachmentDelone = `${pdtBaseApi}/attachment/delone`; // 产品生成文档 删除文件
export const attachmentList = `${pdtBaseApi}/attachment/list`; // 产品生成文档 文件列表
export const fundlabelSave = `${pdtBaseApi}/pdmpcommon/yiye/fundlabel/save`; // 产品生成文档 打标签
export const byinvestarea = `${pdtBaseApi}/fundinfo/query/qdfundHoldy/byinvestarea`; // 通过投资地区获取海外基金节假日产品信息
export const getexchholdy = `${pdtBaseApi}/exch/getexchholdy`; // 获取交易所指定年份假期是否更新
export const holdyAnno = `${pdtBaseApi}/notice/exch/holdy/anno`; // 生成公告
export const holdyTa = `${pdtBaseApi}/notice/exch/holdy/ta`; // 导出TA文件
export const syncexchholdy = `${pdtBaseApi}/exch/syncexchholdy`; // 同步指定年份交易所假期
export const qdhldycontrdesc = `${pdtBaseApi}/fundinfo/save/qdhldycontrdesc`; // 配置合同描述
// 公募信息 --------------------------------------------------------------------------end

// 公告 --------------------------------------------------------------------------start
export const listNoticeApi = `${pdtBaseApi}/notice/list`;
export const saveNoticeApi = `${pdtBaseApi}/notice/save`;
export const saveNoticeCsrcApi = `${pdtBaseApi}/notice/savecsrc`;
export const countbystatus = `${pdtBaseApi}/notice/countbystatus`; // 公告管理类型的徽标数量

export const delNoticeApi = `${pdtBaseApi}/notice/remove`;
export const detailNoticeApi = `${pdtBaseApi}/notice/detail`;
export const detailMatchApi = `${pdtBaseApi}/notice/matchdetail`; // 公告模板编辑
export const updateMatchApi = `${pdtBaseApi}/notice/updatematch`; // 公告模板保存
export const getMatchReceiverApi = `${pdtBaseApi}/notice/matchreceiver`; // 获取公告类型通知人邮箱
export const listNoticeTreeApi = `${pdtBaseApi}/catalog/noticeTree`;
export const noticeMatchfund = `${pdtBaseApi}/notice/matchfund`; // 根据上传的word文件匹配基金
export const uploadRelateFund = `${pdtBaseApi}/notice/uploadRelateFund`; // 公告管理-批量上传新增公告

export const syncNoticeApi = `${pdtBaseApi}/notice/syncfile`;
export const listNoticeMatchApi = `${pdtBaseApi}/notice/matchlist`;
export const saveBatchNoticeApi = `${pdtBaseApi}/notice/batch/save`;
export const getFundManagerNoticeApi = `${pdtBaseApi}/notice/fundmanager/template`;
export const saveFundManagerNoticeApi = `${pdtBaseApi}/notice/fundmanager/save`;
export const readFundManagerXmlApi = `${pdtBaseApi}/notice/fundmanager/readxml`;
export const synchronousApi = `${pdtBaseApi}/notice/syncann`;

export const listImportantApi = `${pdtBaseApi}/important/list`; // 报社设置
export const saveImportantApi = `${pdtBaseApi}/important/save`;
export const listNewsApi = `${pdtBaseApi}/important/news/list`;
export const saveNewsApi = `${pdtBaseApi}/important/news/save`;

export const listDividendApi = `${pdtBaseApi}/fund/dividend/list`; // 分红决议文件列表
export const detailDividendApi = `${pdtBaseApi}/fund/dividend/detail`; // 分红决议文件详情
export const delDividendFileApi = `${pdtBaseApi}/fund/dividend/filedel`; // 分红决议文件列表删除
export const genDividendFileApi = `${pdtBaseApi}/notice/resdividend`;
export const saveDividendApi = `${pdtBaseApi}/fund/dividend/save`;
export const uploadDividendFileApi = `${pdtBaseApi}/fund/dividend/fileconvert`;
export const newsorderListApi = `${pdtBaseApi}/newsorder/list`;
export const newsorderSaveApi = `${pdtBaseApi}/newsorder/save`;
export const newsfeeListApi = `${pdtBaseApi}/newsfee/list`; // 报刊费用列表接口
export const newsfeeCalculateApi = `${pdtBaseApi}/newsfee/calculate`; // 报刊费用日期设置
export const newsfeeExportApi = `${pdtBaseApi}/newsfee/export`; // 报刊费用导出Exce
export const newsfeeRuleApi = `${pdtBaseApi}/newsfee/rule`; // 报刊费用存量基金规则
export const newsfeeUpdateApi = `${pdtBaseApi}/newsfee/update`; // 报刊费用编辑

export const auditListApi = `${pdtBaseApi}/audit/list`; // 审计计划
export const abarbeitungListApi = `${pdtBaseApi}/abarbeitung/list`; // 整改计划
export const auditListExportApi = `${pdtBaseApi}/audit/export`; // 审计计划导出
export const abarbeitungListExportApi = `${pdtBaseApi}/abarbeitung/export`; // 整改计划导出

// 公告 --------------------------------------------------------------------------end

// 产品文档 --------------------------------------------------------------------------start
export const listDocTreeApi = `${pdtBaseApi}/catalog/listTree`;
export const listDocFileListApi = `${pdtBaseApi}/file/list`;
export const listDocHistoryApi = `${pdtBaseApi}/history/list`;

export const saveFileApi = `${pdtBaseApi}/file/save`;
export const removeFileApi = `${pdtBaseApi}/file/remove`;
export const addCatalogApi = `${pdtBaseApi}/catalog/add`;
export const editCatalogApi = `${pdtBaseApi}/catalog/edit`;
export const moveCatalogApi = `${pdtBaseApi}/catalog/move`;
export const delCatalogApi = `${pdtBaseApi}/catalog/remove`;
export const updateAgencyTreeApi = `${pdtBaseApi}/catalog/agencyTree/update`; // 刷新代销机构树
export const authPermissionApi = `${pdtBaseApi}/permission/authorization`;
export const detailPermissionApi = `${pdtBaseApi}/permission/info`;

export const readAutoNumberFileApi = `${pdtBaseApi}/notice/read`; // 自动编号
export const listNoticeTypeApi = `${pdtBaseApi}/notice/type`;
export const getNoticeNumberApi = `${pdtBaseApi}/notice/getnoticenum`;
export const genAutoNumberFileApi = `${pdtBaseApi}/notice/autonumber`;
export const genAutoNumnerPollingApi = `${pdtBaseApi}/notice/autonumber/polling`;
export const downloadAutoNumberPdfApi = `${pdtBaseApi}/notice/autonumber/download`;
export const batchReadAutoNumberFileAutoNumberFileApi = `${pdtBaseApi}/notice/batch/read`;

export const detailTemplateApi = `${pdtBaseApi}/template/detail`; // 模板管理
export const delTemplateMgApi = `${pdtBaseApi}/mg/remove`;
export const viewTemplateMgApi = `${pdtBaseApi}/mg/view`;
export const updateTemplateMgApi = `${pdtBaseApi}/mg/update`;
export const saveTemplateMgApi = `${pdtBaseApi}/mg/save`;
export const listTemplateCategoryApi = `${pdtBaseApi}/category/list`;
export const delTemplateCategoryApi = `${pdtBaseApi}/category/detail`;
export const saveTemplateCategoryApi = `${pdtBaseApi}/category/save`;
export const listTemplateCategoryHisApi = `${pdtBaseApi}/category/his`;
export const listTemplateMgApi = `${pdtBaseApi}/mg/list`;
export const detailTemplateMgApi = `${pdtBaseApi}/mg/detail`;
export const saveTemplateSqlContentApi = `${pdtBaseApi}/sqlcontent/save`;
export const delTemplateSqlContentApi = `${pdtBaseApi}/sqlcontent/remove`;

export const listDirectoryApi = `${pdtBaseApi}/directory/list`;
export const addDirectoryApi = `${pdtBaseApi}/directory/add`;
export const dargDirectoryApi = `${pdtBaseApi}/directory/drag`;
export const updateDirectoryApi = `${pdtBaseApi}/directory/update`;
export const delDirectoryApi = `${pdtBaseApi}/directory/remove`;

export const exportSummaryApi = `${pdtBaseApi}/pdi/export`;
export const viewSummaryApi = `${pdtBaseApi}/pdi/preview`;
export const listSummaryApi = `${pdtBaseApi}/pdi/list`;
export const exportRiskApi = `${pdtBaseApi}/pdi/risk`; // 导出风险揭示书
export const listSummaryFileApi = `${pdtBaseApi}/pdi/file/list`;
export const saveSummaryFileApi = `${pdtBaseApi}/pdi/file/save`;
export const reportSummaryFileApi = `${pdtBaseApi}/pdi/file/report`;
export const removeSummaryFileApi = `${pdtBaseApi}/pdi/file/remove`;
export const listSummaryFeedbackFundApi = `${pdtBaseApi}/pdi/file/read/fundlist`;
export const listSummaryFeedbackAgencyApi = `${pdtBaseApi}/pdi/file/read/agencylist`;
export const listSummaryAgencyApi = `${pdtBaseApi}/pdi/agencyinfo`;

export const listRecruitDirectoryApi = `${pdtBaseApi}/directory/pdmp/list`;
export const saveNewRecruitDirectoryApi = `${pdtBaseApi}/pdmp/newterm`;
export const saveRecruitTreeApi = `${pdtBaseApi}/pdmp/copytree`;
export const listRecruitApi = `${pdtBaseApi}/pdmp/list`;
export const genRecruitContentApi = `${pdtBaseApi}/pdmp/generate`;
export const genAllRecruitContentApi = `${pdtBaseApi}/pdmp/generate/all`;
export const importRecruitApi = `${pdtBaseApi}/pdmp/import`;

export const saveRecruitContentApi = `${pdtBaseApi}/pdmp/save`;
export const saveRecruitAllContentApi = `${pdtBaseApi}/pdmp/saveall`;
export const viewRecruitApi = `${pdtBaseApi}/pdmp/preview`;
export const exportRecruitApi = `${pdtBaseApi}/pdmp/export`;
export const updateTitleNumApi = `${pdtBaseApi}/pdmp/updatenum`;

export const sendEmailRecruitApi = `${pdtBaseApi}/pdmp/sendemail`;
export const submitRecruitContentApi = `${pdtBaseApi}/pdmp/submit`;
export const listRecruitApproveApi = `${pdtBaseApi}/pdmp/approve/log`;
export const saveRecruitExtApi = `${pdtBaseApi}/pdmp/ext/save`;
export const listRecruitPermissionApi = `${pdtBaseApi}/pdmp/permission/list`;
export const saveRecruitPermissionApi = `${pdtBaseApi}/pdmp/permission/save`;

// 招募信息维护
export const listRecruitUpdateRecordApi = `${pdtBaseApi}/pdmp/record/list`;
export const saveRecruitUpdateRecordApi = `${pdtBaseApi}/pdmp/record/save`;
export const listRecruitUpdateDataApi = `${pdtBaseApi}/pdmp/data/list`;
export const updateRecruitUpdateDataApi = `${pdtBaseApi}/pdmp/data/update`;
export const updateSeasonreportApi = `${pdtBaseApi}/pdmp/record/seasonreport/update`;
export const updateRecruitUpdateRecordStatusApi = `${pdtBaseApi}/pdmp/record/updatestatus`;

export const getProcessDocFileListApi = `${pdtBaseApi}/file/processlist`;

export const exportChannelsFileApi = `${pdtBaseApi}/organinfo/exorganfundnum`;

// 反洗钱评测表
export const listAntiMoneyEvalApi = `${pdtBaseApi}/antimoneyeval/list`;
export const genAntiMoneyEvalApi = `${pdtBaseApi}/antimoneyeval/generate`;
export const analyseAntiMoneyEvalApi = `${pdtBaseApi}/antimoneyeval/analyse`;
export const downloadAntiMoneyEvalApi = `${pdtBaseApi}/antimoneyeval/download`;
// 新反洗钱
export const getTemplateByTypeApi = `${pdtBaseApi}/antiMoneyEvalTemplate/getTemplateByType`;
export const antiMoneyEvalFlowInfoSave = `${pdtBaseApi}/antiMoneyEvalFlowInfo/save`;
export const antiMoneyEvalInfoList = `${pdtBaseApi}/antiMoneyEvalInfo/list`;
export const antiMoneyEvalInfoExport = `${pdtBaseApi}/antiMoneyEvalInfo/export`;
export const batchInitApproval = `${pdtBaseApi}/antiMoneyEvalFlowInfo/batchInitApproval`;
export const batchReApproval = `${pdtBaseApi}/antiMoneyEvalFlowInfo/batchReApproval`;
export const copyTemplateByFund = `${pdtBaseApi}/antiMoneyEvalTemplate/copyTemplateByFund`;
export const queryNewByFundCode = `${pdtBaseApi}/antiMoneyEvalInfo/checkNew`; // 根据fundCode查询新基金最新反洗钱评测信息

// 产品文档 --------------------------------------------------------------------------end

// 产品日历 --------------------------------------------------------------------------start
export const listEventTrackApi = `${pdtBaseApi}/event/track/list`;
export const listEventApi = `${pdtBaseApi}/event/list`;
export const saveEventApi = `${pdtBaseApi}/event/save`;
export const delEventApi = `${pdtBaseApi}/event/remove`; // 删除事件
export const detaileEventApi = `${pdtBaseApi}/event/detail`;

export const listEventRuleApi = `${pdtBaseApi}/event/rule/list`;
export const saveRuleApi = `${pdtBaseApi}/event/rule/save`; // 保存事件规则
export const detailRuleApi = `${pdtBaseApi}/event/rule/detail`; // 事件规则详情
export const delRuleApi = `${pdtBaseApi}/event/rule/remove`; // 删除事件规则

export const listEventBaseDateApi = `${pdtBaseApi}/event/basedate/list`;
export const listEventFundSettingApi = `${pdtBaseApi}/event/fundsetting/list`;
export const listTemplatesApi = `${pdtBaseApi}/event/templates/list`;

// 产品日历 --------------------------------------------------------------------------end

// 消息 --------------------------------------------------------------------------start
export const listMessageApi = `${pdtBaseApi}/message-general/systemMessage/list`;
export const removeMessageApi = `${pdtBaseApi}/message-general/systemMessage/remove`;
export const updateMessageStatusApi = `${pdtBaseApi}/message-general/systemMessage/setStatus`;
// 消息 --------------------------------------------------------------------------end

// 流程处理 --------------------------------------------------------------------------start
export const getProcessTypeApi = `${impBaseApi}/bpm/category/sub`; // 流程类型
export const listProcessRequestApi = `${impBaseApi}/bpm/task/list/request`; // 我的申请
export const listProcessApproveApi = `${impBaseApi}/bpm/task/list/approve`; // 我的处理
export const listProcessTodoApi = `${impBaseApi}/bpm/task/list/todo`; // 待办列表
export const listProcessReadApi = `${impBaseApi}/bpm/task/list/read`; // 待阅列表
export const listProcessAllApi = `${impBaseApi}/bpm/task/list/all`; // 审批日志
export const listProcessDraftApi = `${impBaseApi}/bpm/task/list/draft`; // 草稿箱
// 流程处理 --------------------------------------------------------------------------end

// 流程表单相关 -----start----------
export const dictList = `${upmBaseApi}/upm/dict/v1/listchild`;
export const agencyList = `${pdtBaseApi}/organinfo/queryorganlist`;
export const checkAgecyAttrApi = `${pdtBaseApi}/organinfo/checkagencyattr`;
export const agencyExport = `${pdtBaseApi}/notice/process/agency/export`;
export const managerList = `${pdtBaseApi}/fundmanager/queryfundmanagerlist`;
export const userList = `${upmBaseApi}/upm/user/v1/list`;
export const userDetail = `${upmBaseApi}/upm/user/v1/getUserList`;

export const fundList = `${pdtBaseApi}/fundinfo/fuzzysearch`;
export const fundFullList = `${pdtBaseApi}/fundinfo/list`;
export const shareList = `${pdtBaseApi}/fundinfo/sharelist`;
export const bpmShareList = `${pdtBaseApi}/fundinfo/bpm/sharelist`;

export const initAgencyUpload = `${pdtBaseApi}/organinfo/initfundagency/getorgainbyfilepath`;
export const periodList = `${pdtBaseApi}/organinfo/bpm/organinfobyfundid`;
export const genAgencyNotice = `${pdtBaseApi}/notice/agency/change`; // post
export const pubAgencyNotice = `${pdtBaseApi}/notice/pub`;
export const pubNotice = `${pdtBaseApi}/notice/generatepub`;

export const dividendDate = `${pdtBaseApi}/common/getworkdate`;
export const subRedProjectUpload = `${pdtBaseApi}/notice/subred`; // post
export const subRedProjectRelease = `${pdtBaseApi}/notice/subredpub`;
export const sharebonusList = `${pdtBaseApi}/fundinfo/sharebonus`;
export const subredapplyProjectUpload = `${pdtBaseApi}/notice/subredapply`; // post
export const agencyRelease = `${pdtBaseApi}/notice/agencyrelease`; // 成立流程生成代销机构名称

export const dividendNotice = `${pdtBaseApi}/notice/dividend`;
export const dividendFundday = `${pdtBaseApi}/fundinfo/fundday`;
export const dividendcount = `${pdtBaseApi}/fundinfo/bonuscount`;

export const dividendDates = `${pdtBaseApi}/common/divdate`;
export const fundDataList = `${pdtBaseApi}/fundinfo/etfunit`;
export const fundEtfList = `${pdtBaseApi}/fundinfo/etflist`;

export const agencyInformationNotice = `${pdtBaseApi}/notice/initagencydetail`;
export const agencyListedNotice = `${pdtBaseApi}/notice/initagencyanndetail`;
export const changeImportFile = `${pdtBaseApi}/organinfo/agencychange/getorgaininfo`;
export const dividendPurchase = `${pdtBaseApi}/fundinfo/largepur`;

export const listFuturesAccount = `${pdtBaseApi}/futures/mappinglist`;
export const dividendSignPeople = `${pdtBaseApi}/fundmanager/managerids`;
export const listFuturesCompany = `${pdtBaseApi}/futures/white`;

export const importAgency = `${pdtBaseApi}/organinfo/agency/import`;
export const generateAgencyList = `${pdtBaseApi}/notice/release/agency`;
export const getFundFeeApi = `${pdtBaseApi}/fundinfo/getfundfee`;

export const seatapplydocApi = `${pdtBaseApi}/notice/seatapplydoc`;
export const prodTradeseatList = `${pdtBaseApi}/prod/tradeseat/list`;

export const perfapprList = `${pdtBaseApi}/prod/perfappr/list`;
export const generateemail = `${pdtBaseApi}/prod/perfoperator/generateemail`;
export const perfoperatorList = `${pdtBaseApi}/prod/perfoperator/list`;
export const perfoperatorAdd = `${pdtBaseApi}/prod/perfoperator/add`;
export const perfoperatorDel = `${pdtBaseApi}/prod/perfoperator/del`;
export const perfoperatorBatchupdate = `${pdtBaseApi}/prod/perfoperator/batchupdate`;
export const appritemList = `${pdtBaseApi}/prod/appritem/list`;
export const minifundLiquidFund = `${pdtBaseApi}/minifund/liquid/fund`; // 清盘迷你基金详情
export const processannopub = `${pdtBaseApi}/notice/processannopub`; // 流程文件发布

// 流程表单相关 -----end----------

// 系统处理 --------------------------------------------------------------------------start
export const pdtconfigListApi = `${pdtBaseApi}/pdtconfig/list`;
export const pdtconfigDetailApi = `${pdtBaseApi}/pdtconfig/detail`;
export const pdtconfigInsertApi = `${pdtBaseApi}/pdtconfig/insert`;
export const pdtconfigUpdateApi = `${pdtBaseApi}/pdtconfig/update`;
export const pdtconfigDelApi = `${pdtBaseApi}/pdtconfig/del`;
export const listLogs = `${pdtBaseApi}/pdtconfig/logs`;
// 系统处理 --------------------------------------------------------------------------end

// 通用维护 --------------------------------------------------------------------------start
// 通用查询
export const comeleQuery = `${pdtBaseApi}/comele/query`;
export const comEleDetailApi = `${pdtBaseApi}/comele/detail`;
export const comEleViewApi = `${pdtBaseApi}/comele/view`;
export const comElePreviewApi = `${pdtBaseApi}/comele/preview`;
export const comEleSaveApi = `${pdtBaseApi}/comele/save`;
export const comEleApproveApi = `${pdtBaseApi}/comele/approve`;
export const comEleElementreviewApi = `${pdtBaseApi}/comele/elementreview/detail`;
export const comEleQuerylistApi = `${pdtBaseApi}/comele/common/querylist`;

// 功能
export const comEleFuncListApi = `${pdtBaseApi}/comele/func/list`;
export const comEleFuncDetailApi = `${pdtBaseApi}/comele/func/detail`;
export const comEleFuncSaveApi = `${pdtBaseApi}/comele/func/save`;
export const comEleFuncRemoveApi = `${pdtBaseApi}/comele/func/remove`;

// 要素
export const comEleElementListApi = `${pdtBaseApi}/comele/element/list`;
export const comEleElementDetailApi = `${pdtBaseApi}/comele/element/detail`;
export const comEleElementSaveApi = `${pdtBaseApi}/comele/element/save`;
export const comEleElementRemoveApi = `${pdtBaseApi}/comele/element/remove`;

export const comEleCurElementListApi = `${pdtBaseApi}/comele/curelement/list`;
export const comEleElementQueryApi = `${pdtBaseApi}/comele/element/query`;
export const comEleDimensionQueryApi = `${pdtBaseApi}/comele/dimension/query`;
export const comEleElementPermissionSaveApi = `${pdtBaseApi}/comele/elementpermission/save`;
export const comEleVersionlistApi = `${pdtBaseApi}/comele/element/versionlist`;

// 功能-要素
export const comEleFuncElementListApi = `${pdtBaseApi}/comele/funcelement/list`;
export const comEleFuncElementSaveApi = `${pdtBaseApi}/comele/funcelement/save`;

// 模块
export const comEleModuleTreeListApi = `${pdtBaseApi}/comele/moduletree/list`;
export const comEleModuleElementDetailApi = `${pdtBaseApi}/comele/moduleelement/detail`;
export const comEleModuleSaveApi = `${pdtBaseApi}/comele/module/save`;
export const comEleModuleRemoveApi = `${pdtBaseApi}/comele/module/remove`;
export const comEleModuleQueryApi = `${pdtBaseApi}/comele/module/query`;

// 角色
export const comEleRoleTreeListApi = `${pdtBaseApi}/comele/roletree/list`;
export const comEleRoleSaveApi = `${pdtBaseApi}/comele/role/save`;
export const comEleRoleDetailApi = `${pdtBaseApi}/comele/role/detail`;
export const comEleRoleRemoveApi = `${pdtBaseApi}/comele/role/remove`;

export const comElePermissionDetailApi = `${pdtBaseApi}/comele/elementpermission/detail`;
export const comEleRoleMappingListApi = `${pdtBaseApi}/comele/rolemapping/detail`;
export const comEleRoleElementListApi = `${pdtBaseApi}/comele/roleelement/list`;
// 要素-角色
export const comEleElementRoleSaveApi = `${pdtBaseApi}/comele/elementrole/save`;

// 审批
export const comEleReviewListApi = `${pdtBaseApi}/comele/elementreview/list`;
export const comEleReviewProxyApi = `${pdtBaseApi}/comele/elementreview/list/14bdb20838c142b3a56cd4144aa3afce`;

// 数据配置
export const sqlmodelList = `${pdtBaseApi}/param/pull/sqlmodel/list`;
export const sqlmodelSave = `${pdtBaseApi}/param/pull/sqlmodel/save`;
export const sqlmodelDel = `${pdtBaseApi}/param/pull/sqlmodel/delList`;
// 参数订阅
export const subscribeTitle = `${pdtBaseApi}/subscribeTitle/pageList`;
export const subscribeTitleSave = `${pdtBaseApi}/subscribeTitle/save`;
export const subscribeTitleDelete = `${pdtBaseApi}/subscribeTitle/delete`;

// 通用维护 --------------------------------------------------------------------------end

export const assesinfoList = `${pdtBaseApi}/compliance/assesinfo/list`; // 合规扣分情况列表
export const assesinfoSave = `${pdtBaseApi}/compliance/assesinfo/save`; // 合规扣分情况保存
export const assesinfoDel = `${pdtBaseApi}/compliance/assesinfo/del`; // 合规扣分情况删除
export const annoList = `${pdtBaseApi}/compliance/anno/list`; // 合规信息披露列表
export const annoReturn = `${pdtBaseApi}/compliance/anno/return`; // 合规信息披露退回
export const annoConfagain = `${pdtBaseApi}/compliance/anno/confagain`; // 合规信息披露再确认

export const fundlifeCycleList = `${pdtBaseApi}/workbench/fundlife/cycle/list`; // 产品生命周期

// 信息披露规则维护
export const disclosureRuleList = `${pdtBaseApi}/disclosure/baseInfo/page`; // 信息披露规则列表
export const disclosureRuleSave = `${pdtBaseApi}/disclosure/baseInfo/save`; // 保存信息披露规则
export const disclosureRuleEnable = `${pdtBaseApi}/disclosure/baseInfo/enable`; // 启用信息披露规则
export const disclosureRuleDisable = `${pdtBaseApi}/disclosure/baseInfo/disable`; // 禁用信息披露规则
export const disclosureRuleDelete = `${pdtBaseApi}/disclosure/baseInfo/delete`; // 删除信息披露规则

// 基金/投资经理审计 -----------------------------------------------------------------
export const listManagerLeavesApi = `${pdtBaseApi}/fundManagerLeaveAuditInfo/list`; // 基金经理离任查询列表
export const detailFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditInfo/detail`; // 基金经理离任——详情
export const saveBasicFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditInfo/edit`; // 基金经理离任——基本信息保存
export const saveViolationFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditViolation/edit`; // 基金经理离任——合规信息保存
export const saveShareFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditShare/edit`; // 基金经理离任——业绩信息信息保存——审查期间内主要经济指标变动情况
export const saveBusinessFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditChange/edit`; // 基金经理离任——业绩信息信息保存——审查期间内的经营成果及变动分析
export const saveFinanceFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditFinance/edit`; // 基金经理离任——业绩信息信息保存——审查期间内的财务状况
export const saveResultsManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditExtend/edit`; // 基金经理离任——业绩评估信息保存
export const exportFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditInfo/export`; // 基金经理离任——文件生成
export const saveFundsManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditFund/edit`; // 基金经理离任——基金费用保存
export const updateBasicManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditInfo/pull`; // 基金经理离任——基本信息更新
export const updateFinanceFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditFinance/pull`; // 基金经理离任——业绩信息信息保存——审查期间内的财务状况更新
export const updateBusinessFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditChange/pull`; // 基金经理离任——业绩信息信息保存——审查期间内的经营成果及变动分析更新
export const updateFundIncomeFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditFund/income/pull`; // 基金经理离任——业绩信息信息保存——基金收入更新
export const updateFundFfeeFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditFund/fee/pull`; // 基金经理离任——业绩信息信息保存——基金费用更新
export const updateShareFundManageLeaveApi = `${pdtBaseApi}/fundManagerLeaveAuditShare/pull`; // 基金经理离任——业绩信息信息保存——审查期间内主要经济指标变动情况更新
export const updatepPrformanceAppraisalApi = `${pdtBaseApi}/fundManagerLeaveAuditInfo/performance/pull`; // 基金经理离任——业绩信息更新——业绩评估
