import md5 from 'js-md5';
import * as config from './config';
import { upmHttp, storage, fn } from '@cerdo/cerdo-utils';
export { api as commonApi } from '@cerdo/cerdo-utils';

const { get, post, download } = upmHttp;

/** 错误优先；不用try catch和fn.checkResponse */
export const pdtGet = (data) =>
  new Promise((resolve) => {
    get({ ...data })
      .then((result) => {
        if (fn.checkResponse(result)) {
          resolve([null, result]);
        } else {
          console.error(data.url, result);
          resolve([result, null]);
        }
      })
      .catch((result) => {
        console.error(data.url, result);
        resolve([result, null]);
      });
  });
export const pdtPost = (data) =>
  new Promise((resolve) => {
    post({ ...data })
      .then((result) => {
        if (fn.checkResponse(result)) {
          resolve([null, result]);
        } else {
          console.error(data.url, result);
          resolve([result, null]);
        }
      })
      .catch((result) => {
        console.error(data.url, result);
        resolve([result, null]);
      });
  });

export const downloadBatchFile = (data) =>
  download({ url: config.downloadBatchFileApi, data: data, method: 'post' });

export const getUser = (data) => get({ url: config.getUserApi, data: data });
export const getWorkDay = (data) => get({ url: config.getWorkDayApi, data });
export const getConfigList = (data) => get({ url: config.getConfigListApi, data });
export const getMarketSale = (data) => get({ url: config.getMarketSaleApi, data });
export const fuzzysearch = (data) => get({ url: config.fuzzysearchApi, data });
export const getAllFunds = (data) => get({ url: config.getAllFundsApi, data });
export const listFundShare = (data) => get({ url: config.listFundShareApi, data });
export const getStatistics = (data) => get({ url: config.getStatisticsApi, data });
export const dictv1Listchild = (data) => get({ url: config.dictList, data });
export const getWorkDate = (data) => pdtGet({ url: config.getWorkDateApi, data });
export const getdesigndate = (data) => pdtGet({ url: config.getdesigndateApi, data });

// 公募产品 --------------------------------------------------------------------------start
export const listFundInfo = (data) => get({ url: config.listFundInfoApi, data });
export const detailFundInfo = (data) => get({ url: config.detailFundInfoApi, data });
export const saveFundInfo = (data) => post({ url: config.saveFundInfoApi, data });
export const removeFundInfo = (data) => get({ url: config.removeFundInfoApi, data });
export const syncFundContract = (data) => get({ url: config.syncFundContractApi, data });
export const saveLiquidation = (data) => post({ url: config.saveLiquidationApi, data });

export const listOpenRecord = (data) => get({ url: config.listOpenRecordApi, data }); // 开放记录
export const saveOpenRecord = (data) => post({ url: config.saveOpenRecordApi, data });

export const listEditRecord = (data) => get({ url: config.listEditRecordApi, data }); // 修改记录

export const listGuideTree = (data) => get({ url: config.listGuideTreeApi, data }); // 产品编辑向导
export const detailGuideTree = (data) => get({ url: config.detailGuideTreeApi, data });

export const listFundAccount = (data) => get({ url: config.listFundAccountApi, data }); // 基金交易账户
export const saveFundAccount = (data) => post({ url: config.saveFundAccountApi, data });
export const removeFundAccount = (data) => get({ url: config.removeFundAccountApi, data });
// 公募产品 --------------------------------------------------------------------------end

// 专户产品 --------------------------------------------------------------------------start
export const listSpecialFundInfo = (data) => get({ url: config.listSpecialFundInfoApi, data });
export const listshare = (data) => get({ url: config.listshareApi, data });
export const detailSpecialFundInfo = (data) => get({ url: config.detailSpecialFundInfoApi, data });
export const saveSpecialFundInfo = (data) => post({ url: config.saveSpecialFundInfoApi, data });
export const specialfundeventList = (data) => get({ url: config.specialfundeventListApi, data });
export const detailSpecialfundeventList = (data) =>
  get({ url: config.detailSpecialfundeventListApi, data });
export const saveSpecialfundeventList = (data) =>
  post({ url: config.saveSpecialfundeventListApi, data });
export const setSpecialfundeventCronlist = (data) =>
  get({ url: config.setSpecialfundeventCronlistApi, data });
export const createSpecialfundeventt = (data) =>
  get({ url: config.createSpecialfundeventtApi, data });
export const listAllocationFundevent = (data) =>
  get({ url: config.listAllocationFundeventtApi, data });
export const detailEventList = (data) => get({ url: config.detailEventListApi, data });
export const saveSpecialresultsList = (data) =>
  post({ url: config.saveSpecialresultsListApi, data });
export const listAchieveFundeventt = (data) => get({ url: config.listAchieveFundeventtApi, data });
export const listResultMessageFundeventt = (data) =>
  get({ url: config.listResultMessageFundeventtApi, data });
export const saveachieveFundeventt = (data) => post({ url: config.saveachieveFundeventtApi, data });
export const exportSpecialfundevent = (data) =>
  download({ url: config.exportSpecialfundeventApi, data });
export const generateSpecialfundevent = (data) =>
  download({ url: config.generateSpecialfundeventApi, data });
export const exportSpecialResults = (data) =>
  download({ url: config.exportSpecialResultsApi, data });
export const exportTASpecialfundevent = (data) =>
  download({ url: config.exportTASpecialfundeventApi, data });
// 专户产品 --------------------------------------------------------------------------end

// 信息维护 --------------------------------------------------------------------------start
export const listAgency = (data) => get({ url: config.listAgencyApi, data });
export const detailAgency = (data) => get({ url: config.detailAgencyApi, data });
export const delAgency = (data) => get({ url: config.delAgencyApi, data });
export const saveAgency = (data) => post({ url: config.saveAgencyApi, data });
export const exportAgency = (data) => download({ url: config.exportAgencyApi, data });

export const listFundListById = (data) => get({ url: config.listFundListByIdApi, data });
export const removeAgencyMapping = (data) => get({ url: config.removeAgencyMappingApi, data });
export const saveAgencyMapping = (data) => post({ url: config.saveAgencyMappingApi, data });

export const listAgencyFunds = (data) => get({ url: config.listAgencyFundsApi, data });
export const exportAgencyFunds = (data) => download({ url: config.exportAgencyFundsApi, data });
export const importAgencyFunds = (data) =>
  post({ url: config.importAgencyFundsApi, data: data.data });
export const saveAgencyFunds = (data) => post({ url: config.saveAgencyFundsApi, data });

export const listManagement = (data) => get({ url: config.listManagementApi, data }); // 管理人员信息
export const detailManagement = (data) => get({ url: config.detailManagementApi, data });
export const saveManagement = (data) => post({ url: config.saveManagementApi, data });
export const removeManagement = (data) => get({ url: config.removeManagementApi, data });

export const listManagementDay = (data) => get({ url: config.listManagementDayApi, data }); // 管理人员 每天历史信息
export const getManagementDay = (data) => get({ url: config.getManagementDayApi, data });
export const saveManagementDay = (data) => post({ url: config.saveManagementDayApi, data });
export const removeManagementDay = (data) => get({ url: config.removeManagementDayApi, data });

export const listManager = (data) => get({ url: config.listManagerApi, data });
export const exportfundinfobyfundmanager = (data) =>
  download({ url: config.exportfundinfobyfundmanagerApi, data });
export const importnewfundinfobyfundmanagerid = (data) =>
  post({ url: config.importnewfundinfobyfundmanageridApi, data: data.data });
export const addmappinglist = (data) => post({ url: config.addmappinglistApi, data });
export const detailManager = (data) => get({ url: config.detailManagerApi, data });
export const delManager = (data) => get({ url: config.delManagerApi, data });
export const saveManager = (data) => post({ url: config.saveManagerApi, data });
export const queryFundListByFundManagerId = (data) =>
  get({ url: config.queryFundListByFundManagerIdApi, data });
export const annoQueryfundinfobyfundmanagerid = (data) =>
  get({ url: config.annoQueryfundinfobyfundmanageridApi, data });
export const removeManagerMapping = (data) => get({ url: config.removeManagerMappingApi, data });
export const saveManagerMapping = (data) => post({ url: config.saveManagerMappingApi, data });
export const syncFundManager = (data) => get({ url: config.syncFundManagerApi, data });
export const queryFundManagerByFundId = (data) =>
  get({ url: config.queryFundManagerByFundIdApi, data });
export const saveFundMappingByXml = (data) => post({ url: config.saveFundMappingByXmlApi, data });
export const exportManager = (data) => download({ url: config.exportManagerApi, data });
export const queryManagerAmount = (data) => get({ url: config.queryManagerAmountApi, data });
export const managersysprvlgreclist = (data) =>
  get({ url: config.managersysprvlgreclistApi, data });

export const listFundInfoXbrl = (data) => get({ url: config.listFundInfoXbrlApi, data });
export const initFundInfoXbrl = (data) => get({ url: config.initFundInfoXbrlApi, data });
export const detailFundInfoXbrl = (data) => get({ url: config.detailFundInfoXbrlApi, data });
export const saveFundInfoXbrl = (data) => post({ url: config.saveFundInfoXbrlApi, data });
export const exportFundInfotXbrl = (data) => download({ url: config.exportFundInfotXbrlApi, data });
export const saveFundInfoXbrlAgency = (data) =>
  post({ url: config.saveFundInfoXbrlAgencyApi, data });

export const listEtf = (data) => get({ url: config.listEtfApi, data });
export const listEtfUnit = (data) =>
  get({ url: config.listEtfUnitApi, data, headers: { useHandleRes: true } });

// 信息维护(基金信息变更维护)
export const listFundManagerChange = (data) => get({ url: config.listFundManagerChangeApi, data }); // 基金信息变更维护列表
export const doFundApply = (data) => get({ url: config.doFundApplyApi, data }); // 基金信息变更申请

// 迷你基金
export const listMiniFund = (data) => get({ url: config.listMiniFundApi, data }); // 基金信息变更维护列表
export const detailMiniFund = (data) => get({ url: config.detailMiniFundApi, data }); // 基金信息变更维护列表
export const downloadMiniFundFile = (data) =>
  download({ url: config.downloadMiniFundFileApi, data }); // 基金信息变更维护列表
export const saveEmailConfig = (data) => post({ url: config.saveEmailConfigApi, data }); // 迷你基金邮件保存
export const detailEamilConfig = (data) => get({ url: config.detailEamilConfigApi, data }); // 迷你基金邮件保存
export const saveIspubweek = (data) => post({ url: config.saveIspubweekApi, data }); // 迷你基金保存本周内是否发布迷你性提示公告接口
export const saveRemark = (data) => post({ url: config.saveRemarkApi, data }); // 迷你基金保存备注接口
export const detailLiquidation = (data) => get({ url: config.detailLiquidationApi, data }); // 迷你基金保存备注接口
export const updateList = (data) => get({ url: config.updateListApi, data }); // 迷你基金更新接口
export const downloadMiniFundDoc = (data) => download({ url: config.downloadMiniFundDocApi, data }); // 迷你基金更新接口

export const listFuturesWhite = (data) => get({ url: config.listFuturesWhiteApi, data }); // 期货白名单列表
export const saveFuturesWhite = (data) => post({ url: config.saveFuturesWhiteApi, data }); // 期货白名单列表保存

// 专户席位信息
export const listSpecialSeats = (data) => get({ url: config.listSpecialSeatsApi, data }); // 专户席位信息列表
export const detailSpecialSeats = (data) => get({ url: config.detailSpecialSeatsApi, data }); // 专户席位设置信息
export const saveSpecialSeats = (data) => post({ url: config.saveSpecialSeatsApi, data }); // 专户席位保存

export const exportChannelsFile = (data) => download({ url: config.exportChannelsFileApi, data }); // 信息维护 代销机构信息导出基础信息

export const listSpecialSeatsLetter = (data) =>
  post({ url: config.listSpecialSeatsLetterApi, data }); // 专户信披配置
export const specialfundinfoxbrl = (data) => get({ url: config.specialfundinfoxbrlApi, data });
export const initSpecialfundinfoxbrl = (data) =>
  get({ url: config.initSpecialfundinfoxbrlApi, data });
export const detailSpecialfundinfoxbrl = (data) =>
  get({ url: config.detailSpecialfundinfoxbrlApi, data });
export const saveSpecialfundinfoxbrl = (data) =>
  post({ url: config.saveSpecialfundinfoxbrlApi, data });
export const exportSpecialfundinfoxbrl = (data) =>
  download({ url: config.exportSpecialfundinfoxbrlApi, data });

export const listSpecialClientmap = (data) => get({ url: config.listSpecialClientmapApi, data }); // 专户客户投资信息列表
export const reviewSpecialClientmap = (data) =>
  get({ url: config.reviewSpecialClientmapApi, data }); // 专户客户投资信息复核
export const saveSpecialClientmap = (data) => post({ url: config.saveSpecialClientmapApi, data }); // 专户客户投资保存
export const detailSpecialClientmap = (data) =>
  get({ url: config.detailSpecialClientmapApi, data }); // 专户客户投资信息详情
export const searchSpecialClientmap = (data) =>
  get({ url: config.searchSpecialClientmapApi, data }); // 专户客户投资信息查询

export const listAssetManagement = (data) => get({ url: config.listAssetManagementApi, data }); // 资产管理列表
export const importAssetManagement = (data) => post({ url: config.importAssetManagementApi, data }); // 资产管理文件导入
export const delAssetManagement = (data) => get({ url: config.delAssetManagementApi, data }); // 资产管理列表删除

export const listDividendInformation = (data) =>
  get({ url: config.listDividendInformationApi, data }); // 分红信息列表
export const detailDividendInformation = (data) =>
  get({ url: config.detailDividendInformationApi, data }); // 分红信息列表详情
export const listDividendConfig = (data) => get({ url: config.listDividendConfigApi, data }); // 分红信息配置列表
export const saveDividendConfig = (data) => post({ url: config.saveDividendConfigApi, data }); // 分红信息配置列表保存
export const updateDividendConfig = (data) => post({ url: config.updateDividendConfigApi, data }); // 分红配置列表编辑更新
export const delDividendConfig = (data) => get({ url: config.delDividendConfigApi, data }); // 分红信息删除
export const exportDividendFile = (data) => download({ url: config.exportDividendFileApi, data }); // 分红信息导出
// 信息维护 --------------------------------------------------------------------------end

// 机构信息 --------------------------------------------------------------------------start
export const tradeseatList = (data) => get({ url: config.tradeseatList, data }); // 获取新增的席位列表
export const bpmFundlist = (data) => get({ url: config.bpmFundlistApi, data }); // 获取基金列表
export const bpmFundSharelist = (data) => get({ url: config.fundInfoShareListApi, data }); // 获取基金列表
export const prodTradeseatList = (data) => get({ url: config.prodTradeseatList, data }); // 获取基金列表
export const tradeseatContractlist = (data) => get({ url: config.tradeseatContractlist, data }); // 获取基金列表
export const perfapprList = (data) => get({ url: config.perfapprList, data }); // 通过代码日期获取业绩数据
export const generateemail = (data) => get({ url: config.generateemail, data }); // 业绩经办人邮件生成
export const perfoperatorList = (data) => get({ url: config.perfoperatorList, data }); // 业绩经办人列表
export const perfoperatorAdd = (data) => post({ url: config.perfoperatorAdd, data }); // 业绩经办人新增
export const perfoperatorDel = (data) => get({ url: config.perfoperatorDel, data }); // 业绩经办人删除
export const appritemList = (data) => get({ url: config.appritemList, data }); // 业绩复核列表
export const perfoperatorBatchupdate = (data) =>
  post({ url: config.perfoperatorBatchupdate, data }); // 业绩经办人修改
export const pdmpcommonList = (data) => get({ url: config.pdmpcommonList, data });
export const pdmpcommonGenerate = (data) => get({ url: config.pdmpcommonGenerate, data });
export const generateAll = (data) => get({ url: config.generateAll, data });
export const yiyeExport = (data) => get({ url: config.yiyeExport, data });
export const yiyePreview = (data) => get({ url: config.yiyePreview, data });
export const pdoneList = (data) => get({ url: config.pdoneList, data });
export const pdmpcommonCopytree = (data) => get({ url: config.pdmpcommonCopytree, data });
export const attachmentSave = (data) => pdtPost({ url: config.attachmentSave, data });
export const attachmentDelone = (data) => pdtGet({ url: config.attachmentDelone, data });
export const attachmentList = (data) => pdtGet({ url: config.attachmentList, data });
export const fundlabelSave = (data) => pdtGet({ url: config.fundlabelSave, data });
export const holdyAnno = (data) => download({ url: config.holdyAnno, data });
export const holdyTa = (data) => download({ url: config.holdyTa, data });
export const syncexchholdy = (data) => pdtGet({ url: config.syncexchholdy, data });
export const qdhldycontrdescApi = (data) => pdtPost({ url: config.qdhldycontrdesc, data });
// 公募信息 --------------------------------------------------------------------------end

// 公告 --------------------------------------------------------------------------start
export const listNotice = (data) => get({ url: config.listNoticeApi, data });
export const downloadNotice = (data) => download({ url: config.listNoticeApi, data });
export const saveNotice = (data) => post({ url: config.saveNoticeApi, data });
export const saveNoticeCsrc = (data) => post({ url: config.saveNoticeCsrcApi, data });
export const countbystatus = (data) => get({ url: config.countbystatus, data });
export const delNotice = (data) => post({ url: `${config.delNoticeApi}`, data });
export const detailNotice = (data) => get({ url: config.detailNoticeApi, data });
export const detailMatch = (data) => get({ url: config.detailMatchApi, data }); // 公告模板编辑
export const updateMatch = (data) =>
  post({ url: config.updateMatchApi, data, conf: { useHandleRes: true } }); // 公告模板保存
export const getMatchReceiver = (data) => get({ url: config.getMatchReceiverApi, data }); // 公告模板保存
export const listNoticeTree = (data) => get({ url: config.listNoticeTreeApi, data });
export const noticeMatchfund = (data) => pdtGet({ url: config.noticeMatchfund, data });

export const syncNotice = (data) => get({ url: config.syncNoticeApi, data });
export const listNoticeMatch = (data) => get({ url: config.listNoticeMatchApi, data });
export const saveBatchNotice = (data) => post({ url: config.saveBatchNoticeApi, data });
export const getFundManagerNotice = (data) => get({ url: config.getFundManagerNoticeApi, data });
export const saveFundManagerNotice = (data) => post({ url: config.saveFundManagerNoticeApi, data });
export const readFundManagerXml = (data) => get({ url: config.readFundManagerXmlApi, data });
export const synchronousNotice = (data) => get({ url: config.synchronousApi, data });

export const listImportant = (data) => get({ url: config.listImportantApi, data });
export const saveImportant = (data) => post({ url: config.saveImportantApi, data });
export const listNews = (data) => get({ url: config.listNewsApi, data });
export const saveNews = (data) => post({ url: config.saveNewsApi, data });

export const listDividend = (data) => get({ url: config.listDividendApi, data });
export const detailDividend = (data) => get({ url: config.detailDividendApi, data });
export const delDividendFile = (data) => get({ url: config.delDividendFileApi, data });
export const genDividendFile = (data) => get({ url: config.genDividendFileApi, data });
export const saveDividend = (data) => post({ url: config.saveDividendApi, data });
export const uploadDividendFile = (data) => get({ url: config.uploadDividendFileApi, data });
export const newsorderList = (data) => get({ url: config.newsorderListApi, data });
export const newsorderSave = (data) => post({ url: config.newsorderSaveApi, data });
export const newsfeeList = (data) => get({ url: config.newsfeeListApi, data });
export const newsfeeCalculate = (data) => get({ url: config.newsfeeCalculateApi, data });
export const newsfeeExport = (data) => download({ url: config.newsfeeExportApi, data });
export const newsfeeRule = (data) => get({ url: config.newsfeeRuleApi, data });
export const newsfeeUpdate = (data) => post({ url: config.newsfeeUpdateApi, data });
export const auditList = (data) => get({ url: config.auditListApi, data });
export const abarbeitungList = (data) => get({ url: config.abarbeitungListApi, data });
export const auditListExport = (data) => download({ url: config.auditListExportApi, data });
export const abarbeitungListExport = (data) =>
  download({ url: config.abarbeitungListExportApi, data });
// 公告 --------------------------------------------------------------------------end

// 产品文档 --------------------------------------------------------------------------start

export const listDocTree = (data) => get({ url: config.listDocTreeApi, data });
export const listDocFileList = (data) => get({ url: config.listDocFileListApi, data });
export const listDocHistory = (data) => get({ url: config.listDocHistoryApi, data });

export const saveFile = (data) => post({ url: config.saveFileApi, data });
export const downloadFile = (data) => download({ url: config.downloadFileApi, data });
export const addCatalog = (data) => post({ url: config.addCatalogApi, data });
export const editCatalog = (data) => post({ url: config.editCatalogApi, data });
export const moveCatalog = (data) => post({ url: config.moveCatalogApi, data });
export const delCatalog = (data) => post({ url: config.delCatalogApi, data });
export const updateAgencyTree = (data) => get({ url: config.updateAgencyTreeApi, data });
export const removeFile = (data) => post({ url: config.removeFileApi, data });
export const authPermission = (data) => post({ url: config.authPermissionApi, data });
export const detailPermission = (data) => get({ url: config.detailPermissionApi, data });

export const readAutoNumberFile = (data) => post({ url: config.readAutoNumberFileApi, data });
export const listNoticeType = (data) => get({ url: config.listNoticeTypeApi, data });
export const getNoticeNumber = (data) => get({ url: config.getNoticeNumberApi, data });
export const genAutoNumberFile = (data) =>
  post({ url: config.genAutoNumberFileApi, data, conf: { timeout: 1000000 } }); // 生成pdf设置请求超时时间
export const genAutoNumnerPolling = (data) => get({ url: config.genAutoNumnerPollingApi, data });
export const downloadAutoNumberPdf = (data) =>
  download({ url: config.downloadAutoNumberPdfApi, data });
export const batchReadAutoNumberFile = (data) =>
  post({ url: config.batchReadAutoNumberFileAutoNumberFileApi, data });

export const detailTemplate = (data) => get({ url: config.detailTemplateApi, data });
export const delTemplateMg = (data) => get({ url: config.delTemplateMgApi, data });
export const saveTemplateMg = (data) => post({ url: config.saveTemplateMgApi, data });
export const viewTemplateMg = (data) => get({ url: config.viewTemplateMgApi, data });
export const updateTemplateMg = (data) => post({ url: config.updateTemplateMgApi, data });
export const listTemplateCategory = (data) => get({ url: config.listTemplateCategoryApi, data });
export const saveTemplateCategory = (data) => get({ url: config.saveTemplateCategoryApi, data });
export const listTemplateCategoryHis = (data) =>
  get({ url: config.listTemplateCategoryHisApi, data, headers: { useHandleRes: true } });
export const delTemplateCategory = (data) => get({ url: config.delTemplateCategoryApi, data });
export const listTemplateMg = (data) => get({ url: config.listTemplateMgApi, data });
export const detailTemplateMg = (data) => get({ url: config.detailTemplateMgApi, data });
export const saveTemplateSqlContent = (data) =>
  post({ url: config.saveTemplateSqlContentApi, data });
export const delTemplateSqlContent = (data) => get({ url: config.delTemplateSqlContentApi, data });

export const listSummary = (data) => get({ url: config.listSummaryApi, data });
export const listDirectory = (data) => get({ url: config.listDirectoryApi, data });
export const addDirectory = (data) => get({ url: config.addDirectoryApi, data });
export const dargDirectory = (data) => get({ url: config.dargDirectoryApi, data });
export const updateDirectory = (data) => get({ url: config.updateDirectoryApi, data });
export const delDirectory = (data) => get({ url: config.delDirectoryApi, data });
export const exportSummary = (data) => download({ url: config.exportSummaryApi, data });
export const viewSummary = (data) => get({ url: config.viewSummaryApi, data });
export const exportRisk = (data) => get({ url: config.exportRiskApi, data });

export const listSummaryFile = (data) => get({ url: config.listSummaryFileApi, data });
export const saveSummaryFile = (data) => post({ url: config.saveSummaryFileApi, data });
export const reportSummaryFile = (data) => get({ url: config.reportSummaryFileApi, data });
export const removeSummaryFile = (data) => get({ url: config.removeSummaryFileApi, data });
export const listSummaryFeedbackFund = (data) =>
  get({ url: config.listSummaryFeedbackFundApi, data });
export const listSummaryFeedbackAgency = (data) =>
  get({ url: config.listSummaryFeedbackAgencyApi, data });
export const listSummaryAgency = (data) => get({ url: config.listSummaryAgencyApi, data });

export const listRecruitDirectory = (data) => get({ url: config.listRecruitDirectoryApi, data }); // 招募书
export const saveNewRecruitDirectory = (data) =>
  get({ url: config.saveNewRecruitDirectoryApi, data }); // 招募书
export const saveRecruitTree = (data) => get({ url: config.saveRecruitTreeApi, data }); // 复制招募书结构
export const listRecruit = (data) => get({ url: config.listRecruitApi, data }); // 招募书
export const viewRecruit = (data) => get({ url: config.viewRecruitApi, data }); // 招募书预览
export const exportRecruit = (data) => get({ url: config.exportRecruitApi, data }); // 招募书导出
export const updateTitleNum = (data) => get({ url: config.updateTitleNumApi, data }); // 刷新招募树章节序号
export const sendEmailRecruit = (data) => get({ url: config.sendEmailRecruitApi, data }); // 招募书发送催办邮件

export const genRecruitContent = (data) => get({ url: config.genRecruitContentApi, data }); // 根据模板生成内容
export const genAllRecruitContent = (data) => get({ url: config.genAllRecruitContentApi, data }); // 根据全部模板生成内容
export const importRecruit = (data) => get({ url: config.importRecruitApi, data });

export const saveRecruitContent = (data) => post({ url: config.saveRecruitContentApi, data }); //
export const saveRecruitAllContent = (data) => post({ url: config.saveRecruitAllContentApi, data }); //
export const submitRecruitContent = (data) => post({ url: config.submitRecruitContentApi, data }); //
export const listRecruitApprove = (data) => get({ url: config.listRecruitApproveApi, data }); //
export const saveRecruitExt = (data) => post({ url: config.saveRecruitExtApi, data }); //

export const listRecruitPermission = (data) => get({ url: config.listRecruitPermissionApi, data }); //
export const saveRecruitPermission = (data) => post({ url: config.saveRecruitPermissionApi, data }); //

export const listRecruitUpdateRecord = (data) =>
  get({ url: config.listRecruitUpdateRecordApi, data }); //
export const saveRecruitUpdateRecord = (data) =>
  post({ url: config.saveRecruitUpdateRecordApi, data }); //
export const listRecruitUpdateData = (data) => get({ url: config.listRecruitUpdateDataApi, data });
export const updateSeasonreport = (data) => get({ url: config.updateSeasonreportApi, data });
export const updateRecruitUpdateData = (data) =>
  post({ url: config.updateRecruitUpdateDataApi, data });
export const updateRecruitUpdateRecordStatus = (data) =>
  get({ url: config.updateRecruitUpdateRecordStatusApi, data }); //

export const getProcessDocFileList = (data) => get({ url: config.getProcessDocFileListApi, data });

// 反洗钱评测
export const listAntiMoneyEval = (data) => get({ url: config.listAntiMoneyEvalApi, data });
export const genAntiMoneyEval = (data) => get({ url: config.genAntiMoneyEvalApi, data });
export const analyseAntiMoneyEval = (data) => post({ url: config.analyseAntiMoneyEvalApi, data });
export const downloadAntiMoneyEval = (data) =>
  download({ url: config.downloadAntiMoneyEvalApi, data });
export const getTemplateByType = (data) => get({ url: config.getTemplateByTypeApi, data });
export const antiMoneyEvalFlowInfoSave = (data) =>
  post({ url: config.antiMoneyEvalFlowInfoSave, data });
export const antiMoneyEvalInfoList = (data) => get({ url: config.antiMoneyEvalInfoList, data });
export const antiMoneyEvalInfoExport = (data) =>
  download({ url: config.antiMoneyEvalInfoExport, data });
export const batchInitApproval = (data) => get({ url: config.batchInitApproval, data });
export const batchReApproval = (data) => get({ url: config.batchReApproval, data });
export const copyTemplateByFund = (data) => get({ url: config.copyTemplateByFund, data });
export const queryNewByFundCode = (data) => pdtGet({ url: config.queryNewByFundCode, data });

// 产品文档 --------------------------------------------------------------------------end

// 产品日历 --------------------------------------------------------------------------start
export const listEventTrack = (data) => get({ url: config.listEventTrackApi, data });
export const listEvent = (data) => get({ url: config.listEventApi, data });
export const saveEvent = (data) => post({ url: config.saveEventApi, data });
export const listEventRule = (data) => get({ url: config.listEventRuleApi, data });
export const detaileEvent = (data) => get({ url: config.detaileEventApi, data });
export const listEventBaseDate = (data) => get({ url: config.listEventBaseDateApi, data });
export const listEventFundSetting = (data) => get({ url: config.listEventFundSettingApi, data });

export const listTemplates = (data) => get({ url: config.listTemplatesApi, data });
export const saveRule = (data) => post({ url: config.saveRuleApi, data });
export const detailRule = (data) => get({ url: config.detailRuleApi, data });
export const delRule = (data, id = '') => post({ url: `${config.delRuleApi}/${id}`, data });
export const delEvent = (data, id = '') => post({ url: `${config.delEventApi}/${id}`, data });

// 产品日历 --------------------------------------------------------------------------end

// 消息 --------------------------------------------------------------------------start
export const listMessage = (data) => get({ url: config.listMessageApi, data });
export const removeMessage = (data) => post({ url: config.removeMessageApi, data });
export const updateMessageStatus = (data) => post({ url: config.updateMessageStatusApi, data });
// 消息 --------------------------------------------------------------------------end

// 流程处理 --------------------------------------------------------------------------start
const timestamp = new Date().getTime();
export const getProcessType = (data) =>
  get({
    url: config.getProcessTypeApi,
    data: { ...data, ...{ timestamp, signature: md5(`${timestamp}`) }, catalogName: 'pdt' },
    headers: { sessionId: storage.getToken(), useHandleRes: true },
  });
export const listProcessRequest = (data) =>
  get({
    url: config.listProcessRequestApi,
    data: { ...data, ...{ timestamp, signature: md5(`${timestamp}`) } },
    headers: { sessionId: storage.getToken(), useHandleRes: true },
  });
export const listProcessApprove = (data) =>
  get({
    url: config.listProcessApproveApi,
    data: { ...data, ...{ timestamp, signature: md5(`${timestamp}`) } },
    headers: { sessionId: storage.getToken(), useHandleRes: true },
  });
export const listProcessTodo = (data) =>
  get({
    url: config.listProcessTodoApi,
    data: { ...data, ...{ timestamp, signature: md5(`${timestamp}`) } },
    headers: { sessionId: storage.getToken(), useHandleRes: true },
  });
export const listProcessRead = (data) =>
  get({
    url: config.listProcessReadApi,
    data: { ...data, ...{ timestamp, signature: md5(`${timestamp}`) } },
    headers: { sessionId: storage.getToken(), useHandleRes: true },
  });
export const listProcessAll = (data) =>
  get({
    url: config.listProcessAllApi,
    data: { ...data, ...{ timestamp, signature: md5(`${timestamp}`) } },
    headers: { sessionId: storage.getToken(), useHandleRes: true },
  });
export const listProcessDraft = (data) =>
  get({
    url: config.listProcessDraftApi,
    data: { ...data, ...{ timestamp, signature: md5(`${timestamp}`) } },
    headers: { sessionId: storage.getToken(), useHandleRes: true },
  });

export const checkAgecyAttr = (data) => post({ url: config.checkAgecyAttrApi, data });
export const agencyExport = (data) => download({ url: config.agencyExport, data, method: 'post' });
export const minifundLiquidFund = (data) => pdtGet({ url: config.minifundLiquidFund, data });
export const processannopub = (data) => get({ url: config.processannopub, data });
// 流程处理 --------------------------------------------------------------------------end

// 系统处理 --------------------------------------------------------------------------start
export const pdtconfigList = (data) => get({ url: config.pdtconfigListApi, data });
export const pdtconfigDetail = (data) => get({ url: config.pdtconfigDetailApi, data });
export const pdtconfigInsert = (data) => post({ url: config.pdtconfigInsertApi, data });
export const pdtconfigUpdate = (data) => post({ url: config.pdtconfigUpdateApi, data });
export const pdtconfigDel = (data) => get({ url: config.pdtconfigDelApi, data });
export const listLogs = (data) => get({ url: config.listLogs, data });
// 系统处理 --------------------------------------------------------------------------end

// 通用维护 --------------------------------------------------------------------------start
// 通用查询
export const comeleQuery = (data) => get({ url: config.comeleQuery, data });
export const comEleDetail = (data) => get({ url: config.comEleDetailApi, data });
export const comEleView = (data) => get({ url: config.comEleViewApi, data });
export const comElePreview = (data) => get({ url: config.comElePreviewApi, data });
export const comEleSave = ({ type, data }) =>
  post({ url: `${config.comEleSaveApi}/${type}`, data });
export const comEleApprove = (data) => get({ url: config.comEleApproveApi, data });
export const comEleElementreview = (data) => get({ url: config.comEleElementreviewApi, data });

// 功能
export const comEleFuncList = (data) => get({ url: config.comEleFuncListApi, data });
export const comEleFuncDetail = (data) => get({ url: config.comEleFuncDetailApi, data });
export const comEleFuncSave = (data) => post({ url: config.comEleFuncSaveApi, data });
export const comEleFuncRemove = (data) => get({ url: config.comEleFuncRemoveApi, data });

// 要素
export const comEleElementList = (data) => get({ url: config.comEleElementListApi, data });
export const comEleElementDetail = (data) => get({ url: config.comEleElementDetailApi, data });
export const comEleElementSave = (data) => post({ url: config.comEleElementSaveApi, data });
export const comEleElementRemove = (data) => get({ url: config.comEleElementRemoveApi, data });

export const comEleCurElementList = (data) => get({ url: config.comEleCurElementListApi, data });
export const comEleElementQuery = (data) => get({ url: config.comEleElementQueryApi, data });
export const comEleDimensionQuery = (data) => get({ url: config.comEleDimensionQueryApi, data });
export const comEleElementPermissionSave = (data) =>
  post({ url: config.comEleElementPermissionSaveApi, data });
export const comEleVersionlist = (data) => post({ url: config.comEleVersionlistApi, data });

// 功能-要素
export const comEleFuncElementList = (data) => get({ url: config.comEleFuncElementListApi, data });
export const comEleFuncElementSave = (data) => post({ url: config.comEleFuncElementSaveApi, data });

// 模块
export const comEleModuleTreeList = (data) => get({ url: config.comEleModuleTreeListApi, data });
export const comEleModuleElementDetail = (data) =>
  get({ url: config.comEleModuleElementDetailApi, data });
export const comEleModuleSave = (data) => post({ url: config.comEleModuleSaveApi, data });
export const comEleModuleRemove = (data) => get({ url: config.comEleModuleRemoveApi, data });

export const comEleModuleQuery = (data) => get({ url: config.comEleModuleQueryApi, data });

// 角色
export const comEleRoleTreeList = (data) => get({ url: config.comEleRoleTreeListApi, data });
export const comEleRoleSave = (data) => post({ url: config.comEleRoleSaveApi, data });
export const comEleRoleDetail = (data) => get({ url: config.comEleRoleDetailApi, data });
export const comEleRoleRemove = (data) => get({ url: config.comEleRoleRemoveApi, data });

export const comElePermissionDetail = (data) =>
  get({ url: config.comElePermissionDetailApi, data });
export const comEleRoleMappingList = (data) => get({ url: config.comEleRoleMappingListApi, data });
export const comEleRoleElementList = (data) => get({ url: config.comEleRoleElementListApi, data });
// 要素-角色
export const comEleElementRoleSave = (data) => post({ url: config.comEleElementRoleSaveApi, data });

// 审批
export const comEleReviewList = (data) => get({ url: config.comEleReviewListApi, data });
// 数据配置
export const sqlmodelSave = (data) => pdtPost({ url: config.sqlmodelSave, data });
export const sqlmodelDel = (data) => pdtPost({ url: config.sqlmodelDel, data });
// 参数订阅
export const subscribeTitleSave = (data) => pdtPost({ url: config.subscribeTitleSave, data });
export const subscribeTitleDelete = (data) => pdtGet({ url: config.subscribeTitleDelete, data });

// 通用维护 --------------------------------------------------------------------------end

export const assesinfoSave = (data) => post({ url: config.assesinfoSave, data });
export const assesinfoDel = (data) => get({ url: config.assesinfoDel, data });
export const annoConfagain = (data) => post({ url: config.annoConfagain, data });
export const annoReturn = (data) => post({ url: config.annoReturn, data });
export const fundlifeCycleList = (data) => pdtGet({ url: config.fundlifeCycleList, data });

// 信息披露规则录入
export const disclosureRuleSave = (data) => pdtPost({ url: config.disclosureRuleSave, data }); // 保存信息披露规则
export const disclosureRuleEnable = (data) => pdtGet({ url: config.disclosureRuleEnable, data }); // 启用信息披露规则
export const disclosureRuleDisable = (data) => pdtGet({ url: config.disclosureRuleDisable, data }); // 禁用信息披露规则
export const disclosureRuleDelete = (data) => pdtGet({ url: config.disclosureRuleDelete, data }); // 删除信息披露规则
export const ossBaseFileInfoList = (data) => pdtPost({ url: config.ossBaseFileInfoListApi, data }); // 查询oss文件列表

// 基金/投资经理离任 --------------------------------------------------------------------------
export const listManagerLeaves = (data) => get({ url: config.listManagerLeavesApi, data });
export const detailFundManageLeave = (data) => post({ url: config.detailFundManageLeaveApi, data });
export const saveBasicFundManageLeave = (data) =>
  post({ url: `${config.saveBasicFundManageLeaveApi}/${data.id}`, data });
export const saveViolationFundManageLeave = (data) =>
  post({ url: config.saveViolationFundManageLeaveApi, data });
export const saveBusinessFundManageLeave = (data) =>
  post({ url: config.saveBusinessFundManageLeaveApi, data });
export const saveFinanceFundManageLeave = (data) =>
  post({ url: config.saveFinanceFundManageLeaveApi, data });
export const exportFundManageLeave = (data) =>
  download({ url: config.exportFundManageLeaveApi, data });
export const saveShareFundManageLeave = (data) =>
  post({ url: config.saveShareFundManageLeaveApi, data });
export const saveResultsManageLeave = (data) =>
  post({ url: config.saveResultsManageLeaveApi, data });
export const saveFundsManageLeave = (data) => post({ url: config.saveFundsManageLeaveApi, data });
export const updateBasicManageLeave = (data) =>
  post({ url: `${config.updateBasicManageLeaveApi}/${data.id}`, data });
export const updateFinanceFundManageLeave = (data) =>
  post({ url: config.updateFinanceFundManageLeaveApi, data });
export const updateBusinessFundManageLeave = (data) =>
  post({ url: config.updateBusinessFundManageLeaveApi, data });
export const updateFundIncomeFundManageLeave = (data) =>
  post({ url: config.updateFundIncomeFundManageLeaveApi, data });
export const updateFundFfeeFundManageLeave = (data) =>
  post({ url: config.updateFundFfeeFundManageLeaveApi, data });
export const updateShareFundManageLeave = (data) =>
  post({ url: config.updateShareFundManageLeaveApi, data });
export const updatepPrformanceAppraisal = (data) =>
  post({ url: `${config.updatepPrformanceAppraisalApi}/${data.id}`, data });
