import React, { useEffect, useState } from 'react';
import { Button, Popconfirm, type ButtonProps, type PopconfirmProps } from 'antd';
import { cacheGet, download as upmDownload } from '@cerdo/cerdo-utils/lib/upmHttp';
import { userPermissionApi } from '@cerdo/cerdo-utils/lib/config';

interface IButton extends ButtonProps {
  permissionId?: string;
  /** 点击按钮，弹出删除二次确认提示 */
  deleteConfirm?: boolean;
  popconfirmProps?: PopconfirmProps;

  download?: {
    url: string;
    filename: string;
  };
}

const Index: React.FC<IButton> = ({
  children,
  permissionId,
  deleteConfirm,
  disabled,
  popconfirmProps,
  download,
  onClick,
  ...rest
}) => {
  const [hasPermission, setHasPermission] = useState<boolean>(false);

  const fetchPermission = async () => {
    if (!permissionId) {
      return;
    }

    const res = await cacheGet({ url: userPermissionApi, data: { permissionids: permissionId } });
    const hasPermission = res.data?.[0]?.haspermission === 1;
    if (hasPermission) {
      setHasPermission(true);
    }
  };

  const handleClick = (e) => {
    if (deleteConfirm) {
      return;
    }

    if (download) {
      upmDownload({ data: { filename: download.filename }, url: download.url });
      return;
    }

    onClick(e);
  };

  useEffect(() => {
    fetchPermission();
  }, []);

  if (permissionId && !hasPermission) {
    return null;
  }

  return (
    <Popconfirm
      title="确定要删除吗？"
      onConfirm={onClick}
      disabled={disabled || !deleteConfirm}
      {...popconfirmProps}
    >
      <Button size="small" disabled={disabled} onClick={handleClick} {...rest}>
        {children}
      </Button>
    </Popconfirm>
  );
};

export default Index;
