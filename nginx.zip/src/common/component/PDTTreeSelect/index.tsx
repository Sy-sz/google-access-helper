import React, { useEffect, useState } from 'react';
import { type TreeSelectProps, TreeSelect, Tooltip, Space, Tag } from 'antd';
import { isEmpty } from 'lodash';
import { dictTree } from '@cerdo/cerdo-utils/lib/api';

interface DictParams {
  internalFlag?: '1'; // 是否内部，传1数据会剔除合作公司
  deptName?: string; // 部门名称
  deptId?: string; // 部门id
}

interface IProps extends TreeSelectProps<any> {
  dictId?: string;
  dictParams?: DictParams;
  title?: React.ReactNode;
  parentSelectable?: boolean;
  /** 点父节点文字展开/收起子项 */
  expandByTitle?: boolean;
}

const index: React.FC<IProps> = (props) => {
  const {
    dictId,
    title,
    dictParams,
    parentSelectable,
    expandByTitle = true,
    ...otherProps
  } = props;
  const [options, setOptions] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState([]);

  const expandSubTree = (value) => {
    setExpandedKeys((prevKeys) => {
      const idx = prevKeys.findIndex((item) => item === value);
      if (idx === -1) {
        return [...prevKeys, value];
      }
      return prevKeys.filter((item) => item !== value);
    });
  };

  const formatTreeData = (data) => {
    data.forEach((item) => {
      item.title = item.dictLabel;
      item.value = item.dictValue;
      item.selectable = parentSelectable ? true : !item.children?.length;
      if (item.children?.length) {
        if (expandByTitle) {
          item.title = <div onClick={() => expandSubTree(item.value)}>{item.title}</div>;
        }
        formatTreeData(item.children);
      }
    });
    return data;
  };

  const fetchDictData = async () => {
    const params = { dictId };
    if (!isEmpty(dictParams)) {
      Object.assign(params, { queryParams: dictParams });
    }
    const res = await dictTree(params);
    const child = res.data.children;
    if (!child?.length) {
      return;
    }

    const treeData = formatTreeData(child);
    setOptions(treeData);
  };

  const renderMaxTagPlaceholder = (values) => (
    <Tooltip
      title={
        <Space direction="vertical">
          {values.map((a) => (
            <Tag key={a.key}>{a.label}</Tag>
          ))}
        </Space>
      }
    >
      +{values.length} ...
    </Tooltip>
  );

  useEffect(() => {
    if (dictId) {
      fetchDictData();
    }
  }, []);

  return (
    <>
      {title && <span style={{ display: 'inline-block', marginRight: 8 }}>{title} :</span>}
      <TreeSelect
        showSearch
        showArrow
        treeData={options}
        style={{ width: 200 }}
        maxTagCount={1}
        maxTagTextLength={5}
        treeNodeFilterProp="title"
        treeExpandedKeys={expandedKeys}
        placeholder={title ? `请选择${title}` : '请选择'}
        onTreeExpand={setExpandedKeys}
        maxTagPlaceholder={renderMaxTagPlaceholder}
        {...otherProps}
      />
    </>
  );
};

export default index;
