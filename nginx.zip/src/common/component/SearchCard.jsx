/**
 * 字典查询 传递dictid
 */
import React, { Component } from 'react';
import { Card, Row, Form } from 'antd';
import { SearchButton } from '@cerdo/cerdo-design';
import { DownOutlined, UpOutlined } from '@ant-design/icons';
import { uniqueId, isFunction } from 'lodash';

class SearchCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      expand: props.expand || false,
    };
  }

  // 是否展开
  handleIsShowClick = () => {
    this.setState(
      {
        expand: !this.state.expand,
      },
      () => {
        this.props?.onExpand?.(this.state.expand);
      },
    );
  };

  onReset = () => {
    const { onReset, onSearch } = this.props;
    this.form.resetFields();
    if (isFunction(onReset)) {
      onReset();
      return;
    }
    onSearch();
  };

  render() {
    const {
      children,
      title,
      size,
      onSearch,
      renderTop,
      showNum = 3,
      formProps,
      ...otherProps
    } = this.props;
    const { expand } = this.state;

    // 将原数组重新定义
    // const newChildren = isArray(children) ? [...children] : [children];
    const formClassName = uniqueId('search-card-form-');
    let className = 'ant-card-search';
    if (size === 'small') {
      className += ' small-card';
    }

    const expandText = expand ? '收起' : '展开';
    const ExpandIcon = expand ? UpOutlined : DownOutlined;
    const showExpand = Array.isArray(children) && children.filter(Boolean).length > showNum;

    return (
      <Card bordered={false} title={title} className={className} {...otherProps}>
        {isFunction(renderTop) && renderTop()}
        <Form
          labelCol={{ span: 6 }}
          wrapperCol={{ span: 14 }}
          {...formProps}
          ref={(ref) => {
            this.form = ref;
          }}
          onFinish={onSearch}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <Row className={formClassName} style={{ width: 'calc(100% - 192px)' }}>
              {children}
            </Row>
            <div style={{ display: 'flex', alignItems: 'end' }}>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                {showExpand && (
                  <a onClick={this.handleIsShowClick}>
                    {expandText}
                    <ExpandIcon style={{ fontSize: 10, marginLeft: 2, marginRight: 16 }} />
                  </a>
                )}
                <SearchButton onReset={this.onReset} />
              </div>
            </div>
          </div>
        </Form>
        <style>
          {`
            .${formClassName}>.ant-col:nth-child(n + ${showNum + 1}){
              ${expand ? '' : 'display: none;'}
            }
          `}
        </style>
      </Card>
    );
  }
}

export default SearchCard;
