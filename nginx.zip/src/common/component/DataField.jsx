import PropTypes from 'prop-types';
import React from 'react';
import { Tooltip } from 'antd';
import { IssuesCloseOutlined } from '@ant-design/icons';
import moment from 'moment';

const DataField = (props) => {
  const style = {
    position: 'absolute',
    left: typeof props.mustIcon === 'function' ? '96.4%' : '89%',
    top: 0,
    color: 'red',
    zIndex: 10,
    display: 'inline-flex',
    alignItems: 'center',
    height: '100%',
  };

  const Tips = () => {
    return (
      <Tooltip
        placement="top"
        title={
          typeof props.mustIcon === 'function'
            ? props.mustIcon().description
            : props.mustIcon.description
        }
      >
        <IssuesCloseOutlined style={style} />
      </Tooltip>
    );
  };
  if (props.editable) {
    return (
      <div style={{ position: 'relative' }}>
        <div>{props.children}</div>
        {typeof props.mustIcon === 'function' ? (
          props.mustIcon() ? (
            <Tips />
          ) : null
        ) : props.mustIcon ? (
          <Tips />
        ) : null}
      </div>
    );
  }

  if (
    props.value &&
    typeof props.value === 'string' &&
    (props.value.indexOf('null') !== -1 || props.value.indexOf('undefined') !== -1)
  ) {
    return '-';
  }
  if (moment.isMoment(props.value) && props.momentFormat) {
    const format = props.momentFormat === true ? 'YYYY-MM-DD' : props.momentFormat;
    return props.value.format(format);
  }
  return props.value || '-';
};

DataField.propTypes = {
  editable: PropTypes.bool,
  value: PropTypes.any,
  children: PropTypes.element,
  momentFormat: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
};

DataField.defaultProps = {
  editable: true,
  value: '-',
};

export default DataField;
