import React from 'react';
import { Card, type CardProps } from 'antd';
import classnames from 'classnames';
import { PDTEmpty } from '@/common/component';

interface ListCardProps extends CardProps {
  showEmpty?: boolean;
}

const ListCard: React.FC<ListCardProps> = (props) => {
  const { showEmpty, className, children, ...otherProps } = props;

  return (
    <Card bordered={false} className={classnames('ant-card-list', className)} {...otherProps}>
      {showEmpty ? <PDTEmpty /> : children}
    </Card>
  );
};

export default ListCard;
