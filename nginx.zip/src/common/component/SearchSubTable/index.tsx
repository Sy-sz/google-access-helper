import React from 'react';
import { get } from 'lodash';
import { SearchAgGridTable } from '@cerdo/cerdo-design';
import { type IColumnDefs } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import { type TableConfig } from 'ag-grid-react';

interface SubTableProps {
  /** 子表格所在父表格的那一行数据 */
  data: Record<string, any>;
  /** 子表格的数据字段名，默认children */
  subDataKey?: 'children' | string;
  columnDefs: IColumnDefs;
  tableConfig?: Omit<TableConfig, 'columnDefs'>;
  wrapperStyle?: React.CSSProperties;
}

/** SearchAgGridTable 子表格 */
const Index: React.FC<SubTableProps> = ({
  data,
  subDataKey = 'children',
  columnDefs,
  tableConfig,
  wrapperStyle,
}) => {
  return (
    <div
      style={{
        paddingLeft: 30,
        paddingBottom: 10,
        width: '40%',
        backgroundColor: 'var(--card-bg)',
        ...wrapperStyle,
      }}
    >
      <SearchAgGridTable
        tableConfig={{
          height: 40 * (data.children?.length || 4) + 40,
          defaultColDef: { flex: 1 },
          pagination: false,
          rowData: get(data, subDataKey, []),
          statusBar: null,
          ...tableConfig,
          columnDefs,
        }}
      />
    </div>
  );
};

export default Index;
