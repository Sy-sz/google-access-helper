import React, { useMemo, useRef, useState, useImperativeHandle } from 'react';
import { Tag } from 'antd';
import { cloneDeep, isPlainObject, merge } from 'lodash';
import { SearchAgGridTable } from '@cerdo/cerdo-design';
import type {
  ISearchAgGridTable,
  ITableConfig,
  SearchFormConfig,
} from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import { CreatePortal } from '@/common/component';

/** 序号列 */
const serialColumn = {
  headerName: '序号',
  hideInSearch: true,
  width: 80,
  minWidth: 80,
  sortable: false,
  pinned: 'left',
  valueGetter: 'node.rowIndex + 1',
  checkboxSelection: true,
  showDisabledCheckboxes: true,
  headerCheckboxSelection: true,
};

const defaultTableConfig: () => ITableConfig = () => ({
  cacheBlockSize: 10000,
  autoHeight: true,
  suppressCellFocus: false,
  enableRangeSelection: false,
  suppressRowClickSelection: true,
  defaultColDef: { filter: false, unSortIcon: true },
});
const defaultSearchFormConfig: () => SearchFormConfig = () => ({
  searchColNum: 4,
  defaultCollapsed: false,
});

interface SelectStatus {
  selectAll: boolean;
  selectedRows: any[];
}
interface PDTTableConfig extends Omit<ITableConfig, 'onSelectionChanged'> {
  onSelectionChanged?: (e: any, selectStatus?: SelectStatus) => void;
}

interface PDTSearchAgGridTableProps extends Omit<ISearchAgGridTable, 'ITableConfig'> {
  /** 是否展示序号列， 默认是, 也可以传对象，即序号列的配置 */
  showSerialColumn?: boolean | Record<string, any>;
  rowId?: string;
  onFormatParams?: <T>(params: T) => T;
  onFormatRowData?: <T>(data: T) => T;
  onLoadData?: (data: any[], total: number) => void;
  tableConfig: PDTTableConfig;
}

const PDTSearchAgGridTable: React.FC<PDTSearchAgGridTableProps> = React.forwardRef((props, ref) => {
  const {
    showSerialColumn = true,
    rowId,
    tableConfig,
    searchFormConfig,
    actionBtns,
    method = 'get',
    onFormatParams,
    onFormatRowData,
    onLoadData,
    ...otherProps
  } = props;
  const { columnDefs = [], rowModelType, onSelectionChanged, onGridReady } = tableConfig;

  const gridRef = useRef(null);
  const searchTableRef = useRef(null);
  const [pageInfo, setPageInfo] = useState({ currentPage: 1, pageSize: 20 });
  const [currentDataMap, setCurrentDataMap] = useState(new Map()); // 缓存所有请求过的数据
  const [selectAll, setSelectAll] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [total, setTotal] = useState(0);
  const serverSide = rowModelType === 'serverSide';

  /** 格式化入参； 1.取分页参数 */
  const onFormatParamsDefault = (params) => {
    const { currentPage, pageSize } = params;
    setPageInfo({ currentPage, pageSize });

    if (typeof onFormatParams === 'function') {
      return onFormatParams(params);
    }

    return params;
  };

  /** 格式化数据； 1. 缓存所有请求过的数据 */
  const onFormatRowDataDefault = (data) => {
    if (serverSide && rowId) {
      const newCurrentDataMap = data.reduce((acc, cur) => {
        acc.set(cur[rowId], cur);
        return acc;
      }, currentDataMap);
      setCurrentDataMap(newCurrentDataMap);
    }

    if (typeof onFormatRowData === 'function') {
      return onFormatRowData(data);
    }

    return data;
  };

  /** onLoadData回调； 1. 取total */
  const onLoadDataDefault = (data, total) => {
    setTotal(total);
    if (typeof onLoadData === 'function') {
      onLoadData(data, total);
    }
  };

  /** selection事件； 1. 给事件加第二个参数 2. 把选中状态存下来 */
  const onSelectionChangedDefault = (e) => {
    let selectAll = false;
    let toggledNodes = [];
    if (serverSide) {
      const selection = e.api.getServerSideSelectionState();
      selectAll = selection.selectAll;
      toggledNodes = selection.toggledNodes;
    } else {
      toggledNodes = e.api.getSelectedRows();
    }
    setSelectAll(selectAll);
    setSelectedRows(toggledNodes);
    if (typeof onSelectionChanged !== 'function') {
      return;
    }

    let selectedRows = toggledNodes;
    if (serverSide) {
      selectedRows = [];
      for (const [key, value] of currentDataMap) {
        if (toggledNodes.includes(key)) {
          selectedRows.push(value);
        }
      }
    }

    onSelectionChanged(e, { selectAll, selectedRows });
  };

  const onGridReadyDefault = (grid) => {
    gridRef.current = grid;
    if (typeof onGridReady === 'function') {
      onGridReady(grid);
    }
  };

  const tableConfigMerged = useMemo(() => {
    const serialCol: any = { ...serialColumn };
    const currTableConfig = cloneDeep(tableConfig);
    // 是否展示序号
    if (showSerialColumn) {
      if (serverSide) {
        const { currentPage = 1, pageSize = 20 } = pageInfo || {};
        serialCol.valueGetter = `node.rowIndex + 1 + ${pageSize} * (${currentPage} - 1)`;
      }
      if (isPlainObject(showSerialColumn)) {
        Object.assign(serialCol, showSerialColumn);
      }
      currTableConfig.columnDefs = [serialCol, ...columnDefs];
    }

    // 1. 根据rowId添加tabconfig.getRowId 2. 给onSelectionChanged事件增加第二个参数
    if (serverSide && rowId) {
      if (!currTableConfig.getRowId) {
        currTableConfig.getRowId = (params) => params.data[rowId];
      }
    }

    currTableConfig.onSelectionChanged = onSelectionChangedDefault;
    currTableConfig.onGridReady = onGridReadyDefault;

    return merge(defaultTableConfig(), currTableConfig);
  }, [JSON.stringify(tableConfig), JSON.stringify(pageInfo)]);

  const searchFormConfigMerged = useMemo(() => {
    const currSearchFormConfig = cloneDeep(searchFormConfig) || {};
    currSearchFormConfig.optionRender = ({ form, onSearch }, btnArr) => {
      return btnArr.map(({ type, props, key }) => {
        const newProps = { ...props };
        if (key === 'reset') {
          newProps.onClick = () => {
            form.resetFields();
            onSearch({ currentPage: 1 });
            gridRef.current.api.deselectAll();
          };
        }
        return React.createElement(type, newProps);
      });
    };

    const defaultConfig = {
      ...defaultSearchFormConfig(),
      formProps: {
        onFinish: (values) => {
          searchTableRef.current?.onSearch({ ...values, currentPage: 1 });
          gridRef.current.api.deselectAll();
        },
      },
    };

    return merge(defaultConfig, currSearchFormConfig);
  }, [JSON.stringify(searchFormConfig)]);

  useImperativeHandle(ref, () => searchTableRef.current || {});

  return (
    <>
      {(tableConfigMerged.columnDefs[0] as any)?.checkboxSelection && (
        <CreatePortal container=".search-ag-grid-table .search-table .search-table-header">
          <span>
            <Tag color="warning">
              已选中{selectAll ? total - selectedRows.length : selectedRows.length}条
            </Tag>
          </span>
        </CreatePortal>
      )}
      <SearchAgGridTable
        resetAutoQuery
        method={method}
        ref={searchTableRef}
        actionBtns={actionBtns || [<span key="null" />]}
        tableConfig={tableConfigMerged}
        searchFormConfig={searchFormConfigMerged}
        onFormatParams={onFormatParamsDefault}
        onFormatRowData={onFormatRowDataDefault}
        onLoadData={onLoadDataDefault}
        {...otherProps}
      />
    </>
  );
});

export default PDTSearchAgGridTable;
