import { type ReactNode, useState, useEffect } from 'react';
import { api } from '@cerdo/cerdo-utils';

interface PDTTextProps {
  value: string;
  dictId?: string;
}

/** 接收字典id和value，返回label */
const PDTText: ReactNode = (props: PDTTextProps) => {
  const { dictId, value } = props;
  const [data, setData] = useState<Record<string, any>>({});

  useEffect(() => {
    if (!dictId) {
      return;
    }

    api.dictTree({ dictId }).then((res) => {
      const dataMap = res.data?.children.reduce((acc, { dictLabel, dictValue }) => {
        acc[dictValue] = dictLabel;
        return acc;
      }, {});
      setData(dataMap);
    });
  }, []);

  if (!dictId || typeof value !== 'string') {
    return value || null;
  }

  return data[value] || null;
};

export default PDTText;
