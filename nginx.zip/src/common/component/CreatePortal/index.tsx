import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';

interface CreatePortalType {
  container: string;
}

const Index: React.FC<CreatePortalType> = (props) => {
  const [isMount, setIsMount] = useState(false);

  useEffect(() => {
    const container = document.querySelector(props.container);
    if (!container) {
      console.error(`CreatePortal: "${props.container}" 不存在`);
      return;
    }

    setIsMount(true);
  }, []);

  return isMount && createPortal(props.children, document.querySelector(props.container));
};

export default Index;
