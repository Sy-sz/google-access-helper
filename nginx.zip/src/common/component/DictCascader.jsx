/**
 * 字典查询 传递dictid
 */
import React, { Component } from 'react';
import { Cascader } from 'antd';
import { listDictionary } from '@cerdo/cerdo-utils/lib/api';
import { toOptionsArrayNoKey } from '@cerdo/cerdo-utils/lib/array';
import { fn } from '@cerdo/cerdo-utils';

class DictCascader extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: [],
        };
        this.queryDictionaryData();
    }

    queryDictionaryData = () => {
        const { dictid } = this.props;
        if (!dictid) { return; }
        listDictionary({ dictids: dictid }).then((result) => {
            if (fn.checkResponse(result)) {
                this.setState({
                    data: result.data[0].children,
                });
            }
        });
    }

    render() {
        const { data } = this.state;
        const {
            id, children, dictid, optionLabel = 'name', optionValue = 'name',
            ...otherProps
        } = this.props;
        return (
            <Cascader
                allowClear
                showSearch
                style={{ width: 200 }}
                placeholder="请选择"
                options={Array.isArray(data) && toOptionsArrayNoKey(data, optionLabel, optionValue)}
                {...otherProps}
            />
        );
    }
}

export default (DictCascader);
