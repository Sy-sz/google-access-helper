/**
 * 比如多个邮箱拼接，只展示第一个，利用popover展示其余的，支持一键复制
 */

import React from 'react';
import { Popover, Tag, Space, Typography } from 'antd';
import { copyText } from '@/utils';
import styles from './style.module.less';

const { Paragraph } = Typography;

const PopoverItem = (props) => {
  const { children, separator = ';' } = props;

  const childList = children?.split(separator);

  if (!childList) {
    return null;
  }

  if (childList.length === 1) {
    return <Tag>{childList[0]}</Tag>;
  }

  const content = () => (
    <Space direction="vertical">
      <Paragraph copyable={{ tooltips: false }} onClick={() => copyText(childList.join('\n'))} />
      {childList.map((e) => (
        <Tag key={e}>{e}</Tag>
      ))}
    </Space>
  );

  return (
    <Popover content={content} overlayClassName={styles.popStyle}>
      <Tag>{childList[0]}</Tag>
      {childList.length > 1 && <Tag>+{childList.length - 1}...</Tag>}
    </Popover>
  );
};

export default PopoverItem;
