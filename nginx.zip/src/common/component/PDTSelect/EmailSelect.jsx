import React, { useEffect, useState } from 'react';
import { Select } from 'antd';
import { fn } from '@cerdo/cerdo-utils';
import { listDictionary } from '@cerdo/cerdo-utils/lib/api';

const dictids = '1509fba8-d093-4213-ab85-df02dc24020e';
// const emailReg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((.[a-zA-Z0-9_-]{2,3}){1,2})$/

const List = (props) => {
  const [options, setOptions] = useState([]);
  const [domainList, setDomainList] = useState([]);

  const onSearch = (e) => {
    if (!e) {
      setOptions([]);
      return;
    }

    const [val] = e.split('@');
    const opts = domainList.map((domain) => ({
      value: `${val}@${domain}`,
      label: `${val}@${domain}`,
    }));
    setOptions(opts);
  };

  const fetchEmailDomain = () => {
    listDictionary({ dictids }).then((res) => {
      if (fn.checkResponse(res)) {
        setDomainList(res.data?.[0]?.children?.map((e) => e.value) ?? []);
      }
    });
  };

  useEffect(() => {
    fetchEmailDomain();
  }, []);

  return (
    <div>
      <Select
        mode="tags"
        options={options}
        onSearch={onSearch}
        placeholder="请输入邮箱"
        style={{ width: '100%' }}
        {...props}
      />
    </div>
  );
};

export default List;
