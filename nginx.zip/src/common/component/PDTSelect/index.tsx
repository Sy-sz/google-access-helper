import React, { useEffect, useState } from 'react';
import { unstable_batchedUpdates } from 'react-dom';
import { Select, Space, Tooltip, Tag, type SelectProps } from 'antd';
import { isEmpty, pick } from 'lodash';
import { type SelectValue } from 'antd/lib/select';
import { dictTree } from '@cerdo/cerdo-utils/lib/api';

export interface DictRawData {
  dictLabel: string;
  dictValue: string;
  [key: string]: any;
}
type DictParamsKey =
  | 'deptId'
  | 'deptIds'
  | 'status'
  | 'userName'
  | 'account'
  | 'id'
  | 'internalFlag';
type DictParams = {
  [key in DictParamsKey as `${key}`]?: string;
};

interface IProps extends SelectProps<SelectValue> {
  dictId?: string;
  dictParams?: DictParams;
  /** 下拉框第一项为全部，值为空字符 */
  showAll?: boolean;
  title?: React.ReactNode;
  /** 是否把字典接口中除label、value以外的字段放到options中 */
  showOtherProps?: boolean | string[];
  formatRawData?: (rawData: DictRawData[]) => DictRawData[];
}

const index: React.FC<IProps> = ({
  dictId,
  showAll,
  title,
  value,
  mode,
  showArrow = true,
  showOtherProps = false,
  dictParams,
  maxTagTextLength,
  options: optionsProps,
  onChange,
  formatRawData,
  ...otherProps
}) => {
  const [options, setOptions] = useState([]);
  const [valueMap, setValueMap] = useState({});
  const maxTagLen = maxTagTextLength || (showArrow ? 5 : 6);

  const setOptionLabelProp = (label) => (
    <span title={label}>
      {label.slice(0, maxTagLen)}
      {label.length > maxTagLen ? '...' : null}
    </span>
  );

  /** 查 字典 */
  const fetchDictData = async () => {
    const params = { dictId };
    if (!isEmpty(dictParams)) {
      Object.assign(params, { queryParams: dictParams });
    }
    const res = await dictTree(params);
    let child = res.data.children as DictRawData[];
    if (!child?.length) {
      return;
    }

    if (typeof formatRawData === 'function') {
      child = formatRawData(child);
    }
    const vMap = {};
    const options = child.map(({ dictLabel, dictValue, ...otherProps }) => {
      const obj: any = {
        label: dictLabel,
        value: dictValue,
        optionLabelProp: setOptionLabelProp(dictLabel),
      };
      vMap[dictValue] = dictLabel;
      if (showOtherProps === true) {
        Object.assign(obj, otherProps);
      }
      if (Array.isArray(showOtherProps) && showOtherProps.length) {
        Object.assign(obj, pick(otherProps, showOtherProps));
      }
      return obj;
    });

    if (showAll) {
      options.unshift({ label: '全部', value: '' });
    }
    unstable_batchedUpdates(() => {
      setOptions(options);
      setValueMap(vMap);
    });
  };

  const onSelectChange = (value, option) => {
    if (typeof onChange !== 'function') {
      return;
    }

    if (!showAll || mode !== 'multiple') {
      onChange(value, option);
      return;
    }

    if (!value.length) {
      onChange([], option);
      return;
    }

    const val = value.at(-1) === '' ? [''] : value.filter(Boolean);
    onChange(val, option);
  };

  const renderMaxTagPlaceholder = (values) => (
    <Tooltip
      title={
        <Space direction="vertical">
          {values.map((a) => (
            <Tag key={a.key}>{valueMap[a.value]}</Tag>
          ))}
        </Space>
      }
    >
      +{values.length} ...
    </Tooltip>
  );

  useEffect(() => {
    if (dictId) {
      fetchDictData();
    }
  }, []);

  /** 设置 optionLabelProp， TODO: antd升级后可删除 */
  useEffect(() => {
    if (optionsProps?.length) {
      const vMap = {};
      const options = optionsProps.map((item) => {
        const newItem = { ...item };
        vMap[item.value] = item.label;
        newItem.optionLabelProp = setOptionLabelProp(item.label);
        return newItem;
      });
      unstable_batchedUpdates(() => {
        setValueMap(vMap);
        setOptions(options);
      });
    }
  }, [optionsProps]);

  return (
    <>
      {title && <span style={{ display: 'inline-block', marginRight: 8 }}>{title} :</span>}
      <Select
        allowClear
        showSearch
        mode={mode}
        value={value}
        maxTagCount={1}
        options={options}
        showArrow={showArrow}
        style={{ width: 200 }}
        optionFilterProp="label"
        onChange={onSelectChange}
        autoClearSearchValue={false}
        optionLabelProp="optionLabelProp"
        // maxTagTextLength={showArrow ? 5 : 6}
        filterOption={(val, { label, value }) =>
          (label as string)?.includes(val.trim()) || (value as string)?.includes(val.trim())
        }
        maxTagPlaceholder={renderMaxTagPlaceholder}
        placeholder={title ? `请选择${title}` : '请选择'}
        {...otherProps}
      />
    </>
  );
};

export default index;
