import { Form, Tooltip } from 'antd';
import { isFunction } from 'lodash';
import React, { useState } from 'react';
import moment from 'moment';
import { listDictionary } from '@cerdo/cerdo-utils/lib/api';
import { fn } from '@cerdo/cerdo-utils/lib';
import { LoadingOutlined } from '@ant-design/icons';

const FormItem = Form.Item;

const FormLabel = (props) => {
  let { value: propsValue, dictid = null, formatter = null, renderValue = null } = props;

  const [loading] = useState(false);

  if (isFunction(formatter)) {
    propsValue = formatter(propsValue);
  }

  if (moment.isMoment(propsValue)) {
    propsValue = propsValue.format('YYYY-MM-DD');
  }
  if (dictid) {
    // setLoading(true);
    listDictionary({ dictids: dictid }).then((result) => {
      if (fn.checkResponse(result)) {
        (result.data || []).some((a) => {
          if (a.value === propsValue || a.code === propsValue || a.name === propsValue) {
            propsValue = a.name;
            return true;
          }
          return false;
        });
      }
      // setLoading(false);
    });
  }

  return isFunction(renderValue) ? (
    renderValue(propsValue)
  ) : loading ? (
    <LoadingOutlined />
  ) : (
    <Tooltip
      title={propsValue}
      style={{
        display: 'inline-block',
        verticalAlign: 'bottom',
        maxWidth: '100%',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
      }}
    >
      {propsValue}
    </Tooltip>
  );
};

function HBFormItem(props) {
  const { editable = true, children, formatter, ...otherProps } = props;

  return editable ? (
    <FormItem {...otherProps}>{children}</FormItem>
  ) : (
    <FormItem {...otherProps}>
      <FormLabel formatter={formatter} {...otherProps} />
    </FormItem>
  );
}
export default HBFormItem;
