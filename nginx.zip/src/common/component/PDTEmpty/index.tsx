import React from 'react';
import { Empty, type EmptyProps } from 'antd';

interface PDTEmptyProps extends EmptyProps {
  wrapClassName?: string;
  wrapStyle?: React.CSSProperties;
}

const PDTEmpty: React.FC<PDTEmptyProps> = ({ wrapClassName, wrapStyle, ...otherProps }) => {
  return (
    <div
      className={wrapClassName}
      style={{
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        ...wrapStyle,
      }}
    >
      <Empty {...otherProps} />
    </div>
  );
};

export default PDTEmpty;
