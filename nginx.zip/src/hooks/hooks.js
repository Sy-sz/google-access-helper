import React from 'react';
import { useTreeSelect } from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import store from '@/store';
import { listSpecialFundInfo } from 'common/axios';

/**
 * 查询所有基金份额
 * @param {} options
 */
export const useBpmShareList = (options = {}) => {
  const dispatcher = store.useModelDispatchers('pdtSystem');
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return async () => {
        const res = await dispatcher.bpmShareList({
          keyword: state.value || '',
          fundperiod: options.fundperiod || null,
          page: 1,
          size: 1000,
          all: 1,
        });
        if (res.data && Array.isArray(res.data)) {
          return res.data
            .map((a) => ({
              label: (
                <span>
                  {a.fundname}[{a.fundcode}] <b style={{ float: 'right' }}>{a.businesstype}</b>
                </span>
              ),
              value: a.fundcode,
              name: a.fundname,
              ...a,
            }))
            .filter((a) => a.value);
        }
        return [];
      };
    },
    ...options,
  });
};

/**
 * 查询所有机构信息（非代销机构）
 * @param {} options
 */
export const useAgencyList = (options = {}) => {
  const dispatcher = store.useModelDispatchers('pdtSystem');
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return async () => {
        const res = await dispatcher.listFuturesCompany({});
        if (res.data && Array.isArray(res.data)) {
          const resData = res.data.map((a) => ({
            label: a.futuresname,
            value: a.futuresid,
            id: a.futuresid,
          }));
          return resData;
        }
        return [];
      };
    },
    ...options,
  });
};

/**
 * 查询所有专户产品
 * @param {} options
 */
export const useSpecialList = (options = {}) => {
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return async () => {
        const res = await listSpecialFundInfo({ page: 1, size: 1000 });
        if (res.data && Array.isArray(res.data)) {
          const resData = res.data.map((a) => ({
            label: `${a.fundname}[${a.fundcode}]`,
            value: a.fundid,
            id: a.fundid,
          }));
          return resData;
        }
        return [];
      };
    },
    ...options,
  });
};

export const useWeekDays = (options = {}) => {
  const frequency = [1, 2, 3, 4, 5, 6, 7];
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return frequency.map((item) => {
        return {
          label: `周 ${item}`,
          value: String(item),
        };
      });
    },
    ...options,
  });
};

export const useWeekFre = (options = {}) => {
  const frequency = [1, 2, 3, 4, 5];
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return frequency.map((item) => {
        return {
          label: `第 ${item}个`,
          value: String(item),
        };
      });
    },
    ...options,
  });
};
export const useWorkDays = (options = {}) => {
  let frequency = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
    27, 28, 29, 30, -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -12, -13, -14, -15, -16, -17, -18, -19,
    -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30,
  ];
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return frequency.map((item) => {
        return {
          label: `第 ${item} 个工作日`,
          value: String(item),
        };
      });
    },
    ...options,
  });
};

export const useFrequency = (options = {}) => {
  let frequency = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
    27, 28, 29, 30, 31,
  ];
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return frequency.map((item) => {
        return {
          label: `每 ${item}`,
          value: item,
        };
      });
    },
    ...options,
  });
};

export const useAssignmonth = (options = {}) => {
  let frequency = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return frequency.map((item) => {
        return {
          label: `${item}月`,
          value: String(item),
        };
      });
    },
    ...options,
  });
};

export const useEndnum = (options = {}) => {
  let frequency = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return frequency.map((item) => {
        return {
          label: item,
          value: item,
        };
      });
    },
    ...options,
  });
};

export const useIsEndnum = (options = {}) => {
  let frequency = [1, 0];
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return frequency.map((item) => {
        return {
          label: item === 1 ? '是' : '否',
          value: item,
        };
      });
    },
    ...options,
  });
};

export const useDictList = (options = {}) => {
  const dispatcher = store.getModelDispatchers('pdtSystem');
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return async () => {
        const res = await dispatcher.dictList({ dictids: options.id });
        if (
          res.data &&
          Array.isArray(res.data) &&
          res.data.length > 0 &&
          Array.isArray(res.data[0].children)
        ) {
          return res.data[0].children.map((a) => ({ ...a, ...{ label: a.name } }));
        }
        return [];
      };
    },

    ...options,
  });
};

/**
 * 查询所有机构信息（非代销机构）
 * @param {} options
 */
export const usePagerList = (options = {}) => {
  const dispatcher = store.useModelDispatchers('pdtSystem');
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return async () => {
        const res = await dispatcher.agencyList({
          ...(state.params || {}),
          businesstype: options.businesstype || '',
          keyword: state.value,
          page: 1,
          size: 1000,
        });
        if (res.data && Array.isArray(res.data)) {
          const resData = res.data
            .filter((a) => a.businesstype === options.type && a.companyname !== '基金管理人网站')
            .map((a) => ({
              label: a.companyname,
              value: a.organinfoid,
              id: a.organinfoid,
            }));
          return resData;
        }
        return [];
      };
    },
    ...options,
  });
};

/**
 * 查询产品部所有人
 * @param {} options
 */
export const useUserList = (options = {}) => {
  const dispatcher = store.useModelDispatchers('pdtSystem');
  return useTreeSelect({
    request: ({ state = {}, id }) => {
      return async () => {
        const res = await dispatcher.userList({
          account: options.account,
          departmentid: options.departmentid,
          page: 1,
          size: 1000,
        });
        if (res.data && Array.isArray(res.data)) {
          return res.data
            .filter((a) => Number(a.status) === 1 && a.departmentid === options.departmentid)
            .map((a) => ({
              ...a,
              value: a.userid,
              label: a.name,
            }));
        }
        return [];
      };
    },
    ...options,
  });
};
