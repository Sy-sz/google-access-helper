import { useEffect, useState } from 'react';
import { cacheGet } from '@cerdo/cerdo-utils/lib/upmHttp';
import { userPermissionApi } from '@cerdo/cerdo-utils/lib/config';

type Options = {
  id: string | string[];
};

/** 根据id的顺序和数量，返回boolean[] */
const usePermission = (options: Options): boolean[] => {
  const { id } = options;
  const [result, setResult] = useState<boolean[]>([]);

  const fetchPermission = async () => {
    const permissionids = Array.isArray(id) ? id.join() : id;
    try {
      const res = await cacheGet({ url: userPermissionApi, data: { permissionids } });
      const result = res.data?.reduce((acc: boolean[], cur: any) => {
        acc.push(cur.haspermission === 1);
        return acc;
      }, []);
      setResult(result);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchPermission();
  }, []);

  return result;
};

export default usePermission;
