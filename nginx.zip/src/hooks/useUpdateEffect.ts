import { useEffect, useRef } from 'react';

/**
 * 跟useEffect一样，只是首次挂载不会执行
 */

const useUpdateEffect = (effect: () => void, deps: any[]) => {
  const isMounted = useRef(false);

  useEffect(() => {
    if (isMounted.current) {
      return effect();
    }

    isMounted.current = true;
  }, deps);
};

export default useUpdateEffect;
