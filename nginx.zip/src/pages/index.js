import { lazy } from 'react';

export default {
  // 产品列表 webpackChunkName: "Product"
  // ProductList: lazy(() => import('./product/list')), // 全部产品
  // ProductForm: lazy(() => import('./product/form')), // 产品编辑

  ProductList: lazy(() => import('./Sproduct/list')), // 全部产品
  ProductForm: lazy(() => import('./product/form')), // 产品编辑

  // 专户列表
  SpecialProductList: lazy(() => import('./specialProduct/list')), // 全部产品
  SpecialProductForm: lazy(() => import('./specialProduct/form')), // 专户产品编辑

  // 信息维护 webpackChunkName: "Info"
  AgencyList: lazy(() => import('./maintain/agency')), // 机构信息
  ChannelsList: lazy(() => import('./maintain/channels')), // 代销机构信息
  ManagermentList: lazy(() => import('./maintain/management')), // 管理人员信息
  FundMgList: lazy(() => import('./maintain/manager/fund')), // 基金经理
  InvestmentMgList: lazy(() => import('./maintain/manager/investment')), // 投资经理
  etfInformation: lazy(() => import('./maintain/etfInformation')), // ETF参数信息
  XbrlFundInfo: lazy(() => import('./maintain/xbrlFundInfo')), // XBRL参数信息
  AgencyFunds: lazy(() => import('./maintain/agencyFunds')), // 代销机构信息基金
  FundManagerChange: lazy(() => import('./maintain/fundMangerChang')), // 基金信息变更维护
  FuturesWhiteList: lazy(() => import('./maintain/futuresWhitelist')), // 期货白名单
  SpecialSeats: lazy(() => import('./maintain/specialSeats')), // 专户席位
  SpecialProductLetter: lazy(() => import('./maintain/specialProductLetter')), // 专户信披配置
  SpecialFundInfo: lazy(() => import('./maintain/specialFundInfo')), // 专户投资策略
  SpecialCustomer: lazy(() => import('./maintain/specialCustomer')), // 专户客户投资信息
  AssetManagement: lazy(() => import('./maintain/assetManagement')), // 资产管理信息
  RecruitRecord: lazy(() => import('./maintain/recruitRecord')), // 招募更新时间维护
  ManagerChanges: lazy(() => import('./maintain/managerChanges')), // 基金经理变更

  DividendInformationList: lazy(() => import('./maintain/dividendInformation')), // 分红信息
  DividendInformationConfig: lazy(() => import('./maintain/dividendInformation/com')), // 分红信息配置表

  // 公告 webpackChunkName: "Notice"
  NoticeList: lazy(() => import('./notice/noticeMg')), // 公告管理
  NoticeTemplate: lazy(() => import('./notice/template')), // 公告模板管理
  NoticeDisclosure: lazy(() => import('./notice/disclosure')), // 公告披露方式
  NoticeNewpaper: lazy(() => import('./notice/newspaper')), // 基金对应报社维护
  DividendFile: lazy(() => import('./notice/dividendFile/list')), // 分红决议文件
  DividendFileForm: lazy(() => import('./notice/dividendFile/form')), // 专户产品编辑
  NoticeSfc: lazy(() => import('./notice/noticeSfc')), // 见证监会公告管理
  AuditPlan: lazy(() => import('./notice/auditPlan')), // 审计计划
  AuditPlanCorrect: lazy(() => import('./notice/auditPlan/correct')), // 整改计划

  // 事件管理  webpackChunkName: "Event"
  EventList: lazy(() => import('./calendar/eventList')),
  EventManage: lazy(() => import('./calendar/manage')),
  EventManageEdit: lazy(() => import('./calendar/manage/com/manageEdit')),
  EventRule: lazy(() => import('./calendar/ruleManage')),

  // 文档管理 webpackChunkName: "Doc"
  ProductDocMg: lazy(() => import('./doc/docMg')), // 文档管理
  AutoNumber: lazy(() => import('./doc/autoNumber')), // 自动编号
  SummaryEdit: lazy(() => import('./doc/summary/edit')), // 编辑概要
  Summary: lazy(() => import('./doc/summary')), // 概要生成
  PubSummary: lazy(() => import('./doc/pubSummary')), // 概要上报
  RecruitBook: lazy(() => import('./doc/recruitBook/list')), // 招募列表
  RecruitBookEdit: lazy(() => import('./doc/recruitBook/edit')), // 招募编辑
  TemplateMg: lazy(() => import('./doc/templateMg')), // 模板管理
  MiniFundList: lazy(() => import('./doc/miniFund/list')), // 迷你基金
  MiniFundForm: lazy(() => import('./doc/miniFund/detail')), // 迷你基金
  PorcessDocMg: lazy(() => import('./doc/processDocMg')), // 流程文档管理
  ParamsCheck: lazy(() => import('./doc/paramsCheck')), // 参数核对

  // 流程管理 webpackChunkName: "Process"
  ProcessRequest: lazy(() => import('./process/request')), // 我的申请
  ProcessTodo: lazy(() => import('./process/todo')), // 待办列表
  ProcessRead: lazy(() => import('./process/read')), // 待阅列表
  ProcessAll: lazy(() => import('./process/all')), // 审批日志
  ProcessDraft: lazy(() => import('./process/draft')), // 草稿箱

  // 专户产品开放日
  SpecialProductOPDConfig: lazy(() => import('./specialProductOPD/config')), // 配置信息
  SpecialProductOPDList: lazy(() => import('./specialProductOPD/list')), // 专户开放日信息列表
  SpecialProductOPDListDetails: lazy(() => import('./specialProductOPD/list/com/Details')), // 专户详情页面
  SpecialProductOPDForm: lazy(() => import('./specialProductOPD/form')), // 新增配置信息

  // 专户产品业绩信息
  SpecialProductResultsConfig: lazy(() => import('./specialProductResults/config')), // 配置信息
  specialProductResultsList: lazy(() => import('./specialProductResults/list')), // 专户产品业绩信息列表
  specialProductResultsForm: lazy(() => import('./specialProductResults/form')), // 专户业绩新增配置信息

  antiMoneyEval: lazy(() => import('./antiMoneyEval')), // 反洗钱评测
  AntiMoneyNewFund: lazy(() => import('./antiMoney/newFund')), // 新反洗钱评测 新基金评测
  AntiMoneyExistingFund: lazy(() => import('./antiMoney/existingFund')), // 存续基金评测
  AntiScore: lazy(() => import('./antiMoney/score')), // 打分

  // 机构信息
  SeatInfo: lazy(() => import('./institutionsInfo/seatInfo')), // 席位信息
  PerformanceReview: lazy(() => import('./institutionsInfo/performanceReview')), // 基金业绩复核
  AccountantConfig: lazy(() => import('./institutionsInfo/accountantConfig')), // 会计人员关系配置表

  // 公募信息
  NewspaperCost: lazy(() => import('./publicOfferingInfo/newspaperCost')), // 报刊费用
  OnePage: lazy(() => import('./publicOfferingInfo/onePage')), // 一页通
  OnePageEdit: lazy(() => import('./publicOfferingInfo/onePage/edit')), // 一页通编辑
  OverseasHoliday: lazy(() => import('./publicOfferingInfo/overseasHoliday')), // 海外基金节假日
  HolidayMaintenance: lazy(() => import('./publicOfferingInfo/holidayMaintenance')), // 节假日维护

  // 系统维护
  ConfigTable: lazy(() => import('./system/ConfigTable')), // 配置表维护
  pdtLog: lazy(() => import('./system/log')), // 日志列表

  // 通用维护
  AtomElementsRole: lazy(() => import('./atomElements/role')), // 角色维护
  AtomElementsElements: lazy(() => import('./atomElements/elements')), // 元素维护
  AtomElementsFuncs: lazy(() => import('./atomElements/functions')), // 要素与权限
  FormDesigner: lazy(() => import('./atomElements/formDesigner')), // 表单设计器
  ComForm: lazy(() => import('./atomElements/comForm')), // 产品属性配置化
  AtomElementsReview: lazy(() => import('./atomElements/review')), // 审批列表
  AtomElementsView: lazy(() => import('./atomElements/elementsView')), // 要素视图
  ComTable: lazy(() => import('./atomElements/comTable')), // 通用表格
  comNewTable: lazy(() => import('./atomElements/comNewTable')), // 通用页面(通用表格改造版)
  DataServies: lazy(() => import('./atomElements/dataServies')), // 数据服务
  ParamSubscribe: lazy(() => import('./atomElements/paramSubscribe')), // 参数订阅

  DeductPoints: lazy(() => import('./other/deductPoints')), // 扣分管理
  InfoDisclosure: lazy(() => import('./other/infoDisclosure')), // 信息披露
  LifeCycle: lazy(() => import('./other/lifeCycle')), // 产品生命周期

  // 信息披露规则维护
  DisclosureInfo: lazy(() => import('./disclosure/disclosureInfo')), // 信息披露规则维护

  // 基金/投资经理离任审计
  ManagerLeaveAudit: lazy(() => import('./managerLeaveAudit/list')), // 离任审计查询页面
  ManagerLeaveAuditDetail: lazy(() => import('./managerLeaveAudit/detail')), // 离任审计查询详情
};
