import React, { useRef, useState } from 'react';
import { Modal, DatePicker, Form, message } from 'antd';
import { SearchAgGridTable, DictSelectPlus } from '@cerdo/cerdo-design';
import { antiMoneyEvalInfoExport } from '@/common/axios';
import store from '@/store';
import moment from 'moment';
import { CreatePortal, SearchSubTable, PDTButton } from '@/common/component';
import { D } from '@/utils';
import { getNewFundColumns, newFundSubColumns } from '../data';

const FormItem = Form.Item;

const Index = () => {
  const [visibleNewFund, setVisibleNewFund] = useState(false); // 新基金评测 modal
  const agGridRef = useRef(null); // agGrid ref
  const selectFundOpts = useRef<Record<string, any>>({}); // 新基金评测 选择的基金信息
  const [form] = Form.useForm();
  const [, dispatchers] = store.useModel('pdtSystem');

  /** 入参 格式化 */
  const onFormatParams = (params: any) => {
    if (params.evalDate?.length) {
      const [startDate, endDate] = params.evalDate;
      params.startDate = startDate.format('YYYY-MM-DD');
      params.endDate = endDate.format('YYYY-MM-DD');
      delete params.evalDate;
    }
    params.type = 'new';
    return params;
  };

  /** 下载评测列表 按钮 */
  const exportNewFund = () => {
    const selectedRows = agGridRef.current?.api.getSelectedRows();
    if (!selectedRows.length) {
      message.info('请选择需要导出的数据');
      return;
    }

    let filename = '新基金评测_文件包.zip';
    if (selectedRows.length === 1) {
      filename = `${selectedRows[0].fundName}_反洗钱评估表单_${moment().format('YYYY_MM_DD')}.xls`;
    }
    const id = selectedRows.map((item) => item.id).join();
    antiMoneyEvalInfoExport({ id, filename });
  };

  const onGridReady = (grid) => {
    agGridRef.current = grid;
  };

  /** 基金选择框 change 事件 */
  const onFundSelectChange = (value, option) => {
    selectFundOpts.current = option;
  };

  /** 新基金评测 modal 确认按钮 */
  const onNewFundConfirm = () => {
    form.validateFields().then((values) => {
      const { fundCode, evalDate } = values;
      dispatchers.updateState({
        // @ts-ignore
        antimoneyActiveRow: {
          fundCode,
          fundName: selectFundOpts.current.dictLabel,
          evalDate: evalDate.format('YYYY-MM-DD'),
        },
      });
      setVisibleNewFund(false);
      window.openTab({ path: `/app/pdt/doc/antimoney/score?type=new&fetchRuleTree=true` });
    });
  };

  return (
    <div>
      <CreatePortal container=".search-ag-grid-table .search-table-header">
        <b>新基金评测列表</b>
      </CreatePortal>

      <SearchAgGridTable
        method="get"
        url="/fscy/pdt-api/antiMoneyEvalInfo/list"
        onFormatParams={onFormatParams}
        actionBtns={[
          <PDTButton
            key="1"
            type="primary"
            onClick={() => setVisibleNewFund(true)}
            permissionId="e43fa676-a781-4ad0-ae48-e77a8c25e03c"
          >
            新基金评测
          </PDTButton>,
          <PDTButton key="2" type="primary" onClick={exportNewFund}>
            下载评测列表
          </PDTButton>,
        ]}
        tableConfig={{
          autoHeight: true,
          suppressCellFocus: false,
          masterDetail: true,
          detailRowAutoHeight: true,
          onGridReady,
          columnDefs: getNewFundColumns({ dispatchers }),
          detailCellRenderer: ({ data }) => (
            <SearchSubTable
              data={data}
              columnDefs={newFundSubColumns}
              wrapperStyle={{ width: '60%' }}
            />
          ),
        }}
        tableState={{
          autoSaveColumnState: true, // 是否自动保存列状态
          enableBackendColumnState: true // 是否启用后端列状态
        }}
        searchFormConfig={{
          searchColNum: 4,
          defaultCollapsed: false,
          formProps: { wrapperCol: { span: 14 } },
        }}
      />

      <Modal
        title="新基金评测"
        visible={visibleNewFund}
        maskClosable={false}
        onCancel={() => setVisibleNewFund(false)}
        onOk={onNewFundConfirm}
      >
        <Form form={form} labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
          <FormItem
            label="可选基金"
            name="fundCode"
            rules={[{ required: true, message: '请选择基金' }]}
          >
            <DictSelectPlus
              style={{ width: '100%' }}
              placeholder="请输入产品名称、代码搜索"
              filterOption={(value, { dictLabel, dictValue }) =>
                dictLabel?.includes(value) || dictValue?.includes(value)
              }
              onChange={onFundSelectChange}
              dictId={D.FUNDINFO_LIST}
            />
          </FormItem>
          <FormItem
            label="评测日期"
            name="evalDate"
            rules={[{ required: true, message: '请选择评测日期' }]}
          >
            <DatePicker style={{ width: '100%' }} />
          </FormItem>
        </Form>
      </Modal>
    </div>
  );
};

export default Index;
