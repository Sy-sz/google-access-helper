import React, { useState, useRef, useEffect } from 'react';
import { Tabs, Modal, Form, DatePicker, Checkbox, message } from 'antd';
import moment from 'moment';
import { SearchAgGridTable, DictSelectPlus } from '@cerdo/cerdo-design';
import store from '@/store';
import { CreatePortal, SearchSubTable, PDTButton } from '@/common/component';
import { batchInitApproval, batchReApproval, antiMoneyEvalInfoExport } from '@/common/axios';
import { D } from '@/utils';
import { type activeKeyType, getExistingFundColumns, newFundSubColumns, PERMISSION } from '../data';

const FormItem = Form.Item;
const urlMap: Record<activeKeyType, string> = {
  notYetReview: '/fscy/pdt-api/antiMoneyEvalInfo/duration/list',
  alreadyReview: '/fscy/pdt-api/antiMoneyEvalInfo/list',
};

const Index = () => {
  const [pdtState, dispatchers] = store.useModel('pdtSystem');
  const [form] = Form.useForm();
  const [activeKey, setActiveKey] = useState<activeKeyType>('notYetReview');
  const [batchLoading, setBatchLoading] = useState(false);

  const [visibleExisting, setVisibleExisting] = useState<boolean | 'batch' | 'single'>(false); // batch: 批量评测, single: 单个评测
  const searchAgTableRef = useRef(null);
  const agGridRef = useRef(null);
  const selectedRows = useRef([]);
  const searchParams = useRef<Record<string, any>>({});

  const onGridReady = (grid) => {
    agGridRef.current = grid;
  };

  /** 入参 格式化 */
  const onFormatParams = (params: any) => {
    if (activeKey === 'alreadyReview') {
      const [startDate, endDate] = params.evalDate || [];
      params.type = 'duration';
      params.startDate = startDate?.format('YYYY-MM-DD');
      params.endDate = endDate?.format('YYYY-MM-DD');
      delete params.evalDate;
    }
    // params.page = params.currentPage;
    // delete params.currentPage;
    searchParams.current = params;
    return params;
  };

  const onTabsChange = (key) => {
    searchAgTableRef.current.form.resetFields();
    setActiveKey(key);
  };

  /** 批量初评、复评 打开弹框 */
  const openBatchModal = () => {
    const rows = agGridRef.current.api?.getSelectedRows();
    if (!rows?.length) {
      message.info('请选择需要评测的基金');
      return;
    }
    form.setFieldsValue({ fundCode: rows.map((item) => item.fundCode) });
    selectedRows.current = rows;
    setVisibleExisting('batch');
  };

  /** 批量初评、复评、请初评 点确认 */
  const onModalConfirm = () => {
    form.validateFields().then(async (values) => {
      const year = searchParams.current.year;
      // 单个评测
      if (visibleExisting === 'single') {
        const antimoneyActiveRow = {
          ...pdtState.antimoneyActiveRow,
          year,
          evalDate: values.evalDate.format('YYYY-MM-DD'),
        };
        setVisibleExisting(false);
        // @ts-ignore
        dispatchers.updateState({ antimoneyActiveRow });
        window.openTab({ path: `/app/pdt/doc/antimoney/score?type=duration&fetchRuleTree=true` });
        return;
      }

      // 批量评测
      for (const { status } of selectedRows.current) {
        if (status === '99') {
          message.info('请勿勾选已结束状态的产品');
          return;
        }
      }

      setBatchLoading(true);
      const evalDate = moment(values.evalDate).format('YYYY-MM-DD');
      const request = activeKey === 'notYetReview' ? batchInitApproval : batchReApproval;
      const dynamicParam =
        activeKey === 'notYetReview'
          ? { fundCode: values.fundCode.join() } // 批量初评
          : { id: selectedRows.current.map((e) => e.id).join() }; // 批量复评

      try {
        await request({ ...dynamicParam, year, evalDate });
        message.success('操作成功');
        setVisibleExisting(false);
        searchAgTableRef.current.onSearch();
      } catch (error) {}
      setBatchLoading(false);
    });
  };

  /** 已发起评测 导出 */
  const exportAlreadyFund = () => {
    const selectedRows = agGridRef.current?.api.getSelectedRows();
    if (!selectedRows.length) {
      message.info('请选择需要导出的数据');
      return;
    }

    let filename = '存续基金评测_文件包.zip';
    if (selectedRows.length === 1) {
      filename = `${selectedRows[0].fundName}_反洗钱评估表单_${moment().format('YYYY_MM_DD')}.xls`;
    }
    const id = selectedRows.map((item) => item.id).join();
    antiMoneyEvalInfoExport({ id, filename });
  };

  /** 渲染按钮 */
  const renderActionBtns = () => {
    const buttons = [
      <PDTButton
        key="1"
        type="primary"
        onClick={openBatchModal}
        permissionId={activeKey === 'notYetReview' ? PERMISSION.batchFirst : PERMISSION.batchSecond}
      >
        {`批量${activeKey === 'notYetReview' ? '初评' : '复评'}`}
      </PDTButton>,
    ];

    if (activeKey === 'alreadyReview') {
      buttons.push(
        <PDTButton key="2" type="primary" onClick={exportAlreadyFund}>
          下载评测表
        </PDTButton>,
      );
    }

    return buttons;
  };

  /** 基金选择框 change 事件 */
  const onFundSelectChange = (value, option) => {
    // selectFundOpts.current = option;
  };

  useEffect(() => {
    searchAgTableRef.current.onSearch({ currentPage: 1 });
  }, [activeKey]);

  return (
    <div>
      <Tabs
        activeKey={activeKey}
        onChange={onTabsChange}
        tabBarStyle={{ padding: '0 12px' }}
        style={{ backgroundColor: 'var(--card-bg)' }}
      >
        <Tabs.TabPane tab="未发起评测" key="notYetReview" />
        <Tabs.TabPane tab="已发起评测" key="alreadyReview" />
      </Tabs>

      <CreatePortal container=".search-ag-grid-table .search-table-header">
        <b>评测列表</b>
      </CreatePortal>

      <SearchAgGridTable
        method="get"
        url={urlMap[activeKey]}
        onFormatParams={onFormatParams}
        ref={searchAgTableRef}
        actionBtns={renderActionBtns()}
        tableConfig={{
          autoHeight: true,
          suppressCellFocus: false,
          masterDetail: true,
          detailRowAutoHeight: true,
          onGridReady,
          columnDefs: getExistingFundColumns({ activeKey, dispatchers, setVisibleExisting }),
          detailCellRenderer: ({ data }) => (
            <SearchSubTable
              data={data}
              columnDefs={newFundSubColumns}
              wrapperStyle={{ width: '60%' }}
            />
          ),
        }}
        searchFormConfig={{
          initialValues: { year: moment() },
          searchColNum: 4,
          defaultCollapsed: false,
          formProps: { wrapperCol: { span: 14 } },
        }}
      />

      <Modal
        title="批量评测"
        visible={!!visibleExisting}
        maskClosable={false}
        onCancel={() => setVisibleExisting(false)}
        onOk={onModalConfirm}
        confirmLoading={batchLoading}
      >
        <Form
          form={form}
          labelCol={{ span: 6 }}
          wrapperCol={{ span: 18 }}
          initialValues={{ isChecked: true }}
        >
          {visibleExisting === 'batch' && (
            <FormItem
              label="已选择基金"
              name="fundCode"
              rules={[{ required: true, message: '请选择基金' }]}
            >
              <DictSelectPlus
                disabled
                mode="multiple"
                style={{ width: '100%' }}
                placeholder="请输入产品名称、代码搜索"
                filterOption={(value, { dictLabel, dictValue }) =>
                  dictLabel?.includes(value) || dictValue?.includes(value)
                }
                onChange={onFundSelectChange}
                dictId={D.FUNDINFO_LIST}
              />
            </FormItem>
          )}
          {activeKey === 'notYetReview' && (
            <FormItem
              label="评测日期"
              name="evalDate"
              rules={[{ required: true, message: '请选择评测日期' }]}
            >
              <DatePicker style={{ width: '100%' }} />
            </FormItem>
          )}
          <FormItem
            name="isChecked"
            wrapperCol={{ offset: 6 }}
            valuePropName="checked"
            rules={[
              {
                validator(_, value) {
                  if (!value) {
                    return Promise.reject(new Error('请勾选'));
                  }
                  return Promise.resolve();
                },
              },
            ]}
          >
            <Checkbox>已查阅上述基金评分内容</Checkbox>
          </FormItem>
        </Form>
      </Modal>
    </div>
  );
};

export default Index;
