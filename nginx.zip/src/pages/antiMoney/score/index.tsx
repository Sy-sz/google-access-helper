import React, { useEffect, useState, useRef, useMemo } from 'react';
import { Table, Card, Button, Space, message, Row, Col, Popover, Modal, Input, Tag } from 'antd';
import { isEmpty, findLastIndex } from 'lodash';
import store from '@/store';
import { url } from '@cerdo/cerdo-utils';
import { getTemplateByType, antiMoneyEvalFlowInfoSave } from '@/common/axios';
import CopyScore from './copyScore';
import { type DataType, getScoreColumns, scoreRecordColumns } from '../data';

export interface BaseInfoType {
  type?: 'new' | 'duration';
  fetchRuleTree?: boolean;
  fundCode?: string;
  fundName?: string;
  evalDate?: string;
}

/** 初始化基础参数, 优先从 url 中获取，没有则从 store 中获取 */
const initBaseParams = (pdtSystem) => {
  const { fundCode, fundName, evalDate, type, fetchRuleTree } = url.getAllQueryString(); // fetchRuleTree: 是否需要获取规则树
  const { fundCode: fCode, fundName: fName, evalDate: eDate } = pdtSystem.antimoneyActiveRow;
  return {
    type,
    fetchRuleTree,
    fundCode: fundCode || fCode,
    fundName: fundName || fName,
    evalDate: evalDate || eDate,
  } as BaseInfoType;
};

const index = () => {
  const [ruleTree, setRuleTree] = useState<DataType[]>([]);
  const [dataSource, setDataSource] = useState<DataType[]>([]);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [preSaveVisible, setPreSaveVisible] = useState(false); // 提交、推荐 确认弹框
  const [opResult, setOpResult] = useState<'1' | '0'>(); // 用来区分保存、退回
  const [memo, setMemo] = useState(''); // 提交、退回时 备注信息
  const [selectFlag, setSelectFlag] = useState(false); // 记录是否手动打分过，如果手动打过，再复制其他基金的打分时，提示用户

  const multipleMap = useRef<Record<string, boolean>>({}); // 是否多选映射
  const ruleTreeId = useRef<string>();
  const cardWrapper = useRef<HTMLDivElement>(null);
  const [pdtSystem, dispatchers] = store.useModel('pdtSystem');
  const { fundCode, fundName, evalDate, type, fetchRuleTree } = initBaseParams(pdtSystem);
  const isValid = pdtSystem.antimoneyActiveRow?.fundCode === fundCode;
  const storeData = isValid ? pdtSystem.antimoneyActiveRow : {};
  const { status, evalForm, templateId, id, year, children } = storeData;
  const isFirstReview = ['0', '1'].includes(status); // 是否为初评
  const isSecondReview = ['11', '12'].includes(status); // 是否为复评

  /** 总分 = 每项分数 * 权重% 之和；多选时取最大值 */
  const totalScore = useMemo(() => {
    const multiScoreMap: Record<DataType['risk'], DataType> = {};
    let total = 0;
    dataSource.forEach((item) => {
      if (item.isChecked) {
        const isMultiple = multipleMap.current[item.risk];
        if (isMultiple) {
          if (item.score > (multiScoreMap[item.risk]?.score || 0)) {
            multiScoreMap[item.risk] = item;
          }
        } else {
          total += (item.score * item.weight) / 100;
        }
      }
    });
    Object.values(multiScoreMap).forEach((item) => {
      total += (item.score * item.weight) / 100;
    });
    total = total > 100 ? 100 : total;
    return total ? Number(total.toFixed(2)) : total;
  }, [dataSource]);

  /** 风险等级 */
  const riskLv = useMemo(() => {
    if (totalScore < 50) {
      return '低风险';
    } else if (totalScore >= 50 && totalScore < 80) {
      return '中风险';
    }
    return '高风险';
  }, [totalScore]);

  const onCheckChange = (record: DataType) => {
    let risk = record.risk;
    const newData = dataSource.map((item: any) => {
      if (item.uuid === record.uuid) {
        return {
          ...item,
          isChecked: !item.isChecked,
        };
      } else if (item.risk === risk && !multipleMap.current[risk]) {
        // 如果是单选，需要把其他选中的取消
        return {
          ...item,
          isChecked: false,
        };
      }
      return item;
    });
    setDataSource(newData);
    setSelectFlag(true);
  };

  const formatData = (ruleTree: Partial<DataType>[]) => {
    if (!ruleTree?.length) {
      return;
    }

    const lvMap: Record<string, any> = {}; // 记录前两级的数据
    const isMultipleMap: Record<string, boolean> = {}; // 风险子项是否多选
    const newData: DataType[] = [];
    const lv1LengthMap: Map<String, number> = new Map(); // 确保顺序准确

    const loopData = (data: Partial<DataType>[]) => {
      data.forEach((item: DataType, idx: number) => {
        if (item.lv === 3) {
          const riskRowSpan = idx === 0 ? data.length : 0;
          const newItem = {
            uuid: item.uuid,
            rule: item.value,
            score: item.score,
            isChecked: item.isChecked,
            dimension: lvMap.lv1.value,
            risk: lvMap.lv2.value,
            weight: lvMap.lv2.weight,
            isMultiple: lvMap.lv2.isMultiple,
            required: lvMap.lv2.required,
            riskRowSpan,
          };
          newData.push(newItem);
          const prev = lv1LengthMap.get(newItem.dimension) || 0;
          lv1LengthMap.set(newItem.dimension, prev + 1);
        } else if (item.lv === 2) {
          isMultipleMap[item.value] = item.isMultiple;
          lvMap[`lv${item.lv}`] = item;
        } else if (item.lv === 1) {
          lvMap[`lv${item.lv}`] = item;
        }

        if (item.children?.length) {
          loopData(item.children);
        }
      });
    };

    loopData(ruleTree);
    newData.forEach((item: DataType) => {
      if (lv1LengthMap.has(item.dimension)) {
        item.dimensionRowSpan = lv1LengthMap.get(item.dimension);
        lv1LengthMap.delete(item.dimension);
      } else {
        item.dimensionRowSpan = 0;
      }
    });

    setDataSource(newData);
    multipleMap.current = isMultipleMap;
  };

  /** 把选中项回填进规则树中 */
  const fillCheckedToTree = () => {
    const idMap = dataSource.reduce((acc, cur) => {
      acc[cur.uuid] = cur;
      return acc;
    }, {});
    const loopTree = (data) => {
      data.forEach((item) => {
        if (item.children?.length) {
          loopTree(item.children);
        }
        if (item.uuid) {
          item.isChecked = idMap[item.uuid].isChecked;
        }
      });
    };
    loopTree(ruleTree);
  };

  /** 校验 必填项 */
  const validateRequired = () => {
    let pass = true;
    const loopData = (data: any) => {
      for (const { lv, value, children, required } of data) {
        if (lv === 1 && pass) {
          loopData(children);
        } else if (lv === 2 && required) {
          if (children.every((item) => !item.isChecked)) {
            pass = false;
            message.info(`${value} 未打分`);
            break;
          }
        }
      }
    };
    loopData(ruleTree);
    return pass;
  };

  const preSave = (type) => {
    setOpResult(type);
    setPreSaveVisible(true);
  };

  /** 提交、同意：1，退回：0 */
  const onSave = async () => {
    fillCheckedToTree();
    const pass = validateRequired();
    if (!pass) {
      return;
    }

    setConfirmLoading(true);
    try {
      await antiMoneyEvalFlowInfoSave({
        id: status === '0' ? '' : id,
        type,
        fundCode,
        evalDate,
        opResult,
        isBatch: false,
        riskLv,
        score: totalScore,
        memo,
        status,
        templateId: ruleTreeId.current,
        evalForm: JSON.stringify(ruleTree),
      });
      message.success('操作成功');
      setTimeout(() => {
        window.closeTab({ path: '/app/pdt/doc/antimoney/score' });
      }, 500);
    } catch (error) {
      setConfirmLoading(false);
    }
  };

  const fetchRulesTree = async () => {
    // 如果是复评，回显打分数据
    if (!fetchRuleTree && !isEmpty(evalForm)) {
      setRuleTree(JSON.parse(evalForm));
      ruleTreeId.current = templateId;
      return;
    }

    const res = await getTemplateByType({ id, year, type, fundCode, evalDate });
    const content = JSON.parse(res.data?.content || '[]');
    setRuleTree(content);
    ruleTreeId.current = res.data?.id;
  };

  const getConfirmText = () => {
    switch (status) {
      case '1':
        return '提交';
      case '11':
      case '12':
        return '提交复评';
      case '20':
        return '同意';
      default:
        return '提交';
    }
  };

  /** 打分详情，初评、复评、审核 */
  const scoreDetailList = useMemo(() => {
    if (!children?.length) {
      return [];
    }

    const getLastIndex = (cb) => findLastIndex(children, cb);

    // 都取最新的打分记录，且复评和审批取同意的记录
    const lastIndexMap = {
      初评: ({ status }) => status === '1' || status === '0',
      复评: ({ status, opResult }) => opResult === '1' && (status === '12' || status === '11'),
      审批: ({ status, opResult }) => opResult === '1' && status === '20',
    };

    return Object.entries(lastIndexMap).reduce((acc, [prefix, condition]) => {
      const lastIndex = getLastIndex(condition);
      if (lastIndex !== -1) {
        const { opUser, score, riskLv, createtime, memo } = children[lastIndex];
        acc.push({ prefix, opUser, score, riskLv, createtime, memo });
      }
      return acc;
    }, []);
  }, [children]);

  /** 提交确认弹框的数据 */
  const preSaveData = useMemo(() => {
    let data = [{ prefix: '当前', score: totalScore, riskLv }];

    if (isSecondReview) {
      data.unshift(scoreDetailList[0]);
      return data;
    }

    if (status === '20') {
      data = scoreDetailList;
    }

    return data;
  }, [totalScore, riskLv, scoreDetailList, isSecondReview]);

  /** 提交确认弹框的提示文字 */
  const preSaveTip = useMemo(() => {
    // 退回操作、状态没值、首次评测，不需要提示
    if (opResult === '0' || !status || preSaveData.length <= 1) {
      return null;
    }

    const [first, current] = preSaveData;
    const isHighRisk = current?.riskLv === '高风险';
    const isScoreMismatch = first.score !== current.score;

    if (isSecondReview) {
      if (isHighRisk) {
        return '当前反洗钱等级为高风险, 请确认是否提交，提交后将由高级管理人员进行审批';
      }
      if (isScoreMismatch && type === 'new') {
        return '当前复评分数与初评分数不一致，请确认是否提交，提交后将由高级管理人员进行审批';
      }
    }

    if (status === '20' && isHighRisk) {
      return '当前反洗钱等级为高风险，请确认是否提交';
    }

    return null;
  }, [opResult, status, preSaveData, scoreDetailList, isSecondReview, type]);

  /** 打分记录 */
  const renderScoreRecord = () => {
    return (
      <Table
        size="small"
        rowKey="id"
        columns={scoreRecordColumns}
        dataSource={children}
        pagination={false}
      />
    );
  };

  useEffect(() => {
    fetchRulesTree();
  }, []);

  useEffect(() => {
    formatData(ruleTree);
  }, [ruleTree]);

  useEffect(() => {
    if (!isValid) {
      dispatchers.updateState({
        // @ts-ignore
        antimoneyActiveRow: {},
      });
    }
  }, [isValid]);

  return (
    <>
      <div ref={cardWrapper} style={{ marginBottom: 10 }}>
        <Card bordered={false} style={{ padding: '12px 6px' }}>
          <Space direction="vertical" size={30} style={{ width: '100%' }}>
            <Row justify="space-between">
              <b>
                {fundName}[{fundCode}]
              </b>
              {!!children?.length && (
                <Popover title={<b>打分记录</b>} placement="leftTop" content={renderScoreRecord()}>
                  <a>打分记录</a>
                </Popover>
              )}
              <CopyScore
                status={status}
                type={type}
                selectFlag={selectFlag}
                getRuleTree={setRuleTree}
                setSelectFlag={setSelectFlag}
              />
            </Row>

            {scoreDetailList.map(({ prefix, opUser, score, riskLv, createtime, memo }) => (
              <Space size={30} key={prefix} direction="vertical" style={{ width: '100%' }}>
                <Row style={{ paddingLeft: '80px' }}>
                  <Col span={6}>{`${prefix}人: ${opUser}`}</Col>
                  {prefix !== '审批' && (
                    <>
                      <Col span={6}>{`${prefix}分数: ${score}`}</Col>
                      <Col span={6}>{`${prefix}等级: ${riskLv}`}</Col>
                    </>
                  )}
                  <Col span={6}>{`${prefix}时间: ${createtime}`}</Col>
                </Row>
                <div style={{ paddingLeft: 80 }}>
                  {prefix}备注：{memo}
                </div>
              </Space>
            ))}
          </Space>
        </Card>
      </div>

      <Modal
        width={700}
        title={`确认${opResult === '1' ? '提交' : '退回'}`}
        visible={preSaveVisible}
        onCancel={() => setPreSaveVisible(false)}
        footer={
          <Row justify="space-between" align="middle">
            {preSaveTip ? (
              <Tag key="warning" color="warning" style={{ height: 22 }}>
                {preSaveTip}
              </Tag>
            ) : (
              <div />
            )}
            <Space>
              <Button key="cancel" onClick={() => setPreSaveVisible(false)}>
                取消
              </Button>
              <Button key="comfirm" type="primary" disabled={confirmLoading} onClick={onSave}>
                确认
              </Button>
            </Space>
          </Row>
        }
      >
        <Space direction="vertical" size="middle" style={{ width: '100%' }}>
          {preSaveData.map(({ prefix, score, riskLv }) => (
            <Row key={prefix} style={{ paddingLeft: 30 }}>
              <Col span={12}>
                {prefix}分数: {score}
              </Col>
              <Col span={12}>
                {prefix}等级: {riskLv}
              </Col>
            </Row>
          ))}
          <div style={{ paddingLeft: 30, display: 'flex' }}>
            <div style={{ whiteSpace: 'nowrap' }}>备注信息：</div>
            <Input.TextArea
              placeholder="请输入备注信息"
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
            />
          </div>
        </Space>
      </Modal>

      <Card bordered={false} bodyStyle={{ textAlign: 'right' }}>
        <Row justify="space-between" style={{ marginBottom: 20 }}>
          {totalScore ? (
            <Space>
              <b>当前分数: {totalScore}</b>
              <b>当前等级: {riskLv}</b>
            </Space>
          ) : (
            <div />
          )}

          <Space>
            {status !== '99' && !!ruleTree.length && (
              <>
                <Button type="primary" onClick={() => preSave('1')}>
                  {getConfirmText()}
                </Button>
                {status && !isFirstReview && (
                  <Button type="primary" onClick={() => preSave('0')}>
                    退回
                  </Button>
                )}
              </>
            )}
          </Space>
        </Row>
        <Table
          bordered
          size="small"
          rowKey="uuid"
          pagination={false}
          dataSource={dataSource}
          scroll={{
            y: `calc(100vh - 180px - ${(cardWrapper.current?.offsetHeight || 0) + 20}px)`,
          }}
          columns={getScoreColumns({ status, onCheckChange })}
        />
      </Card>
    </>
  );
};

export default index;
