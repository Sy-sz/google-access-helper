import React, { useState } from 'react';
import { Button, Modal, Space, message } from 'antd';
import { DictSelectPlus } from '@cerdo/cerdo-design';
import { copyTemplateByFund } from '@/common/axios';
import { D } from '@/utils';
import { type BaseInfoType } from './index';

interface CopyScoreProps {
  selectFlag: boolean;
  setSelectFlag: (flag: boolean) => void;
  status: string;
  type: BaseInfoType['type'];
  getRuleTree: (params: any) => void;
}

const copyScore: React.FC<CopyScoreProps> = (props) => {
  const { status, type, selectFlag, getRuleTree, setSelectFlag } = props;
  const [copyVisible, setCopyVisible] = useState(false);
  const [copyFundCode, setCopyFundCode] = useState(''); // 复制评分的 基金代码

  /** 复制评分项 确定 */
  const onOk = async () => {
    if (!copyFundCode) {
      message.info('请选择基金');
      return;
    }

    const res = await copyTemplateByFund({ fundCode: copyFundCode, type });
    if (res.data.content) {
      getRuleTree(JSON.parse(res.data.content));
    }
    setCopyVisible(false);
    setSelectFlag(false);
  };

  if (status && status !== '0') {
    return null;
  }

  return (
    <>
      <Button type="link" size="small" onClick={() => setCopyVisible(true)}>
        复制评分等级
      </Button>
      <Modal
        width={400}
        title="复制评分项"
        visible={copyVisible}
        onOk={onOk}
        onCancel={() => setCopyVisible(false)}
      >
        <Space style={{ marginLeft: 30 }} direction="vertical" size="large">
          <Space>
            <span>
              <span style={{ color: 'var(--tag-error-color)' }}>*</span> 选择基金:&nbsp;
            </span>
            <DictSelectPlus
              style={{ width: 200 }}
              placeholder="请输入产品名称、代码搜索"
              filterOption={(value, { dictLabel, dictValue }) =>
                dictLabel?.includes(value) || dictValue?.includes(value)
              }
              onChange={setCopyFundCode}
              dictId={D.FUNDINFO_LIST}
            />
          </Space>
          {selectFlag && (
            <div style={{ fontSize: 12, color: 'var(--tag-error-color)' }}>
              复制基金评分项将覆盖当前页面打分项
            </div>
          )}
        </Space>
      </Modal>
    </>
  );
};

export default copyScore;
