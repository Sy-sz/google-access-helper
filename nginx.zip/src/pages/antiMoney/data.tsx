import React from 'react';
import { DatePicker, Checkbox, Tag } from 'antd';
import moment from 'moment';
import { PDTButton } from '@/common/component';
import { D } from '@/utils';
import { type IColumnDefs } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import { type ColumnsType } from 'antd/lib/table';

export const formCol = {
  labelCol: { span: 6 },
  wrapperCol: { span: 14 },
};

const statusLinkTxtMap = {
  0: '请初评',
  1: '请初评',
  11: '请复评',
  12: '请复评',
  20: '请审批',
  99: '查看',
};

export const PERMISSION = {
  /** 初评 */
  firstReview: 'd42efd59-4825-4acf-95d9-db628a1600a6',
  /** 复评 */
  secondReview: '5f58e330-adc5-4f1d-b9d5-b4690482b3ee',
  /** 审批 */
  thirdReview: '980a2730-ffa0-45b6-8ea1-ae2a26ef844d',

  /** 批量初评 */
  batchFirst: '7f77dea7-6941-4aa5-96b0-17036084a8ee',
  /** 批量复评 */
  batchSecond: 'f4cd01b6-e363-47a1-8eba-652ed67e8f56',
};

// ------------------新基金评测---------------------
type getNewFundColumnsType = (params: { dispatchers: any }) => IColumnDefs;
const getPermissionId = (status: string) => {
  switch (status) {
    case '0':
    case '1':
      return PERMISSION.firstReview;
    case '11':
    case '12':
      return PERMISSION.secondReview;
    case '20':
      return PERMISSION.thirdReview;
    default:
      return undefined;
  }
};
export const getNewFundColumns: getNewFundColumnsType = ({ dispatchers }) => [
  {
    headerName: '产品名称',
    field: 'fundCode',
    hideInTable: true,
    component: 'DictSelectPlus',
    dictId: D.FUNDINFO_LIST,
    componentProps: {
      mode: 'multiple',
      filterOption: (value, { dictLabel, dictValue }) =>
        dictLabel?.includes(value) || dictValue?.includes(value),
      placeholder: '请输入产品名称、代码搜索',
    },
    transform: (value) => value?.join(),
  },
  {
    headerName: '产品名称',
    field: 'fundName',
    width: 300,
    minWidth: 300,
    hideInSearch: true,
    cellRenderer: 'agGroupCellRenderer',
    valueGetter: ({ data }) => `${data.fundName}[${data.fundCode}]`,
    checkboxSelection: true,
    headerCheckboxSelection: true,
  },
  {
    headerName: '基金类型',
    field: 'fundType',
    component: 'DictSelectPlus',
    renderType: 'tag',
    dictId: '5bbfb267-25cd-4ac5-82b1-2fcb47f80ef5',
    componentProps: {
      placeholder: '请选择基金类型',
    },
    flex: 1,
  },
  {
    headerName: '评测日期',
    field: 'evalDate',
    component: DatePicker.RangePicker,
    type: 'date',
    flex: 1,
  },
  {
    headerName: '评分',
    field: 'score',
    hideInSearch: true,
    flex: 1,
  },
  {
    headerName: '反洗钱等级',
    field: 'riskLv',
    hideInSearch: true,
    cellRenderer: ({ value }) => (
      <span style={value === '高风险' ? { color: 'var(--tag-error-color)' } : {}}>{value}</span>
    ),
    flex: 1,
  },
  {
    headerName: '状态',
    field: 'status',
    component: 'DictSelectPlus',
    dictId: 'd5ed14f8-cad5-4377-9b9f-b4c132e9485e',
    renderType: 'tag',
    componentProps: {
      placeholder: '请选择状态',
    },
    flex: 1,
  },
  {
    headerName: '备注',
    field: 'memo',
    hideInSearch: true,
    flex: 1,
  },
  {
    headerName: '操作',
    hideInSearch: true,
    width: 100,
    minWidth: 100,
    filter: false,
    cellRenderer: ({ data }) => {
      return (
        <PDTButton
          type="link"
          permissionId={getPermissionId(data.status)}
          onClick={() => {
            dispatchers.updateState({ antimoneyActiveRow: data });
            window.openTab({ path: `/app/pdt/doc/antimoney/score?type=new` });
          }}
        >
          {statusLinkTxtMap[data.status]}
        </PDTButton>
      );
    },
  },
];
export const newFundSubColumns: IColumnDefs = [
  {
    headerName: '文件状态',
    field: 'status',
    dictId: '1628b9fd-f23f-4462-89c2-5e2928a04675',
    hideInSearch: true,
  },
  {
    headerName: '操作',
    field: 'opResult',
    hideInSearch: true,
    cellRenderer: ({ value, data }) => {
      if (value === '0') {
        return <Tag color="red">退回</Tag>;
      }
      return <Tag color="blue">{['0', '1'].includes(data.status) ? '提交' : '同意'}</Tag>;
    },
  },
  {
    headerName: '操作人',
    field: 'opUser',
    hideInSearch: true,
  },
  {
    headerName: '备注',
    field: 'memo',
    hideInSearch: true,
  },
  {
    headerName: '操作时间',
    field: 'createtime',
    hideInSearch: true,
  },
];

// ------------------打分---------------------
export interface DataType {
  lv?: number;
  uuid: string;
  dimension: string;
  risk: string;
  weight: number;
  rule: string;
  value?: string;
  score?: number;
  isChecked?: boolean;
  isMultiple?: boolean;
  dimensionRowSpan?: number;
  rickRowSpan?: number;
  children?: Partial<DataType>[];
}
type ScoreColumnsType = (params: {
  status: string;
  onCheckChange: (record: DataType) => void;
}) => ColumnsType<DataType>;

export const getScoreColumns: ScoreColumnsType = ({ status, onCheckChange }) => [
  {
    title: '维度',
    dataIndex: 'dimension',
    width: 120,
    render: (value, record: any) => ({
      children: value,
      props: { rowSpan: record.dimensionRowSpan },
    }),
  },
  {
    title: '风险子项',
    dataIndex: 'risk',
    width: 150,
    render: (value, record: any) => ({
      children: (
        <>
          {record.required && (
            <span style={{ color: 'var(--tag-error-color)', marginRight: 3 }}>*</span>
          )}
          {value}
        </>
      ),
      props: { rowSpan: record.riskRowSpan },
    }),
  },
  {
    title: '权重',
    width: 120,
    dataIndex: 'weight',
    render: (value, record: any) => ({
      children: `${value}%`,
      props: { rowSpan: record.riskRowSpan },
    }),
  },
  {
    title: '评分规则',
    dataIndex: 'rule',
    colSpan: 2,
  },
  {
    title: '分数',
    dataIndex: 'score',
    width: 100,
    colSpan: 0,
  },
  {
    title: '评分',
    dataIndex: 'isChecked',
    width: 100,
    render: (value, record) => {
      return (
        <Checkbox
          checked={value}
          disabled={['20', '99'].includes(status)}
          onChange={() => onCheckChange(record)}
        />
      );
    },
  },
];

interface scoreRecordDataType {
  status: string;
  opUser: string;
  opResult: '0' | '1';
  createtime: string;
}
// 打分记录
export const scoreRecordColumns: ColumnsType<scoreRecordDataType> = [
  {
    title: '状态',
    width: 60,
    dataIndex: 'status',
    render: (value) => <Tag color="orange">{statusLinkTxtMap[value]?.slice(1)}</Tag>,
  },
  {
    title: '操作人',
    width: 60,
    dataIndex: 'opUser',
  },
  {
    title: '操作',
    width: 60,
    dataIndex: 'opResult',
    render: (value, { status }) => {
      if (value === '0') {
        return <Tag color="red">退回</Tag>;
      }

      let txt = '同意';
      if (['0', '1', '11', '12'].includes(status)) {
        txt = '提交';
      }
      return <Tag color="blue">{txt}</Tag>;
    },
  },
  {
    title: '操作时间',
    width: 130,
    dataIndex: 'createtime',
  },
];

// ------------------存续基金评测---------------------
export type activeKeyType = 'alreadyReview' | 'notYetReview';
type ExistingColumnDefs = (IColumnDefs[number] & { activeKey?: activeKeyType })[];
type getExistingFundColumnsType = (params: {
  dispatchers: any;
  activeKey: activeKeyType;
  setVisibleExisting: React.Dispatch<React.SetStateAction<boolean | 'batch' | 'single'>>;
}) => ExistingColumnDefs;
export const getExistingFundColumns: getExistingFundColumnsType = ({
  activeKey,
  dispatchers,
  setVisibleExisting,
}) => {
  const currentYear = moment().year();
  const rawData: ExistingColumnDefs = [
    {
      headerName: '产品名称',
      field: 'fundCode',
      hideInTable: true,
      component: 'DictSelectPlus',
      dictId: D.FUNDINFO_LIST,
      componentProps: {
        mode: 'multiple',
        filterOption: (value, { dictLabel, dictValue }) =>
          dictLabel?.includes(value) || dictValue?.includes(value),
        placeholder: '请输入产品名称、代码搜索',
      },
      transform: (value) => value?.join(),
    },
    {
      headerName: '产品名称',
      field: 'fundName',
      width: 300,
      minWidth: 300,
      hideInSearch: true,
      cellRenderer: activeKey === 'alreadyReview' ? 'agGroupCellRenderer' : undefined,
      valueGetter: ({ data }) => `${data.fundName}[${data.fundCode}]`,
      checkboxSelection: true,
      headerCheckboxSelection: true,
    },
    {
      headerName: '评测年度',
      field: 'year',
      component: DatePicker.YearPicker,
      hideInTable: true,
      componentProps: {
        allowClear: false,
      },
      transform: (value) => value?.format('YYYY'),
      activeKey: 'notYetReview',
    },
    {
      headerName: '评测日期',
      field: 'evalDate',
      component: DatePicker.RangePicker,
      componentProps: {
        defaultValue: [moment(`${currentYear}-01-01`), moment(`${currentYear}-12-31`)],
      },
      type: 'date',
      activeKey: 'alreadyReview',
      flex: 1,
    },
    {
      headerName: '基金类型',
      field: 'fundType',
      component: 'DictSelectPlus',
      renderType: 'tag',
      dictId: '5bbfb267-25cd-4ac5-82b1-2fcb47f80ef5',
      componentProps: {
        placeholder: '请选择基金类型',
      },
      flex: 1,
    },
    {
      headerName: '上年度评分',
      field: 'score',
      activeKey: 'notYetReview',
      hideInSearch: true,
      flex: 1,
    },
    {
      headerName: '上年度反洗钱等级',
      field: 'riskLv',
      hideInSearch: true,
      cellRenderer: ({ value }) => (
        <span style={value === '高风险' ? { color: 'var(--tag-error-color)' } : {}}>{value}</span>
      ),
      activeKey: 'notYetReview',
      flex: 1,
    },
    {
      headerName: '评分',
      field: 'score',
      hideInSearch: true,
      activeKey: 'alreadyReview',
      flex: 1,
    },
    {
      headerName: '反洗钱等级',
      field: 'riskLv',
      hideInSearch: true,
      cellRenderer: ({ value }) => (
        <span style={value === '高风险' ? { color: 'var(--tag-error-color)' } : {}}>{value}</span>
      ),
      activeKey: 'alreadyReview',
      flex: 1,
    },
    {
      headerName: '状态',
      field: 'status',
      component: 'DictSelectPlus',
      dictId: 'd5ed14f8-cad5-4377-9b9f-b4c132e9485e',
      renderType: 'tag',
      componentProps: {
        placeholder: '请选择状态',
      },
      hideInSearch: activeKey === 'notYetReview',
      hideInTable: true,
      flex: 1,
    },
    {
      headerName: '状态',
      field: 'status',
      component: 'DictSelectPlus',
      dictId: '6a7cf257-90ae-4da7-beba-8bca414e2fdc',
      renderType: 'tag',
      componentProps: {
        placeholder: '请选择状态',
      },
      hideInSearch: true,
      flex: 1,
    },
    {
      headerName: '备注',
      field: 'memo',
      hideInSearch: true,
      flex: 1,
    },
    {
      headerName: '操作',
      hideInSearch: true,
      width: 100,
      minWidth: 100,
      filter: false,
      cellRenderer: ({ data }) => {
        return (
          <PDTButton
            type="link"
            permissionId={getPermissionId(data.status)}
            onClick={() => {
              dispatchers.updateState({ antimoneyActiveRow: data });
              if (data.status === '0') {
                setVisibleExisting('single');
                return;
              }

              window.openTab({ path: `/app/pdt/doc/antimoney/score?type=duration` });
            }}
          >
            {statusLinkTxtMap[data.status]}
          </PDTButton>
        );
      },
    },
  ];

  if (activeKey === 'alreadyReview') {
    return rawData.filter((item) => item.activeKey !== 'notYetReview');
  }
  return rawData.filter((item) => item.activeKey !== 'alreadyReview');
};
