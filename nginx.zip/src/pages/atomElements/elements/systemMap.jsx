import React, { useState } from 'react';
import { Form, Input, Popconfirm, Table, Typography, Space, Button } from 'antd';
import { PDTSelect, PDTText } from '@/common/component';
import { uuid, D } from '@/utils';
import styles from './style.less';

const EditableCell = ({
  editing,
  dataIndex,
  title,
  required,
  component: Component,
  componentProps = {},
  record,
  index,
  children,
  ...restProps
}) => {
  const inputNode = Component ? (
    <Component {...componentProps} />
  ) : (
    <Input placeholder="请输入" {...componentProps} />
  );
  return (
    <td {...restProps}>
      {editing ? (
        <Form.Item
          name={dataIndex}
          style={{ margin: 0 }}
          rules={[{ required, message: `${title}必填` }]}
        >
          {inputNode}
        </Form.Item>
      ) : (
        <PDTText dictId={componentProps.dictId} value={children?.[1]} />
      )}
    </td>
  );
};

const getDefaultFields = () => ({
  alias: '',
  srcSys: undefined,
  pk: '',
  table_name: '',
  event: undefined,
});

const Index = (props) => {
  const { value = [], onChange } = props;
  const [form] = Form.useForm();
  const [editingKey, setEditingKey] = useState('');
  const isEditing = (record) => record.id === editingKey;
  const edit = (record) => {
    form.setFieldsValue({ ...getDefaultFields(), ...record });
    setEditingKey(record.id);
  };

  const cancel = () => {
    setEditingKey('');
  };

  const save = async (id) => {
    try {
      const row = await form.validateFields();
      const newData = [...value];
      const index = newData.findIndex((item) => id === item.id);
      if (index > -1) {
        const item = newData[index];
        newData.splice(index, 1, {
          ...item,
          ...row,
        });
      } else {
        newData.push(row);
      }
      onChange(newData);
      setEditingKey('');
    } catch (errInfo) {
      console.log('Validate Failed:', errInfo);
    }
  };

  const onDelete = ({ id }) => {
    onChange(value.filter((item) => item.id !== id));
    setEditingKey('');
  };

  const columns = [
    {
      title: '别名',
      dataIndex: 'alias',
      editable: true,
      required: true,
    },
    {
      title: '所属系统',
      dataIndex: 'srcSys',
      editable: true,
      required: true,
      component: PDTSelect,
      componentProps: { style: { width: 100 }, dictId: D.SRCSYS },
    },
    {
      title: '所属主键',
      dataIndex: 'pk',
      editable: true,
    },
    {
      title: '表名',
      dataIndex: 'table_name',
      editable: true,
    },
    {
      title: '事件',
      dataIndex: 'event',
      editable: true,
      component: PDTSelect,
      componentProps: { style: { width: 100 }, dictId: D.EVENT },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      width: 120,
      render: (_, record) => {
        const editable = isEditing(record);
        return (
          <Space>
            {editable ? (
              <>
                <Typography.Link onClick={() => save(record.id)}>保存</Typography.Link>
                <Popconfirm title="确定取消吗?" onConfirm={cancel}>
                  <a>取消</a>
                </Popconfirm>
              </>
            ) : (
              <Typography.Link onClick={() => edit(record)}>编辑</Typography.Link>
            )}
            <Popconfirm title="确定删除吗?" onConfirm={() => onDelete(record)}>
              <a>删除</a>
            </Popconfirm>
          </Space>
        );
      },
    },
  ];

  const mergedColumns = columns.map((col) => {
    if (!col.editable) {
      return col;
    }
    return {
      ...col,
      onCell: (record) => ({
        record,
        dataIndex: col.dataIndex,
        title: col.title,
        editing: isEditing(record),
        required: col.required,
        component: col.component,
        componentProps: col.componentProps,
      }),
    };
  });

  const onAddClick = () => {
    const id = uuid();
    onChange([...value, { id }]);
    setEditingKey(id);
    form.setFieldsValue(getDefaultFields());
  };

  return (
    <Form form={form} component={false}>
      <Table
        size="small"
        components={{
          body: { cell: EditableCell },
        }}
        rowKey={(record) => record.id}
        dataSource={value}
        columns={mergedColumns}
        rowClassName="editable-row"
        pagination={false}
        className={styles.footStyle}
        footer={() => (
          <Button type="dashed" size="small" disabled={!!editingKey} onClick={onAddClick}>
            新增
          </Button>
        )}
      />
    </Form>
  );
};
export default Index;
