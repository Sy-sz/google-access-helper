import React, { useRef } from 'react';
import { Form, Col, Input, Button, Space, Divider, Typography } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { DictSelectPlus, FetchTable, SearchSelect } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { fn } from '@cerdo/cerdo-utils';
import SearchCard from 'common/component/SearchCard';
import { comEleDimensionQuery, comEleElementList } from 'common/axios';
import { openModal } from '@/utils';
import Edit from './edit';
import RoleEdit from '../role/eidt';
import ModuleTreeSelect from '../component/ModuleTreeSelect';
import PopverRole from '../component/PopverRole';

const FormItem = Form.Item;
const columnsList = [
  {
    title: '要素',
    dataIndex: 'elementname',
    fixed: 'left',
    width: 160,
    render: (text, record) => (
      <PopverRole data={record}>
        <Typography.Paragraph copyable>{text}</Typography.Paragraph>
      </PopverRole>
    ),
  },
  { title: '要素名称', dataIndex: 'elementdesc', fixed: 'left', width: 100 },
  {
    title: '维度',
    dataIndex: 'dimensionname',
    width: 100,
    render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph>,
  },
  { title: '维度名称', dataIndex: 'dimensiondesc', width: 100 },
  {
    title: '要素类型',
    dataIndex: 'type',
    width: 100,
    render: (text) => ['普通要素', '唯一性要素', '虚拟要素'][Number(text)],
  },
  { title: '数据类型', dataIndex: 'valuetype', width: 100 },
  {
    title: '是否主键',
    dataIndex: 'ispk',
    width: 50,
    align: 'center',
    render: (text) => (text === '1' ? <CheckOutlined /> : null),
  },
  // { title: '是否外键', dataIndex: 'isforegnkey', width: 50, render: (text) => text === '1' ? <CheckOutlined /> : null },
  // { title: '外键Key', dataIndex: 'foreignkeyid', width: 100 },
  { title: '归属部门', dataIndex: 'belongdeptname', width: 100 },
  { title: '引用系统', dataIndex: 'srcsys', width: 100 },
  { title: '所属模块', dataIndex: 'modulename', width: 100 },
  // { title: '用途', dataIndex: 'elementpurp', width: 100 },
  {
    title: '最近更新人/时间',
    dataIndex: 'updateuser',
    width: 150,
    fixed: 'right',
    render: (_, record) => {
      return (
        <Space size={0} direction="vertical">
          <span>{record.updateuser}</span>
          <span>{record.updatetime}</span>
        </Space>
      );
    },
  },
];

const Elements = () => {
  const formRef = useRef(null);
  const tableRef = useRef(null);

  const reloadData = () => {
    tableRef.current.reloadAndReset();
  };

  // const deleteItem = ({ dimid }) => {
  //   comEleElementRemove({ dimid }).then(() => {
  //     reloadData();
  //   });
  // };

  const handleAdd = () => {
    openModal(Edit, { editType: 'add', onOk: reloadData });
  };

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams(formRef.current).then((values) => {
        comEleElementList({ ...values }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
        });
      });
    });
  };

  const onReset = () => {
    reloadData();
  };

  const columns = columnsList
    .filter((a) => (typeof a.showTable === 'undefined' ? true : false))
    .concat({
      title: '操作',
      fixed: 'right',
      width: 120,
      render: (_, record) => (
        <Space size={0} split={<Divider type="vertical" />}>
          <Button
            type="link"
            onClick={() =>
              openModal(RoleEdit, {
                title: `要素(${record.elementname}[${record.elementdesc}])权限设置`,
                data: record,
                onOk: reloadData,
              })
            }
          >
            权限设置
          </Button>
          <Button type="link" onClick={() => openModal(Edit, { ...record, onOk: reloadData })}>
            编辑
          </Button>
          {/* <Popconfirm title="确认删除？" onConfirm={() => deleteItem(record)}>
            <Button type="link" danger>删除</Button>
          </Popconfirm> */}
        </Space>
      ),
    });

  return (
    <>
      <SearchCard ref={formRef} onSearch={reloadData} onReset={onReset}>
        <Col span={8}>
          <FormItem label="关键词" name="keyword">
            <Input allowClear placeholder="请输入关键词" />
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="维度" name="dimensionname">
            <SearchSelect
              style={{ width: '100%' }}
              getData={comEleDimensionQuery}
              placeholder="请选择维度搜索"
              onSearch={null}
            >
              {(item) => (
                <SearchSelect.Option key={item.dimensionname} value={item.dimensionname}>
                  {item.dimensiondesc}[{item.dimensionname}]
                </SearchSelect.Option>
              )}
            </SearchSelect>
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="要素类型" name="type">
            <DictSelectPlus dictId="67166c64-21dd-417e-9254-9dcc13f1834a" />
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="所属模块" name="moduleid">
            <ModuleTreeSelect allowClear />
          </FormItem>
        </Col>
      </SearchCard>

      <ListCard
        title="要素列表"
        bordered={false}
        extra={
          <Button type="primary" onClick={handleAdd}>
            添加
          </Button>
        }
      >
        <FetchTable
          size="small"
          showTools={false}
          rowKey="dimid"
          ref={tableRef}
          getList={getList}
          columns={columns}
          scroll={{ y: 'calc(100vh - 320px)', x: 1200 }}
          autoHeight={{ blankHeight: 230 }}
        />
      </ListCard>
    </>
  );
};

export default Elements;
