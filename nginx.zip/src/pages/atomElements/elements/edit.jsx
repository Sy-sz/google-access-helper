import React, { useEffect, useState } from 'react';
import {
  DeptTreeSelect,
  DictSelectPlus,
  DragModal,
  FetchSelect,
  UserSelect,
} from '@cerdo/cerdo-design';
import { CONST, fn, storage } from '@cerdo/cerdo-utils';
import { AutoComplete, Col, DatePicker, Divider, Form, Input, Radio, Row, Select } from 'antd';
import {
  comEleElementSave,
  comEleDimensionQuery,
  comEleModuleQuery,
  comEleElementQuery,
} from '@/common/axios';
import ModuleTreeSelect from '../component/ModuleTreeSelect';
import { D } from '@/utils';
import moment from 'moment';
import SystemMap from './systemMap';

const FormItem = Form.Item;

const Edit = (props) => {
  const { open, title, onCancel, onOk, editType, ...otherProps } = props;
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [dimensionNameOptions, setDimensionNameOptions] = useState([]);
  const userInfo = storage.getUserInfo() || {};

  const initialValues = {
    ...otherProps,
    ...otherProps.elementcomponent,
    srctime: otherProps.srctime ? moment(otherProps.srctime) : undefined,
    srcsys: otherProps.srcsys ? otherProps.srcsys.split(',') : undefined,
  };

  const getData = () => {
    Promise.all([comEleDimensionQuery(), comEleModuleQuery()]).then((result) => {
      if (fn.checkResponse(result[0])) {
        setDimensionNameOptions(result[0].data.map((a) => ({ ...a, value: a.dimensionname })));
      }
      if (fn.checkResponse(result[1])) {
        // setDimensionNameOptions(result[1].data);
      }
    });
  };

  useEffect(() => {
    getData();
  }, []);

  const handleOk = () => {
    setLoading(true);
    form
      .validateFields()
      .then((values) => {
        Object.keys(values).forEach((key) => {
          const element = values[key];
          if (element && typeof element === 'string') {
            values[key] = values[key].trim();
          }
          if (element === undefined) {
            values[key] = '';
          }
        });

        values.srcsys = (values.srcsys || []).join();

        comEleElementSave({
          ...otherProps,
          ...values,
          elementMapping: values.elementMapping || [],
          elementcomponent: {
            componentname: values.componentname,
            dictid: values.dictid,
            queryparam: values.queryparam,
            ismult: values.ismult,
          },
        })
          .then((result) => {
            if (fn.checkResponse(result)) {
              onOk();
            }
          })
          .finally(() => setLoading(false));
      })
      .catch(() => setLoading(false));
  };

  const handleCancel = () => {
    onCancel();
    form.resetFields();
  };

  return (
    <DragModal
      title={title ?? editType === 'add' ? '新增要素' : '编辑要素'}
      visible={open}
      width="calc(1000px)"
      maskClosable={false}
      destroyOnClose
      closable={false}
      onCancel={handleCancel}
      onOk={handleOk}
      okText="保存"
      confirmLoading={loading}
    >
      <Form form={form} {...CONST.formModalLayout} initialValues={initialValues}>
        <Row>
          <Divider type="horizontal" orientation="left">
            要素信息
          </Divider>
          <Col span={12}>
            <FormItem
              label="要素"
              name="elementname"
              rules={[
                {
                  required: true,
                  message: '请输入要素',
                },
              ]}
            >
              <Input placeholder="请输入要素" />
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="要素名称"
              name="elementdesc"
              rules={[
                {
                  required: true,
                  message: '请输入要素名称',
                },
              ]}
            >
              <Input placeholder="请输入要素名称" />
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="维度"
              name="dimensionname"
              rules={[
                {
                  required: true,
                  message: '请选择维度',
                },
              ]}
            >
              <AutoComplete
                options={dimensionNameOptions}
                placeholder="请选择维度"
                onSelect={(value, option) => {
                  form.setFieldsValue({ dimensiondesc: option.dimensiondesc });
                }}
              />
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="维度名称"
              name="dimensiondesc"
              rules={[
                {
                  required: true,
                  message: '请输入维度名称',
                },
              ]}
            >
              <Input placeholder="请输入维度名称" />
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="要素类型"
              name="type"
              rules={[
                {
                  required: true,
                  message: '请选择要素类型',
                },
              ]}
            >
              <DictSelectPlus
                dictId="67166c64-21dd-417e-9254-9dcc13f1834a"
                style={{ width: '100%' }}
                placeholder="请选择要素类型"
              />
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="数据类型"
              name="valuetype"
              rules={[
                {
                  required: true,
                  message: '请选择数据类型',
                },
              ]}
            >
              <DictSelectPlus
                dictId="ef1d3000-92dd-4cfd-8836-21e817c31a7c"
                style={{ width: '100%' }}
                placeholder="请选择数据类型"
              />
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="是否主键"
              name="ispk"
              initialValue="0"
              rules={[
                {
                  required: true,
                  message: '请选择是否主键',
                },
              ]}
            >
              <Radio.Group>
                <Radio value="1">是</Radio>
                <Radio value="0">否</Radio>
              </Radio.Group>
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="是否外键"
              name="isforeignkey"
              initialValue="0"
              rules={[
                {
                  required: true,
                  message: '请选择是否外键',
                },
              ]}
            >
              <Radio.Group>
                <Radio value="1">是</Radio>
                <Radio value="0">否</Radio>
              </Radio.Group>
            </FormItem>
          </Col>
          <FormItem
            noStyle
            shouldUpdate={(prevValues, curValues) =>
              prevValues.isforeignkey !== curValues.isforeignkey
            }
          >
            {({ getFieldValue }) =>
              getFieldValue('isforeignkey') === '1' && (
                <Col span={12}>
                  <FormItem
                    label="外键"
                    name="foreignkeyid"
                    rules={[
                      {
                        required: true,
                        message: '请选择外键',
                      },
                    ]}
                  >
                    <FetchSelect
                      getData={comEleElementQuery}
                      getParams={(value) => ({
                        keyword: value,
                        ispk: '1',
                      })}
                      style={{ width: '100%' }}
                      placeholder="请选择外键"
                      dropdownMatchSelectWidth={false}
                      firstInit
                    >
                      {(item) => (
                        <FetchSelect.Option
                          key={item.dimid}
                          value={item.dimid}
                          title={`${item.elementname}(${item.elementdesc}) - ${item.dimensionname}(${item.dimensiondesc})`}
                        >
                          {item.elementname}({item.elementdesc}) - {item.dimensionname}(
                          {item.dimensiondesc})
                        </FetchSelect.Option>
                      )}
                    </FetchSelect>
                  </FormItem>
                </Col>
              )
            }
          </FormItem>
          <Divider type="horizontal" orientation="left">
            关联信息
          </Divider>
          <FormItem
            noStyle
            shouldUpdate={(prevValues, curValues) => prevValues.type !== curValues.type}
          >
            {({ getFieldValue }) => (
              <Col span={12}>
                <FormItem
                  label="所属模块"
                  name="moduleid"
                  rules={[
                    {
                      required: ['0', '1'].includes(getFieldValue('type')),
                      message: '请选择所属模块',
                    },
                  ]}
                >
                  <ModuleTreeSelect />
                </FormItem>
              </Col>
            )}
          </FormItem>
          <Col span={12}>
            <FormItem
              label="归属部门"
              name="belongdept"
              rules={[
                {
                  // required: true,
                  message: '请选择归属部门',
                },
              ]}
            >
              <DeptTreeSelect style={{ width: '100%' }} placeholder="请选择归属部门" />
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="创建人"
              initialValue={userInfo.userName}
              name="srcuser"
              rules={[
                {
                  // required: true,
                  message: '请选择创建人',
                },
              ]}
            >
              <UserSelect style={{ width: '100%' }}>
                {(item) => {
                  return (
                    <Select.Option key={item.id} value={item.userName}>
                      {item.userName}
                    </Select.Option>
                  );
                }}
              </UserSelect>
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="创建时间"
              name="srctime"
              initialValue={moment()}
              rules={[
                {
                  required: false,
                  message: '请选择创建时间',
                },
              ]}
            >
              <DatePicker placeholder="请选择创建时间" style={{ width: '100%' }} />
            </FormItem>
          </Col>
          <Col span={24}>
            <FormItem
              {...CONST.formModalFullLayout}
              label="引用系统"
              name="srcsys"
              rules={[
                {
                  required: false,
                  message: '请选择引用系统',
                },
              ]}
            >
              <DictSelectPlus
                mode="tags"
                dictId="597397d7-65c3-408c-8a47-25d9f488f3d3"
                style={{ width: '100%' }}
                placeholder="请选择引用系统"
              />
            </FormItem>
          </Col>
          <Col span={24}>
            <FormItem
              {...CONST.formModalFullLayout}
              label="用途"
              name="elementpurp"
              rules={[
                {
                  // required: true,
                  message: '请输入用途',
                },
              ]}
            >
              <Input.TextArea autoSize={{ minRows: 3, maxRows: 20 }} placeholder="请输入用途" />
            </FormItem>
          </Col>
          <Col span={24}>
            <FormItem label="对应其他系统" name="elementMapping" {...CONST.formModalFullLayout}>
              <SystemMap />
            </FormItem>
          </Col>
          <Divider type="horizontal" orientation="left">
            前端组件信息
          </Divider>
          <Col span={12}>
            <FormItem
              label="组件类型"
              name="componentname"
              rules={[
                {
                  // required: true,
                  message: '请输入组件类型',
                },
              ]}
            >
              <DictSelectPlus
                dictId="9b638ac1-e614-42d8-bcc3-3f30fe281108"
                style={{ width: '100%' }}
                placeholder="请选择字典ID"
              />
            </FormItem>
          </Col>
          <FormItem
            noStyle
            shouldUpdate={(prevValues, curValues) =>
              prevValues.componentname !== curValues.componentname
            }
          >
            {({ getFieldValue }) =>
              ['DictSelectPlus'].includes(getFieldValue('componentname')) && (
                <>
                  <Col span={12}>
                    <FormItem
                      label="字典ID"
                      name="dictid"
                      rules={[
                        {
                          required: true,
                          message: '请输入字典ID',
                        },
                      ]}
                    >
                      <Input placeholder="请输入字典ID" />
                    </FormItem>
                  </Col>
                  <Col span={12}>
                    <FormItem
                      label="查询参数"
                      name="queryparam"
                      rules={[
                        {
                          required: false,
                          message: '请输入参数',
                        },
                      ]}
                    >
                      <Input placeholder="请输入参数" />
                    </FormItem>
                  </Col>
                </>
              )
            }
          </FormItem>
          <Col span={12}>
            <FormItem label="是否多选" name="ismult">
              <DictSelectPlus
                dictId={D.YESORNO_LIST}
                style={{ width: '100%' }}
                placeholder="请选择是否多选"
              />
            </FormItem>
          </Col>
        </Row>
      </Form>
    </DragModal>
  );
};

export default Edit;
