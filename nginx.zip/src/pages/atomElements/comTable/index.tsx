import React, { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import { Spin, Tooltip, Space, Result } from 'antd';
import moment from 'moment';
import { SearchAgGridTable } from '@cerdo/cerdo-design';
import { url, fn, guid, api } from '@cerdo/cerdo-utils';
import { isEmpty, get, cloneDeep, isPlainObject, omit, forOwn } from 'lodash';
import { comEleFuncList } from '@/common/axios';
import type { IJsonSchema, TColumnDefs, TCellRenderConfig, TSubTableConfig } from './types';
import type { ProcessRowGroupForExportParams, ExcelRow } from 'ag-grid-community';
import { comEleQuerylistApi } from '@/common/axios/config';
import ButtonRender from './buttonRender';
import { pickerMap, rowHeight } from './data';

/** 子表格 */
const SubTable =
  ({
    footButton,
    searchAgGridTableRef,
    style,
    getGlobalDeps,
    ...subTableConfig
  }: TSubTableConfig) =>
  ({ data, node }) => {
    const { deps, buttons } = footButton || {};
    // footButton 的依赖，只支持从 node 里的值
    const dependencies = getGlobalDeps(deps)?.map((item) => {
      if (item.startsWith('$')) {
        return get(node, item.slice(1));
      }
      return item;
    });

    const height = rowHeight * (data.CHILDREN?.length || 4) + 40;

    return (
      <div style={{ paddingLeft: 30, paddingBottom: 10, width: '60%', ...style }}>
        <SearchAgGridTable
          tableConfig={{
            height: height > 430 ? 430 : height,
            // defaultColDef: { flex: 1 },
            suppressCellFocus: false,
            pagination: false,
            rowData: data.CHILDREN,
            statusBar: null,
            ...subTableConfig,
          }}
        />
        {buttons && (
          <ButtonRender
            buttons={buttons}
            dependencies={dependencies}
            searchAgGridTableRef={searchAgGridTableRef}
          />
        )}
      </div>
    );
  };

const Index = () => {
  const [jsonschema, setJsonSchema] = useState<IJsonSchema>({});
  const [searchParams, setSearchParams] = useState({}); // 搜索参数
  const [selectionRows, setSelectionRows] = useState([]); // 选中的行
  const { funcid, searchForm } = url.getAllQueryString();
  const agGridRef = useRef(null); // agGrid ref
  const searchAgGridTableRef = useRef(null); // searchAgGridTable ref
  const dictMap = useRef({}); // 字典
  const { tableConfig, searchFormConfig, actionBtns, roles, method = 'get' } = jsonschema;

  /** 全局依赖 */
  const getGlobalDeps = useCallback(
    (deps) => {
      if (!deps?.length) {
        return [];
      }

      return deps.map((dep) => {
        if (!dep.startsWith('$')) {
          return dep;
        }

        const [path1, path2] = dep.slice(1).split('.');
        switch (path1) {
          case 'uuid':
          case 'guid':
            return guid();
          case 'funcid':
            return funcid;
          case 'moment':
            return moment().format(path2);
          case 'searchParams': // 搜索参数
            return searchParams[path2] || '';
          case 'selection': // 复选框 选中的参数(逗号分隔的字符串)
            const values = selectionRows?.map((item) => item[path2])?.join();
            return values;
          default:
            return dep;
        }
      });
    },
    [searchParams, selectionRows],
  );

  /** 表头中的cellRenderer */
  const renderCell =
    ({ deps, buttons }: TCellRenderConfig) =>
    (params) => {
      const dependencies = getGlobalDeps(deps)?.map((item) => {
        if (item.startsWith('$')) {
          return get(params, item.slice(1));
        }
        return item;
      });
      if (buttons?.length) {
        return (
          <Space>
            <ButtonRender
              buttons={buttons}
              dependencies={dependencies}
              searchAgGridTableRef={searchAgGridTableRef}
            />
          </Space>
        );
      }
      return null;
    };

  /** 格式化表头 */
  interface IFormatColumnDefs {
    columnDefs: TColumnDefs;
    isSubTable?: boolean;
  }
  const formatColumnDefs = ({ columnDefs, isSubTable }: IFormatColumnDefs) =>
    columnDefs.map(({ cellRenderConfig, tooltip, ...columns }) => {
      if (isPlainObject(cellRenderConfig) && !isEmpty(cellRenderConfig)) {
        columns.cellRenderer = renderCell(cellRenderConfig);
      }

      if (tooltip) {
        columns.cellRenderer = ({ value }) => (
          <Tooltip title={value}>
            <span>{value}</span>
          </Tooltip>
        );
      }

      // 子表格隐藏表单
      if (isSubTable) {
        columns.hideInSearch = columns.hideInSearch ?? true;
      }

      // 搜索条件，日期格式化
      const picker = columns.componentProps?.picker;
      if (!columns.hideInSearch && picker) {
        columns.transform = (value) =>
          value ? moment(value).format(pickerMap[picker]) : undefined;
      }
      // 搜索条件，多选时转为字符串
      const mode = columns.componentProps?.mode;
      if (!columns.hideInSearch && mode) {
        columns.transform = (value) =>
          value?.length ? value.join(columns.separator || ',') : undefined;
      }
      // 多选字典翻译
      if (columns.dictId && mode) {
        columns.valueGetter = ({ data }) => {
          const value = data[columns.field]
            ?.split(',')
            ?.map((item) => dictMap.current[columns.dictId][item])
            ?.join();
          return value;
        };
      }

      return columns;
    });

  const formatDictMap = (dictRes) =>
    dictRes.reduce((map, res) => {
      const { dictId, children } = res.data;
      const dictItemMap = {};
      children.forEach((item) => {
        dictItemMap[item.dictValue] = item.dictLabel;
      });
      if (!map[dictId]) {
        map[dictId] = dictItemMap;
      }
      return map;
    }, {});

  /** 查 父表格的多选字典 */
  const fetchMultipleDict = (columns) =>
    new Promise(async (resolve) => {
      const multipleDictId = [];
      columns.forEach(({ dictId, componentProps }) => {
        if (dictId && componentProps?.mode === 'multiple') {
          multipleDictId.push(api.dictTree({ dictId }));
        }
      });
      if (!multipleDictId.length) {
        resolve({});
        return;
      }

      const dictRes = await Promise.all(multipleDictId);
      const dictMap = formatDictMap(dictRes);
      resolve(dictMap);
    });

  /** 查 子表格的所有字典，导出需要 */
  const fetchSubDictMap = async (subColumns) => {
    if (!subColumns?.length) {
      return;
    }

    const subDictId = [];
    subColumns.forEach(({ dictId }) => {
      if (dictId) {
        subDictId.push(api.dictTree({ dictId }));
      }
    });
    if (!subDictId.length) {
      return;
    }

    const subDictRes = await Promise.all(subDictId);
    const subDictMap = formatDictMap(subDictRes);
    Object.assign(dictMap.current, subDictMap);
  };

  /** 初始化数据、字典 */
  const fetchDataByFuncId = async () => {
    try {
      const res = await comEleFuncList({ funcid });
      const data = res.data?.find((e) => e.funcid === funcid);
      if (!fn.checkResponse(res) || !data?.jsonschema) {
        return;
      }

      const jsonschema = JSON.parse(data.jsonschema) as IJsonSchema;
      console.log('jsonschema--> 接口', cloneDeep(jsonschema));

      const columns = jsonschema.tableConfig.columnDefs;
      dictMap.current = await fetchMultipleDict(columns);
      const columnDefs = formatColumnDefs({ columnDefs: columns });
      const config = { columnDefs };

      // 子表格相关
      const subTableConfig = jsonschema.tableConfig.subTableConfig;
      if (subTableConfig?.columnDefs?.length) {
        const subColumns = formatColumnDefs({
          columnDefs: subTableConfig?.columnDefs,
          isSubTable: true,
        });
        Object.assign(config, {
          masterDetail: true,
          detailRowAutoHeight: true,
          keepDetailRows: true,
          ...omit(subTableConfig, 'columnDefs'),
          detailCellRenderer: SubTable({
            ...subTableConfig,
            columnDefs: subColumns,
            searchAgGridTableRef,
            getGlobalDeps,
          }),
        });
      }
      Object.assign(jsonschema.tableConfig, config);
      setJsonSchema(jsonschema);
      document.title = data.funcname;
    } catch (error) {
      console.error(error);
    }
  };

  /** 查数据接口入参格式化， 并把搜索参数存下来 */
  const onFormatParams = (params) => {
    params.funcid = funcid;
    if (tableConfig?.pagination) {
      params.page = params.currentPage;
      params.size = params.pageSize;
    }
    delete params.currentPage;
    delete params.pageSize;
    setSearchParams(params);
    return params;
  };

  const onGridReady = (grid) => {
    agGridRef.current = grid;
  };

  /** 导出子表格-设置单元格属性 */
  const cell = (text: any, styleId?: string | string[]) => ({
    styleId: styleId,
    data: {
      type: /^\d+$/.test(text) ? 'Number' : 'String',
      value: text,
    },
  });

  /** 导出子表格-组装表头和数据 */
  const getCustomContentBelowRow = (params: ProcessRowGroupForExportParams) => {
    const subColumns = tableConfig?.subTableConfig?.columnDefs;
    if (isEmpty(subColumns)) {
      return undefined;
    }

    const validColumns = subColumns.filter((item) => item.field);
    const headerCells = validColumns.map((item) => cell(item.headerName, 'header'));
    headerCells.unshift(cell(''));
    const bodyCells = (record) => {
      // 子表格导出翻译
      const content = validColumns.map((item) => {
        const { dictId, field, componentProps } = item;
        let cellValue = record[field];
        if (dictId) {
          if (componentProps?.mode === 'multiple') {
            cellValue = cellValue
              ?.split(',')
              ?.map((id) => dictMap.current[dictId][id])
              ?.join();
          } else {
            cellValue = dictMap.current[dictId][cellValue];
          }
        }
        return cell(cellValue, ['body', 'leftType', 'stringType']);
      });

      return [cell(''), ...content];
    };

    const head = [{ outlineLevel: 1, cells: headerCells, collapsed: true }];
    const body = params.node.data.CHILDREN?.map((record) => [
      { outlineLevel: 1, cells: bodyCells(record), collapsed: true },
    ]) || [{ outlineLevel: 1, cells: [cell('')] }];

    const rows = head.concat(...body);

    return rows as ExcelRow[];
  };

  /** 导出 */
  const exportExcel = useCallback(
    (fileName) => agGridRef.current?.api.exportDataAsExcel({ fileName }),
    [],
  );

  /** actionsBtns依赖 */
  const actionsBtnsDeps = useMemo(
    () => getGlobalDeps(actionBtns?.deps),
    [actionBtns, getGlobalDeps],
  );

  /** 搜索框默认值 */
  const searchFormInitValues = useMemo(() => {
    if (!tableConfig?.columnDefs?.length || !searchForm) {
      return {};
    }

    const params = JSON.parse(searchForm);
    const fieldMap = {};
    // 处理日期的默认值，把字符串转为moment
    tableConfig.columnDefs.forEach(({ field, ...rest }) => {
      fieldMap[field] = rest;
    });
    forOwn(params, (value, key) => {
      const datePicker = fieldMap[key]?.component === 'DatePicker';
      const picker = fieldMap[key]?.componentProps?.picker;
      if (datePicker || picker) {
        params[key] = moment(value);
      }
    });
    return params;
  }, [searchForm, tableConfig]);

  /** 角色权限控制 */
  const hasRoleAuth = useMemo(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!roles?.length) {
      return true;
    }
    const hasAuth = user.roleInfoList.some((item) => roles.includes(item.id));
    return hasAuth;
  }, [roles]);

  /** 选中行 */
  const onSelectionChanged = (e) => {
    setSelectionRows(e.api.getSelectedRows());
  };

  useEffect(() => {
    fetchDataByFuncId();
  }, []);

  const subColumns = tableConfig?.subTableConfig?.columnDefs;
  useEffect(() => {
    fetchSubDictMap(subColumns);
  }, [subColumns]);

  if (isEmpty(jsonschema)) {
    return <Spin style={{ width: '100%', marginTop: '20vh' }} />;
  }

  if (!hasRoleAuth) {
    return <Result status="403" title="暂无权限" />;
  }

  return (
    <div>
      <SearchAgGridTable
        ref={searchAgGridTableRef}
        actionBtns={[
          <ButtonRender
            key="1"
            exportExcel={exportExcel}
            buttons={actionBtns?.buttons}
            dependencies={actionsBtnsDeps}
            searchParams={searchParams}
            searchAgGridTableRef={searchAgGridTableRef}
          />,
        ]}
        resetAutoQuery
        tableConfig={{
          autoHeight: true,
          suppressCellFocus: false,
          pagination: false,
          onGridReady,
          suppressExcelExport: false,
          defaultExcelExportParams: { getCustomContentBelowRow },
          excelStyles: [
            {
              id: 'header',
              interior: {
                color: '#aaaaaa',
                pattern: 'Solid',
              },
            },
            {
              id: 'body',
              interior: {
                color: '#dddddd',
                pattern: 'Solid',
              },
            },
          ],
          onSelectionChanged,
          ...tableConfig,
        }}
        searchFormConfig={{
          defaultCollapsed: false,
          searchColNum: 4,
          initialValues: searchFormInitValues,
          ...searchFormConfig,
        }}
        method={method}
        url={jsonschema.url || comEleQuerylistApi}
        // onFormatResponse={onFormatResponse}
        onFormatParams={onFormatParams}
      />
    </div>
  );
};

export default Index;
