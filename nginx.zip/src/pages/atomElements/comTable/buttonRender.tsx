import React, { useEffect, useState } from 'react';
import { Popconfirm, Button, message } from 'antd';
import { omit } from 'lodash';
import { cacheGet } from '@cerdo/cerdo-utils/lib/upmHttp';
import { userPermissionApi } from '@cerdo/cerdo-utils/lib/config';
import { pdtHttp, convertDeps, convertObjectDeps } from './data';
import type { ButtonRenderProps, ComfirmProps } from './types';

const Index: React.FC<ButtonRenderProps> = (props) => {
  const {
    dependencies = [],
    buttons = [],
    searchParams,
    searchAgGridTableRef,
    exportExcel,
  } = props;
  const [buttonData, setButtonData] = useState([]);

  const onConfirm = async ({
    source,
    actionType,
    popconfirm,
    url,
    api,
    fileName,
    method = 'get',
    data = {},
  }: ComfirmProps) => {
    if (source === 'button' && popconfirm) {
      return;
    }

    switch (actionType) {
      case 'api': {
        if (!api) {
          message.info('未配置接口地址');
          return;
        }

        const convertApi = convertDeps(api, dependencies);
        const params = convertObjectDeps(data, dependencies);
        await pdtHttp[method]({ url: convertApi, data: params });
        message.success('操作成功');
        searchAgGridTableRef?.current?.onSearch();
        break;
      }
      case 'url':
        window.open(convertDeps(url, dependencies));
        break;
      case 'fe-export':
        exportExcel(convertDeps(fileName, dependencies));
        break;
      case 'be-export': {
        if (!api) {
          message.info('未配置接口地址');
          return;
        }

        const convertApi = convertDeps(api, dependencies);
        const params = convertObjectDeps(data, dependencies);
        params.filename = convertDeps(fileName, dependencies);
        Object.assign(params, searchParams);
        method = 'download';
        pdtHttp[method]({ url: convertApi, data: params });
        break;
      }
      default:
    }
  };

  /** 查 按钮权限 */
  const fetchButtonPermission = () => {
    const requestArr = [];
    buttons.forEach((item) => {
      if (item.permissionId) {
        requestArr.push(
          cacheGet({
            url: userPermissionApi,
            data: { permissionids: item.permissionId },
          }),
        );
      }
    });
    if (!requestArr.length) {
      setButtonData(buttons);
      return;
    }

    const permissionMap = {};
    Promise.all(requestArr).then((res) => {
      res.forEach((item) => {
        const { haspermission, permissionid } = item.data?.[0];
        permissionMap[permissionid] = haspermission === 1;
      });
      const buttonData = buttons.filter(
        (item) => !item.permissionId || permissionMap[item.permissionId],
      );
      setButtonData(buttonData);
    });
  };

  useEffect(() => {
    fetchButtonPermission();
  }, [buttons]);

  return (
    <>
      {buttonData.map(({ text, popconfirm, ...rest }, i) => {
        return (
          <Popconfirm
            key={i}
            visible={popconfirm ? undefined : false}
            title={popconfirm?.title || '确认操作吗？'}
            {...popconfirm}
            onConfirm={() => onConfirm({ popconfirm, ...rest })}
          >
            <Button
              size="small"
              type="primary"
              {...omit(rest, ['actionType', 'fileName', 'permissionId'])}
              onClick={() => onConfirm({ source: 'button', popconfirm, ...rest })}
            >
              {convertDeps(text, dependencies)}
            </Button>
          </Popconfirm>
        );
      })}
    </>
  );
};

export default Index;
