import type {
  ISearchAgGridTable,
  IColumnDefs,
  SearchFormConfig,
} from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import type { ButtonProps, PopconfirmProps } from 'antd';
import { TableConfig } from 'ag-grid-react';

export interface IButtons extends ButtonProps {
  text: string;
  /** api: 调接口的按钮(删除)；url: 跳页面的按钮(新增、编辑); fe-export: 前端导出；be-export： 后端导出 */
  actionType: 'api' | 'url' | 'fe-export' | 'be-export';
  url?: string;
  api?: string;
  method?: 'get' | 'post' | 'download';
  /** api入参 */
  data?: Record<string, string>;
  popconfirm?: PopconfirmProps;
  /** 权限字典id */
  permissionId?: string;
  /** 导出文件名 */
  fileName?: string;
}

interface DepsButtons {
  deps?: string[];
  buttons?: IButtons[];
}

export type TCellRenderConfig = DepsButtons;

export interface TSubTableConfig extends Omit<ITableConfig, 'subTableConfig'> {
  footButton?: DepsButtons;
  getGlobalDeps: (params: any) => string[];
  searchAgGridTableRef?: React.MutableRefObject<any>;
  style?: React.CSSProperties;
}

/** 复用 SearchAgGridTable 的 IColumnDefs 类型 */
export type TColumnDefs = (IColumnDefs[number] & {
  cellRenderConfig?: TCellRenderConfig;
  tooltip?: boolean;
  field?: string;
  valueGetter?: string | ((params: any) => string);
  cellRenderer?: (params: any) => React.ReactNode; // TODO: 为什么没有覆盖原有的类型
})[];

interface ITableConfig extends Omit<TableConfig, 'columnDefs'> {
  columnDefs?: TColumnDefs;
  subTableConfig?: TSubTableConfig;
}

export interface IJsonSchema extends Omit<ISearchAgGridTable, 'tableConfig'> {
  roles?: string[];
  tableConfig?: ITableConfig;
  searchFormConfig?: SearchFormConfig;
  actionBtns?: DepsButtons;
}

export interface ButtonRenderProps {
  buttons: IButtons[];
  dependencies?: any[];
  exportExcel?: (fileName: string) => void;
  /** 搜索参数 */
  searchParams?: Record<string, any>;
  searchAgGridTableRef?: React.MutableRefObject<any>;
}

export type ComfirmProps = Partial<IButtons> & { source?: 'button' | 'popconfirm' };
