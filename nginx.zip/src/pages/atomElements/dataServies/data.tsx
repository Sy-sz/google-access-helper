import React from 'react';
import { Space } from 'antd';
import { PDTButton } from '@/common/component';
import { type IColumnDefs } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import { D } from '@/utils';

type GetColumnsDefs = (params: {
  onEdit: (row: Record<string, any>) => void;
  onDel: (ids: string) => void;
}) => IColumnDefs;
export const getColumnsDefs: GetColumnsDefs = ({ onEdit, onDel }) => [
  {
    headerName: '数据服务ID',
    field: 'callapiId',
    hideInSearch: true,
    flex: 1,
    checkboxSelection: true,
  },
  {
    headerName: '数据服务',
    field: 'callapiName',
    flex: 1,
    componentProps: { placeholder: '请输入数据服务' },
  },
  {
    headerName: '数据类型',
    field: 'dataType',
    flex: 1,
    dictId: D.FUNCTION_TYPE_LIST,
    hideInSearch: true,
  },
  {
    headerName: '主键字段',
    field: 'pkEleName',
    hideInSearch: true,
    flex: 1,
  },
  {
    headerName: '行主键',
    field: 'fkEleName',
    hideInSearch: true,
    flex: 1,
  },
  {
    headerName: '表名',
    field: 'tableName',
    hideInSearch: true,
    flex: 1,
  },
  {
    headerName: '所属系统',
    field: 'srcSys',
    hideInSearch: true,
    flex: 1,
  },
  {
    headerName: '操作',
    width: 120,
    minWidth: 120,
    filter: false,
    hideInSearch: true,
    cellRenderer: ({ data }) => {
      return (
        <Space size="large">
          <PDTButton type="link" style={{ padding: 0 }} onClick={() => onEdit(data)}>
            编辑
          </PDTButton>

          <PDTButton
            type="link"
            style={{ padding: 0 }}
            deleteConfirm
            onClick={() => onDel(data.id)}
          >
            删除
          </PDTButton>
        </Space>
      );
    },
  },
];
