import React, { useState, useRef } from 'react';
import { Space, Form, message, Modal, Input } from 'antd';
import { isEmpty } from 'lodash';
import { SearchAgGridTable, DictSelectPlus } from '@cerdo/cerdo-design';
import { PDTButton } from '@/common/component';
import { sqlmodelSave, sqlmodelDel } from '@/common/axios';
import { sqlmodelList } from '@/common/axios/config';
import { getColumnsDefs } from './data';
import { D } from '@/utils';

const FormItem = Form.Item;

const DataServies = () => {
  const [visible, setVisible] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]); // 已勾选的行
  const agGridRef = useRef(null); // agGrid ref
  const searchAgTableRef = useRef(null);
  const activeRow = useRef<Record<string, any>>({}); // 正在编辑中的行
  const [form] = Form.useForm();

  const onGridReady = (grid) => {
    agGridRef.current = grid;
  };

  /** 关闭弹窗 */
  const closeModal = () => {
    setVisible(false);
    activeRow.current = {};
    form.resetFields();
  };

  /** 删除 */
  const onDel = async (ids: string) => {
    const [err] = await sqlmodelDel({ ids });
    if (err) {
      return;
    }

    message.success('删除成功');
    searchAgTableRef.current.onSearch();
  };

  /** 批量删除 */
  const onBatchDel = async () => {
    const ids = selectedRows.map((item) => item.id).join();
    onDel(ids);
  };

  /** 编辑 */
  const onEdit = (row) => {
    form.setFieldsValue(row);
    activeRow.current = row;
    setVisible(true);
  };

  /** 保存 */
  const onOk = async () => {
    const values = await form.validateFields();
    setConfirmLoading(true);
    const id = activeRow.current.id || '';
    const [err] = await sqlmodelSave({ ...values, id });
    if (err) {
      setConfirmLoading(false);
      return;
    }

    message.success('操作成功');
    searchAgTableRef.current.onSearch();
    closeModal();
    setConfirmLoading(false);
  };

  const onSelectionChanged = () => {
    const selectedRows = agGridRef.current?.api?.getSelectedRows();
    setSelectedRows(selectedRows);
  };

  return (
    <div>
      <SearchAgGridTable
        method="get"
        url={sqlmodelList}
        ref={searchAgTableRef}
        // onFormatParams={onFormatParams}
        actionBtns={[
          <Space key="Space">
            <PDTButton key="1" type="primary" onClick={() => setVisible(true)}>
              新增
            </PDTButton>
            <PDTButton
              key="2"
              deleteConfirm
              type="primary"
              disabled={!selectedRows.length}
              onClick={onBatchDel}
            >
              删除
            </PDTButton>
          </Space>,
        ]}
        tableConfig={{
          autoHeight: true,
          suppressCellFocus: false,
          suppressRowClickSelection: true,
          onGridReady,
          onSelectionChanged,
          columnDefs: getColumnsDefs({ onEdit, onDel }),
        }}
        searchFormConfig={{ searchColNum: 4 }}
      />

      <Modal
        title={`${isEmpty(activeRow.current) ? '新增' : '编辑'}数据服务`}
        visible={visible}
        maskClosable={false}
        onOk={onOk}
        onCancel={closeModal}
        confirmLoading={confirmLoading}
      >
        <Form form={form} labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
          <FormItem
            label="数据服务ID"
            name="callapiId"
            rules={[{ required: true, message: '请选择数据服务ID' }]}
          >
            <Input placeholder="请输入数据服务ID" />
          </FormItem>
          <FormItem
            label="数据服务"
            name="callapiName"
            rules={[{ required: true, message: '请选择数据服务' }]}
          >
            <Input placeholder="请输入数据服务" />
          </FormItem>

          <FormItem
            name="dataType"
            label="数据类型"
            initialValue="FORM"
            rules={[{ required: true, message: '请选择' }]}
          >
            <DictSelectPlus
              allowClear={false}
              style={{ width: '100%' }}
              dictId={D.FUNCTION_TYPE_LIST}
            />
          </FormItem>
          <FormItem
            name="pkEleName"
            label="主键"
            rules={[{ required: true, message: '请输入主键' }]}
          >
            <Input placeholder="请输入主键" />
          </FormItem>
          <FormItem
            noStyle
            shouldUpdate={(prevValues, currentValues) =>
              prevValues.dataType !== currentValues.dataType
            }
          >
            {({ getFieldValue }) =>
              getFieldValue('dataType') === 'TABLE' && (
                <FormItem
                  label="行主键"
                  name="fkEleName"
                  rules={[{ required: true, message: '请输入行主键' }]}
                >
                  <Input placeholder="请输入行主键" />
                </FormItem>
              )
            }
          </FormItem>
          <FormItem
            name="tableName"
            label="表名"
            rules={[{ required: true, message: '请输入表名' }]}
          >
            <Input placeholder="请输入表名" />
          </FormItem>
          <FormItem
            name="srcSys"
            label="所属系统"
            rules={[{ required: true, message: '请输入所属系统' }]}
          >
            <Input placeholder="请输入所属系统" />
          </FormItem>
        </Form>
      </Modal>
    </div>
  );
};

export default DataServies;
