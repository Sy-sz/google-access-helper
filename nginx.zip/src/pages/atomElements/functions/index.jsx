import React, { useRef, useState } from 'react';
import { Form, Col, Input, Button, Space, Popconfirm, Divider } from 'antd';
import { FetchTable } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { convert, fn } from '@cerdo/cerdo-utils';
import SearchCard from 'common/component/SearchCard';
import { comEleFuncRemove, comEleFuncList } from 'common/axios';
import { openModal } from '@/utils';
import Edit from './edit';
import TempEntry from './tempEntry';
import { Link } from 'react-router-dom';
import FuncEle from './funcEle';
import styles from './index.less';
import TableDesigner from './tableDesigner';

const FormItem = Form.Item;
export const columnsList = [
  { title: '功能名称', dataIndex: 'funcname' },
  {
    title: '功能类型',
    dataIndex: 'functype',
    render: (text) => ['表单', '表格'][Number(text)],
  },
  {
    title: '展示类型',
    dataIndex: 'displaytype',
    render: (text) => ['视图', '编辑'][Number(text)],
  },
  {
    title: '审核类型',
    dataIndex: 'reviewtype',
    render: (text) => ['无需审核', '单人审核', '多人审核'][Number(text)],
  },
  { title: '主维度', dataIndex: 'leaddimensiondesc' },
  {
    title: '需要生效控制',
    dataIndex: 'iseffect',
    render: (text) => convert.toYesNo(text),
  },
  // { title: '来源系统', dataIndex: 'srcsys' },
  {
    title: '最近更新人/时间',
    dataIndex: 'updateuser',
    width: 210,
    fixed: 'right',
    render: (_, record) => {
      return (
        <Space>
          <span>{record.updateuser}</span>
          <span>{record.updatetime}</span>
        </Space>
      );
    },
  },
];

const Role = () => {
  const formRef = useRef(null);
  const tableRef = useRef(null);
  const [tableDesigVisible, setTableDesignVisible] = useState(false);
  const [tableDesignRow, setTableDesignRow] = useState({});

  const reloadData = () => {
    tableRef.current.reloadAndReset();
  };

  const handleRemoveClick = ({ funcid }) => {
    comEleFuncRemove({ funcid }).then((result) => {
      if (fn.checkResponse(result)) {
        reloadData();
      }
    });
  };

  const handleAdd = () => {
    openModal(Edit, { editType: 'add', onOk: reloadData });
  };

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams(formRef.current).then((values) => {
        comEleFuncList({ ...values }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
        });
      });
    });
  };

  const onReset = () => {
    reloadData();
  };

  const columns = columnsList.concat([
    {
      title: '临时入口',
      width: 80,
      fixed: 'right',
      render: (_, record) => <TempEntry {...record} />,
    },
    {
      title: '操作',
      fixed: 'right',
      width: '300px',
      render: (_, record) => (
        <Space size={0} split={<Divider type="vertical" />}>
          {record.functype === '0' ? (
            <Link target="_blank" to={`/app/com/formDesigner?layout=sub&funcid=${record.funcid}`}>
              设计表单
            </Link>
          ) : (
            <Button
              type="link"
              size="small"
              onClick={() => {
                // openModal(TableDesigner, record)
                setTableDesignVisible(true);
                setTableDesignRow(record);
              }}
            >
              设计表格
            </Button>
          )}
          <a type="link" onClick={() => openModal(FuncEle, { ...record, onOk: () => {} })}>
            维护要素
          </a>
          <Link target="_blank" to={`/app/com/preview?layout=sub&funcid=${record.funcid}`}>
            预览表单
          </Link>
          <Button
            type="link"
            size="small"
            onClick={() => openModal(Edit, { ...record, onOk: reloadData })}
          >
            编辑
          </Button>
          <Popconfirm
            title="确认删除？"
            onConfirm={() => handleRemoveClick(record)}
            overlayClassName={styles.popconfirm}
          >
            <Button type="link" danger size="small">
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ]);

  return (
    <>
      <SearchCard ref={formRef} onSearch={reloadData} onReset={onReset}>
        <Col span={8}>
          <FormItem label="关键词" name="keyword">
            <Input allowClear placeholder="请输入功能名搜索" />
          </FormItem>
        </Col>
      </SearchCard>

      <ListCard
        title="功能列表"
        bordered={false}
        extra={
          <Button type="primary" onClick={handleAdd}>
            添加
          </Button>
        }
      >
        <FetchTable
          size="small"
          showTools={false}
          rowKey="funcid"
          ref={tableRef}
          getList={getList}
          columns={columns}
          scroll={{ y: 'calc(100vh - 320px)', x: '1200px' }}
          autoHeight={{ blankHeight: 230 }}
        />
      </ListCard>

      <TableDesigner
        {...tableDesignRow}
        visible={tableDesigVisible}
        afterSave={() => reloadData()}
        setTableDesignVisible={setTableDesignVisible}
      />
    </>
  );
};

export default Role;
