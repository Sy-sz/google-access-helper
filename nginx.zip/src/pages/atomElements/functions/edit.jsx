import React, { useState } from 'react';
import { DictSelectPlus, DragModal, SearchSelect } from '@cerdo/cerdo-design';
import { InfoCircleOutlined } from '@ant-design/icons';
import { CONST, fn } from '@cerdo/cerdo-utils';
import { Col, Form, Input, Radio, Row, Modal } from 'antd';
import { comEleDimensionQuery, comEleFuncSave } from '@/common/axios';
import { D } from '@/utils';

const FormItem = Form.Item;

const Edit = (props) => {
  const { open, title, onCancel, onOk, editType, ...otherProps } = props;
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const initialValues = { ...otherProps };

  const saveFunc = (values) => {
    setLoading(true);
    return comEleFuncSave({ ...otherProps, ...values })
      .then((result) => {
        if (fn.checkResponse(result)) {
          onOk();
        }
      })
      .finally(() => setLoading(false));
  };

  const handleOk = async () => {
    form
      .validateFields()
      .then((values) => {
        Object.keys(values).forEach((key) => {
          const element = values[key];
          if (element && typeof element === 'string') {
            values[key] = values[key].trim();
          }
        });
        values.apprvtitle = values.apprvtitle || '';
        if (otherProps.funcid !== values.funcid) {
          Modal.confirm({
            title: '提示',
            icon: null,
            content: (
              <div style={{ color: 'var(--tag-error-color)' }}>
                修改功能ID可能会影响已有功能的使用，请谨慎操作！！！
              </div>
            ),
            onOk: () => {
              values.oldfuncid = otherProps.funcid;
              return saveFunc(values);
            },
          });
          return;
        }

        saveFunc(values);
      })
      .catch(() => setLoading(false));
  };

  const handleCancel = () => {
    onCancel();
    form.resetFields();
  };

  return (
    <DragModal
      title={title ?? editType === 'add' ? '新增功能' : '编辑功能'}
      visible={open}
      width="calc(800px)"
      maskClosable={false}
      destroyOnClose
      closable={false}
      onCancel={handleCancel}
      onOk={handleOk}
      okText="保存"
      confirmLoading={loading}
    >
      <Form form={form} {...CONST.formModalLayout} initialValues={initialValues}>
        <Row>
          <Col span={12}>
            <FormItem
              label="功能名"
              name="funcname"
              rules={[
                {
                  required: true,
                  message: '请输入功能名',
                },
              ]}
            >
              <Input placeholder="请输入功能名" />
            </FormItem>
          </Col>
          <Col span={12}>
            <FormItem
              label="功能类型"
              name="functype"
              initialValue="0"
              rules={[
                {
                  required: true,
                  message: '请选择功能类型',
                },
              ]}
            >
              <DictSelectPlus
                dictId="a5e9cbc7-e2a0-43af-8a0b-32173b0c9b54"
                style={{ width: '100%' }}
                placeholder="请选择功能类型"
              />
            </FormItem>
          </Col>
          <FormItem
            noStyle
            shouldUpdate={(prevValues, currentValues) =>
              prevValues.functype !== currentValues.functype
            }
          >
            {({ getFieldValue }) =>
              getFieldValue('functype') === '0' ? (
                <>
                  <Col span={12}>
                    <FormItem
                      label="展示类型"
                      name="displaytype"
                      initialValue="1"
                      rules={[
                        {
                          required: true,
                          message: '请选择展示类型',
                        },
                      ]}
                    >
                      <DictSelectPlus
                        dictId="9c8b1499-5cf1-4ce7-8385-a4e1578c28cb"
                        style={{ width: '100%' }}
                        placeholder="请选择展示类型"
                      />
                    </FormItem>
                  </Col>
                  <Col span={12}>
                    <FormItem
                      label="审核类型"
                      name="reviewtype"
                      rules={[
                        {
                          required: true,
                          message: '请选择审核类型',
                        },
                      ]}
                    >
                      <DictSelectPlus
                        dictId="a49ef2f7-cd1a-40bf-836b-03f9e1dafcd9"
                        style={{ width: '100%' }}
                        placeholder="请选择审核类型"
                      />
                    </FormItem>
                  </Col>
                  <Col span={12}>
                    <FormItem
                      label="需要生效控制"
                      name="iseffect"
                      initialValue="0"
                      rules={[
                        {
                          required: true,
                          message: '请选择需要生效控制',
                        },
                      ]}
                    >
                      <Radio.Group>
                        <Radio value="1">是</Radio>
                        <Radio value="0">否</Radio>
                      </Radio.Group>
                    </FormItem>
                  </Col>
                  <Col span={12}>
                    <FormItem label="审核标题" name="apprvtitle">
                      <Input placeholder="请输入" />
                    </FormItem>
                  </Col>
                </>
              ) : null
            }
          </FormItem>
          <FormItem
            noStyle
            shouldUpdate={(prevValues, currentValues) =>
              prevValues.functype !== currentValues.functype
            }
          >
            {({ getFieldValue }) => (
              <Col span={12}>
                <FormItem
                  label="主维度"
                  name="leaddimension"
                  rules={[
                    {
                      required: getFieldValue('functype') === '0',
                      message: '请选择维度搜索',
                    },
                  ]}
                >
                  <SearchSelect
                    getData={comEleDimensionQuery}
                    style={{ width: '100%' }}
                    placeholder="请选择维度搜索"
                  >
                    {(item) => (
                      <SearchSelect.Option key={item.dimensionname} value={item.dimensionname}>
                        {item.dimensiondesc}
                      </SearchSelect.Option>
                    )}
                  </SearchSelect>
                </FormItem>
              </Col>
            )}
          </FormItem>
          <Col span={12}>
            <FormItem label="是否自动发起" name="isAudit" initialValue="0">
              <DictSelectPlus
                allowClear={false}
                style={{ width: '100%' }}
                dictId={D.YESORNO_LIST}
              />
            </FormItem>
          </Col>
          {editType !== 'add' && (
            <Col span={24}>
              <FormItem
                {...CONST.formModalFullLayout}
                label="功能ID"
                name="funcid"
                rules={[{ required: true }]}
                tooltip={{
                  title: '修改功能ID可能会影响已有功能的使用，请谨慎操作！！！',
                  icon: <InfoCircleOutlined />,
                }}
              >
                <Input placeholder="修改功能ID可能会影响已有功能的使用，请谨慎操作！！！" />
              </FormItem>
            </Col>
          )}
          <Col span={24}>
            <FormItem
              {...CONST.formModalFullLayout}
              label="功能标题"
              name="functitle"
              tooltip="SQL查询拼接标题，参数主数据dataid"
              rules={[
                {
                  // required: true,
                  message: '请输入SQL',
                },
              ]}
            >
              <Input.TextArea autoSize={{ minRows: 3, maxRows: 20 }} placeholder="请输入SQL" />
            </FormItem>
          </Col>
        </Row>
      </Form>
    </DragModal>
  );
};

export default Edit;
