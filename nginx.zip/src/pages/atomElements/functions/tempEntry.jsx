import React, { useState } from 'react';
import { Modal, Space, Button, message } from 'antd';
import { DictSelectPlus } from '@cerdo/cerdo-design';

const functypeMap = {
  0: 'form',
  1: 'table',
};

const TempEntry = (props) => {
  const { funcid, functype } = props;
  const [open, setOpen] = useState(false);
  const [currentRow, setCurrentRow] = useState({});

  return (
    <>
      <Button type="link" size="small" onClick={() => setOpen(true)}>
        入口
      </Button>
      <Modal footer={null} title={props.funcname} visible={open} onCancel={() => setOpen(false)}>
        <div>
          编辑必填：
          <DictSelectPlus
            onChange={(_, record) => {
              let row = {};
              if (record) {
                row = { ...record, fundid: record.value };
              }
              setCurrentRow(row);
            }}
            dictId="c551ee28-0be9-45d9-87bb-3c9ec3d00fe9"
            style={{ width: '100%' }}
          />
        </div>

        <Space style={{ marginTop: 20 }}>
          <Button
            type="primary"
            onClick={() => {
              const [path] = location.href.split('#');
              window.open(
                `${path}/#/app/com/${functypeMap[functype]}?layout=sub&funcid=${funcid}`,
                '_blank',
              );
            }}
          >
            新增
          </Button>
          <Button
            type="primary"
            onClick={() => {
              if (!currentRow?.fundid) {
                message.info('选了基金，再点编辑');
                return;
              }

              const [path] = location.href.split('#');
              window.open(
                `${path}/#/app/com/form?layout=sub&funcid=${funcid}&dataid=${currentRow.fundid}`,
                '_blank',
              );
            }}
          >
            编辑
          </Button>
        </Space>
      </Modal>
    </>
  );
};

export default TempEntry;
