import React, { useRef, useEffect, useState, useMemo } from 'react';
import { Modal, Spin, Space, Popover, Typography, message } from 'antd';
import { UnorderedListOutlined } from '@ant-design/icons';
// import { CodeEditor } from '@cerdo/cerdo-design';
import CodeEditor, { loader } from '@monaco-editor/react';
import { fn } from '@cerdo/cerdo-utils';
import { comEleFuncElementList, comEleFuncSave } from '@/common/axios';
import type { ModalProps } from 'antd/lib/modal';
import { syntaxHighlight, uuid } from '@/utils';
import * as monaco from 'monaco-editor';
import store from '@/store';
import styles from './index.less';

loader.config({ monaco });

const { useModel } = store;

const defaultCode = JSON.stringify(
  {
    tableConfig: {
      columnDefs: [],
    },
  },
  null,
  2,
);
interface IProps extends ModalProps {
  visible: boolean;
  funcid: string;
  funcname: string;
  jsonschema: string;
  afterSave: () => void;
  setTableDesignVisible: (visible: boolean) => void;
  // [key: string]: any;
}

const Index: React.FC<IProps> = (props) => {
  const { funcid, funcname, visible, jsonschema, setTableDesignVisible, ...otherProps } = props;
  const [defaultColumns, setDefaultColumns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pdtSystem] = useModel('pdtSystem');
  const editorRef = useRef(null);
  const { theme } = pdtSystem;

  const editorKey = useMemo(() => uuid(), [jsonschema]);

  const handleEditorDidMount = (editor) => {
    editorRef.current = editor;
  };

  const handleEditorValidation = (markers) => {
    markers.forEach((marker) => console.log('onValidate:', marker.message));
  };

  /** 根据功能id查要素 */
  const fetchFieldsByFuncId = () => {
    setLoading(true);
    comEleFuncElementList({ funcid })
      .then((res) => {
        const defaultColumns = res.data?.map((item) => ({
          field: item.elementname,
          headerName: item.elementdesc,
        }));
        if (defaultColumns.length) {
          setDefaultColumns(defaultColumns);
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  const onSave = async () => {
    const newJsonschema = editorRef.current.getValue();
    setLoading(true);
    const res = await comEleFuncSave({
      ...otherProps,
      funcid,
      jsonschema: newJsonschema,
      changetable: '1',
    });
    if (fn.checkResponse(res)) {
      message.success('保存成功');
      props.afterSave();
    }
    setLoading(false);
  };

  useEffect(() => {
    if (visible) {
      fetchFieldsByFuncId();
    }
  }, [visible]);

  // console.log('defaultColumns', defaultColumns);
  return (
    <Modal
      width="60%"
      okText="保存"
      keyboard={false}
      title={funcname}
      visible={props.visible}
      className={styles.modal}
      confirmLoading={loading}
      bodyStyle={{ height: '60vh', padding: '0' }}
      onCancel={() => setTableDesignVisible(false)}
      onOk={onSave}
    >
      <Spin spinning={loading} wrapperClassName={styles.spin}>
        <div className={styles.headActionBar}>
          <Space className={styles.left}>
            <Popover
              title={
                <div className={styles.popoverTitle}>
                  <span>已维护的要素</span>{' '}
                  <Typography.Paragraph
                    copyable={{
                      text: JSON.stringify(defaultColumns),
                    }}
                  />
                </div>
              }
              overlayStyle={{ width: 400, height: 400, overflow: 'auto' }}
              content={
                <pre
                  dangerouslySetInnerHTML={{
                    __html: syntaxHighlight(defaultColumns),
                  }}
                />
              }
            >
              <UnorderedListOutlined title="已选要素" />
            </Popover>
          </Space>
          {/* <Space className={styles.right}>
            <CodeOutlined />
            <PlaySquareOutlined />
          </Space> */}
        </div>
        <CodeEditor
          key={editorKey}
          height="calc(100% - 26px)"
          language="json"
          defaultValue={jsonschema || defaultCode}
          theme={theme === 'light' ? 'light' : 'vs-dark'}
          onMount={handleEditorDidMount}
          onValidate={handleEditorValidation}
        />
      </Spin>
    </Modal>
  );
};

export default Index;
