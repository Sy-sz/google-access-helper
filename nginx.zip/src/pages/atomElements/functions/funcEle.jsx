import React, { useEffect, useRef, useState } from 'react';
import { DragModal, FetchTable, SearchSelect } from '@cerdo/cerdo-design';
import { fn } from '@cerdo/cerdo-utils';
import {
  Col,
  Form,
  Input,
  message,
  Row,
  ConfigProvider,
  Tag,
  Typography,
  Space,
  Collapse,
  Spin,
  Switch,
} from 'antd';
import {
  comEleFuncElementSave,
  comEleElementList,
  comEleFuncElementList,
  comEleDimensionQuery,
} from '@/common/axios';
import { SearchOutlined } from '@ant-design/icons';
import zhCN from 'antd/es/locale/zh_CN';
import { SearchCard } from '@/common/component';
import styles from './index.less';
import _ from 'lodash';
import PopverRole from '../component/PopverRole';

const FormItem = Form.Item;

const columnsList = [
  {
    title: '要素',
    dataIndex: 'elementname',
    render: (text, record) => (
      <PopverRole data={record}>
        <Typography.Paragraph copyable>{text}</Typography.Paragraph>
      </PopverRole>
    ),
  },
  { title: '要素名', dataIndex: 'elementdesc' },
  {
    title: '维度',
    dataIndex: 'dimensionname',
    render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph>,
  },
  { title: '维度名', dataIndex: 'dimensiondesc' },
  // {
  //   title: '是否主键',
  //   dataIndex: 'ispk',
  //   align: 'center',
  //   render: (text) => (text === '1' ? <CheckOutlined /> : null),
  // },
];

const FuncEle = (props) => {
  const { open, title, onCancel, onOk, funcid } = props;
  const [loading, setLoading] = useState(false);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [searchValue, setSearchValue] = useState(null);
  const [leftLoading, setLeftLoading] = useState(false);

  const formRef = useRef(null);
  const tableRef = useRef(null);

  const getData = () => {
    setLeftLoading(true);
    comEleFuncElementList({ funcid })
      .then((result) => {
        if (fn.checkResponse(result)) {
          setSelectedRows(result?.data ?? []);
          setSelectedRowKeys(result?.data?.map((a) => a.dimid) ?? []);
        }
      })
      .finally(() => setLeftLoading(false));
  };

  useEffect(() => {
    getData();
  }, []);

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams(formRef.current).then((values) => {
        comEleElementList({
          ...values,
          type: '0,1', // 排除 虚拟要素
        }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
        });
      });
    });
  };

  const reloadData = () => {
    tableRef.current.reloadAndReset();
  };

  const onReset = () => {
    reloadData();
  };

  const handleOk = () => {
    setLoading(true);
    comEleFuncElementSave({
      funcid,
      elements: selectedRows.map((a) => ({
        dimid: a.dimid,
        permissiontype: a.permissiontype ?? '1',
      })),
    })
      .then((result) => {
        if (fn.checkResponse(result)) {
          message.success('保存成功', 0.5, () => {
            onOk();
          });
        }
      })
      .finally(() => setLoading(false));
  };

  const handleCancel = () => {
    onCancel();
  };

  const handleTagClose = ({ dimid }) => {
    setSelectedRowKeys(selectedRowKeys.filter((key) => key !== dimid));
    setSelectedRows(selectedRows.filter((a) => a.dimid !== dimid));
  };

  const handleInputChange = ({ target: { value } }) => {
    setSearchValue(value);
  };

  const hanleTypeChange = (checked, dimid) => {
    let temp = selectedRows.find((a) => a.dimid === dimid);
    if (temp) {
      temp.permissiontype = checked ? '0' : '1';
    }
    setSelectedRows([...selectedRows]);
  };

  const columns = [...columnsList];
  const rowSelection = {
    columnWidth: 50,
    selectedRowKeys: selectedRowKeys,
    // onChange: (keys, rows) => {
    //   setSelectedRowKeys([...selectedRowKeys, ...keys]);
    //   setSelectedRows(_.uniqWith([...selectedRows, ...rows], (a, b) => (a.dimid === b.dimid)));
    // },
    onSelect: (record, selected, rows) => {
      if (selected) {
        setSelectedRowKeys([...selectedRowKeys, record.dimid]);
        setSelectedRows(_.uniqWith([...selectedRows, record], (a, b) => a.dimid === b.dimid));
      } else {
        setSelectedRowKeys(selectedRowKeys.filter((key) => key !== record.dimid));
        setSelectedRows(selectedRows.filter((a) => a.dimid !== record.dimid));
      }
    },
    onSelectAll: (selected, rows, changeRows) => {
      if (selected) {
        setSelectedRowKeys([...selectedRowKeys, ...changeRows.map((a) => a.dimid)]);
        setSelectedRows(
          _.uniqWith([...selectedRows, ...changeRows], (a, b) => a.dimid === b.dimid),
        );
      } else {
        setSelectedRowKeys(
          selectedRowKeys.filter((key) => !changeRows.find((a) => a.dimid === key)),
        );
        setSelectedRows(selectedRows.filter((a) => !changeRows.find((b) => a.dimid === b.dimid)));
      }
    },
  };

  const renderCollapse = () => {
    let collapseData = {};

    console.log('selectedRows', selectedRows);

    selectedRows.forEach((item) => {
      let temp = collapseData[`${item.dimensionname}（${item.dimensiondesc}）`];
      if (temp) {
        temp.push(item);
      } else {
        collapseData[`${item.dimensionname}（${item.dimensiondesc}）`] = [item];
      }
    });

    return (
      <Collapse
        key={Object.keys(collapseData).join()}
        ghost
        size="small"
        defaultActiveKey={Object.keys(collapseData)}
        style={{ maxHeight: `calc(100vh - 380px)`, overflowY: 'auto', margin: '10px 0' }}
      >
        {Object.keys(collapseData).map((key) => (
          <Collapse.Panel
            key={key}
            header={key}
            style={{ padding: 0 }}
            extra={<small>共{collapseData?.[key]?.length}条</small>}
          >
            <Space direction="vertical" size={5}>
              {collapseData?.[key].map((item) => {
                let color = 'transparent';
                if (searchValue) {
                  color =
                    item.dimensiondesc?.toLowerCase().includes(searchValue?.toLowerCase()) ||
                    item.dimensionname?.toLowerCase().includes(searchValue?.toLowerCase()) ||
                    item.elementdesc?.toLowerCase().includes(searchValue?.toLowerCase()) ||
                    item.elementname?.toLowerCase().includes(searchValue?.toLowerCase())
                      ? 'red'
                      : 'transparent';
                }
                return (
                  <Tag
                    key={item.dimid}
                    closable
                    onClose={() => handleTagClose(item)}
                    style={{ maxWidth: '280px', border: `1px solid ${color}` }}
                  >
                    <Switch
                      size="small"
                      checked={Number(item.permissiontype ?? 1) === 0}
                      checkedChildren="仅查看"
                      style={{ margin: '0 5px 1px -3px' }}
                      onChange={(checked) => hanleTypeChange(checked, item.dimid)}
                    />
                    <PopverRole data={item}>
                      <Typography.Text
                        style={{ maxWidth: '160px' }}
                        ellipsis
                      >{`${item.elementdesc}`}</Typography.Text>
                    </PopverRole>
                    {/* <Typography.Text
                        style={{ maxWidth: '160px' }}
                        ellipsis
                      >{`${item.elementname}[${item.elementdesc}]`}</Typography.Text> */}
                  </Tag>
                );
              })}
            </Space>
          </Collapse.Panel>
        ))}
      </Collapse>
    );
  };

  return (
    <DragModal
      title={title ?? '功能要素维护'}
      visible={open}
      width="calc(1200px)"
      maskClosable={false}
      destroyOnClose
      closable={false}
      onCancel={handleCancel}
      onOk={handleOk}
      okText="保存"
      confirmLoading={loading}
      style={{ top: '40px' }}
      bodyStyle={{
        padding: '12px 8px 0',
        maxHeight: 'calc(100vh - 200px)',
      }}
    >
      <Row wrap={false} className={styles['com-element-func']}>
        <Col flex="300px" style={{ borderRight: '1px var(--modal-header-border) solid' }}>
          <Input
            style={{ width: '98%' }}
            placeholder="搜索已选择要素"
            suffix={
              searchValue ? (
                <Typography.Text type="secondary">
                  共
                  {
                    selectedRows.filter(
                      (item) =>
                        item.dimensiondesc?.toLowerCase().includes(searchValue?.toLowerCase()) ||
                        item.dimensionname?.toLowerCase().includes(searchValue?.toLowerCase()) ||
                        item.elementdesc?.toLowerCase().includes(searchValue?.toLowerCase()) ||
                        item.elementname?.toLowerCase().includes(searchValue?.toLowerCase()),
                    ).length
                  }
                  条
                </Typography.Text>
              ) : (
                <SearchOutlined />
              )
            }
            onChange={handleInputChange}
          />
          <Spin spinning={leftLoading} style={{ minHeight: 200 }}>
            {renderCollapse()}
          </Spin>
        </Col>
        <Col flex="auto">
          <SearchCard
            ref={formRef}
            onSearch={reloadData}
            onReset={onReset}
            bodyStyle={{ marginTop: '-12px' }}
          >
            <Col span={8}>
              <FormItem label="关键词" name="keyword">
                <Input allowClear placeholder="请输入要素、维度搜索" />
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="维度" name="dimensionname">
                <SearchSelect
                  getData={comEleDimensionQuery}
                  style={{ width: '160px' }}
                  placeholder="请选择维度搜索"
                  onSearch={null}
                >
                  {(item) => (
                    <SearchSelect.Option key={item.dimensionname} value={item.dimensionname}>
                      {item.dimensiondesc}[{item.dimensionname}]
                    </SearchSelect.Option>
                  )}
                </SearchSelect>
              </FormItem>
            </Col>
          </SearchCard>
          <ConfigProvider locale={zhCN}>
            <FetchTable
              size="small"
              showTools={false}
              rowKey="dimid"
              ref={tableRef}
              getList={getList}
              autoHeight={200}
              columns={columns}
              rowSelection={rowSelection}
              scroll={{ y: 'calc(100vh - 470px)' }}
            />
          </ConfigProvider>
        </Col>
      </Row>
    </DragModal>
  );
};

export default FuncEle;
