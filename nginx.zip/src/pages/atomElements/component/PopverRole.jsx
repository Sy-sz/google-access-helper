import { comElePermissionDetail } from '@/common/axios';
import { Popover, Switch, Table } from 'antd';
import React, { useState } from 'react';
import PopverRoleMember from './PopverRoleMember';
import { fn } from '@cerdo/cerdo-utils';

const PopverRole = (props) => {
  const {
    children,
    data: { dimid, elementname },
  } = props;

  const [tableData, setTaleData] = useState([]);
  const [tableLoading, setTaleLoading] = useState([]);

  // const tableData = data?.permissions?.map(item => {
  //   return {
  //     dimid: data?.dimid,
  //     roleid: item.roleid,
  //     rolename: item.rolename,
  //     viewpermission: Number(item.viewpermission) === 1,
  //     editpermission: Number(item.editpermission) === 1,
  //     reviewpermission: Number(item.reviewpermission) === 1,
  //   };
  // })

  const getData = () => {
    setTaleLoading(true);
    comElePermissionDetail({ dimid })
      .then((result) => {
        if (fn.checkResponse(result)) {
          setTaleData(result.data);
        }
      })
      .finally(() => setTaleLoading(false));
  };

  const handleVisibleChange = (visible) => {
    if (visible && tableData.length === 0) {
      getData();
    }
  };

  return (
    <Popover
      placement="right"
      title={`【${elementname}】权限信息`}
      onVisibleChange={handleVisibleChange}
      content={
        <Table
          size="small"
          rowKey="roleid"
          style={{ width: 300 }}
          dataSource={tableData}
          loading={tableLoading}
          columns={[
            {
              title: '角色名',
              dataIndex: 'rolename',
              render: (text, record) => <PopverRoleMember data={record}>{text}</PopverRoleMember>,
            },
            {
              title: '权限',
              dataIndex: 'permission',
              children: [
                {
                  title: '查看',
                  dataIndex: 'viewpermission',
                  align: 'center',
                  render: (text, record) => <Switch size="small" checked={text} disabled />,
                },
                {
                  title: '编辑',
                  dataIndex: 'editpermission',
                  align: 'center',
                  render: (text, record) => <Switch size="small" checked={text} disabled />,
                },
                {
                  title: '审核',
                  dataIndex: 'reviewpermission',
                  align: 'center',
                  render: (text, record) => <Switch size="small" checked={text} disabled />,
                },
              ],
            },
          ]}
          pagination={false}
          scroll={{ y: 240 }}
        />
      }
    >
      {children}
    </Popover>
  );
};

export default PopverRole;
