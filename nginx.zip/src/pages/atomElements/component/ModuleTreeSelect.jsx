import { comEleModuleTreeList } from '@/common/axios';
import { fn } from '@cerdo/cerdo-utils';
import { TreeSelect } from 'antd';
import React, { useState, useEffect } from 'react';

const ModuleTreeSelect = (props) => {
  const { ...otherProps } = props;
  const [treeData, setTreeData] = useState([]);

  useEffect(() => {
    comEleModuleTreeList({ haselement: '0' }).then(result => {
      if (fn.checkResponse(result)) {
        const treeData = toOptionsArray(result.data, 'nodeName', 'id');
        setTreeData(treeData);
      }
    })
  }, []);

  const toOptionsArray = (array, label, value) => {
    if (!Array.isArray(array)) {
      return array
    };

    const toOptions = (data) => {
      if (data && data.length > 0) {
        data.forEach((e) => {
          e.key = e[value];
          e.value = e[value];
          e.label = e[label];

          if (e.children && e.children.length > 0) {
            toOptions(e.children);
          } else {
            e.children = null;
          }
        });
      }
    };
    toOptions(array);
    return array;
  };


  return (
    <TreeSelect
      style={{ width: '100%' }}
      placeholder="请选择所属模块"
      treeData={treeData}
      treeDefaultExpandAll
      {...otherProps}
    />
  );
}

export default ModuleTreeSelect;
