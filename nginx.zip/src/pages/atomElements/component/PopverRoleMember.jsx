import React, { useState } from 'react';
import { fn } from '@cerdo/cerdo-utils';
import { Popover, Table } from 'antd';
import { comEleRoleMappingList } from '@/common/axios';

const PopverRoleMember = (props) => {
  const {
    title,
    children,
    data: { roleid, rolename },
  } = props;
  const [tableData, setTaleData] = useState([]);
  const [tableLoading, setTaleLoading] = useState([]);

  const getData = () => {
    setTaleLoading(true);
    comEleRoleMappingList({ roleid })
      .then((result) => {
        if (fn.checkResponse(result)) {
          setTaleData(result.data);
        }
      })
      .finally(() => setTaleLoading(false));
  };

  const handleVisibleChange = (visible) => {
    if (visible && tableData.length === 0) {
      getData();
    }
  };

  return (
    <Popover
      placement="right"
      title={title ?? `【${rolename}】成员信息`}
      onVisibleChange={handleVisibleChange}
      content={
        <Table
          size="small"
          style={{ width: 300 }}
          columns={[
            { title: '名称', dataIndex: 'objname' },
            {
              title: '类型',
              dataIndex: 'objtype',
              render: (text) => ['', '员工', '部门', '岗位', '角色'][Number(text)],
            },
          ]}
          loading={tableLoading}
          dataSource={tableData}
          rowKey="objid"
          pagination={false}
          scroll={{ y: 240 }}
        />
      }
    >
      {children}
    </Popover>
  );
};

export default PopverRoleMember;
