# 通用表格配置

> 只写与 `searchAgGridTable` 不同的地方

## url

查表格数据接口。默认 `comele/common/querylist`

## method

默认 `get`

## actionBtns

类型是个对象。包含 `deps` 和 `buttons`

```json
{
    "actionBtns": {
        "deps": ["$searchParams.year", "$moment.YYYYMMDD"],
        "buttons": [
            {
                "text": "导出"，
                "actionType": "fe-exprot",
                "fileName": "华宝基金{{$0}}数据{{$1}}.xlsx"
            }
        ]
    }
}
```

## deps buttons requestConfig 详细说明

`deps` 即依赖，`buttons` 即按钮配置，是为了实现表格各种按钮操作，方便取到所需要的参数，一般都是配合使用。比如 `actionBtns` ，`cellRenderConfig` `footButton` 都有使用到

- `actionBtns` 即表格右上方的按钮，如新增、导出等。
- `cellRenderConfig` 即表格内单元格渲染成按钮，如编辑、删除等。
- `footButton` 即子表格的按钮

`deps` 是个数组，以`$`开头，代码里会把他翻译成对应的参数，方便`buttons`里使用；`deps` 有全局的和非全局的之分

| deps写法          | 含义                                | 作用范围         | 示例                  |
| ----------------- | ----------------------------------- | ---------------- | --------------------- |
| $searchParams.xxx | 取搜索条件里的的值                  | 全局             | $searchParams.year    |
| $moment.xxx       | 调用moment().format(xxx)            | 全局             | $moment.YYYYMMDD      |
| $selection.xxx    | 已勾选行的xxx字段，会用逗号拼接起来 | 全局             | $selection.PK_VALUE   |
| $funcid           | 当前表格的功能ID                    | 全局             | $funcid               |
| $uuid             | 生成随机字符串                      | 全局             | $uuid                 |
| $data.xxx         | 当前行xxx的值                       | cellRenderConfig | $data.PK_VALUE        |
| $parent.data.xxx  | 取子表格的父行xxx的值               | footButton       | $parent.data.PK_VALUE |

> `cellRenderConfig` 的 `deps` 写法不光有 `$data.xxx` ，只要是 `AgGrid cellRenderer` 方法的参数都可以取，比如 `$value` 。好像其他的取了也没啥用...

#### buttons

可以配置多个按钮，继承 `antd Button` 属性，另外增加了下面这些属性

| 属性          | 说明                                                         | 类型                                   | 必须 |
| ------------- | ------------------------------------------------------------ | -------------------------------------- | ---- |
| actionType    | `url`: 跳新页面(会用window.open打开); `fe-export`: 前端导出； `be-export`: 后端导出；`modal`: 打开弹框(弹框内容用通用表单配置) | url \| fe-export \| be-export \| modal | 是   |
| url           | `actionType`为`url`时，跳转的新地址，可以拼`deps`里的参数    | string                                 | 否   |
| popconfirm    | `popconfirm`确认框，如删除按钮。支持 `antd Popconfirm` 属性  | PopconfirmProps                        | 否   |
| permissionId  | 按钮权限 `id`                                                | string                                 | 否   |
| fileName      | 导出文件名                                                   | string                                 | 否   |
| requestConfig | 接口配置                                                     | 见下表                                 | 否   |
| modalProps    | 弹框配置                                                     | 见下表                                 | 否   |

#### requestConfig

接口配置。点击按钮调接口，如导出；或弹框点提交的接口配置

| 属性        | 说明                                                  | 类型                        |
| ----------- | ----------------------------------------------------- | --------------------------- |
| api         | 接口地址                                              | string                      |
| method      | 接口方法                                              | 'get' \| 'post'             |
| data        | 入参，对象的值可以用`deps` 如 { id : "{{$0}}" }       | 对象                        |
| createState | 入参增加创建人、创建时间。默认 CREATEUSER，CREATETIME | boolean \| [string, string] |
| updateState | 入参增加更新人、更新时间。默认 UPDATEUSER，UPDATETIME | boolean \| [string, string] |

#### modalProps

弹框配置，继承了 `antd Modal` 属性，另外增加了下面这些属性

| 属性          | 说明                                                         | 类型                   |
| ------------- | ------------------------------------------------------------ | ---------------------- |
| funcid        | 弹框内表单的功能ID                                           | string                 |
| dataid        | 用来查弹框里表单的初始数据，如编辑，一般是当前行的pkvalue    | string                 |
| selection     | 接口参数增加selectAll: boolean(参数名不可配置); selectid: 'xx,xx'(参数名可配置)。一般搭配deps中$selection.xx使用。 | { selectid："{{$0}}" } |
| requestConfig | 接口配置                                                     | 见上表                 |



## cellRenderConfig

将表格内单元格渲染成按钮

就是重写了表头的 `cellRenderer` 方法，所以`deps` 就是从 `cellRenderer`方法参数中取值，比如，`['$data.xx', '$value']` ，`data.xx`即当前行的数据，`value` 即该单元格数据

```json
{
  "cellRenderConfig": {
    "deps": ["$data.PK_VALUE", "$funcid"],
    "buttons": [
      {
        "text": "编辑",
        "type": "link",
        "actionType": "modal",
        "modalProps": {
          "width": "60%",
          "title": "编辑",
          "funcid": "fe08e2c8fd4c4015a96dc139ff315906",
          "dataid": "{{$0}}",
          "requestConfig": {
            // 配置更新人、更新时间字段；或使用默认配置 "updateState": true
            // 创建人、创建时间同理
            "updateState": ["UPDUSER", "UPDTIME"]
          }
        }
      },
      {
        "text": "删除",
        "type": "link",
        "actionType": "api",
        "popconfirm": true, // 弹二次确认框，也可以传对象，即antd Popconfirm配置
        "requestConfig": {
          "api": "/fscy/pdt-api/audit/delete",
          "data": {
            "id": "{{$0}}"
          }
        }
      }
    ]
  }
}
```

## 子表格

`subTableConfig`，配置同`tableConfig`。新增了 `footButton`，配置同其他按钮

```json
{
  "tableConfig": {
    "subTableConfig": {
      "columnDefs": [],
      "footButton": {}
    }
  }
}
```

## footButton

就是子表格底部按钮，由于子表格是用 `detailCellRenderer`写的，所以这里的`deps`，仅支持从 `detailCellRenderer`方法参数中取值

```json
{
  "footButton": {
    "deps": ["$parent.data.PK_VALUE"],
    "buttons": []
  }
}
```

## 接收 URL 传参

通用表格页面初始化时，会取 `searchForm` 里的参数，作为搜索框的默认值

```json
{
  "cellRenderConfig": {
    "deps": ["$value", "$data.PK_VALUE"],
    "buttons": [
      {
        "text": "{{$0}}",
        "type": "link",
        "actionType": "url",
        "url": "#/app/com/table?layout=sub&funcid=ae916156cb5944258129415d97942c63&searchForm={\"AUDITPLANID\":\"{{$1}}\"}"
      }
    ]
  }
}
```

## 权限

- 页面权限

  ```json
  {
    "roles": ["ab87894e-255c-45c5-923d-66ee90f9b0d4"], // 合规审计岗 角色
    "tableConfig": {}
  }
  ```

  配置了`roles`后，会用`localStorage`中的角色列表跟`roles`中匹配，匹配不上的话，则无权限访问

- 按钮权限

  ```json
  {
    "actionBtns": {
      "deps": ["$moment.YYYYMMDD"],
      "buttons": [
        {
          "text": "导出",
          "actionType": "export",
          "fileName": "内外部审计及检查发现整改跟踪明细表{{$0}}.xlsx",
          "permissionId": "f1844923-fde3-41c4-9acc-f59ee6678ee7"
        }
      ]
    }
  }
  ```
