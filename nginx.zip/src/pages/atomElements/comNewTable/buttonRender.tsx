import React, { useEffect, useState } from 'react';
import { Popconfirm, Button, message } from 'antd';
import { omit, has } from 'lodash';
import { cacheGet } from '@cerdo/cerdo-utils/lib/upmHttp';
import { userPermissionApi } from '@cerdo/cerdo-utils/lib/config';
import { pdtHttp, convertDeps, convertObjectDeps } from './data';
import type { ButtonRenderProps, ComfirmProps, IButtons } from './types';

const Index: React.FC<ButtonRenderProps> = (props) => {
  const {
    dependencies = [],
    buttons = [],
    searchParams,
    searchAgGridTableRef,
    cellRenderParams,
    selectState,
    exportExcel,
    setModalProps,
    setModalVisible,
  } = props;
  const [buttonData, setButtonData] = useState<IButtons[]>([]);
  const [loading, setLoading] = useState<IButtons['actionType'] | boolean>(false);

  const onConfirm = async ({
    source,
    actionType,
    popconfirm,
    url,
    fileName,
    modalProps,
    requestConfig,
  }: ComfirmProps) => {
    if (source === 'button' && popconfirm) {
      return;
    }

    const { api, method = 'get', data = {} } = requestConfig || {}; // 按钮层 接口配置

    switch (actionType) {
      // 调接口，如删除等
      case 'api': {
        if (!api) {
          message.info('未配置接口地址');
          return;
        }

        const convertApi = convertDeps(api, dependencies);
        const params = convertObjectDeps(data, dependencies);
        await pdtHttp[method]({ url: convertApi, data: params });
        message.success('操作成功');
        searchAgGridTableRef?.current?.onSearch();
        break;
      }
      // 链接跳转
      case 'url':
        if (!url) {
          message.info('未配置跳转地址');
          return;
        }

        window.open(convertDeps(url, dependencies));
        break;
      // 前端导出
      case 'fe-export':
        if (!fileName) {
          message.info('未配置导出的文件名');
          return;
        }

        exportExcel(convertDeps(fileName, dependencies));
        break;
      // 后端导出
      case 'be-export': {
        if (!api) {
          message.info('未配置接口地址');
          return;
        }

        const convertApi = convertDeps(api, dependencies);
        const params = convertObjectDeps(data, dependencies);
        params.filename = convertDeps(fileName, dependencies);
        Object.assign(params, omit(searchParams, ['currentPage', 'pageSize']));
        setLoading('be-export');
        pdtHttp['download']({ url: convertApi, data: params, method }).finally(() =>
          setLoading(false),
        );
        break;
      }
      // 弹窗
      case 'modal': {
        if (!modalProps.funcid) {
          message.info('未配置弹窗的funcid');
          return;
        }

        // 翻译动态参数
        const { api, data } = modalProps.requestConfig || {}; // 弹框层 接口配置
        if (api) {
          const convertApi = convertDeps(api, dependencies);
          modalProps.requestConfig.api = convertApi;
        }
        if (data) {
          const convertData = convertObjectDeps(data, dependencies);
          modalProps.requestConfig.data = convertData;
        }

        const params = { ...modalProps, cellRenderParams };

        ['dataid', 'selection'].forEach((field) => {
          if (has(modalProps, field)) {
            params[field] =
              typeof modalProps[field] === 'string'
                ? convertDeps(modalProps[field], dependencies)
                : convertObjectDeps(modalProps[field], dependencies);

            if (field === 'selection') {
              Object.assign(params[field], { selectAll: selectState.selectAll });
            }
          }
        });

        setModalProps(params);
        setModalVisible(true);
        break;
      }
      default:
    }
  };

  /** 查 按钮权限 */
  const fetchButtonPermission = () => {
    const requestArr = [];
    buttons.forEach((item) => {
      if (item.permissionId) {
        requestArr.push(
          cacheGet({
            url: userPermissionApi,
            data: { permissionids: item.permissionId },
          }),
        );
      }
    });
    if (!requestArr.length) {
      setButtonData(buttons);
      return;
    }

    const permissionMap = {};
    Promise.all(requestArr).then((res) => {
      res.forEach((item) => {
        const { haspermission, permissionid } = item.data?.[0];
        permissionMap[permissionid] = haspermission === 1;
      });
      const buttonData = buttons.filter(
        (item) => !item.permissionId || permissionMap[item.permissionId],
      );
      setButtonData(buttonData);
    });
  };

  useEffect(() => {
    fetchButtonPermission();
  }, [buttons]);

  return (
    <>
      {buttonData.map(({ text, popconfirm, ...rest }, i) => {
        return (
          <Popconfirm
            key={i}
            visible={popconfirm ? undefined : false}
            title={popconfirm?.title || '确认操作吗？'}
            {...popconfirm}
            onConfirm={() => onConfirm({ popconfirm, ...rest })}
          >
            <Button
              size="small"
              type="primary"
              // 把用不到的属性去掉，避免传到dom上，省的报警告
              {...omit(rest, [
                'actionType',
                'fileName',
                'permissionId',
                'modalProps',
                'requestConfig',
              ])}
              loading={loading === rest.actionType}
              onClick={() => onConfirm({ source: 'button', popconfirm, ...rest })}
            >
              {convertDeps(text, dependencies)}
            </Button>
          </Popconfirm>
        );
      })}
    </>
  );
};

export default React.memo(Index);
