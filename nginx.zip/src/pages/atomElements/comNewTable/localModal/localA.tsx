import React from 'react';
import { Modal } from 'antd';

const LocalModal = (props) => {
  console.log('🚀 ~ file: localA.tsx:5 ~ LocalModal ~ props:', props);
  return (
    <Modal title="成功" visible {...props}>
      {/* // <Modal {...otherProps} visible={!isEmpty(modalProps)} onCancel={closeModal}> */}
      localmodal
    </Modal>
  );
};

export default LocalModal;
