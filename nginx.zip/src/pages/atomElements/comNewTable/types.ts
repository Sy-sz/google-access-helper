import type {
  ISearchAgGridTable,
  IColumnDefs,
  SearchFormConfig,
} from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import type { ButtonProps, PopconfirmProps, ModalProps } from 'antd';
import { TableConfig } from 'ag-grid-react';

/** 通用接口配置 */
interface RequestConfig {
  /** 接口地址 */
  api: string;
  /** 接口方法 */
  method?: 'get' | 'post';
  /** 接口入参 */
  data?: Record<string, string>;

  /** 创建人信息, 为true传默认创建人、创建时间字段；或自己配置[创建人，创建时间] */
  createState?: boolean | [string, string];
  /** 更新人信息，为true传默认更新人、更新时间字段；或自己配置[更新人，更新时间] */
  updateState?: boolean | [string, string];
}

/** 弹框配置，继承antd的弹框配置，下面是新加的 */
export interface ModalPropsType extends ModalProps {
  /** 弹框中表单的功能id */
  funcid?: string;
  /** 弹框中表单的dataid */
  dataid?: string;
  /** 已选中的行 */
  selection?: Record<string, any>;
  /** cellRender方法的参数 */
  cellRenderParams?: any;
  /** 弹框点确定，接口配置 */
  requestConfig?: RequestConfig;
}

/** 按钮配置, 继承antd的按钮的配置，下面是新加的 */
export interface IButtons extends ButtonProps {
  text: string;
  /**
   * api: 直接调接口(如：删除)；
   * url: 跳页面
   * fe-export: 前端导出
   * be-export： 后端导出
   * modal: 弹框(弹框内容由通用表单配置生成)
   *  */
  actionType: 'api' | 'url' | 'fe-export' | 'be-export' | 'modal';
  /** 跳页面的地址 (actionType=url时需要) */
  url?: string;
  /** 点按钮会弹二次确认框 */
  popconfirm?: PopconfirmProps;
  /** 权限字典id */
  permissionId?: string;
  /** 导出文件名 */
  fileName?: string;
  /** 弹框的参数 */
  modalProps?: ModalPropsType;
  /** 点按钮直接发请求，接口配置 */
  requestConfig?: RequestConfig;
}

/** 依赖与按钮配置 */
interface DepsButtons {
  deps?: string[];
  buttons?: IButtons[];
}

export type TCellRenderConfig = DepsButtons;

/** 子表格配置 */
export interface TSubTableConfig extends Omit<ITableConfig, 'subTableConfig'> {
  footButton?: DepsButtons;
  getGlobalDeps: (params: any) => string[];
  searchAgGridTableRef?: React.MutableRefObject<any>;
  style?: React.CSSProperties;
}

/** 复用 SearchAgGridTable 的 IColumnDefs 类型 */
export type TColumnDefs = (IColumnDefs[number] & {
  cellRenderConfig?: TCellRenderConfig;
  tooltip?: boolean;
  field?: string;
  valueGetter?: string | ((params: any) => string);
  cellRenderer?: (params: any) => React.ReactNode; // TODO: 为什么没有覆盖原有的类型
})[];

interface ITableConfig extends Omit<TableConfig, 'columnDefs'> {
  columnDefs?: TColumnDefs;
  subTableConfig?: TSubTableConfig;
}

export interface IJsonSchema extends Omit<ISearchAgGridTable, 'tableConfig'> {
  roles?: string[];
  /** 是否展示序号列，默认true；传对象则为序号列配置 */
  showSerialColumn?: boolean | Record<string, any>;
  /** 查询接口额外的参数 */
  extraQueryParams?: Record<string, any>;
  /** 每行数据的唯一id，后端分页需要 */
  rowId?: string;

  actionBtns?: DepsButtons;
  tableConfig?: ITableConfig;
  searchFormConfig?: SearchFormConfig;
}

export interface ButtonRenderProps {
  buttons: IButtons[];
  dependencies?: any[];
  /** 搜索参数 */
  searchParams?: Record<string, any>;
  searchAgGridTableRef?: React.MutableRefObject<any>;
  /** cellRender方法的参数  */
  cellRenderParams?: any;
  selectState?: SelectState;
  exportExcel?: (fileName: string) => void;
  setModalProps?: (params: ModalPropsType) => void;
  setModalVisible?: (visible: boolean) => void;
}

export type ComfirmProps = Partial<IButtons> & { source?: 'button' | 'popconfirm' };

/** 选中状态，包含是否全选、选中/排除的项 */
export interface SelectState {
  selectAll: boolean;
  selectedRows: Record<string, any>[];
}
