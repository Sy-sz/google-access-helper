import React, { useRef, useState, useEffect } from 'react';
import { type ModalProps, Modal, message, Spin } from 'antd';
import { forOwn, merge, omit } from 'lodash';
import { fn, upmHttp } from '@cerdo/cerdo-utils';
import MainForm from './mainForm';
import { comEleSave } from '@/common/axios';
import { convertArrayToString } from './data';
import type { ModalPropsType } from '../types';
import scope from './scope';

interface ModalFormProps extends ModalProps {
  visible: boolean;
  modalProps: ModalPropsType;
  // selectState: SelectState;
  setModalVisible: (visible: boolean) => void;
  resetSelection: () => void;
  onModalConfirm: () => void;
}

/** 当前登录人ID */
const user = scope.getCurrentUser()?.id;
/** 当前时间 */
const getCurrentDate = scope.getCurrentDate();
/** 创建人 */
const CREATEUSER = 'CREATEUSER';
/** 创建时间 */
const CREATETIME = 'CREATETIME';
/** 更新人 */
const UPDATEUSER = 'UPDATEUSER';
/** 更新时间 */
const UPDATETIME = 'UPDATETIME';

const ModalForm: React.FC<ModalFormProps> = (props) => {
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(0);
  const formRef = useRef<any>(null);

  const { visible, modalProps, setModalVisible, resetSelection, onModalConfirm } = props;
  const { funcid, dataid, selection, bodyStyle, requestConfig, ...otherProps } = modalProps;
  const {
    api,
    method = 'get',
    data: requestConfigData,
    createState,
    updateState,
  } = requestConfig || {};

  const confirmApi = (params) => {
    const data = { ...params, ...requestConfigData };
    return (
      api ? upmHttp[method]({ url: api, data }) : comEleSave({ type: 1, data })
    ) as Promise<any>;
  };

  /** 处理创建人/时间，更新人/时间 */
  const handleAddValues = (values) => {
    if (createState) {
      let creatorKey = CREATEUSER;
      let createTimeKey = CREATETIME;
      if (Array.isArray(createState)) {
        creatorKey = createState[0] || CREATEUSER;
        createTimeKey = createState[1] || CREATETIME;
      }
      values[creatorKey] = user;
      values[createTimeKey] = getCurrentDate;
    }

    if (updateState) {
      let updaterKey = UPDATEUSER;
      let updateTimeKey = UPDATETIME;
      if (Array.isArray(updateState)) {
        updaterKey = updateState[0] || UPDATEUSER;
        updateTimeKey = updateState[1] || UPDATETIME;
      }
      values[updaterKey] = user;
      values[updateTimeKey] = getCurrentDate;
    }
  };

  const closeModal = () => {
    setModalVisible(false);
    formRef.current.form?.reset();
  };

  const onOk = () => {
    if (selection && Object.values(selection).every((e) => !e)) {
      message.info('请先选择数据');
      return;
    }

    formRef.current.form?.submit((values) => {
      console.log('提交表单', values);
      console.log('xComponentMap', formRef.current.xComponentMap);

      // TODO: 上传文件临时处理(上传组件向外提供的是对象，也就是说只能单选，且接口只存字符)
      forOwn(values, (value, key) => {
        if (formRef.current.xComponentMap[key] === 'FormUploadFile') {
          let fileValue;
          // 第一次上传，value是对象，第二次上传，因为上一次这里已经转处理了，所以value是数组
          if (value?.status === 'done') {
            fileValue = JSON.stringify([value]);
          }
          if (value?.length) {
            fileValue = JSON.stringify(value.filter((e) => e.status === 'done'));
          }
          values[key] = fileValue;
        }
      });

      convertArrayToString(values);
      const queryApiRes = omit(formRef.current.queryApiData, ['jsonschema']);

      handleAddValues(values);

      const params = api
        ? { ...values, ...selection, funcid }
        : { ...queryApiRes, data: values, funcid };

      setLoading(true);
      confirmApi(params)
        .then((res) => {
          if (fn.checkResponse(res)) {
            message.success('操作成功');
            if (selection) {
              resetSelection();
            }
            closeModal();
            onModalConfirm();
          }
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  useEffect(() => {
    if (visible) {
      setIsModalOpen(isModalOpen + 1);
    }
  }, [visible]);

  console.log('modalProps', modalProps);

  return (
    <Modal
      visible={visible}
      onCancel={closeModal}
      onOk={onOk}
      bodyStyle={merge(
        { padding: '12px 12px 0 12px', minHeight: 150, maxHeight: '70%' },
        bodyStyle,
      )}
      {...otherProps}
    >
      <Spin spinning={loading}>
        <MainForm ref={formRef} isModalOpen={isModalOpen} funcid={funcid} dataid={dataid} />
      </Spin>
    </Modal>
  );
};

export default ModalForm;

// const DynamicComponent = ({ path }) => {
//   const [Component, setComponent] = useState(null);

//   useEffect(() => {
//     const importComponent = async () => {
//       const comp = await import(`@/pages/atomElements/comNewTable/localModal/localA`);
//       console.log('🚀 ~ file: index.tsx:18 ~ importComponent ~ comp:', comp);
//       setComponent(comp.default);
//     };

//     importComponent();
//   }, [path]);

//   if (!Component) {
//     return <div>Loading...</div>;
//   }

//   return <Component />;
// };
