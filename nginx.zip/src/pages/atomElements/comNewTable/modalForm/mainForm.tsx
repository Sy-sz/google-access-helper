import React, {
  useEffect,
  useState,
  useRef,
  useMemo,
  useImperativeHandle,
  forwardRef,
} from 'react';
import { unstable_batchedUpdates } from 'react-dom';
import { CerdoForm } from '@cerdo/cerdo-design';
import { dictTree } from '@cerdo/cerdo-utils/lib/api';
import { createForm } from '@formily/core';
import { Spin, Empty, Result, message } from 'antd';
import { forOwn, isEmpty, has, get, set } from 'lodash';
import classnames from 'classnames';
import { fn, storage } from '@cerdo/cerdo-utils';
import { comeleQuery } from '@/common/axios';
import { getFieldStateMap, formatDictMap } from './data';
import scope from './scope';
import styles from './style.module.less';

interface IProps {
  funcid: string;
  dataid?: string;
  isModalOpen?: number;
  ref?: any;
}

const Index: React.FC<IProps> = forwardRef((props, ref) => {
  const { funcid, dataid, isModalOpen } = props;
  const [loading, setLoading] = useState(true);
  const [queryApiData, setQueryApiData] = useState<any>({});
  const [jsonSchema, setJsonSchema] = useState<any>({});
  const [xComponentMap, setXComponentMap] = useState<Record<string, any>>({});
  const form = useRef(createForm());

  const { edata } = queryApiData || {};
  const userInfo = storage.getUserInfo() || {};

  const [proxUser] = useState({ id: userInfo.id, userName: userInfo.userName });

  //  是否edata为空 或edata全都无权限
  const isPermissionEmpty = useMemo(() => {
    if (isEmpty(edata)) {
      return true;
    }

    let flag = true;
    const loopEdata = (data) => {
      forOwn(data, (value, key) => {
        if ('permissiontype' in value) {
          if (value.permissiontype !== '') {
            flag = false;
            return;
          }
        } else {
          loopEdata(value);
        }
      });
    };

    loopEdata(edata);
    return flag;
  }, [edata]);

  /** 把数据中字符串转为数组(多选框) */
  const convertStringToArray = (edata, formData) => {
    if (isEmpty(edata) || isEmpty(formData)) {
      return;
    }

    // 拼接edata中多选字段路径 eg: [a, b.c, b.c.d]
    const getEdataMultiplePath = () => {
      const edataMultiplePath = [];
      const loopEdata: any = (data, prevKey) => {
        forOwn(data, (value, key) => {
          if (has(value, 'componentprops')) {
            if (value.componentprops?.ismult === '1') {
              edataMultiplePath.push(prevKey ? `${prevKey}.${key}` : key);
            }
          } else {
            loopEdata(value, prevKey ? `${prevKey}.${key}` : key);
          }
        });
      };
      loopEdata(edata);
      return edataMultiplePath;
    };

    // 拼接formData中多选字段路径，方便取值和赋值 eg: [a, b[0].c, b[1].c, b[0].c[0].d, b[0].c[1].d, b[1].c[0].d, b[1].c[1].d]
    const getFormDataMultiplePath = (edataMultiplePath) => {
      const formDataMultiplePath = [];
      edataMultiplePath.forEach((item) => {
        if (item.includes('.')) {
          const [first, second, third] = item.split('.');
          if (third) {
            const firstLen = formData[first].length;
            for (let i = 0; i < firstLen; i++) {
              const secondLen = formData[first][i][second].length;
              for (let j = 0; j < secondLen; j++) {
                formDataMultiplePath.push(`${first}[${i}].${second}[${j}].${third}`);
              }
            }
          } else {
            const firstLen = formData[first].length;
            for (let i = 0; i < firstLen; i++) {
              formDataMultiplePath.push(`${first}[${i}].${second}`);
            }
          }
        } else {
          formDataMultiplePath.push(item);
        }
      });
      return formDataMultiplePath;
    };

    const edataMultiplePath = getEdataMultiplePath();
    const formDataMultiplePath = getFormDataMultiplePath(edataMultiplePath);

    formDataMultiplePath.forEach((path) => {
      const value = get(formData, path)?.split(',') || [];
      set(formData, path, value);
    });
  };

  // 根据fieldStateMap 设置表单字段状态
  const batchSetFieldState = ({ formData, fieldStateMap, dimidDictMap }) => {
    // 由于份额之间字段的权限是一致的(edata里只有一份)，但字段历史修改记录是不一致的，这里需要把fieldStateMap里的*号替换成对应的下标
    let newFieldStateMap = fieldStateMap;
    if (!isEmpty(formData)) {
      newFieldStateMap = {};
      forOwn(fieldStateMap, (stateMap, key) => {
        if (stateMap.isTabField) {
          const fieldKey = key.split('.')[0];
          formData[fieldKey]?.forEach((item, i) => {
            const k = key.replace('*', i);
            if (newFieldStateMap[k]) {
              console.error('有重复的key');
            }
            newFieldStateMap[k] = { ...stateMap, PKVALUE: item.PKVALUE };
          });
        } else {
          newFieldStateMap[key] = stateMap;
        }
      });
    }

    forOwn(newFieldStateMap, (stateMap, key) => {
      form.current.setFieldState(key, (state) => {
        const { ...otherState } = stateMap;
        forOwn(otherState, (value, k) => {
          state[k] = value;
        });
      });
    });
  };

  const formatFormData = (data) => {
    forOwn(data, (value, key) => {
      if (value === '') {
        data[key] = undefined;
      }
      if (Array.isArray(value) && value.length) {
        value.forEach((item) => {
          formatFormData(item);
        });
      }
    });
  };

  const fetchFieldDict = async ({ edata }) => {
    let dimidDictMap = {};
    const dictRequestMap = {};
    const loopEdata = (data) => {
      forOwn(data, (value, key) => {
        if ('dimid' in value) {
          if (!isEmpty(value.componentprops)) {
            const { dictid: dictId, queryparam: queryParams } = value.componentprops;
            if (dictId) {
              const params: any = { dictId };
              if (!isEmpty(queryParams)) {
                params.queryParams = JSON.parse(queryParams);
              }
              dictRequestMap[value.dimid] = dictTree(params);
            }
          }
        } else {
          loopEdata(value);
        }
      });
    };

    loopEdata(edata);
    if (!isEmpty(dictRequestMap)) {
      try {
        const dictDataList = await Promise.all(Object.values(dictRequestMap));
        dimidDictMap = dictDataList.reduce((prev, curr, idx) => {
          const dimidDictMap = formatDictMap((curr as any).data.children);
          const dimid = Object.keys(dictRequestMap)[idx];
          prev[dimid] = dimidDictMap;
          return prev;
        }, {});
      } catch (error) {
        message.error('获取字典失败');
      }
    }
    return dimidDictMap;
  };

  const fetchInitData = async () => {
    const request = comeleQuery;
    setLoading(true);
    try {
      // 查 初始数据
      const res = await request({ funcid, dataid, userid: proxUser.id });
      if (!fn.checkResponse(res) || !res.data?.jsonschema) {
        throw Error('数据异常');
      }
      const { edata, jsonschema } = res.data;

      let dimidDictMap = {}; // 数据：字段dimid和字典的映射
      if (dataid) {
        const [map2] = await Promise.all([
          // 查 字典
          fetchFieldDict({ edata }),
        ]);
        dimidDictMap = map2;
      }

      const mData = res.data.data ?? {};
      const schema = JSON.parse(jsonschema);
      const formatData = getFieldStateMap({ ...res.data, mData, schema, dimidDictMap });
      const { fieldStateMap, formData, jsonSchema, xComponentMap } = formatData;
      form.current = createForm();
      batchSetFieldState({ formData, fieldStateMap, dimidDictMap });

      // 把空字符转为undefined，否则placeholder不生效
      formatFormData(formData);
      // 因为多选下拉框的值是数组，这里把字符串转成数组
      convertStringToArray(edata, formData);

      // TODO: 上传文件临时处理(上传组件向外提供的是对象，也就是说只能单选，且接口只存字符)
      forOwn(formData, (value, key) => {
        if (xComponentMap[key] === 'FormUploadFile' && value) {
          formData[key] = JSON.parse(value);
        }
      });

      form.current.setValues(formData);

      unstable_batchedUpdates(() => {
        setLoading(false);
        setQueryApiData(res.data);
        setJsonSchema(jsonSchema);
        setXComponentMap(xComponentMap);
      });
    } catch (error) {
      setLoading(false);
      console.error(error);
    }
  };

  useEffect(() => {
    fetchInitData();
  }, [funcid, dataid, isModalOpen]);

  useImperativeHandle(ref, () => ({ form: form.current, queryApiData, xComponentMap }));

  const isSchemaEmpty = isEmpty(jsonSchema.schema?.properties);
  if (loading) {
    return <Spin className={styles.loading} />;
  }
  if (isSchemaEmpty) {
    return <Result status="404" title="未设计表单" />;
  }
  if (isEmpty(edata)) {
    return <Result status="404" title="未添加要素" />;
  }
  if (isPermissionEmpty) {
    return <Result status="403" title="要素无权限" />;
  }
  if (isEmpty(queryApiData)) {
    // 放最后原因：没有配置jsonschema时，会提示暂无数据，放最后才会提示未设计表单
    return <Empty style={{ paddingTop: '30vh' }} description="暂无数据" />;
  }

  return (
    <div className={styles.container}>
      <CerdoForm
        form={form.current}
        {...jsonSchema?.form}
        schema={jsonSchema?.schema}
        className={classnames(styles.schemaForm)}
        createSchemaFieldOptions={{ scope }}
      />
    </div>
  );
});

export default Index;
