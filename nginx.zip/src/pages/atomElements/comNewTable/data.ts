import { download } from '@cerdo/cerdo-utils/lib/upmHttp';
import { pdtGet, pdtPost } from '@/common/axios';

export const rowHeight = 40;

export const pickerMap = {
  date: 'YYYY-MM-DD',
  week: 'YYYY-wo',
  month: 'YYYY-MM',
  quarter: 'YYYY-[Q]Q',
  year: 'YYYY',
};

export const pdtHttp = {
  get: pdtGet,
  post: pdtPost,
  download,
};

/** 把字符串中如{{$0}}替换为数据 */
export const convertDeps = (str: string, deps: any[]) =>
  str && str.replace(/\{\{\$(\d+)\}\}/g, (_, target) => deps[target]);

/** 把对象中value里如{{$0}}替换为数据 */
export const convertObjectDeps = (obj: Record<string, string>, deps: any[]) => {
  const res: Record<string, any> = {};
  Object.keys(obj).forEach((key) => {
    res[key] = convertDeps(obj[key], deps);
  });
  return res;
};

/** 把 "[a,b]" 转成 [a, b] */
export const extractValues = (str) => {
  if (typeof str !== 'string' || !str?.length) {
    return str;
  }

  return str
    .slice(1, -1)
    .split(',')
    .map((e) => e.trim());
};
