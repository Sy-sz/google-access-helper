## 注意事项

- 必填项添加高亮背景色

```json
"x-component-props": {
    "className": "cerdo-form-item-required",
}
```
