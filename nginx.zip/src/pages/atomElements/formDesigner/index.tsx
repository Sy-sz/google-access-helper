import React, { useEffect, useState } from 'react';
import { message, Modal, Spin, Typography } from 'antd';
import { FormDesigner } from '@cerdo/cerdo-scaffold';
import { fn, url } from '@cerdo/cerdo-utils';
import { comEleFuncDetail, comEleFuncSave } from '@/common/axios';
import defaultSchema from './defaultSchema.json';
import scope from '../comForm/scope';

const defaultJsonSchema = JSON.stringify(defaultSchema);

const Index = () => {
  const [loading, setLoading] = useState(false);
  const [funcData, setFuncData] = useState({ jsonschema: null });
  const funcId = url.getQueryString('funcid');

  const getFuncData = () => {
    setLoading(true);
    comEleFuncDetail({ funcid: funcId })
      .then((result) => {
        if (fn.checkResponse(result)) {
          // result.data.jsonschema = JSON.stringify(schema);
          document.title = `${result?.data?.funcname}-表单设计`;
          setFuncData(result.data);
        } else {
          Modal.info({
            title: (
              <div>
                未查询到此功能【功能号：<Typography.Text copyable>{funcId}</Typography.Text>】
              </div>
            ),
            okText: '关闭页面',
            onOk: () => {
              window.close();
            },
          });
        }
      })
      .finally(() => setLoading(false));
  };

  const handleSaveSchema = (jsonSchema: string) => {
    if (jsonSchema?.includes('当前为配置模板')) {
      message.error('请先修改模板标题');
      return;
    }

    setLoading(true);
    comEleFuncSave({
      ...funcData,
      jsonschema: jsonSchema,
    })
      .then((result) => {
        if (fn.checkResponse(result)) {
          message.success('保存成功');
          setFuncData({
            ...funcData,
            jsonschema: jsonSchema,
          });
        }
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (funcId) {
      getFuncData();
    } else {
      Modal.info({
        title: '请通过功能打开',
        okText: '关闭页面',
        onOk: () => {
          window.close();
        },
      });
    }
  }, [funcId]);

  return (
    <Spin spinning={loading} style={{ minHeight: 'calc(100vh)' }}>
      <FormDesigner
        loadInitialSchema={funcData?.jsonschema || defaultJsonSchema}
        saveSchema={handleSaveSchema}
        createSchemaFieldOptions={{ scope }}
      />
    </Spin>
  );
};
export default Index;
