import React from 'react';
import { Space } from 'antd';
import { PDTButton } from '@/common/component';
import { type IColumnDefs } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import { D } from '@/utils';

type GetColumnsDefs = (params: {
  handleBundle: (row: Record<string, any>) => void;
  handleUnBundle: (row: { id: string }) => void;
  onDel: (ids: string) => void;
}) => IColumnDefs;
export const getColumnsDefs: GetColumnsDefs = ({ handleBundle, handleUnBundle, onDel }) => [
  {
    headerName: '功能表单',
    field: 'funcId',
    hideInTable: true,
    component: 'DictSelectPlus',
    dictId: D.FEEDBACKDATALIST,
    componentProps: { placeholder: '请选择', mode: 'multiple', maxTagCount: 1, showArrow: true },
    transform: (value) => value?.join(),
  },
  {
    headerName: '功能表单',
    field: 'funcName',
    flex: 1,
    hideInSearch: true,
  },
  {
    headerName: '反馈方式',
    field: 'noticeWay',
    flex: 1,
    component: 'DictSelectPlus',
    dictId: D.FEEDBACKMETHOD,
    componentProps: { placeholder: '请选择', mode: 'multiple', showArrow: true },
    transform: (value) => value?.join(),
  },
  {
    headerName: '操作',
    filter: false,
    hideInSearch: true,
    cellRenderer: ({ data }) => {
      return (
        <Space size="large">
          <PDTButton type="link" style={{ padding: 0 }} onClick={() => handleBundle(data)}>
            绑定
          </PDTButton>

          <PDTButton
            type="link"
            disabled={!data.id}
            style={{ padding: 0 }}
            deleteConfirm
            popconfirmProps={{ title: '确定要解绑吗？' }}
            onClick={() => handleUnBundle(data)}
          >
            解绑
          </PDTButton>
          {/* <PDTButton
            type="link"
            style={{ padding: 0 }}
            deleteConfirm
            onClick={() => onDel(data.id)}
          >
            删除
          </PDTButton> */}
        </Space>
      );
    },
  },
];
