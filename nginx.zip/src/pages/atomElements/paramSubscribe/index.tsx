import React, { useState, useRef } from 'react';
import { Form, message, Modal, Input } from 'antd';
import { SearchAgGridTable } from '@cerdo/cerdo-design';
import { PDTSelect } from '@/common/component';
import { subscribeTitleSave, subscribeTitleDelete, sqlmodelDel } from '@/common/axios';
import { subscribeTitle } from '@/common/axios/config';
import { D } from '@/utils';
import { getColumnsDefs } from './data';

const FormItem = Form.Item;

const paramSubscribe = () => {
  const [visible, setVisible] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const agGridRef = useRef(null); // agGrid ref
  const searchAgTableRef = useRef(null);
  const activeRow = useRef<Record<string, any>>({}); // 正在编辑中的行
  const [form] = Form.useForm();

  const onGridReady = (grid) => {
    agGridRef.current = grid;
  };

  /** 关闭弹窗 */
  const closeModal = () => {
    setVisible(false);
    activeRow.current = {};
    form.resetFields();
  };

  /** 删除 */
  const onDel = async (ids: string) => {
    const [err] = await sqlmodelDel({ ids });
    if (err) {
      return;
    }

    message.success('删除成功');
    searchAgTableRef.current.onSearch();
  };

  /** 解绑 */
  const handleUnBundle = async ({ id }) => {
    const [err] = await subscribeTitleDelete({ id });
    if (err) {
      return;
    }

    message.success('解绑成功');
    searchAgTableRef.current.onSearch();
  };

  /** 编辑 */
  const handleBundle = (row) => {
    form.setFieldsValue(row);
    activeRow.current = row;
    setVisible(true);
  };

  /** 保存 */
  const onOk = async () => {
    const values = await form.validateFields();
    setConfirmLoading(true);
    const { funcId, id } = activeRow.current;
    const [err] = await subscribeTitleSave({ ...values, funcId, id });
    if (err) {
      setConfirmLoading(false);
      return;
    }

    message.success('操作成功');
    searchAgTableRef.current.onSearch();
    closeModal();
    setConfirmLoading(false);
  };

  return (
    <div>
      <SearchAgGridTable
        method="get"
        url={subscribeTitle}
        ref={searchAgTableRef}
        resetAutoQuery
        tableConfig={{
          autoHeight: true,
          suppressCellFocus: false,
          suppressRowClickSelection: true,
          onGridReady,
          columnDefs: getColumnsDefs({ handleBundle, handleUnBundle, onDel }),
        }}
        searchFormConfig={{ searchColNum: 4 }}
      />

      <Modal
        title="参数订阅"
        visible={visible}
        maskClosable={false}
        onOk={onOk}
        onCancel={closeModal}
        confirmLoading={confirmLoading}
      >
        <Form form={form} labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
          <FormItem
            label="反馈方式"
            name="noticeWay"
            rules={[{ required: true, message: '请选择' }]}
          >
            <PDTSelect dictId={D.FEEDBACKMETHOD} />
          </FormItem>
          <FormItem
            name="noticeWayText"
            wrapperCol={{ offset: 6 }}
            rules={[{ required: true, message: '请输入' }]}
          >
            <Input.TextArea placeholder="请输入" />
          </FormItem>
        </Form>
      </Modal>
    </div>
  );
};

export default paramSubscribe;
