import { comEleElementPermissionSave, comEleRoleTreeList } from '@/common/axios';
import { DragModal } from '@cerdo/cerdo-design';
import { fn } from '@cerdo/cerdo-utils/es';
import { message, Switch, Table } from 'antd';
import React, { useState, useEffect } from 'react';
import PopverRoleMember from '../component/PopverRoleMember';

const Eidt = (props) => {
  const { open, title, onCancel, onOk, data } = props;
  const [loading, setLoading] = useState(false);
  const [tableLoading, setTaleLoading] = useState(false);
  const [tableData, setTaleData] = useState(false);
  const [elementData, setElementData] = useState([]);
  const [columnsPermissionChecked, setColumnsPermissionChecked] = useState({
    viewpermission: false,
    editpermission: false,
    reviewpermission: false,
  });

  useEffect(() => {
    getData();
  }, []);

  const getData = () => {
    setTaleLoading(true);
    comEleRoleTreeList()
      .then((result) => {
        if (fn.checkResponse(result)) {
          const newTableData = result.data?.[0].children.map((item) => {
            return {
              dimid: data?.dimid,
              roleid: item.id,
              rolename: item.nodeName,
              viewpermission: data?.permissions?.some(
                (a) => Number(a.viewpermission) === 1 && a.roleid === item.id,
              ),
              editpermission: data?.permissions?.some(
                (a) => Number(a.editpermission) === 1 && a.roleid === item.id,
              ),
              reviewpermission: data?.permissions?.some(
                (a) => Number(a.reviewpermission) === 1 && a.roleid === item.id,
              ),
            };
          });
          setTaleData(newTableData);

          setColumnsPermissionChecked({
            viewpermission: newTableData.every((a) => a.viewpermission),
            editpermission: newTableData.every((a) => a.editpermission),
            reviewpermission: newTableData.every((a) => a.reviewpermission),
          });
        }
      })
      .finally(() => setTaleLoading(false));
  };

  const handleCancel = () => {
    onCancel();
  };

  const handleOk = () => {
    if (!(Array.isArray(elementData) && elementData.length > 0)) {
      message.warning('未检测到改动');
      return;
    }
    setLoading(true);
    comEleElementPermissionSave(
      elementData.map((a) => ({
        ...a,
        viewpermission: a.viewpermission ? '1' : '0',
        editpermission: a.editpermission ? '1' : '0',
        reviewpermission: a.reviewpermission ? '1' : '0',
      })),
    )
      .then((result) => {
        if (fn.checkResponse(result)) {
          message.success('保存成功', 0.5, () => {
            onOk();
          });
        }
      })
      .finally(() => setLoading(false));
  };

  const handlePermissionChange = (checked, type, record) => {
    let newElementData = [...elementData];
    const temp = newElementData.find((a) => a.roleid === record.roleid);
    if (temp) {
      temp[`${type}permission`] = checked;
    } else {
      const newRecord = { ...record };
      newRecord[`${type}permission`] = checked;
      newElementData = [...newElementData, newRecord];
    }
    setElementData(newElementData);
    setTaleData(
      tableData.map((item) => {
        if (item.roleid === record.roleid) {
          item[`${type}permission`] = checked;
        }
        return item;
      }),
    );

    setColumnsPermissionChecked({
      ...columnsPermissionChecked,
      [`${type}permission`]: tableData
        ?.map((item) => {
          const temp = (newElementData || []).find((a) => a.roleid === item.roleid);
          return temp ? temp : item;
        })
        ?.every((a) => Number(a[`${type}permission`])),
    });
  };

  const handleAllPermissionChange = (checked, type) => {
    const newTableData = tableData.map((item) => {
      const index = elementData.findIndex((a) => a.roleid === item.roleid);
      const temp = index > -1 ? elementData.splice(index, 1)[0] : item;
      temp[`${type}permission`] = checked;
      return temp;
    });
    setColumnsPermissionChecked({ ...columnsPermissionChecked, [`${type}permission`]: checked });
    setElementData([...elementData, ...newTableData]);
  };

  return (
    <DragModal
      title={title ?? '要素权限设置'}
      visible={open}
      width="calc(800px)"
      maskClosable={false}
      destroyOnClose
      closable={false}
      onCancel={handleCancel}
      onOk={handleOk}
      okText="保存"
      confirmLoading={loading}
      bodyStyle={{
        padding: '8px 12px',
      }}
    >
      <Table
        loading={tableLoading}
        size="small"
        rowKey="roleid"
        dataSource={tableData}
        columns={[
          {
            title: '角色名',
            dataIndex: 'rolename',
            render: (text, record) => <PopverRoleMember data={record}>{text}</PopverRoleMember>,
          },
          {
            title: '权限',
            dataIndex: 'permission',
            children: [
              {
                title: (
                  <Switch
                    size="small"
                    checked={columnsPermissionChecked.viewpermission}
                    checkedChildren="查看"
                    unCheckedChildren="查看"
                    onChange={(checked) => handleAllPermissionChange(checked, 'view')}
                  />
                ),
                dataIndex: 'viewpermission',
                align: 'center',
                render: (text, record) => (
                  <Switch
                    size="small"
                    checked={text}
                    onChange={(checked) => handlePermissionChange(checked, 'view', record)}
                  />
                ),
              },
              {
                title: (
                  <Switch
                    size="small"
                    checked={columnsPermissionChecked.editpermission}
                    checkedChildren="编辑"
                    unCheckedChildren="编辑"
                    onChange={(checked) => handleAllPermissionChange(checked, 'edit')}
                  />
                ),
                dataIndex: 'editpermission',
                align: 'center',
                render: (text, record) => (
                  <Switch
                    size="small"
                    checked={text}
                    onChange={(checked) => handlePermissionChange(checked, 'edit', record)}
                  />
                ),
              },
              {
                title: (
                  <Switch
                    size="small"
                    checked={columnsPermissionChecked.reviewpermission}
                    checkedChildren="审核"
                    unCheckedChildren="审核"
                    onChange={(checked) => handleAllPermissionChange(checked, 'review')}
                  />
                ),
                dataIndex: 'reviewpermission',
                align: 'center',
                render: (text, record) => (
                  <Switch
                    size="small"
                    checked={text}
                    onChange={(checked) => handlePermissionChange(checked, 'review', record)}
                  />
                ),
              },
            ],
          },
        ]}
        pagination={false}
        scroll={{ y: 'calc(100vh - 300px)' }}
      />
    </DragModal>
  );
};

export default Eidt;
