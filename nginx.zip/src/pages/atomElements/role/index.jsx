import React, { useRef, useEffect, useState } from 'react';
import {
  Form,
  Col,
  Input,
  Button,
  Space,
  Row,
  Card,
  Table,
  InputNumber,
  Switch,
  Typography,
  Spin,
  message,
  Tag,
  Modal,
  Checkbox,
} from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import {
  comEleRoleDetail,
  comEleRoleTreeList,
  comEleRoleSave,
  comEleRoleRemove,
  comEleDimensionQuery,
  comEleElementQuery,
  comEleRoleElementList,
} from 'common/axios';
import { EditTree, FetchTable, SearchSelect, UserDeptSelect } from '@cerdo/cerdo-design';
import { array, fn, CONST, guid } from '@cerdo/cerdo-utils';
import styles from './index.less';

const FormItem = Form.Item;

const Role = () => {
  const [treeLoading, setTreeLoading] = useState(false);
  const [treeData, setTreeData] = useState([]);
  const [selectedTreeNode, setSelectedTreeNode] = useState(null);

  const [memberVisible, setMemberVisible] = useState(false);
  const [selectUserKeys, setSelectUserKeys] = useState([]);
  const [selectDeptKeys, setSelectDeptKeys] = useState([]);
  const [selectPositionKeys, setSelectPositionKeys] = useState([]);
  const [memberData, setMemberData] = useState([]);

  const [rightLoading, setRightLoading] = useState(false);
  const [elementData, setElementData] = useState([]);
  const [isAdd, setIsAdd] = useState(false);
  const [selectedDimensionName, setSelectedDimensionName] = useState(null);
  const [columnsPermissionChecked, setColumnsPermissionChecked] = useState({});

  const tableRef = useRef(null);
  const treeRef = useRef(null);
  const tableParamsRef = useRef(null);
  const [form] = Form.useForm();

  const getData = (loading = false) => {
    loading && setTreeLoading(true);
    comEleRoleTreeList()
      .then((result) => {
        if (fn.checkResponse(result)) {
          result.data[0].issystem = 1; // 是第一级 标识为系统
          const newTreeData = array.toOptionsArray(result.data, 'id', 'nodeName');
          loading && setTreeData(newTreeData);
          !loading && treeRef.current.reload(newTreeData);
        }
      })
      .finally(() => loading && setTreeLoading(false));
  };

  useEffect(() => {
    getData(true);
  }, []);

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams({}).then((values) => {
        const { elementData = [], ...otherParams } = tableParamsRef.current || {};
        if (!otherParams?.roleid) {
          resolve(null);
          setColumnsPermissionChecked({
            viewpermission: false,
            editpermission: false,
            reviewpermission: false,
          });
          return;
        }
        otherParams.elementname = (otherParams.elementname || []).join();
        delete otherParams.tableResult;
        comEleRoleElementList({
          ...values,
          ...otherParams,
          type: '0,1',
        }).then((result) => {
          if (fn.checkResponse(result)) {
            const newResult = {
              ...result,
              data: result.data.map((item) => {
                const temp = (elementData || []).find((a) => a.dimid === item.dimid);
                return temp ? temp : item;
              }),
            };
            setColumnsPermissionChecked({
              viewpermission:
                newResult.data?.length > 0 &&
                newResult.data?.every((a) => Number(a.viewpermission) === 1),
              editpermission:
                newResult.data?.length > 0 &&
                newResult.data?.every((a) => Number(a.editpermission) === 1),
              reviewpermission:
                newResult.data?.length > 0 &&
                newResult.data?.every((a) => Number(a.reviewpermission) === 1),
            });
            tableParamsRef.current = { ...tableParamsRef.current, tableResult: newResult };
            resolve(newResult);
          }
        });
      });
    });
  };

  const handleTreeNodeSelect = (_, { selected, node }) => {
    if (selected) {
      setIsAdd(false);
      setElementData([]);
      setSelectedTreeNode(node);
      tableParamsRef.current = { roleid: node?.id }; // 清空搜索值
      // 清空权限变动信息
      if (node?.issystem === 1 || !node) {
        // 系统级 清空表单
        form.resetFields();
        setMemberData([]);

        setSelectUserKeys([]);
        setSelectDeptKeys([]);
        setSelectPositionKeys([]);
        return;
      }
      setRightLoading(true);
      comEleRoleDetail({ roleid: node.id })
        .then((result) => {
          if (fn.checkResponse(result)) {
            const { rolename, roledesc, sort, roleid, parentid, mappings } = result.data;
            form.setFieldsValue({ roleid, rolename, roledesc, sort, parentid });
            setMemberData(mappings);

            setSelectUserKeys(mappings.filter((a) => Number(a.objtype) === 1).map((a) => a.objid));
            setSelectDeptKeys(mappings.filter((a) => Number(a.objtype) === 2).map((a) => a.objid));
            setSelectPositionKeys(
              mappings.filter((a) => Number(a.objtype) === 3).map((a) => a.objid),
            );

            tableRef.current.reloadAndReset();
          }
        })
        .finally(() => setRightLoading(false));
    }
  };

  const handleSaveClick = () => {
    if ((selectedTreeNode?.issystem === 1 || !selectedTreeNode?.id) && !isAdd) {
      return;
    }
    form.validateFields().then((values) => {
      const submitData = {
        ...values,
        mappings: [...memberData],
        permissions: [...elementData],
      };
      setRightLoading(true);
      comEleRoleSave(submitData)
        .then((result) => {
          if (fn.checkResponse(result)) {
            setIsAdd(false);
            message.success('保存成功', 0.5, () => {
              // 保存完成后，是否重新查询刷新一遍
              const { roleid, rolename } = result.data;
              setSelectedTreeNode({ id: roleid, value: rolename });
              handleTreeNodeSelect(null, { selected: true, node: { id: roleid, value: rolename } });
              getData();
            });
          }
        })
        .finally(() => setRightLoading(false));
    });
  };

  const handleAddClick = () => {
    setIsAdd(true);
    form.setFieldsValue({ parentid: selectedTreeNode.id });
    // tableRef.current.reloadAndReset();
  };

  const handleDeleteClick = () => {
    if (!(selectedTreeNode && selectedTreeNode.id)) {
      message.warning('请选择要删除的角色');
      return;
    }
    Modal.confirm({
      title: `确认删除【${selectedTreeNode.value}】角色?`,
      onOk: () => {
        comEleRoleRemove({ roleid: selectedTreeNode.id }).then((result) => {
          if (fn.checkResponse(result)) {
            message.success('删除成功', 0.5, () => {
              getData();
              handleTreeNodeSelect(null, { selected: true, node: null });
            });
          }
        });
      },
    });
  };

  const handlePermissionChange = (checked, type, record) => {
    let newElementData = [...elementData];
    const temp = newElementData.find((a) => a.dimid === record.dimid);
    if (temp) {
      temp[`${type}permission`] = checked ? '1' : '0';
    } else {
      const newRecord = { ...record };
      newRecord[`${type}permission`] = checked ? '1' : '0';
      newElementData = [...newElementData, newRecord];
    }
    setElementData(newElementData);
    tableParamsRef.current = { ...tableParamsRef.current, elementData: newElementData };

    const { tableResult } = tableParamsRef.current;
    setColumnsPermissionChecked({
      ...columnsPermissionChecked,
      [`${type}permission`]: tableResult?.data
        ?.map((item) => {
          const temp = (newElementData || []).find((a) => a.dimid === item.dimid);
          return temp ? temp : item;
        })
        ?.every((a) => Number(a[`${type}permission`]) === 1),
    });
    tableRef.current.dataSourceChange({
      ...tableResult,
      data: tableResult?.data?.map((item) => {
        if (item.dimid === record.dimid) {
          item[`${type}permission`] = checked;
        }
        return item;
      }),
    });
  };

  const handleAllPermissionChange = (checked, type) => {
    if (!tableParamsRef?.current?.tableResult) {
      return;
    }
    const { tableResult } = tableParamsRef.current;
    const newTableData = tableResult?.data.map((item) => {
      const index = elementData.findIndex((a) => a.dimid === item.dimid);
      const temp = index > -1 ? elementData.splice(index, 1)[0] : item;
      temp[`${type}permission`] = checked ? '1' : '0';
      return temp;
    });
    setColumnsPermissionChecked({ ...columnsPermissionChecked, [`${type}permission`]: checked });
    tableRef.current.dataSourceChange({ ...tableResult, data: newTableData });
    tableParamsRef.current = {
      ...tableParamsRef.current,
      elementData: [...elementData, ...newTableData],
    };
    setElementData([...elementData, ...newTableData]);
  };

  const handleDimensionChange = (value) => {
    setSelectedDimensionName(value);
    tableParamsRef.current = { ...tableParamsRef.current, dimensionname: value };
    tableRef.current.reloadAndReset();
  };

  const handleElementChange = (value) => {
    tableParamsRef.current = { ...tableParamsRef.current, elementname: value };
    tableRef.current.reloadAndReset();
  };

  const handleCheckChange = (checked) => {
    tableParamsRef.current = { ...tableParamsRef.current, haspermission: checked ? '1' : '0' };
    tableRef.current.reloadAndReset();
  };

  const getColumns = () => {
    return [
      {
        title: '要素',
        dataIndex: 'elementname',
        width: 100,
        render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph>,
      },
      { title: '要素名', dataIndex: 'elementdesc', width: 100 },
      {
        title: '维度',
        dataIndex: 'dimensionname',
        width: 100,
        render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph>,
      },
      { title: '维度名', dataIndex: 'dimensiondesc', width: 100 },
      {
        title: '是否主键',
        dataIndex: 'ispk',
        align: 'center',
        width: 50,
        render: (text) => (text === '1' ? <CheckOutlined /> : null),
      },
      {
        title: '权限',
        dataIndex: 'permission',
        children: [
          {
            title: (
              <Switch
                size="small"
                checked={columnsPermissionChecked.viewpermission}
                checkedChildren="查看"
                unCheckedChildren="查看"
                onChange={(checked) => handleAllPermissionChange(checked, 'view')}
              />
            ),
            dataIndex: 'viewpermission',
            width: 60,
            align: 'center',
            render: (text, record) => (
              <Switch
                size="small"
                checked={Number(text) === 1}
                onChange={(checked) => handlePermissionChange(checked, 'view', record)}
              />
            ),
          },
          {
            title: (
              <Switch
                size="small"
                checked={columnsPermissionChecked.editpermission}
                checkedChildren="编辑"
                unCheckedChildren="编辑"
                onChange={(checked) => handleAllPermissionChange(checked, 'edit')}
              />
            ),
            dataIndex: 'editpermission',
            width: 60,
            align: 'center',
            render: (text, record) => (
              <Switch
                size="small"
                checked={Number(text) === 1}
                onChange={(checked) => handlePermissionChange(checked, 'edit', record)}
              />
            ),
          },
          {
            title: (
              <Switch
                size="small"
                checked={columnsPermissionChecked.reviewpermission}
                checkedChildren="审核"
                unCheckedChildren="审核"
                onChange={(checked) => handleAllPermissionChange(checked, 'review')}
              />
            ),
            dataIndex: 'reviewpermission',
            width: 60,
            align: 'center',
            render: (text, record) => (
              <Switch
                size="small"
                checked={Number(text) === 1}
                onChange={(checked) => handlePermissionChange(checked, 'review', record)}
              />
            ),
          },
        ],
      },
    ];
  };

  /**
   * objtype 1-人员 2-部门 3-岗位 4-角色
   */
  const handleMemberSave = (
    selectUserKeys,
    selectUsers,
    selectDeptKeys,
    selectDepts,
    selectPositionKeys,
    selectPositions,
  ) => {
    setSelectUserKeys(selectUserKeys);
    setSelectDeptKeys(selectDeptKeys);
    setSelectPositionKeys(selectPositionKeys);
    setMemberVisible(false);

    setMemberData([
      ...selectUsers.map((a) => ({
        id: guid(),
        objid: a.id,
        objname: a.name,
        objtype: a.objtype,
        roleid: selectedTreeNode.id,
      })),
      ...selectDepts.map((a) => ({
        id: guid(),
        objid: a.id,
        objname: a.name,
        objtype: a.objtype,
        roleid: selectedTreeNode.id,
      })),
      ...selectPositions.map((a) => ({
        id: guid(),
        objid: a.id,
        objname: `${a.name}${a.deptName ? `(${a.deptName})` : ''}`,
        objtype: a.objtype,
        roleid: selectedTreeNode.id,
      })),
    ]);
  };

  return (
    <Row gutter={[8, 16]} className={styles['com-element-role']}>
      <Col span={6}>
        <Card bordered={false}>
          <EditTree
            ref={treeRef}
            style={{ height: 'calc(100vh - 155px)', overflowX: 'auto' }}
            expandedKeys={[treeData?.[0]?.key]}
            selectedKeys={[selectedTreeNode?.id]}
            onSelect={handleTreeNodeSelect}
            gData={treeData}
            loading={treeLoading}
            allowEdit={false}
          />
        </Card>
      </Col>
      <Col span={18}>
        <Spin spinning={rightLoading}>
          <Row gutter={[0, 8]}>
            <Col span={24}>
              <Card bordered={false} bodyStyle={{ textAlign: 'right' }}>
                <Typography.Text style={{ lineHeight: '32px', float: 'left' }} strong>
                  {isAdd ? (
                    <Tag color="#108ee9" style={{ color: '#fff' }}>
                      新增
                    </Tag>
                  ) : (
                    selectedTreeNode?.value
                  )}
                </Typography.Text>
                <Space>
                  <Button
                    type="primary"
                    disabled={!(selectedTreeNode?.issystem === 1)}
                    onClick={handleAddClick}
                  >
                    新增
                  </Button>
                  <Button
                    type="primary"
                    disabled={selectedTreeNode?.issystem === 1 || !selectedTreeNode?.id}
                    danger
                    onClick={handleDeleteClick}
                  >
                    删除
                  </Button>
                  <Button
                    type="primary"
                    disabled={(selectedTreeNode?.issystem === 1 || !selectedTreeNode?.id) && !isAdd}
                    onClick={handleSaveClick}
                  >
                    保存
                  </Button>
                </Space>
              </Card>
            </Col>
            <Col span={24}>
              <Card bordered={false}>
                <Form form={form} scrollToFirstError {...CONST.formLayout}>
                  <Row>
                    <Col span={0}>
                      <FormItem name="roleid">
                        <Input />
                      </FormItem>
                    </Col>
                    <Col span={0}>
                      <FormItem name="parentid">
                        <Input />
                      </FormItem>
                    </Col>
                    <Col span={8}>
                      <FormItem
                        label="角色名"
                        name="rolename"
                        rules={[
                          {
                            required: true,
                            message: '请输入角色名',
                          },
                        ]}
                      >
                        <Input placeholder="请输入角色名" />
                      </FormItem>
                    </Col>
                    <Col span={8}>
                      <FormItem
                        label="排序"
                        name="sort"
                        rules={[
                          {
                            required: true,
                            message: '请输入排序',
                          },
                        ]}
                      >
                        <InputNumber min={0} style={{ width: '100%' }} placeholder="请输入排序" />
                      </FormItem>
                    </Col>
                    <Col span={8}>
                      <FormItem
                        label="角色描述"
                        name="roledesc"
                        rules={[
                          {
                            message: '请输入角色描述',
                          },
                        ]}
                      >
                        <Input placeholder="请输入角色描述" />
                      </FormItem>
                    </Col>
                    <Col span={0}>
                      <Button htmlType="submit" type="primary" onClick={handleSaveClick}>
                        保存
                      </Button>
                    </Col>
                  </Row>
                </Form>
              </Card>
            </Col>
            <Col span={24}>
              <Card
                title="成员列表"
                bordered={false}
                extra={
                  <Button
                    type="primary"
                    disabled={(selectedTreeNode?.issystem === 1 || !selectedTreeNode?.id) && !isAdd}
                    onClick={() => setMemberVisible(true)}
                  >
                    编辑
                  </Button>
                }
              >
                <Table
                  size="small"
                  columns={[
                    { title: '名称', dataIndex: 'objname' },
                    {
                      title: '类型',
                      dataIndex: 'objtype',
                      render: (text) => ['', '员工', '部门', '岗位', '角色'][Number(text)],
                    },
                  ]}
                  dataSource={memberData}
                  rowKey="id"
                  pagination={false}
                  scroll={{ y: 200 }}
                />
              </Card>
            </Col>
            <Col span={24}>
              <Card
                title="要素权限"
                bordered={false}
                extra={
                  selectedTreeNode?.id && (
                    <Space key={selectedTreeNode?.id}>
                      <Checkbox onChange={({ target: { checked } }) => handleCheckChange(checked)}>
                        仅看有权限
                      </Checkbox>
                      <SearchSelect
                        getData={comEleDimensionQuery}
                        style={{ width: '160px' }}
                        placeholder="请选择维度搜索"
                        onChange={handleDimensionChange}
                        onSearch={null}
                      >
                        {(item) => (
                          <SearchSelect.Option key={item.dimensionname} value={item.dimensionname}>
                            {item.dimensiondesc}[{item.dimensionname}]
                          </SearchSelect.Option>
                        )}
                      </SearchSelect>
                      <SearchSelect
                        key={selectedDimensionName}
                        mode="multiple"
                        maxTagCount={1}
                        // maxTagTextLength={3}
                        onChange={handleElementChange}
                        getData={comEleElementQuery}
                        placeholder="请选择要素搜索"
                        getParams={(value) => ({
                          dimensionname: selectedDimensionName,
                          keyword: value,
                        })}
                        onSearch={null}
                        optionFilterProp="children"
                      >
                        {(item) => (
                          <SearchSelect.Option key={`${item.elementname}-${item.dimensionname}`} value={item.elementname}>
                            {item.elementdesc}[{item.elementname}]
                          </SearchSelect.Option>
                        )}
                      </SearchSelect>
                    </Space>
                  )
                }
              >
                {/* <Table
                  size="small"
                  columns={[
                    { title: '要素', dataIndex: 'elementname', width: 100, render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph> },
                    { title: '要素名', dataIndex: 'elementdesc', width: 100 },
                    { title: '维度', dataIndex: 'dimensionname', width: 100, render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph> },
                    { title: '维度名', dataIndex: 'dimensiondesc', width: 100 },
                    { title: '是否主键', dataIndex: 'ispk', width: 50, render: (text) => text === '1' ? <CheckOutlined /> : null },
                    {
                      title: '权限', dataIndex: 'permission', children: [
                        { title: '查看', dataIndex: 'viewpermission', width: 60, align: 'center', render: (text, record) => <Switch size="small" checked={Number(text) === 1} onChange={(checked) => handlePermissionChange(checked, 'view', record)} /> },
                        { title: '编辑', dataIndex: 'editpermission', width: 60, align: 'center', render: (text, record) => <Switch size="small" checked={Number(text) === 1} onChange={(checked) => handlePermissionChange(checked, 'edit', record)} /> },
                        { title: '审核', dataIndex: 'reviewpermission', width: 60, align: 'center', render: (text, record) => <Switch size="small" checked={Number(text) === 1} onChange={(checked) => handlePermissionChange(checked, 'review', record)} /> },
                      ]
                    }
                  ]}
                  dataSource={elementData}
                  rowKey="dimid"
                  scroll={{ y: 300 }}
                /> */}
                <FetchTable
                  key={selectedTreeNode?.id}
                  size="small"
                  ref={tableRef}
                  showTools={false}
                  getList={getList}
                  columns={getColumns()}
                  rowKey="dimid"
                  scroll={{ y: 300 }}
                />
              </Card>
            </Col>
          </Row>
        </Spin>
      </Col>
      <UserDeptSelect
        deptable
        userable
        roleable={false}
        positionable
        singleMode={false}
        visible={memberVisible}
        onSave={handleMemberSave}
        onCancel={() => setMemberVisible(false)}
        selectUserKeys={selectUserKeys}
        selectDeptKeys={selectDeptKeys}
        selectPositionKeys={selectPositionKeys}
      />
    </Row>
  );
};

export default Role;
