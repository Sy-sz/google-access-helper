import React from 'react';
import { Modal, Form, DatePicker } from 'antd';
import moment from 'moment';

const PreSubmit = (props) => {
  const { open, setPreSubmitOpen, handleConfirm } = props;
  const [form] = Form.useForm();

  const onOk = () => {
    form.validateFields().then((values) => {
      values.effectdate = values.effectdate.format('YYYYMMDD');
      handleConfirm(values);
    });
  };

  return (
    <Modal
      visible={open}
      title="确认信息"
      width={400}
      onOk={onOk}
      onCancel={() => setPreSubmitOpen(false)}
    >
      <Form form={form} initialValues={{ effectdate: moment() }}>
        <Form.Item
          label="生效日期"
          name="effectdate"
          rules={[{ required: true, message: '请选择生效日期' }]}
        >
          <DatePicker
            style={{ width: '200px' }}
            disabledDate={(current) => current && current < moment()}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default PreSubmit;
