/*
 - 没有 reviewid 根据 displayType 判断
  0 : 查看  (只读；取data；无按钮）
  1 : 编辑  (可编辑；取data；提交按钮)

- 有 reviewid 根据 status 判断
   0 : 退回
    - 退回编辑(只限提交人；可编辑；取vdata; 提交按钮)
    - 退回查看(只限审批人；只读；取vdata; 无按钮)
  10 : 审批中   (只读；取vdata且比对数据；同意按钮 退回按钮)
  99 : 审核通过 (只读；取vdata且比对数据；无按钮)

比对数据逻辑如下(框内展示新值，框下展示旧值)：
- 表格
  从 vdata 里取新增的
  从 data 里取删除的
  剩下的所有字段逐个对比是否被修改
  最终，增删改要合并在一起
- 非表格
  逐个字段比对
*/
import { get, set, isEqual, isEmpty, cloneDeep, forOwn } from 'lodash';

// 表单设计器使用表格时，必须给表格父级容器和表格列命名，命名方式为 字段名加后缀；
// 比如，表格字段为RGFEE，表格父级容器为 RGFEE-CONTAINER；字段为 fundName，列命名为 fundName-CONTAINER
const CONTAINER = '-CONTAINER';
// 审核时，显示修改前的值
const AUDIT_PREFIX = '修改前 :\u00A0\u00A0';

// 移除倒数第一个星号
const removeLastStar = (str) => {
  const arr = str.split('.');
  const newArr = [];
  let flag = true;
  // eslint-disable-next-line no-plusplus
  for (let i = arr.length - 1; i >= 0; i--) {
    if (arr[i] === '*' && flag) {
      flag = false;
      continue;
    }
    newArr.push(arr[i]);
  }
  return newArr.reverse().join('.');
};

/**
 * 从路径中移除中括号
 * @param {string} path 路径
 * @returns string
 * @example a.b[0].c => a.b.c
 */
export const removeBrackets = (path) => {
  const pathArr = path.split('.');
  const pathArrWithoutBrackets = pathArr.map((item) => {
    if (item.includes('[')) {
      return item.split('[')[0];
    }
    return item;
  });
  return pathArrWithoutBrackets.join('.');
};

// 比较两个数组；返回差异对象(字段的路径和旧值)和合并后的数组
const diffArray = ({ oldArr, newArr, arrName, uniqKey = 'PKVALUE' }) => {
  const diffMap = {};
  let mergeArr = [];

  const oldIds = oldArr.map((e) => e[uniqKey]);
  const newIds = newArr.map((e) => e[uniqKey]);
  // 新增
  const addList = newArr
    .filter((item) => !oldIds.includes(item[uniqKey]))
    .map((e) => ({ ...e, modifyType: '新增' }));
  // 删除
  const delList = oldArr.filter((item) => !newIds.includes(item[uniqKey])).map((e) => e[uniqKey]);
  oldArr.forEach((item) => {
    const newItem = { ...item };
    if (delList.includes(newItem[uniqKey])) {
      newItem.modifyType = '删除';
    }
    mergeArr.push(newItem);
  });
  // 汇总到 mergeArr，并排序 把删除的放最后
  mergeArr.push(...addList);
  const { del, other } = mergeArr.reduce(
    (prev, curr) => {
      const key = curr.modifyType === '删除' ? 'del' : 'other';
      prev[key].push(curr);
      return prev;
    },
    { del: [], other: [] },
  );
  if (del.length) {
    mergeArr = other.concat(del);
  }

  // 修改
  // 一定要汇总完了再比对修改的，因为要用到下标做路径
  mergeArr.forEach((item, idx) => {
    if (!item.modifyType) {
      const newItem = newArr.find((e) => e[uniqKey] === item[uniqKey]);
      if (!isEqual(item, newItem)) {
        forOwn(newItem, (value, key) => {
          if (value !== item[key]) {
            if (Array.isArray(value) && Array.isArray(item[key])) {
              const { mergeArr: subMergeArr, diffMap: subDiffMap } = diffArray({
                oldArr: item[key],
                newArr: value,
                arrName: `${arrName}[${idx}].${key}`,
              });
              Object.assign(diffMap, subDiffMap);
              item[key] = subMergeArr;
            } else {
              diffMap[`${arrName}[${idx}].${key}`] = item[key];
              item[key] = value;
            }
          }
        });
      }
    }

    // 父级是新增，子级自然也是新增
    if (item.modifyType === '新增') {
      forOwn(item, (value) => {
        if (Array.isArray(value) && value.length) {
          value.forEach((ele) => {
            ele.modifyType = '新增';
          });
        }
      });
    }
  });

  return { mergeArr, diffMap };
};

export const formatEmpty = (v) => (v === '' || v == null ? '--' : v);

export const getFieldStateMap = ({
  mData,
  edata = {},
  vdata = {},
  schema,
  reviewid,
  status,
  dimidDictMap,
}) => {
  // 字段对应的组件类型 eg: { "itemlist": 'ArrayTable', ... }
  const xComponentMap = {};
  // 字段路径对应的所有动态属性 eg: { "itemlist[0].fundname": { pattern: 'readPretty', ... }, ... }
  const fieldStateMap = {};
  let formData = mData;
  if (reviewid) {
    // 从审批开始，表单数据取vdata
    formData = status === '0' ? vdata : cloneDeep(vdata);
  }

  const setXcomponentMap = (schema) => {
    forOwn(schema.properties, (value, key) => {
      xComponentMap[key] = value['x-component'];

      if (value.properties) {
        setXcomponentMap(value);
      }
    });
  };

  // 处理是否显示，是否只读，tooltip
  const loopEData = (edata) => {
    const setFieldStateMap = ({ key, value, isTable, isTabField }) => {
      const { permissiontype, tooltip, srcuser, srctime, dimid } = value;
      const stateColumnMap = {}; // 表格字段的父级属性
      const stateMap = {}; // 表格字段自身属性

      if (!permissiontype) {
        if (isTable) {
          stateColumnMap.display = 'hidden';
        } else {
          stateMap.display = 'hidden';
        }
      } else {
        if (!permissiontype.includes('1')) {
          stateMap.pattern = 'readPretty';
        }
        if (!isTable) {
          stateMap.fieldInfo = { srcuser, srctime, tooltip, dimid };
        }
      }

      if (isTabField) {
        stateMap.isTabField = true;
      }
      if (!isEmpty(stateMap)) {
        fieldStateMap[key] = stateMap;
      }
      if (!isEmpty(stateColumnMap)) {
        // 因为是设置父级路径，所以要去掉最后一位星号
        const columnsKey = removeLastStar(key);
        fieldStateMap[`${columnsKey}${CONTAINER}`] = stateColumnMap;
      }
    };

    forOwn(edata, (value, key) => {
      if ('permissiontype' in value) {
        setFieldStateMap({ key, value });
      } else if (xComponentMap[key] === 'ArrayTable') {
        // 表格所有列都没有权限时，表格隐藏
        const isHideTable = Object.values(value).every((e) => !e.permissiontype);
        if (isHideTable) {
          fieldStateMap[`${key}${CONTAINER}`] = { display: 'hidden' };
        } else {
          // 表格所有列都只读时，表格只读
          const isTableReadOnly = Object.values(value).every(
            (e) => !e.permissiontype.includes('1'),
          );
          if (isTableReadOnly) {
            fieldStateMap[`${key}`] = { pattern: 'readPretty' };
          }
          forOwn(value, (val, k) => {
            // 表格中，列是否只读需要设置整列字段本身属性,所以用星号；列是否隐藏需要设置字段的父级属性
            setFieldStateMap({ key: `${key}.*.${k}`, value: val, isTable: true });
          });
        }
      } else if (xComponentMap[key] === 'ArrayTabs') {
        // tabs中，所有字段都只读时，tabs只读
        let isTabReadOnly = true;
        forOwn(value, (val, k) => {
          if ('permissiontype' in val) {
            // tabs 中，各个tab栏之间，权限是一致的，这里用星号
            setFieldStateMap({ key: `${key}.*.${k}`, value: val, isTabField: true });
            if (val.permissiontype.includes('1')) {
              isTabReadOnly = false;
            }
          } else {
            // 表格所有列都没有权限时，表格隐藏
            const isHideTable = Object.values(val).every((e) => !e.permissiontype);
            if (isHideTable) {
              fieldStateMap[`${key}.*.${k}${CONTAINER}`] = { display: 'hidden' };
            } else {
              // 表格所有列都只读时，表格只读
              const isTableReadOnly = Object.values(val).every(
                (e) => !e.permissiontype.includes('1'),
              );
              if (isTableReadOnly) {
                fieldStateMap[`${key}.*.${k}`] = { pattern: 'readPretty' };
              }

              forOwn(val, (v, y) => {
                setFieldStateMap({ key: `${key}.*.${k}.*.${y}`, value: v, isTable: true });
                if (v.permissiontype.includes('1')) {
                  isTabReadOnly = false;
                }
              });
            }
          }
        });
        if (isTabReadOnly) {
          fieldStateMap[`${key}`] = { pattern: 'readPretty' };
        }
      }
    });
  };

  // 比较 vdata 和 mData，1. 得到修改前的值 2. 标记新增、删除的表格行或tab栏
  const diffVData = (vdata) => {
    const stateMap = {};

    const setStateMap = ({ key, value, dimid }) => {
      const dictMap = dimidDictMap[dimid];
      let v = value;
      if (dictMap) {
        if (value?.includes(',')) {
          v = value.split(',').reduce((prev, curr) => {
            prev += `${dictMap[curr] || ''} `;
            return prev;
          }, '');
          v = value
            .split(',')
            .map((e) => dictMap[e])
            .join();
        } else {
          v = dictMap[value];
        }
      }
      stateMap[key] = {
        description: `${AUDIT_PREFIX}${formatEmpty(v)}`,
      };
    };

    forOwn(vdata, (value, key) => {
      if (typeof value !== 'object') {
        const oldValue = get(mData, key);
        const { permissiontype, dimid } = get(edata, key, {});
        if (!isEqual(oldValue, value) && permissiontype?.includes('2')) {
          setStateMap({ key, value: oldValue, dimid });
        }
      } else if (Array.isArray(value)) {
        const { mergeArr, diffMap } = diffArray({
          oldArr: mData[key] || [],
          newArr: vdata[key],
          arrName: key,
        });
        forOwn(diffMap, (val, k) => {
          const path = removeBrackets(k);
          const { permissiontype, dimid } = get(edata, path, {});
          if (permissiontype?.includes('2')) {
            setStateMap({ key: k, value: val, dimid });
          }
        });
        formData[key] = mergeArr;
      }
    });

    Object.keys(stateMap).forEach((path) => {
      if (path in fieldStateMap) {
        Object.assign(fieldStateMap[path], stateMap[path]);
      } else {
        fieldStateMap[path] = stateMap[path];
      }
    });
  };

  // 表格增加 数据状态列，用来标识新增、删除的行；tab栏增加 extra；用来标识新增、删除的栏
  const setTableModifyTag = (schema) => {
    forOwn(schema.properties, (value, key) => {
      if (value['x-component'] === 'ArrayTable') {
        const indexList = Object.values(value.items.properties).map((e) => e['x-index']);
        const maxIndex = Math.max(...indexList) + 1; // 放表格最后一列
        value.items.properties['modifyTypeColumns'] = {
          type: 'void',
          'x-component': 'ArrayTable.Column',
          'x-component-props': {
            title: '操作类型',
            width: 80,
          },
          'x-designable-id': Math.random(),
          'x-index': maxIndex,
          name: 'modifyTypeColumns',
          properties: {
            modifyType: {
              type: 'string',
              'x-decorator': 'FormItem',
              'x-component': 'Text',
              'x-designable-id': Math.random(),
              'x-index': 0,
              'x-component-props': {
                style: { color: 'orange' },
              },
              name: 'modifyType',
            },
          },
        };
      }

      if (value['x-component'] === 'ArrayTabs') {
        // 新增份额：xxx，xxx；删除份额：yyy,yyy
        let txt = [];

        const { add, del } = (formData[key] ?? []).reduce(
          (prev, { modifyType }, idx) => {
            if (modifyType === '新增') {
              prev.add.push(`${value.title}${idx + 1}`);
            }
            if (modifyType === '删除') {
              prev.del.push(`${value.title}${idx + 1}`);
            }
            return prev;
          },
          { add: [], del: [] },
        );
        if (add?.length) {
          txt.push(`新增: ${add.join(', ')}`);
        }
        if (del?.length) {
          txt.push(`删除: ${del.join(', ')}`);
        }
        if (txt.length) {
          set(value, 'x-component-props.tabBarExtraContent', txt.join(' '));
        }
      }

      if (value.items) {
        setTableModifyTag(value.items);
      } else if (value.properties) {
        setTableModifyTag(value);
      }
    });
  };

  // schema字段对应的组件类型(只遍历第一层)
  setXcomponentMap(schema.schema);
  // 设置字段是否显示，是否只读，气泡提示
  loopEData(edata);
  // 10审批中；需要显示修改前的值，都是只读
  if (reviewid && ['10'].includes(status)) {
    diffVData(vdata); // 会更改formData
    setTableModifyTag(schema.schema); // 要在 diffVData 之后调用
  }

  // TODO: 直接得出最终的 jsonSchema，可能比目前的 setFieldState 方式性能更好？
  return { fieldStateMap, formData, jsonSchema: schema };
};

// 把字典转成 key value 的对象形式
export const formatDictMap = (data) => {
  const map = {};
  const loopData = (arr) => {
    arr.forEach((item) => {
      if (item.dictLabel) {
        map[item.dictValue] = item.dictLabel;
      }
      if (item.children?.length) {
        loopData(item.children);
      }
    });
  };
  loopData(data);
  return map;
};
