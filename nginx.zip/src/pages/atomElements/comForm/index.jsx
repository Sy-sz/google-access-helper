/* eslint-disable no-return-assign */
import React, { useEffect, useState, useRef, useMemo } from 'react';
import { unstable_batchedUpdates } from 'react-dom';
import { CerdoForm, UserSelect } from '@cerdo/cerdo-design';
import { dictTree } from '@cerdo/cerdo-utils/lib/api';
import { createForm } from '@formily/core';
import {
  Button,
  Spin,
  Space,
  Select,
  Empty,
  Result,
  Popover,
  Tabs,
  Timeline,
  Card,
  Form,
  Modal,
  message,
} from 'antd';
import { forOwn, isEmpty, omit, has, get, set } from 'lodash';
import moment from 'moment';
import classnames from 'classnames';
import { url, fn, storage } from '@cerdo/cerdo-utils';
import { comElePreview, comeleQuery, comEleSave, comEleVersionlist } from '@/common/axios';
// import { usePrevious } from '@/hooks';
import { getFieldStateMap, formatDictMap, formatEmpty } from './data';
import PreSubmit from './PreSubmit';
import FormProcess from './FormProcess';
import scope from './scope';
import styles from './style.module.less';

const { TabPane } = Tabs;
const ymd = 'YYYY-MM-DD HH:mm:ss';

// 产品负责人：UserSelect
// 托管人/境外托管人/境外投资顾问/注册登记机构/基金管理人/律师事务所/会计事务所，非字典框
const Index = (props) => {
  const [loading, setLoading] = useState(true);
  const [queryApiData, setQueryApiData] = useState({});
  const [jsonSchema, setJsonSchema] = useState({});
  const [readOnly, setReadOnly] = useState(false);
  const [reloadFlag, setReloadFlag] = useState(false); // 提交或同意后，重新加载数据
  const form = useRef(createForm());

  const [preSubmitOpen, setPreSubmitOpen] = useState(false);
  const preSubmitData = useRef({});

  const { funcid, dataid, reviewid, secdataid } = url.getAllQueryString();
  const { status, iseffect, funcname, reviewer, alreviewer, functitle, edata } = queryApiData || {};
  const userInfo = storage.getUserInfo() || {};
  const isReviewer = reviewer?.split(',')?.includes(userInfo?.account); // 当前登录人是否为审批人
  const hasReviewed = isReviewer && alreviewer?.includes(userInfo?.account); // 当前登录人是审批人, 且未审批过

  const { pathname } = props?.location ?? {};
  const isPreview = pathname?.endsWith('preview');
  const [proxUser, setProxUser] = useState({ id: userInfo.id, userName: userInfo.userName });

  //  至少有一个字段可编辑，则显示提交按钮
  const atLeastOneEditable = useMemo(() => {
    if (isEmpty(edata) || readOnly) {
      return false;
    }

    let flag = false;
    const loopEdata = (data) => {
      forOwn(data, (value, key) => {
        if (!('permissiontype' in value)) {
          loopEdata(value);
        }
        if (value.permissiontype?.includes('1')) {
          flag = true;
          return false;
        }
      });
    };

    loopEdata(edata);
    return flag;
  }, [edata]);

  //  是否edata为空 或edata全都无权限
  const isPermissionEmpty = useMemo(() => {
    if (isEmpty(edata)) {
      return true;
    }

    let flag = true;
    const loopEdata = (data) => {
      forOwn(data, (value, key) => {
        if ('permissiontype' in value) {
          if (value.permissiontype !== '') {
            flag = false;
            return;
          }
        } else {
          loopEdata(value);
        }
      });
    };

    loopEdata(edata);
    return flag;
  }, [edata]);

  /**
   * 因为多选下拉框的值是数组，这里把数组转成字符串
   */
  const convertArrayToString = (values) => {
    forOwn(values, (value, key) => {
      if (Array.isArray(value)) {
        if (typeof value[0] === 'string') {
          values[key] = value.join();
        } else {
          value.forEach((item) => {
            convertArrayToString(item);
          });
        }
      }
    });
  };

  /** 把数据中字符串转为数组(多选框) */
  const convertStringToArray = (edata, formData) => {
    if (isEmpty(edata) || isEmpty(formData)) {
      return;
    }

    // 拼接edata中多选字段路径 eg: [a, b.c, b.c.d]
    const getEdataMultiplePath = () => {
      const edataMultiplePath = [];
      const loopEdata = (data, prevKey) => {
        forOwn(data, (value, key) => {
          if (has(value, 'componentprops')) {
            if (value.componentprops?.ismult === '1') {
              edataMultiplePath.push(prevKey ? `${prevKey}.${key}` : key);
            }
          } else {
            loopEdata(value, prevKey ? `${prevKey}.${key}` : key);
          }
        });
      };
      loopEdata(edata);
      return edataMultiplePath;
    };

    // 拼接formData中多选字段路径，方便取值和赋值 eg: [a, b[0].c, b[1].c, b[0].c[0].d, b[0].c[1].d, b[1].c[0].d, b[1].c[1].d]
    const getFormDataMultiplePath = (edataMultiplePath) => {
      const formDataMultiplePath = [];
      edataMultiplePath.forEach((item) => {
        if (item.includes('.')) {
          const [first, second, third] = item.split('.');
          if (third) {
            const firstLen = formData[first].length;
            for (let i = 0; i < firstLen; i++) {
              const secondLen = formData[first][i][second].length;
              for (let j = 0; j < secondLen; j++) {
                formDataMultiplePath.push(`${first}[${i}].${second}[${j}].${third}`);
              }
            }
          } else {
            const firstLen = formData[first].length;
            for (let i = 0; i < firstLen; i++) {
              formDataMultiplePath.push(`${first}[${i}].${second}`);
            }
          }
        } else {
          formDataMultiplePath.push(item);
        }
      });
      return formDataMultiplePath;
    };

    const edataMultiplePath = getEdataMultiplePath();
    const formDataMultiplePath = getFormDataMultiplePath(edataMultiplePath);

    formDataMultiplePath.forEach((path) => {
      const value = get(formData, path)?.split(',') || [];
      set(formData, path, value);
    });
  };

  // 提交 或 同意
  const onSubmit = (type) => {
    unstable_batchedUpdates(() => {
      setPreSubmitOpen(false);
      setLoading(true);
    });

    if (!type) {
      // eslint-disable-next-line no-param-reassign
      type = readOnly ? '2' : '1';
    }

    form.current.submit((values) => {
      convertArrayToString(values);
      const data = {
        ...omit(queryApiData, ['jsonschema']),
        ...preSubmitData.current,
        data: values,
        funcid,
        dataid,
        reviewid,
      };
      comEleSave({ type, data })
        .then((res) => {
          if (fn.checkResponse(res)) {
            if (!reviewid) {
              const url = `${window.location.href}&reviewid=${res.message}`;
              location.href = url;
            }
            setReloadFlag(!reloadFlag);
          }
        })
        .catch(() => {
          setLoading(false);
          preSubmitData.current = {};
        });
    });
  };

  // 生效日期
  const preSubmit = () => {
    form.current.submit().then(() => {
      if (iseffect === '1' && !readOnly) {
        setPreSubmitOpen(true);
        return;
      }

      onSubmit();
    });
  };

  // 生效日期 确认
  const handleConfirm = (data) => {
    preSubmitData.current = data;
    onSubmit();
  };

  // 页面是否只读
  const isReadOnlyFn = ({ displaytype, status, applyaccount }) => {
    // 没有 reviewid 根据 displaytype; 0 查看；1 编辑
    // 有 reviewid 根据 status; 0 退回；10 审批中；99 审批通过
    if (reviewid) {
      // 退回
      if (status === '0') {
        return applyaccount !== userInfo.account; // 登录人不是提交人，只读
      }
      return status === '10' || status === '99'; // 审核中，审核通过
    }
    return displaytype === '0'; // 查看
  };

  // 气泡显示字段信息(基本信息、用途、修改历史)
  const renderFieldTitle = ({ fieldInfo, dimIdMap, dimidDictMap, state, PKVALUE }) => {
    const { srcuser, srctime, tooltip, dimid } = fieldInfo || {};
    let currentField = dimIdMap?.[dimid] ?? [];
    const dictMap = dimidDictMap[dimid];
    if (PKVALUE) {
      currentField = currentField.filter((e) => e.pkvalue === PKVALUE);
    }
    currentField?.sort((a, b) => b.updatetime?.localeCompare(a.updatetime));

    const content = (
      <Tabs animated={false} size="small" tabBarGutter={18}>
        <TabPane tab="基本信息" key="1">
          <div>创建人: {srcuser}</div>
          <div>创建时间: {moment(srctime).format(ymd)}</div>
        </TabPane>
        <TabPane tab="用途" key="2">
          <div>{tooltip || <Empty />}</div>
        </TabPane>
        <TabPane tab="修改历史" key="3">
          {currentField.length ? (
            <Timeline>
              {currentField.map((item, i) => {
                let v = item.value;
                if (dictMap) {
                  if (item.value.includes(',')) {
                    v = item.value
                      .split(',')
                      .map((e) => dictMap[e] || '')
                      .join();
                  } else {
                    v = dictMap[item.value];
                  }
                }
                return (
                  <Timeline.Item key={i}>
                    <p>
                      [{formatEmpty(v)}] {item.updateuser}
                    </p>
                    <p>{item.updatetime}</p>
                  </Timeline.Item>
                );
              })}
            </Timeline>
          ) : (
            <Empty />
          )}
        </TabPane>
      </Tabs>
    );

    return (
      <Popover content={content} placement="bottom" overlayClassName={styles.fieldPop}>
        <span style={{ cursor: 'pointer' }}>{state.title}</span>
      </Popover>
    );
  };

  // 根据fieldStateMap 设置表单字段状态
  const batchSetFieldState = ({ formData, fieldStateMap, dimIdMap, dimidDictMap }) => {
    // 由于份额之间字段的权限是一致的(edata里只有一份)，但字段历史修改记录是不一致的，这里需要把fieldStateMap里的*号替换成对应的下标
    let newFieldStateMap = fieldStateMap;
    if (!isEmpty(formData)) {
      newFieldStateMap = {};
      forOwn(fieldStateMap, (stateMap, key) => {
        if (stateMap.isTabField) {
          const fieldKey = key.split('.')[0];
          formData[fieldKey]?.forEach((item, i) => {
            const k = key.replace('*', i);
            if (newFieldStateMap[k]) {
              console.error('有重复的key');
            }
            newFieldStateMap[k] = { ...stateMap, PKVALUE: item.PKVALUE };
          });
        } else {
          newFieldStateMap[key] = stateMap;
        }
      });
    }

    console.log('newFieldStateMap----->', newFieldStateMap);
    forOwn(newFieldStateMap, (stateMap, key) => {
      form.current.setFieldState(key, (state) => {
        const { fieldInfo, PKVALUE, ...otherState } = stateMap;
        forOwn(otherState, (value, k) => {
          state[k] = value;
        });
        if (fieldInfo) {
          state.title = renderFieldTitle({ fieldInfo, dimIdMap, dimidDictMap, state, PKVALUE });
        }
      });
    });
  };

  const formatFormData = (data) => {
    forOwn(data, (value, key) => {
      if (value === '') {
        data[key] = undefined;
      }
      if (Array.isArray(value) && value.length) {
        value.forEach((item) => {
          formatFormData(item);
        });
      }
    });
  };

  const fetchFieldHistory = async ({ edata }) => {
    let dimIdMap = {};
    const dimids = [];
    Object.values(edata).forEach((item) => {
      if ('dimid' in item) {
        dimids.push(item.dimid);
      } else {
        Object.values(item).forEach((ele) => {
          if ('dimid' in ele) {
            dimids.push(ele.dimid);
          }
        });
      }
    });
    const { data } = await comEleVersionlist({ dataid, reviewid, dimids });
    if (data?.length) {
      dimIdMap = data.reduce((prev, curr) => {
        const dimidList = prev[curr.dimid] || [];
        dimidList.push(curr);
        prev[curr.dimid] = dimidList;
        return prev;
      }, {});
    }
    return dimIdMap;
  };

  const fetchFieldDict = async ({ edata }) => {
    let dimidDictMap = {};
    const dictRequestMap = {};
    const loopEdata = (data) => {
      forOwn(data, (value, key) => {
        if ('dimid' in value) {
          if (!isEmpty(value.componentprops)) {
            const { dictid: dictId, queryparam: queryParams } = value.componentprops;
            if (dictId) {
              const params = { dictId };
              if (!isEmpty(queryParams)) {
                console.log('🚀 ~ file: index.jsx:339 ~ forOwn ~ queryParams:', queryParams);
                params.queryParams = JSON.parse(queryParams);
              }
              dictRequestMap[value.dimid] = dictTree(params);
            }
          }
        } else {
          loopEdata(value);
        }
      });
    };

    loopEdata(edata);
    if (!isEmpty(dictRequestMap)) {
      try {
        const dictDataList = await Promise.all(Object.values(dictRequestMap));
        dimidDictMap = dictDataList.reduce((prev, curr, idx) => {
          const dimidDictMap = formatDictMap(curr.data.children);
          const dimid = Object.keys(dictRequestMap)[idx];
          prev[dimid] = dimidDictMap;
          return prev;
        }, {});
      } catch (error) {
        message.error('获取字典失败');
      }
    }
    return dimidDictMap;
  };

  const fetchInitData = async () => {
    const request = isPreview ? comElePreview : comeleQuery;
    setLoading(true);
    try {
      // 查 初始数据
      const res = await request({ funcid, dataid, reviewid, userid: proxUser.id, secdataid });
      if (!fn.checkResponse(res) || !res.data?.jsonschema) {
        throw Error('数据异常');
      }
      const { edata, jsonschema } = res.data;

      let dimIdMap = {}; // 数据：字段dimid和历史记录的映射
      let dimidDictMap = {}; // 数据：字段dimid和字典的映射
      if (dataid || reviewid) {
        const [map1, map2] = await Promise.all([
          // 查 字段历史修改记录
          fetchFieldHistory({ edata }),
          // 查 字典
          fetchFieldDict({ edata }),
        ]);
        dimIdMap = map1;
        dimidDictMap = map2;
      }

      const readOnly = isReadOnlyFn(res.data);
      const mData = res.data.data ?? {};
      const schema = JSON.parse(jsonschema);
      const formatData = getFieldStateMap({ ...res.data, mData, schema, reviewid, dimidDictMap });
      const { fieldStateMap, formData, jsonSchema } = formatData;
      form.current = createForm();
      batchSetFieldState({ formData, fieldStateMap, dimIdMap, dimidDictMap });

      // 把空字符转为undefined，否则placeholder不生效
      if (!reviewid) {
        formatFormData(formData);
      }
      // 因为多选下拉框的值是数组，这里把字符串转成数组
      convertStringToArray(edata, formData);

      form.current.setPattern(readOnly ? 'readPretty' : 'editable');
      form.current.setValues(formData);

      unstable_batchedUpdates(() => {
        setLoading(false);
        setReadOnly(readOnly);
        setQueryApiData(res.data);
        setJsonSchema(jsonSchema);
      });
    } catch (error) {
      setLoading(false);
      console.error(error);
    }
  };

  useEffect(() => {
    fetchInitData();
  }, [proxUser.id, reloadFlag]);

  useEffect(() => {
    document.title = functitle || funcname || '';
  }, [functitle, funcname]);

  const isSchemaEmpty = isEmpty(jsonSchema.schema?.properties);
  if (loading) {
    return <Spin className={styles.loading} />;
  }
  if (isSchemaEmpty) {
    return <Result status="404" title="未设计表单" />;
  }
  if (isEmpty(edata)) {
    return <Result status="404" title="未添加要素" />;
  }
  if (isPermissionEmpty && !isPreview) {
    return <Result status="403" title="要素无权限" />;
  }
  if (isEmpty(queryApiData)) {
    // 放最后原因：没有配置jsonschema时，会提示暂无数据，放最后才会提示未设计表单
    return <Empty style={{ paddingTop: '30vh' }} description="暂无数据" />;
  }

  return (
    <div className={styles.container}>
      <div className={styles.formHead}>
        <span className={styles.title}>{functitle || funcname || ''} </span>
        {isPreview && (
          <Space>
            <UserSelect
              allowClear={false}
              value={proxUser.userName}
              onChange={(value, record) => {
                setProxUser({ id: value, userName: record.children });
              }}
            >
              {(item) => {
                return (
                  <Select.Option key={item.id} value={item.id} data={item}>
                    {item.userName}
                  </Select.Option>
                );
              }}
            </UserSelect>
          </Space>
        )}

        {!isPreview && (
          <Space>
            {!readOnly && atLeastOneEditable && (
              <Button type="primary" onClick={preSubmit}>
                提交
              </Button>
            )}
            {reviewid && status === '10' && isReviewer && !hasReviewed && (
              <>
                <Button
                  type="primary"
                  onClick={() => {
                    Modal.confirm({
                      title: '确认同意？',
                      onOk: preSubmit,
                    });
                  }}
                >
                  同意
                </Button>
                <Button type="primary" onClick={() => onSubmit('3')}>
                  退回
                </Button>
              </>
            )}
            <FormProcess reviewid={reviewid} reloadFlag={reloadFlag} />
          </Space>
        )}
      </div>

      {isPreview && isPermissionEmpty ? (
        <Result status="403" title="要素无权限" />
      ) : (
        <>
          <Card title="基本信息" bordered={false} className={styles.formInfo}>
            <Form layout="inline">
              <Form.Item label="申请人">{queryApiData.applyuser}</Form.Item>
              <Form.Item label="申请时间">{moment(queryApiData.applytime).format(ymd)}</Form.Item>
            </Form>
          </Card>

          <CerdoForm
            form={form.current}
            {...jsonSchema?.form}
            schema={jsonSchema?.schema}
            className={classnames(styles.schemaForm, { [styles.reviewStyle]: !!reviewid })}
            createSchemaFieldOptions={{ scope }}
          />
          <PreSubmit
            open={preSubmitOpen}
            setPreSubmitOpen={setPreSubmitOpen}
            handleConfirm={handleConfirm}
          />
        </>
      )}
    </div>
  );
};

export default Index;
