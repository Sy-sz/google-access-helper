import React, { useState, useEffect } from 'react';
import { Button, Popover, Timeline } from 'antd';
import { comEleElementreview } from '@/common/axios';
import { fn } from '@cerdo/cerdo-utils';

const optypeMap = {
  1: '提交',
  2: '同意',
  3: '退回',
};

const FormProcess = ({ reviewid, reloadFlag }) => {
  const [data, setData] = useState([]);

  const renderContent = () => {
    if (data.length) {
      return (
        <Timeline>
          {data.map((item) => (
            <Timeline.Item key={item.optime}>
              <p>{`[${optypeMap[item.optype]}] ${item.opusername}`}</p>
              <p>{item.optime}</p>
            </Timeline.Item>
          ))}
        </Timeline>
      );
    }

    return null;
  };

  const fetchProcess = () => {
    comEleElementreview({ reviewid }).then((res) => {
      if (fn.checkResponse(res)) {
        setData(res.data);
      }
    });
  };

  useEffect(() => {
    if (reviewid) {
      fetchProcess();
    }
  }, [reviewid, reloadFlag]);

  if (!reviewid) {
    return null;
  }

  return (
    <Popover placement="leftBottom" content={renderContent()}>
      <Button type="primary">跟踪</Button>
    </Popover>
  );
};

export default FormProcess;
