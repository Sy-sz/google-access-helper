import { action } from '@formily/reactive';
import { url } from '@cerdo/cerdo-utils';
import moment from 'moment';

/** 取 此刻日期时间 */
const getCurrentDate = () => moment().format('YYYY-MM-DD HH:mm:ss');
/** 取 localStorage里用户信息 */
const getCurrentUser = () => JSON.parse(localStorage.getItem('user'));
/** 取 url中的参数 */
const getUrlParam = () => url.getAllQueryString();

/** 设置 字段dataSource，如 Select等 */
const setDataSource = (service, params) => (field) => {
  field.loading = true;
  service?.(params).then(
    action.bound((res) => {
      if (Array.isArray(res.data.children)) {
        res.data = res.data.children;
      }

      res.data.forEach((item) => {
        item.label = item.dictLabel;
        item.value = item.dictValue;
      });

      // 只有一项时，自动选中
      if (res.data.length === 1) {
        field.value = res.data[0].value;
      }

      field.dataSource = res.data;
      field.loading = false;
    }),
  );
};
/** 设置 字段value，如select、input等 */
const setValue = (service, params) => (field) => {
  field.loading = true;
  service?.(params).then(
    action.bound((res) => {
      if (Array.isArray(res.data.children)) {
        res.data = res.data.children;
      }

      res.data.forEach((item) => {
        item.label = item.dictLabel;
        item.value = item.dictValue;
      });

      field.dataSource = res.data;
      field.value = res.data[0].value;
      field.loading = false;
    }),
  );
};

export default {
  getCurrentDate,
  getCurrentUser,
  getUrlParam,
  setDataSource,
  setValue,
};
