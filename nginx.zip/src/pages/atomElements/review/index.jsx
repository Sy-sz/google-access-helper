import React, { useRef } from 'react';
import { Form, Col, Input, Button, Space, Select } from 'antd';
import { FetchTable } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { fn, storage } from '@cerdo/cerdo-utils';
import SearchCard from 'common/component/SearchCard';
import { comEleReviewList } from 'common/axios';
import { Link } from 'react-router-dom';

const FormItem = Form.Item;

const statusObj = {
  10: <span className="orange">审核中</span>,
  99: <span className="green">审核通过</span>,
  0: <span className="red">退回</span>,
};
const columnsList = [
  { title: '审批标题', dataIndex: 'title' },
  { title: '申请人', dataIndex: 'applyuser' },
  { title: '审批人', dataIndex: 'reviewername' },
  { title: '已审批人', dataIndex: 'alreviewername' },
  {
    title: '状态',
    dataIndex: 'status',
    width: 80,
    render: (text, record) => {
      if (text === '99' && !record.reviewer) {
        return <span className="green"> 自动通过</span>;
      }
      return statusObj[`${text}`];
    },
  },
  {
    title: '提交人/提交时间',
    dataIndex: 'create',
    width: 160,
    render: (_, record) => {
      return (
        <Space size={0} direction="vertical">
          <span>{record.createuser}</span>
          <span>{record.createtime}</span>
        </Space>
      );
    },
  },
];

const Reivew = () => {
  const formRef = useRef(null);
  const tableRef = useRef(null);

  const userInfo = storage.getUserInfo();

  const reloadData = () => {
    tableRef.current.reloadAndReset();
  };

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams(formRef.current).then((values) => {
        comEleReviewList({ ...values }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
        });
      });
    });
  };

  const onReset = () => {
    reloadData();
  };

  /**
   * Status : 0 退回、 10 审批中 、 99 通过
   * 退回 - 只有提交人可以 编辑、其他人无操作按钮
   * 审批中 - 审核人可以审核、编辑人只能查看
   * 通过 - 审核人、编辑人只能查看
   */
  const renderOpBtn = (record) => {
    const url = `/app/com/form?layout=sub&reviewid=${record.reviewid}&dataid=${record.dataid}&funcid=${record.funcid}`;
    if (Number(record.status) === 0) {
      if (record.createuser === userInfo?.account) {
        return (
          <Button type="link">
            <Link to={url} target="_blank">
              编辑
            </Link>
          </Button>
        );
      }
      return null;
    }

    if (Number(record.status) === 10) {
      if (
        !record.reviewer?.split(',').includes(userInfo?.account) ||
        record.alreviewer?.split(',').includes(userInfo?.account)
      ) {
        return (
          <Button type="link">
            <Link to={url} target="_blank">
              查看
            </Link>
          </Button>
        );
      }
      return (
        <Button type="link">
          <Link to={url} target="_blank">
            审核
          </Link>
        </Button>
      );
    }

    if (Number(record.status) === 99) {
      return (
        <Button type="link">
          <Link to={url} target="_blank">
            查看
          </Link>
        </Button>
      );
    }
  };

  const columns = columnsList.concat({
    title: '操作',
    width: '100px',
    render: (_, record) => renderOpBtn(record),
  });

  return (
    <>
      <SearchCard ref={formRef} onSearch={reloadData} onReset={onReset}>
        <Col span={8}>
          <FormItem label="关键词" name="keyword">
            <Input allowClear placeholder="请输入关键词" />
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="审批状态" name="status">
            <Select
              allowClear
              options={[
                { key: '10', label: '审批中', value: '10' },
                { key: '99', label: '审批通过', value: '99' },
                { key: '0', label: '退回', value: '0' },
              ]}
              placeholder="请选择审批状态"
            />
          </FormItem>
        </Col>
      </SearchCard>
      <ListCard title="审批列表" bordered={false}>
        <FetchTable
          size="small"
          showTools={false}
          rowKey="id"
          ref={tableRef}
          getList={getList}
          columns={columns}
          scroll={{ y: 'calc(100vh - 320px)' }}
          autoHeight={{ blankHeight: 230 }}
        />
      </ListCard>
    </>
  );
};

export default Reivew;
