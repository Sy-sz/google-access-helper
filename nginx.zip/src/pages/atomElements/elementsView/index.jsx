import React, { useRef, useEffect, useState } from 'react';
import {
  Form,
  Col,
  Input,
  Button,
  Space,
  Row,
  Card,
  Table,
  Spin,
  Switch,
  Typography,
  Tooltip,
  InputNumber,
  message,
  Modal,
  Tag,
  Tabs,
  Checkbox,
} from 'antd';
import { FontSizeOutlined, CreditCardOutlined } from '@ant-design/icons';
import {
  comEleModuleTreeList,
  comEleModuleElementDetail,
  comEleModuleRemove,
  comEleModuleSave,
  comEleElementQuery,
  commonApi,
  comEleElementList,
  comEleDimensionQuery,
  comEleCurElementList,
} from 'common/axios';
import { EditTree, FetchTable, SearchSelect } from '@cerdo/cerdo-design';
import { fn, CONST, url } from '@cerdo/cerdo-utils';
import { HBFormItem } from '@/common/component';
import PopverRoleMember from '../component/PopverRoleMember';
import styles from './index.less';
import _ from 'lodash';
import PopverRole from '../component/PopverRole';

const FormItem = Form.Item;

const ElementsView = () => {
  const [treeLoading, setTreeLoading] = useState(false);
  const [treeData, setTreeData] = useState([]);
  const [rightLoading, setRightLoading] = useState(false);
  const [selectedTreeNode, setSelectedTreeNode] = useState({ iselement: 1 });
  const [isAdd, setIsAdd] = useState(false);

  const [form] = Form.useForm();
  const treeRef = useRef(null);
  const tableRef = useRef(null);
  const curEleTableRef = useRef(null);
  const permissionRef = useRef({ isManager: false });

  const [roleData, setRoleData] = useState([]);
  const [funcData, setFuncData] = useState([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const dimId = url.getQueryString('dimid');

  const [selectedDimensionName, setSelectedDimensionName] = useState(null);
  const tableParamsRef = useRef(null);

  const [curEleData, setCurEleData] = useState(null);

  const getModuleElementData = (moduleid) => {
    if (!moduleid) {
      return;
    }
    comEleElementQuery({ moduleid }).then((result) => {
      if (fn.checkResponse(result)) {
        setSelectedRowKeys(result.data?.map((a) => a.dimid) || []);
        setSelectedRows(result.data || []);
      }
    });
  };

  const handleTreeNodeSelect = (_, { selected, node }) => {
    if (selected) {
      setIsAdd(false);
      setSelectedRows([]);
      setSelectedRowKeys([]);
      setSelectedTreeNode(node);
      tableParamsRef.current = { id: node?.id };

      if (node) {
        if (Number(node.iselement) === 1) {
          setRightLoading(true);
          comEleModuleElementDetail({ dimid: node.id })
            .then((result) => {
              if (fn.checkResponse(result)) {
                const {
                  elementdesc,
                  elementname,
                  dimensiondesc,
                  dimensionname,
                  srcsys,
                  elementpurp,
                  permissions,
                  funcs,
                } = result.data;
                form.setFieldsValue({
                  elementname: `${elementdesc}（${elementname}）`,
                  dimensionname: `${dimensiondesc}-${dimensionname}`,
                  srcsys,
                  elementpurp,
                });
                setRoleData(permissions);
                setFuncData(funcs);
                curEleTableRef?.current?.reloadAndReset();
              }
            })
            .finally(() => setRightLoading(false));
        } else {
          const { id: moduleid, value: modulename, sort } = node;
          form.setFieldsValue({ moduleid, modulename, sort });
          getModuleElementData(moduleid);
        }
      }
    }
  };

  const toOptionsArray = (array, label, value) => {
    if (!Array.isArray(array)) {
      return array;
    }

    const toOptions = (data) => {
      if (data && data.length > 0) {
        data.forEach((e) => {
          e.key = e[label];
          e.value = e[value];
          e.label = e[label];
          e.icon =
            Number(e.iselement) === 1 ? (
              <Tooltip title="要素">
                <FontSizeOutlined />
              </Tooltip>
            ) : (
              <Tooltip title="模块">
                <CreditCardOutlined />
              </Tooltip>
            );
          e.selectable = permissionRef.current.isManager || Number(e.iselement) === 1;

          if (dimId && e.id === dimId) {
            setSelectedTreeNode(e);
            handleTreeNodeSelect(null, { selected: true, node: e });
          }

          if (e.children && e.children.length > 0) {
            toOptions(e.children);
          } else {
            e.children = null;
          }
        });
      }
    };
    toOptions(array);
    return array;
  };

  const getData = (loading = false) => {
    loading && setTreeLoading(true);
    comEleModuleTreeList()
      .then((result) => {
        if (fn.checkResponse(result)) {
          const newTreeData = toOptionsArray(result.data, 'id', 'nodeName');
          loading && setTreeData(newTreeData);
          !loading && treeRef.current.reload(newTreeData);
        }
      })
      .finally(() => loading && setTreeLoading(false));
  };

  // 验证用户权限
  const verifyUserPermission = () => {
    commonApi
      .userPermission({ permissionids: '697b371c-9140-4500-a7e0-d50c07f2529d' })
      .then((result) => {
        if (fn.checkResponse(result)) {
          permissionRef.current = { isManager: result.data[0].haspermission === 1 };
          getData(true);
        }
      });
  };

  useEffect(() => {
    verifyUserPermission();
  }, []);

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams({}).then((values) => {
        comEleElementList({
          ...values,
          ...tableParamsRef.current,
          elementname: (tableParamsRef.current.elementname || []).join(),
          type: '0,1', // 排除 虚拟要素
        }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
        });
      });
    });
  };

  const getCurElementList = () => {
    return new Promise((resolve) => {
      if (!tableParamsRef.current?.id) {
        resolve(null);
        return;
      }
      curEleTableRef.current.getFormParams({}).then((values) => {
        comEleCurElementList({
          ...values,
          dimid: tableParamsRef.current?.id,
        }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve({ count: result?.data?.count, data: result.data?.data });
            setCurEleData(result?.data ?? {});
          }
        });
      });
    });
  };

  const getColumns = () => {
    return [
      {
        title: '要素',
        dataIndex: 'elementname',
        render: (text, record) => (
          <PopverRole data={record}>
            <Typography.Paragraph copyable>{text}</Typography.Paragraph>
          </PopverRole>
        ),
      },
      { title: '要素名', dataIndex: 'elementdesc' },
      {
        title: '维度',
        dataIndex: 'dimensionname',
        render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph>,
      },
      { title: '维度名', dataIndex: 'dimensiondesc' },
      { title: '所属模块', dataIndex: 'modulename' },
      // {
      //   title: '是否主键',
      //   dataIndex: 'ispk',
      //   align: 'center',
      //   width: 80,
      //   render: (text) => (text === '1' ? <CheckOutlined /> : null),
      // },
    ];
  };

  const handleSaveModuleClick = () => {
    form.validateFields().then((values) => {
      setRightLoading(true);
      comEleModuleSave({
        ...values,
        mappings: selectedRowKeys,
      })
        .then((result) => {
          if (fn.checkResponse(result)) {
            const { moduleid, modulename, parentid, sort } = result.data || {};
            form.setFieldsValue({ moduleid }); // 新增后，需要绑定id 否则再次保存会新增一条
            message.success('保存成功', 0.5, () => {
              setSelectedTreeNode({
                id: moduleid,
                value: modulename,
                parentId: parentid,
                sort: sort,
                icon: (
                  <Tooltip title="模块">
                    <CreditCardOutlined />
                  </Tooltip>
                ),
              });
              getData();
              // if (moduleid !== selectedTreeNode?.id) {
              //   handleTreeNodeSelect(null, {
              //     selected: true, node: {
              //       id: moduleid,
              //       value: modulename,
              //       parentId: parentid,
              //       sort: sort,
              //       icon: <Tooltip title="模块"><CreditCardOutlined /></Tooltip>
              //     }
              //   });
              // }
            });
          }
        })
        .finally(() => setRightLoading(false));
    });
  };

  const handleRemoveModuleClick = () => {
    Modal.confirm({
      title: `确认删除【${selectedTreeNode?.value}】模块`,
      onOk: () => {
        comEleModuleRemove({ moduleid: selectedTreeNode?.id }).then((result) => {
          if (fn.checkResponse(result)) {
            message.success('删除成功', 0.5, () => {
              getData();
              form.resetFields();
              setSelectedTreeNode({ iselement: 0 });
            });
          }
        });
      },
    });
  };

  const handleAddModuleClick = () => {
    setIsAdd(true);
    form.resetFields();
    setSelectedRows([]);
    setSelectedRowKeys([]);
    form.setFieldsValue({ parentid: selectedTreeNode?.id });
    tableRef.current.reloadAndReset();
  };

  const handleDimensionChange = (value) => {
    setSelectedDimensionName(value);
    tableParamsRef.current = { ...tableParamsRef.current, dimensionname: value };
    tableRef.current.reloadAndReset();
  };

  const handleElementChange = (value) => {
    tableParamsRef.current = { ...tableParamsRef.current, elementname: value };
    tableRef.current.reloadAndReset();
  };

  const handleCheckChange = (checked) => {
    tableParamsRef.current = {
      ...tableParamsRef.current,
      moduleid: checked ? selectedTreeNode?.id : null,
    };
    tableRef.current.reloadAndReset();
  };

  const rowSelection = {
    columnWidth: 50,
    selectedRowKeys: selectedRowKeys,
    getCheckboxProps: (record) => ({
      // 如果已经有所属模块，并且模块不是当前的则不允许操作
      disabled:
        !!record.modulename && !!record.moduleid && selectedTreeNode?.id !== record.moduleid,
    }),
    // onChange: (keys, rows) => {
    //   setSelectedRowKeys([...selectedRowKeys, ...keys]);
    //   setSelectedRows(_.uniqWith([...selectedRows, ...rows], (a, b) => (a.dimid === b.dimid)));
    // },
    onSelect: (record, selected, rows) => {
      if (selected) {
        setSelectedRowKeys([...selectedRowKeys, record.dimid]);
        setSelectedRows(_.uniqWith([...selectedRows, record], (a, b) => a.dimid === b.dimid));
      } else {
        setSelectedRowKeys(selectedRowKeys.filter((key) => key !== record.dimid));
        setSelectedRows(selectedRows.filter((a) => a.dimid !== record.dimid));
      }
    },
    onSelectAll: (selected, rows, changeRows) => {
      if (selected) {
        setSelectedRowKeys([...selectedRowKeys, ...changeRows.map((a) => a.dimid)]);
        setSelectedRows(
          _.uniqWith([...selectedRows, ...changeRows], (a, b) => a.dimid === b.dimid),
        );
      } else {
        setSelectedRowKeys(
          selectedRowKeys.filter((key) => !changeRows.find((a) => a.dimid === key)),
        );
        setSelectedRows(selectedRows.filter((a) => !changeRows.find((b) => a.dimid === b.dimid)));
      }
    },
  };

  return (
    <Row gutter={[8, 16]} className={styles['com-elemnt-view']}>
      <Col span={6}>
        <Card bordered={false}>
          <EditTree
            style={{ height: 'calc(100vh - 155px)', overflowX: 'auto' }}
            showIcon
            selectedKeys={[selectedTreeNode?.id]}
            expandedKeys={[treeData?.[0]?.key]}
            onSelect={handleTreeNodeSelect}
            gData={treeData}
            loading={treeLoading}
            allowEdit={false}
            ref={treeRef}
          />
        </Card>
      </Col>
      <Col span={18}>
        <Spin spinning={rightLoading}>
          {Number(selectedTreeNode?.iselement) === 1 ? (
            <Row gutter={[0, 8]}>
              <Col span={24}>
                <Card
                  title={
                    <Space>
                      {selectedTreeNode?.icon}
                      <Typography.Text>{selectedTreeNode?.value}</Typography.Text>
                    </Space>
                  }
                  bordered={false}
                >
                  <Form form={form} scrollToFirstError {...CONST.formLayout}>
                    <Row>
                      <Col span={8}>
                        <HBFormItem label="要素" name="elementname" editable={false} />
                      </Col>
                      {/* <Col span={8}>
                        <HBFormItem label="要素名称" name="elementdesc" editable={false} />
                      </Col> */}
                      <Col span={8}>
                        <HBFormItem label="所属维度" name="dimensionname" editable={false} />
                      </Col>
                      {/* <Col span={8}>
                        <HBFormItem label="所属维度名" name="dimensiondesc" editable={false} />
                      </Col> */}
                      <Col span={8}>
                        <HBFormItem label="引用系统" name="srcsys" editable={false} />
                      </Col>
                      <Col span={24}>
                        <HBFormItem
                          {...CONST.formFullLayout}
                          label="用途"
                          name="elementpurp"
                          editable={false}
                          renderValue={(value) => (
                            <div
                              style={{
                                whiteSpace: 'pre',
                                wordBreak: 'break-word',
                                marginTop: '4px',
                              }}
                            >
                              {value}
                            </div>
                          )}
                        />
                      </Col>
                    </Row>
                  </Form>
                </Card>
              </Col>
              <Col span={24}>
                <Card bordered={false}>
                  <Tabs tabBarStyle={{ padding: '0 16px' }} tabBarGutter={16}>
                    <Tabs.TabPane tab="所属功能" key="func">
                      <Table
                        size="small"
                        columns={[
                          { title: '功能名', dataIndex: 'funcname' },
                          {
                            title: '功能类型',
                            dataIndex: 'functype',
                            render: (text) => ['表单', '表格'][Number(text)],
                          },
                          {
                            title: '展示类型',
                            dataIndex: 'displaytype',
                            render: (text) => ['视图', '编辑'][Number(text)],
                          },
                        ]}
                        dataSource={funcData}
                        pagination={false}
                        scroll={{ y: 450 }}
                      />
                    </Tabs.TabPane>
                    <Tabs.TabPane tab="权限信息" key="per">
                      <Table
                        size="small"
                        columns={[
                          {
                            title: '角色名',
                            dataIndex: 'rolename',
                            render: (text, record) => (
                              <PopverRoleMember data={record}>{text}</PopverRoleMember>
                            ),
                          },
                          {
                            title: '权限',
                            dataIndex: 'permission',
                            children: [
                              {
                                title: '查看',
                                dataIndex: 'viewpermission',
                                render: (text) => (
                                  <Switch
                                    size="small"
                                    key={text}
                                    disabled
                                    checked={Number(text) === 1}
                                  />
                                ),
                              },
                              {
                                title: '编辑',
                                dataIndex: 'editpermission',
                                render: (text) => (
                                  <Switch
                                    size="small"
                                    key={text}
                                    disabled
                                    checked={Number(text) === 1}
                                  />
                                ),
                              },
                              {
                                title: '审核',
                                dataIndex: 'reviewpermission',
                                render: (text) => (
                                  <Switch
                                    size="small"
                                    key={text}
                                    disabled
                                    checked={Number(text) === 1}
                                  />
                                ),
                              },
                            ],
                          },
                        ]}
                        dataSource={roleData}
                        pagination={false}
                        scroll={{ y: 450 }}
                      />
                    </Tabs.TabPane>
                    <Tabs.TabPane tab="数据信息" key="data">
                      <FetchTable
                        size="small"
                        showTools={false}
                        ref={curEleTableRef}
                        getList={getCurElementList}
                        columns={Object.keys(curEleData?.desc ?? {}).map((key) => ({
                          dataIndex: key,
                          title: curEleData?.desc[key],
                        }))}
                        scroll={{ y: 'calc(100vh - 450px)' }}
                        autoHeight={{ blankHeight: 230 }}
                      />
                    </Tabs.TabPane>
                  </Tabs>
                </Card>
              </Col>
            </Row>
          ) : (
            <Row gutter={[0, 8]}>
              <Col span={24}>
                <Card bordered={false} bodyStyle={{ textAlign: 'right' }}>
                  <Typography.Text style={{ lineHeight: '32px', float: 'left' }} strong>
                    {isAdd ? (
                      <Tag color="#108ee9" style={{ color: '#fff' }}>
                        新增
                      </Tag>
                    ) : (
                      <Space>
                        {selectedTreeNode?.icon}
                        <Typography.Text>{selectedTreeNode?.value}</Typography.Text>
                      </Space>
                    )}
                  </Typography.Text>
                  <Space>
                    <Button type="primary" onClick={handleAddModuleClick}>
                      新增模块
                    </Button>
                    <Button
                      type="primary"
                      disabled={isAdd}
                      danger
                      onClick={handleRemoveModuleClick}
                    >
                      删除
                    </Button>
                    <Button type="primary" onClick={handleSaveModuleClick}>
                      保存
                    </Button>
                  </Space>
                </Card>
              </Col>
              <Col span={24}>
                <Card bordered={false}>
                  <Form form={form} scrollToFirstError {...CONST.formLayout}>
                    <Row>
                      <Col span={0}>
                        <FormItem name="moduleid">
                          <Input />
                        </FormItem>
                      </Col>
                      <Col span={0}>
                        <FormItem name="parentid">
                          <Input />
                        </FormItem>
                      </Col>
                      <Col span={8}>
                        <FormItem
                          label="模块名"
                          name="modulename"
                          rules={[
                            {
                              required: true,
                              message: '请输入排序',
                            },
                          ]}
                        >
                          <Input placeholder="请输入模块名" />
                        </FormItem>
                      </Col>
                      <Col span={8}>
                        <FormItem
                          label="排序"
                          name="sort"
                          rules={[
                            {
                              required: true,
                              message: '请输入排序',
                            },
                          ]}
                        >
                          <InputNumber min={0} style={{ width: '100%' }} placeholder="请输入排序" />
                        </FormItem>
                      </Col>
                      <Col span={0}>
                        <Button htmlType="submit" type="primary" onClick={handleSaveModuleClick}>
                          保存
                        </Button>
                      </Col>
                    </Row>
                  </Form>
                </Card>
              </Col>
              <Col span={24}>
                <Card
                  title="模块要素"
                  bordered={false}
                  extra={
                    selectedTreeNode?.id && (
                      <Space key={selectedTreeNode?.id}>
                        <Checkbox
                          onChange={({ target: { checked } }) => handleCheckChange(checked)}
                        >
                          仅当前模块
                        </Checkbox>
                        <SearchSelect
                          getData={comEleDimensionQuery}
                          style={{ width: '160px' }}
                          placeholder="请选择维度搜索"
                          onChange={handleDimensionChange}
                          onSearch={null}
                        >
                          {(item) => (
                            <SearchSelect.Option
                              key={item.dimensionname}
                              value={item.dimensionname}
                            >
                              {item.dimensiondesc}[{item.dimensionname}]
                            </SearchSelect.Option>
                          )}
                        </SearchSelect>
                        <SearchSelect
                          key={selectedDimensionName}
                          mode="multiple"
                          maxTagCount={1}
                          maxTagTextLength={3}
                          onChange={handleElementChange}
                          getData={comEleElementQuery}
                          placeholder="请选择要素搜索"
                          getParams={(value) => ({
                            dimensionname: selectedDimensionName,
                            keyword: value,
                          })}
                          onSearch={null}
                          optionFilterProp="children"
                        >
                          {(item) => (
                            <SearchSelect.Option
                              key={`${item.elementname}-${item.dimensionname}`}
                              value={item.elementname}
                            >
                              {item.elementdesc}[{item.elementname}]
                            </SearchSelect.Option>
                          )}
                        </SearchSelect>
                      </Space>
                    )
                  }
                >
                  {/* <Table
                  size="small"
                  columns={[
                    { title: '要素', dataIndex: 'elementname', width: 100, render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph> },
                    { title: '要素名', dataIndex: 'elementdesc', width: 100 },
                    { title: '维度', dataIndex: 'dimensionname', width: 100, render: (text) => <Typography.Paragraph copyable>{text}</Typography.Paragraph> },
                    { title: '维度名', dataIndex: 'dimensiondesc', width: 100 },
                    { title: '是否主键', dataIndex: 'ispk', width: 50, render: (text) => text === '1' ? <CheckOutlined /> : null },
                    {
                      title: '权限', dataIndex: 'permission', children: [
                        { title: '查看', dataIndex: 'viewpermission', width: 60, align: 'center', render: (text, record) => <Switch size="small" checked={Number(text) === 1} onChange={(checked) => handlePermissionChange(checked, 'view', record)} /> },
                        { title: '编辑', dataIndex: 'editpermission', width: 60, align: 'center', render: (text, record) => <Switch size="small" checked={Number(text) === 1} onChange={(checked) => handlePermissionChange(checked, 'edit', record)} /> },
                        { title: '审核', dataIndex: 'reviewpermission', width: 60, align: 'center', render: (text, record) => <Switch size="small" checked={Number(text) === 1} onChange={(checked) => handlePermissionChange(checked, 'review', record)} /> },
                      ]
                    }
                  ]}
                  dataSource={elementData}
                  rowKey="dimid"
                  scroll={{ y: 300 }}
                /> */}
                  <FetchTable
                    rowSelection={rowSelection}
                    key={selectedTreeNode?.id}
                    size="small"
                    ref={tableRef}
                    showTools={false}
                    getList={getList}
                    columns={getColumns()}
                    rowKey="dimid"
                    scroll={{ y: `calc(100vh - 360px)` }}
                    autoHeight={200}
                  />
                </Card>
              </Col>
            </Row>
          )}
        </Spin>
      </Col>
    </Row>
  );
};

export default ElementsView;
