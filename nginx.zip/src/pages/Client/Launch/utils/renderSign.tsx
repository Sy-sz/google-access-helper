import React from 'react';
import { SchemaMarkupField as Field } from 'formily-antd';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { FormMegaLayout } from '@formily/antd-components';
import {
  useTreeDepartment,
  useTreeUser,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import store from '@/store';

interface RenderSignProps {
  title?: string;
  name: string;
  display: boolean;
  editable: boolean;
  upDown?: 'up' | 'down';
  labelWidth?: number;

  /** 是否申请盖章 */
  isseal?: {
    show: boolean;
    title: string;
  };
  /** 是否显示合规会签人 */
  showAuditcountersignusers?: boolean;
  /** 会签 前面插入一些其他字段 */
  prefix?: any[];

  /** 是否渲染成独立的卡片模块，默认是 */
  independentModule?: boolean;

  /** 是否显示 领导同时审批 */
  leaderapprove: boolean;
}

/**
 * 渲染会签模块
 */
export function renderSign(props: RenderSignProps) {
  const {
    title,
    name,
    display,
    editable,
    labelWidth = 140,
    upDown,
    isseal,
    showAuditcountersignusers = true,
    prefix,
    independentModule = true,
    leaderapprove,
  } = props;
  const orgDispatcher = store.useModelDispatchers('org');

  const deptMulProps = useTreeDepartment({
    multiple: true,
    type: undefined,
    tokenSeparators: [';'],
  });
  const userMulProps = useTreeUser({
    multiple: true,
    tokenSeparators: [';'],
  });
  const useAuditcountersignusers = useTreeUser({
    multiple: true,
    tokenSeparators: [';'],
    request: async () =>
      // @ts-ignore
      orgDispatcher.usersByDept().then((result) => {
        if (result && Array.isArray(result.data)) {
          result.data = result.data.filter(
            (a) => a.departmentId === 'FF10BB6C-1F1F-4E85-B05F-1DBD46939B5C',
          );
        }
        return result;
      }),
  });

  const mainContent = (
    <>
      {prefix &&
        prefix.map((fieldProps) => (
          <Field
            key={fieldProps.name}
            editable={editable}
            {...fieldProps}
            x-mega-props={{ span: 4, labelWidth }}
          />
        ))}

      <Field type="object" name={name} display={display} x-mega-props={{ span: 4, labelWidth }}>
        {isseal?.show && (
          <Field
            name="isseal"
            type="radio"
            required
            title={
              <span>
                {isseal?.title && (
                  <>
                    {isseal?.title}
                    <br />
                  </>
                )}
                是否申请盖章
              </span>
            }
            enum={[
              { label: '是', value: '1' },
              { label: '否', value: '0' },
            ]}
            default="1"
            editable={editable}
          />
        )}

        <Field
          name="countersigndeparts"
          title="会签部门"
          type="tree-select"
          editable={editable}
          x-mega-props={{ span: 4, labelWidth }}
          x-component-props={{
            ...deptMulProps,
            placeholder: `请选择会签部门`,
          }}
        />
        <Field
          name="countersignusers"
          title="会签人"
          type="tree-select"
          editable={editable}
          x-mega-props={{ span: 4, labelWidth }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择会签人`,
          }}
        />
        {leaderapprove && (
          <>
            <Field
              name="leaderapprove"
              title="领导同时审批"
              type="radio"
              enum={[
                { label: '是', value: '1' },
                { label: '否', value: '0' },
              ]}
              default="0"
              editable={editable}
              x-mega-props={{ span: 4 }}
            />

            <Field
              name="leader"
              title="领导"
              type="checkbox"
              editable={editable}
              x-mega-props={{ span: 4 }}
            />
            <Field
              name="leaderrank"
              title="领导审批顺序"
              type="string"
              editable={false}
              x-mega-props={{ span: 4 }}
            />
          </>
        )}
        <Field
          name="noticeusers"
          title="知会人"
          type="tree-select"
          editable={editable}
          x-mega-props={{ span: 4, labelWidth }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择知会人`,
          }}
        />
        {showAuditcountersignusers && (
          <Field
            name="auditcountersignusers"
            title="合规会签人员"
            type="tree-select"
            editable={editable}
            x-mega-props={{ span: 4, labelWidth }}
            x-component-props={{
              ...useAuditcountersignusers,
              placeholder: `请选择合规会签人`,
            }}
          />
        )}
      </Field>
    </>
  );

  if (!independentModule) {
    return mainContent;
  }

  return (
    <BaseFormCard
      name={`${name}Card`}
      title={title}
      megaLayout={false}
      display={display}
      upDown={upDown}
    >
      <FormMegaLayout labelWidth={labelWidth} grid autoRow full columns={1}>
        {mainContent}
      </FormMegaLayout>
    </BaseFormCard>
  );
}
