import { forOwn, isEmpty } from 'lodash';
import { leaderSeparator } from './index';

// 需要转换的字段
const signKey = ['countersigndeparts', 'countersignusers', 'noticeusers', 'auditcountersignusers'];

type ToType = 'toArray' | 'toString';

/**
 * 会签人、会签部门、知会人、合规会签人员，如果是数组，转换成字符串；如果是字符串，转换成数组
 * @param dataObj 会签模块数据
 * @returns 转换后的新数据
 */
export function toggleSignType(dataObj, toType?: ToType, values?: Record<string, any>) {
  if (!dataObj) {
    return undefined;
  }

  const newDataObj = {};
  forOwn(dataObj, (value, key) => {
    // 领导同时审批提交时，leaderrank也要传，值用leader的
    if (key === 'leaderapprove' && value === '1' && dataObj.leader?.length) {
      dataObj['leaderrank'] = dataObj.leader.map((e) => values.leaderMap[e]).join(leaderSeparator);
    }

    // 设置 leaderrank
    if (key === 'leaderrank' && value) {
      // leader有值，说明是点的提交
      if (dataObj.leader?.length) {
        newDataObj[key] = dataObj[key]
          .split(leaderSeparator)
          .map((e) => values.leaderMap[e] || e)
          .join();
        return;
      }

      // 能到这里，说明是页面初始化，leaderrank是后端返回的, 是逗号拼接的，这里转换一下；并设置leader的值
      newDataObj[key] = value.replaceAll(',', leaderSeparator);
      newDataObj['leader'] = value.split(',');
      return;
    }

    if (signKey.includes(key)) {
      if (typeof value === 'string') {
        newDataObj[key] = toType === 'toString' ? value : value.split(',');
      } else if (Array.isArray(value)) {
        newDataObj[key] = toType === 'toArray' ? value : value.join(',');
      }
      return;
    }

    newDataObj[key] = value;
  });
  return newDataObj;
}

/** 批量调用 toggleSignType(会签中字符串和数组互转) */
export const batchToggleSignType = (
  values: Record<string, any>,
  keyList: string[],
  toType: ToType,
) => {
  if (isEmpty(values) || !keyList?.length) {
    return {};
  }

  return keyList.reduce((acc, curr) => {
    acc[curr] = toggleSignType(values[curr], toType, values);
    return acc;
  }, {});
};
