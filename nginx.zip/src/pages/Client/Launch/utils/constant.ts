export const agencyNoticetypeid = {
  增加一级交易商: '6820730ae0734361945df95fdbafde78',
  股票换购: '6820730ae0734361945df95fdbafde78',
  费率优惠活动: '8fa042e51001470096746124f16e1506',
  '代销上线产品(新增代销机构)': '6820730ae0734361945df95fdbafde78',
  代销上线产品通知: '000608FE1DDFAA0D9E900000081F455A',
};

export const leaderSeparator = '-->';
