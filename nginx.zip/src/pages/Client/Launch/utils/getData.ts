import store from '@/store';
import { useTreeSelect } from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';

/** 查全部基金 */
export const getFundFullList = (options) => {
  const dispatcher = store.useModelDispatchers('pdtSystem');
  return useTreeSelect({
    request: ({ state = {} }: any) => {
      return async () => {
        const params: any = {
          keyword: state.value || '',
          fundperiod: options.fundperiod || null,
          page: 1,
          size: 1000,
        };
        const res: any = await dispatcher.fundFullList(params);
        if (Array.isArray(res.data)) {
          return res.data.map((a) => ({
            label: `${a.fundshortname || a.fundname}[${a.fundcode}]`,
            value: a.fundcode,
          }));
        }
        return [];
      };
    },
    ...options,
  });
};
