import { message } from 'antd';
import { type createAsyncFormActions } from 'formily-antd';
import { isEmpty } from 'lodash';

type StringMap = Record<string, any>;
interface ValueListItemType {
  filetype: string;
  filekey: string;
  datekey: string;
  filename?: string;
  filedate?: string;
}
type validateSignType = (params: {
  values: StringMap;
  signMap: StringMap;
  elementCode: string;
  formActions: ReturnType<typeof createAsyncFormActions>;
}) => boolean;

/** 批量格式化文件参数(formily组件给文件包了一层参数，接口只要response里的内容) */
export const batchFormatFile = (values: StringMap, fileNames: string[]) => {
  return fileNames.reduce((acc, name) => {
    if (Array.isArray(values[name]) && values[name].length) {
      acc[name] = values[name].map((item) => item.response || item);
    }
    return acc;
  }, {} as StringMap);
};

/** 把平铺在外层的文件，日期字段，转成数组(页面进来时用) */
export const convertFileFlatToArray = (
  values: StringMap,
  fileFlatToArrayMap: Record<string, ValueListItemType[]>,
) => {
  return Object.entries(fileFlatToArrayMap).reduce((acc, [key, valueList]) => {
    const newValue = valueList.map((item) => {
      const newItem: ValueListItemType = { ...item };
      newItem.filename = values[item.filekey];
      newItem.filedate = values[item.datekey];
      return newItem;
    });
    acc[key] = newValue;
    return acc;
  }, {} as StringMap);
};

/** 把数组中的文件、日期字段平铺到最外层(提交时用) */
export const convertFileArrayToFlat = (
  values: StringMap,
  fileFlatToArrayMap: Record<string, ValueListItemType[]>,
) => {
  const result = {};
  Object.keys(fileFlatToArrayMap).forEach((key) => {
    values[key].forEach((item) => {
      result[item.filekey] = batchFormatFile({ anyName: item.filename }, ['anyName']).anyName;
      result[item.datekey] = item.filedate;
    });
  });
  return result;
};

/** 会签人员和会签部门必填一项 */
export const validateSign: validateSignType = ({ values, signMap, elementCode, formActions }) => {
  [values, signMap, elementCode, formActions].forEach((item) => {
    if (isEmpty(item)) {
      console.error('validateSign缺少参数');
    }
  });

  let pass = true;
  for (const [signName, code] of Object.entries(signMap)) {
    if (elementCode === code) {
      const { visible } = (formActions.getFieldState(signName) || {}) as any;
      const { countersigndeparts, countersignusers } = values[signName] || {};
      if (visible && !countersigndeparts && !countersignusers) {
        message.error('请选择会签人或会签部门');
        pass = false;
        break;
      }
    }
  }
  return pass;
};
