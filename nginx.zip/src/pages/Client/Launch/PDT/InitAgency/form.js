import React from 'react';
import { Field } from 'formily-antd';
import { FormMegaLayout } from '@formily/antd-components';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import { Button, message } from 'antd';
import {
  useMegaLayoutProps,
  useDictList,
  useTreeDepartment,
  useTreeUser,
  useBpmShareList,
  // useAgencyLists,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import Download from '@chinahorm/web-components/es/components/Download';
import { baseURL } from '@/setting';

function Form(props) {
  const {
    context: { getProcess },
    formEffects: { formActions },
  } = props;
  const { elementCode, readOnlyFlag, firstTokenFlag, elementId, endElementId } = getProcess() || {};

  const agencyEditable =
    ['10', '20', '21', '30', '31', '12', null].includes(elementCode) && !readOnlyFlag;

  const comProps = {
    size: 'middle',
  };
  const megaProps = {
    labelWidth: 110,
    responsive: { lg: 4, m: 2, s: 1 },
    contextResponsive: { lg: 4, m: 2, s: 1 },
  };

  const megaLayoutProps = useMegaLayoutProps(megaProps);

  const deptMulProps = useTreeDepartment({
    multiple: true,
    type: undefined,
    tokenSeparators: [';'],
  });
  const userMulProps = useTreeUser({
    multiple: true,
    tokenSeparators: [';'],
  });
  // ETF基金代销类型
  // 95729072-e628-4233-ba49-d9eed06c8a8f
  const commissionTypeRequest = useDictList({ id: '9f91a92078c344969e0df4580b373876' });
  const endFlag = elementId === endElementId;
  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard
        title="会签信息"
        megaProps={megaProps}
        visible={
          (!['10', '20', '21', '30', '31', '40', '50', '12'].includes(elementCode) &&
            !firstTokenFlag) ||
          endFlag
        }
      >
        <Field
          name="remark"
          title="备注"
          type="textarea"
          visible={
            (!['10', '20', '21', '30', '31', '40', '50', '12'].includes(elementCode) &&
              !firstTokenFlag) ||
            endFlag
          }
          editable={['60'].includes(elementCode)}
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="countersigndeparts"
          title="会签部门"
          type="tree-select"
          visible={
            (!['10', '20', '21', '30', '31', '40', '50', '12'].includes(elementCode) &&
              !firstTokenFlag) ||
            endFlag
          }
          editable={['60'].includes(elementCode)}
          required
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...comProps,
            ...deptMulProps,
            placeholder: `请选择会签部门`,
          }}
        />
        <Field
          name="countersignusers"
          title="会签人"
          type="tree-select"
          visible={
            (!['10', '20', '21', '30', '31', '40', '50', '12'].includes(elementCode) &&
              !firstTokenFlag) ||
            endFlag
          }
          editable={['60'].includes(elementCode)}
          required
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择会签人`,
          }}
        />
        <Field
          name="noticeusers"
          title="知会人"
          type="tree-select"
          visible={
            (!['10', '20', '21', '30', '31', '40', '50', '12'].includes(elementCode) &&
              !firstTokenFlag) ||
            endFlag
          }
          editable={['60'].includes(elementCode)}
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择知会人`,
          }}
        />
      </BasicFormCard>

      <BasicFormCard title="代销机构信息" megaLayout={false}>
        <Field
          editable={agencyEditable}
          name="agencylist"
          minItems={0}
          maxItems={10}
          type="array"
          default={[]}
          x-component="bpm-array-card"
          x-component-props={{
            key: 'organinfoid',
            title: '代销机构',
            titlefield: 'companyname',
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderRemove: '{{renderRemove}}',
            renderAddition: () => (
              <Button type="primary" size="small">
                新增代销机构
              </Button>
            ),
          }}
        >
          <Field type="object">
            <FormMegaLayout {...megaLayoutProps}>
              <Field
                name="companycode"
                title="机构编号"
                type="string"
                required
                x-component-props={{ placeholder: '请输入机构编号' }}
                editable={agencyEditable}
              />
              <Field
                name="companyname"
                title="机构名称"
                type="string"
                required
                x-component-props={{ placeholder: '请输入机构名称' }}
                editable={agencyEditable}
                x-rules={[
                  {
                    validator: (value) => {
                      const { getFieldValue } = formActions;
                      const agencylist = getFieldValue('agencylist') || [];
                      if (agencylist.filter((a) => a.companyname === value).length > 1) {
                        return '机构名称重复';
                      }
                      return '';
                    },
                  },
                ]}
              />
              <Field
                name="partysimname"
                title="机构简称"
                type="string"
                required
                x-component-props={{ placeholder: '请输入机构简称' }}
                editable={agencyEditable}
                x-rules={[
                  {
                    validator: (value) => {
                      const { getFieldValue } = formActions;
                      const agencylist = getFieldValue('agencylist') || [];
                      if (agencylist.filter((a) => a.partysimname === value).length > 1) {
                        return '机构简称重复';
                      }
                      return '';
                    },
                  },
                ]}
              />
              <Field
                name="englishname"
                title="英文名称"
                type="string"
                x-component-props={{ placeholder: '请输入英文名称' }}
                editable={agencyEditable}
              />
              <Field
                name="companytype"
                title="机构类型"
                type="tree-select"
                required
                x-component-props={{
                  placeholder: '请输入机构类型',
                  optionFilterProp: 'label',
                  ...useDictList({ id: 'f993cf7a384343f281e6cb6ad9ed6173' }),
                }}
                editable={agencyEditable}
              />
              <Field
                name="lawman"
                title="法人代表"
                type="string"
                x-component-props={{ placeholder: '请输入法人代表' }}
                editable={agencyEditable}
              />
              <Field
                name="regaddress"
                title="注册地址"
                type="string"
                required
                x-component-props={{ placeholder: '请输入注册地址' }}
                editable={agencyEditable}
              />
              <Field
                name="regcapital"
                title="注册金额"
                type="number"
                x-component-props={{ placeholder: '请输入注册金额' }}
                editable={agencyEditable}
              />
              <Field
                name="contactor"
                title="联系人"
                type="string"
                x-component-props={{ placeholder: '请输入联系人' }}
                editable={agencyEditable}
              />
              <Field
                name="duty"
                title="职务"
                type="string"
                x-component-props={{ placeholder: '请输入职务' }}
                editable={agencyEditable}
              />
              <Field
                name="mobileno"
                title="手机号码"
                type="string"
                x-component-props={{ placeholder: '请输入手机号码' }}
                editable={agencyEditable}
              />
              <Field
                name="phone"
                title="联系电话"
                type="string"
                x-component-props={{ placeholder: '请输入联系电话' }}
                editable={agencyEditable}
              />
              <Field
                name="address"
                title="联系地址"
                type="string"
                x-component-props={{ placeholder: '请输入联系地址' }}
                editable={agencyEditable}
              />
              <Field
                name="email"
                title="邮箱地址"
                type="string"
                x-component-props={{ placeholder: '请输入邮箱地址' }}
                editable={agencyEditable}
              />
              <Field
                name="fax"
                title="传真"
                type="string"
                x-component-props={{ placeholder: '请输入传真' }}
                editable={agencyEditable}
              />
              <Field
                name="hotline"
                title="客服热线"
                type="string"
                required
                x-component-props={{ placeholder: '请输入客服热线' }}
                editable={agencyEditable}
              />
              <Field
                name="website"
                title="公司网址"
                type="string"
                required
                x-component-props={{ placeholder: '请输入公司网址' }}
                editable={agencyEditable}
              />
              <Field
                name="foundtime"
                title="成立时间"
                type="date"
                x-component-props={{ placeholder: '请输入成立时间', format: 'YYYY-MM-DD' }}
                editable={agencyEditable}
              />
              <Field
                name="issigned"
                title="签署年度框架"
                type="radio"
                default="0"
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否签署年度框架`,
                }}
                editable={agencyEditable}
              />
              <Field
                name="ispdtparams"
                title="有独立产品参数表"
                type="radio"
                default="0"
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否有独立产品参数表`,
                }}
                editable={agencyEditable}
              />
            </FormMegaLayout>
          </Field>
        </Field>
      </BasicFormCard>

      <BasicFormCard title="基金信息" megaLayout={megaProps}>
        <Field visible={false} name="fundinfo" type="string" />
        <Field
          name="fund"
          title="基金"
          type="tree-select"
          required
          x-mega-props={{
            span: 4,
          }}
          x-component-props={{
            filterOption: (value, option) =>
              option.data &&
              ((option.data.fundcode || '').includes(value) ||
                (option.data.fundname || '').includes(value) ||
                (option.data.businesstype || '').includes(value)),
            style: { maxWidth: 500 },
            placeholder: '请选择基金名称',
            ...useBpmShareList(),
          }}
        />
        <Field
          name="agency"
          title="代销机构"
          type="tree-select"
          editable={agencyEditable}
          visible={agencyEditable}
          x-mega-props={{
            addonAfter: '{{addonAfterRender()}}',
          }}
          x-component-props={{
            filterOption: (value, option) =>
              option.data &&
              ((option.data.companyname || '').includes(value) ||
                (option.data.partysimname || '').includes(value)),
            style: { maxWidth: 500 },
            tree: false,
            // placeholder: '请选择机构名称',
            // ...useAgencyLists(),
            maxTagCount: 0,
            multiple: true,
            allowClear: true,
            dropdownMatchSelectWidth: false,
            tokenSeparators: [','],
          }}
        />
        <Field
          // title='导入代销机构'
          name="noticefiles"
          type="bpm-upload-list"
          editable={agencyEditable}
          visible={agencyEditable}
          description={firstTokenFlag && '选择文件前，请先选择基金'}
          x-component-props={{
            onSuccess: '{{fileSuccess("noticefile")}}',
            onDel: () => {},
            accept: '.xls,.xlsx',
            multiple: false,
            isFsfund: true,
            text: '批量导入代销机构',
          }}
          x-mega-props={{
            addonAfter: (
              <Download
                fileName="agencyuploadmodel.xlsx"
                url={`${baseURL}/template/dossier/agencyuploadmodel.xlsx`}
              >
                <Button type="link">下载模板</Button>
              </Download>
            ),
          }}
        />
        <Field
          name="itemlist"
          type="array"
          editable={agencyEditable}
          x-component="form-table"
          x-component-props={{
            operationsWidth: 80,
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            onSelect: '{{changeAgencyTableOnSelect}}',
            renderExtendButtons: '{{renderExtendButtons}}',
            onRemove: '{{changeAgencyTableRemove}}',
            visibleColumns: ['agencytype'],
          }}
          x-mega-props={{ span: 4 }}
        >
          <Field type="object">
            <Field
              name="fundcode"
              title="基金代码"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="fundname"
              title="基金名称"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companyname"
              title="机构名称"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companytype"
              title="机构类型"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="changetype"
              title="类型"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="agencytype"
              title="代销类型"
              type="tree-select"
              required
              // editable={true} 设置后，动态设置不生效，故取消
              x-component-props={{
                ...commissionTypeRequest,
                tree: false,
                dropdownMatchSelectWidth: false,
              }}
            />
            <Field
              name="agencydate"
              title="机构上线日期"
              type="date"
              required
              x-component-props={{}}
            />
            <Field
              name="isexist"
              title="代销机构是否存在"
              type="string"
              editable={false}
              x-component-props={{
                renderLabel: (text, record) =>
                  Number(text) === 0 ? (
                    <Button
                      type="link"
                      style={{ fontSize: 12, paddingLeft: 0 }}
                      onClick={() => {
                        const { getFieldValue, setFieldValue } = formActions;
                        const agencyList = getFieldValue('agencylist') || [];
                        if (agencyList.find((a) => a.companyname === record.companyname)) {
                          message.info('代销机构已添加');
                          return;
                        }

                        setFieldValue('agencylist', [
                          ...agencyList,
                          { organinfoid: record.organinfoid, companyname: record.companyname },
                        ]);
                        setFieldValue(
                          'itemlist',
                          (getFieldValue('itemlist') || []).map((a) => {
                            if (a.companyname === record.companyname) {
                              a.isexist = '已添加';
                            }
                            return a;
                          }),
                        );
                      }}
                    >
                      <span style={{ color: 'red' }}>代销机构不存在</span>，点击添加
                    </Button>
                  ) : Number(text) === 1 ? (
                    ' '
                  ) : (
                    text || ''
                  ),
              }}
            />
          </Field>
        </Field>
      </BasicFormCard>
      <BasicFormCard
        title="公告信息"
        megaLayout={megaProps}
        visible={(['90'].includes(elementCode) && !firstTokenFlag) || endFlag}
      >
        <Field
          name="getAgencyInformationNotice"
          type="button"
          // visible={false}
          editable={['90'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            text: '生成增加代销机构信息',
            onClick: '{{getAgencyInformationNotice}}',
          }}
        />

        <Field
          title={false}
          name="detaillist"
          type="bpm-upload-list"
          editable={false}
          // editable={ ["90"].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            onSuccess: '{{fileNoticeSuccess("detaillist")}}',
            onDel: '{{fileDel("detaillist")}}',
            accept: '.doc,.docx',
            multiple: false,
            isFsfund: true,
          }}
          x-mega-props={{ span: 2 }}
        />

        <Field
          name="getListedNotice"
          type="button"
          editable={['90'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            text: '生成上市公告书',
            onClick: '{{getListedNotice}}',
          }}
        />
        <Field
          title={false}
          name="annlist"
          type="bpm-upload-list"
          // visible={ (["90"].includes(elementCode)) && !firstTokenFlag}
          // editable={ (["90"].includes(elementCode)) && !readOnlyFlag}
          x-component-props={{
            onSuccess: '{{fileNoticeSuccess("annlist")}}',
            onDel: '{{fileDel("annlist")}}',
            accept: '.doc,.docx',
            multiple: false,
            isFsfund: true,
          }}
          x-mega-props={{ span: 2 }}
        />
      </BasicFormCard>
    </>
  );
}

export default Form;
