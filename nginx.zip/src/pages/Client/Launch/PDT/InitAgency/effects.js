import React from 'react';
import { FormEffectHooks } from 'formily-antd';
import { uuid } from '@/utils';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import { Button } from 'antd';
import { ProFormDatePicker, ModalForm } from '@ant-design/pro-form';
import { DeleteOutlined } from '@ant-design/icons';
import { isArray } from 'lodash';
import { useLinkageUtils } from '@chinahorm/web-components/es/components/ProcessLayout/hooks';
const { onFieldValueChange$, onFieldInputChange$, onFieldInit$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    this.managerid = null;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag, readOnlyFlag } = getProcess() || {};
    this.managerid = null;
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
    this.agencyList = [];
  }

  createFormEffects() {
    this.changeAgencyActionRef = React.useRef();
    const { getProcess } = this.props.context;
    const { firstTokenFlag, readOnlyFlag } = getProcess() || {};
    return ($, { setFieldState, setFieldValue, getFieldValue }) => {
      const linkage = useLinkageUtils();

      if (this.firstTokenFlag) {
        onFieldInit$('*(countersigndeparts,countersignusers,noticeusers)').subscribe(
          ({ value, name }) => {
            setFieldValue(name, value ? value.split(';') : value);
          },
        );
      }

      onFieldInit$('itemlist').subscribe(({ name }) => {
        setFieldValue(name, this.formData.itemlist || []);
      });

      onFieldValueChange$('agencylist').subscribe(async (state) => {
        let agencyList = await this.getAgencyData();
        agencyList = [
          ...(getFieldValue('agencylist') || [])
            .filter((a) => a.companyname && a.partysimname)
            .map((a) => ({
              label: (
                <span>
                  {a.companyname} <b style={{ float: 'right', color: 'red', fontSize: 12 }}>新</b>
                </span>
              ),
              value: a.organinfoid,
              ...a,
            })),
          ...agencyList.map((a) => ({
            label: a.companyname,
            value: a.organinfoid,
            ...a,
          })),
        ];
        setFieldState('agency', (state) => {
          state.props['x-component-props'] = {
            ...state.props['x-component-props'],
            treeData: agencyList,
          };
        });
      });

      onFieldValueChange$(
        '*(agencylist.*.companyname,agencylist.*.companytype,agencylist.*.partysimname,agencylist.*.hotline,agencylist.*.website)',
      ).subscribe(async ({ name }) => {
        const arr = (name || '').split('.');
        if (name.length > 2) {
          const agencyList = getFieldValue('agencylist') || [];
          const itemList = getFieldValue('itemlist') || [];
          const agency = agencyList[Number(arr[1])];
          if (agency && itemList.find((a) => a.organinfoid === agency.organinfoid)) {
            setFieldValue(
              'itemlist',
              itemList.map((a) => {
                if (a.organinfoid === agency.organinfoid) {
                  a[arr[2]] = agency[arr[2]];
                }
                return a;
              }),
            );
          }

          let newAgencyList = await this.getAgencyData();
          newAgencyList = [
            ...(getFieldValue('agencylist') || [])
              .filter((a) => a.companyname && a.partysimname)
              .map((a) => ({
                label: (
                  <span>
                    {a.companyname} <b style={{ float: 'right', color: 'red', fontSize: 12 }}>新</b>
                  </span>
                ),
                value: a.organinfoid,
                ...a,
              })),
            ...newAgencyList.map((a) => ({
              label: a.companyname,
              value: a.organinfoid,
              ...a,
            })),
          ];
          setFieldState('agency', (state) => {
            state.props['x-component-props'] = {
              ...state.props['x-component-props'],
              treeData: newAgencyList,
            };
          });
        }
      });

      onFieldValueChange$('fund').subscribe(async ({ value, values }) => {
        if (!values || !isArray(values) || values.length < 2 || this.formData.fund === value) {
          return;
        }
        setFieldValue('fundinfo', JSON.stringify(values[1].data));
        this.antMessage.loading('基金代销机构数据加载中...', 0);
        linkage.componentLoading('itemlist');
        this.dispatcher
          .periodList({
            // 数据请求
            fundid: values[1].data.fundid,
          })
          .then((res) => {
            const { setFieldValue } = this.formActions;
            let itemList = [];
            const fund = values && values[1] ? values[1].data : JSON.parse(this.formData.fundinfo);
            let dataList = res.data;
            let newArrlist = [];
            dataList.forEach((b) => {
              newArrlist.push({
                id: uuid(),
                organinfoid: b.organinfoid,
                companytype: b.companytype,
                companyname: b.companyname,
                fundcode: fund.fundcode,
                fundname: fund.fundname,
                fundid: fund.fundid,
                mainfundcode: fund.mainfundcode,
                mainfundid: fund.mainfundid,
                mainfundname: fund.mainfundname,
                agencydate: b.agencydate,
                agencytype: b.agencytype,
                changetype: '新增代销机构',
              });
            });
            newArrlist = [...itemList, ...newArrlist];

            if (newArrlist.length > 0) {
              setTimeout(() => {
                if (values[1].data.fundperiod === '存续期') {
                  setFieldState('fund', (state) => {
                    state.description = (
                      <span style={{ color: 'red' }}>
                        注意：当前基金【{values[1].data.fundname}
                        】处于存续期，已存在代销关系，建议您发起【代销机构变更流程】。若发起当前流程，原代销关系数据将会被覆盖
                      </span>
                    );
                  });
                } else {
                  setFieldState('fund', (state) => {
                    state.description = (
                      <span style={{ color: 'red' }}>
                        注意：当前基金【{values[1].data.fundname}
                        】已存在代销关系，若发起当前流程，原代销关系数据将会被覆盖
                      </span>
                    );
                  });
                }
                setFieldValue('itemlist', newArrlist);
                this.antMessage.destroy();
                linkage.componentLoaded('itemlist');
              }, 1500);
            } else {
              setFieldValue('itemlist', []);
              setFieldState('fund', (state) => {
                state.description = null;
              });
              this.antMessage.destroy();
              linkage.componentLoaded('itemlist');
            }
          });
      });

      onFieldInit$('*(countersigndeparts,countersignusers,noticeusers)').subscribe(
        ({ value, name }) => {
          setFieldValue(name, value ? value.split(';') : value);
        },
      );
      if (!firstTokenFlag || readOnlyFlag) {
        onFieldInit$('fund').subscribe(({ value, values }) => {
          const fund = values && values[1] ? values[1].data : JSON.parse(this.formData.fundinfo);
          if (fund && Number(fund.isindexfund) === 1) {
            setFieldState('itemlist', (s) => {
              s.props['x-component-props'].visibleColumns = [
                { name: 'agencytype', visible: true, editable: false },
              ];
            });
          } else {
            setFieldState('itemlist', (s) => {
              s.props['x-component-props'].visibleColumns = [
                { name: 'agencytype', visible: false, editable: false },
              ];
            });
          }
        });
      } else if (firstTokenFlag) {
        onFieldInputChange$('fund').subscribe(({ value, values }) => {
          if (
            Array.isArray(values) &&
            values.length > 1 &&
            Number(values[1].data.isindexfund) === 1
          ) {
            setFieldState('itemlist', (s) => {
              s.props['x-component-props'].visibleColumns = [
                { name: 'agencytype', visible: true, editable: true },
              ];
            });
          } else {
            setFieldState('itemlist', (s) => {
              s.props['x-component-props'].visibleColumns = [
                { name: 'agencytype', visible: false, editable: false },
              ];
            });
          }
        });
      }
    };
  }

  getAgencyData = async () => {
    if (this.agencyList.length > 0) {
      return this.agencyList;
    }
    const res = await this.dispatcher.agencyList({ businesstype: '代销机构', page: 1, size: 1000 });
    if (res.data && !res.error) {
      this.agencyList = res.data;
      return this.agencyList;
    }
    return [];
  };

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }

  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileid) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };
  formatData(values) {
    return {
      ...values,
      detaillist: this.formatFiles(values.detaillist),
      annlist: this.formatFiles(values.annlist),
      countersigndeparts: this.joinArray(values.countersigndeparts, ';'),
      countersignusers: this.joinArray(values.countersignusers, ';'),
      noticeusers: this.joinArray(values.noticeusers, ';'),
      agencytype: this.joinArray(values.agencytype, ';'),
      // countersigndeparts: Array.isArray(values.countersigndeparts) ? values.countersigndeparts.join(";") : values.countersigndeparts,
    };
  }

  applySubmit(values) {
    const result = values;
    let data = this.formatData(result);
    return data;
  }

  auditSubmit(values) {
    let data = this.formatData(values);
    return data;
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  get expressionScope() {
    return {
      changeAgencyTableOnSelect: (keys, rows) => {
        this.changeAgencySelectedkeys = keys;
      },
      changeAgencyTableRemove: (idx, record) => {
        this.changeAgencySelectedkeys = [];
      },
      renderRemove: (idx) => {
        const mutators = this.formActions.createMutators('agencylist');
        return (
          <Button
            shape="circle"
            icon={<DeleteOutlined />}
            onClick={() => {
              const agencyList = this.formActions.getFieldValue('agencylist') || [];
              const itemList = this.formActions.getFieldValue('itemlist') || [];
              const agency = agencyList.length > idx ? agencyList[idx] : null;
              if (agency && itemList.find((a) => a.organinfoid === agency.organinfoid)) {
                this.antMessage.info('不可删除，【代销关系信息】中已包含该代销机构。');
                return;
              }
              mutators.remove(idx);
            }}
          />
        );
      },
      fileSuccess: (name) => {
        const { getFieldValue } = this.formActions;
        return ({ file }) => {
          if (file && file.status === 'done') {
            this.antMessage.destroy();
            const fund = getFieldValue('fund');
            if (!fund) {
              this.antMessage.info('请先选择基金');
              return;
            }
            this.antMessage.loading('文件解析中...');
            this.dispatcher
              .initAgencyUpload({
                // 上传文件
                filename: file.response.filename,
                fileid: file.response.fileid,
              })
              .then((res) => {
                if (!res.error && res.data) {
                  this.antMessage.destroy();
                  const { setFieldValue, getFieldState } = this.formActions;
                  const itemList = this.formActions.getFieldValue('itemlist') || [];
                  const agencyList = this.formActions.getFieldValue('agencylist') || [];
                  const fundinfo = getFieldState('fund', (state) =>
                    this.formData.fundinfo
                      ? JSON.parse(this.formData.fundinfo)
                      : state.values[1].data,
                  );
                  let dataList = res.data;
                  let newArrlist = [];
                  dataList.forEach((b) => {
                    const organinfo = agencyList.find((a) => a.companyname === b.companyname);
                    if (!itemList.find((c) => c.companyname === b.companyname)) {
                      newArrlist.push({
                        id: uuid(),
                        organinfoid: b.organinfoid
                          ? b.organinfoid
                          : organinfo
                          ? organinfo.organinfoid
                          : uuid(),
                        companytype: b.companytype,
                        companyname: b.companyname,
                        fundcode: fundinfo.fundcode,
                        fundname: fundinfo.fundname,
                        fundid: fundinfo.fundid,
                        mainfundcode: fundinfo.mainfundcode,
                        mainfundid: fundinfo.mainfundid,
                        mainfundname: fundinfo.mainfundname,
                        isexist: organinfo ? '已添加' : Number(b.isexist),
                        agencydate: b.agencydate,
                        changetype: '新增代销机构',
                        agencytype: b.agencytype,
                      });
                    }
                  });
                  newArrlist = [...itemList, ...newArrlist];
                  setFieldValue('itemlist', newArrlist);
                } else {
                  this.antMessage.loading(res.msg || '解析出错了~', 3);
                }
              });
          }
        };
      },
      addonAfterRender: () => {
        return (
          ['10', '20', '21', '30', '31'].includes(this.elementCode) &&
          !this.readOnlyFlag && (
            <Button
              onClick={() => {
                const { getFieldState, setFieldValue, getFieldValue } = this.formActions;
                const fund = getFieldValue('fund');
                if (!fund) {
                  this.antMessage.info('请先选择基金');
                  return;
                }

                const itemList = this.formActions.getFieldValue('itemlist') || [];
                let dataList = [];
                const fundinfo = getFieldState('fund', (state) =>
                  this.formData.fundinfo
                    ? JSON.parse(this.formData.fundinfo)
                    : state.values[1].data,
                );
                let agency = [...getFieldState('agency', (state) => state.values[1] || [])];
                // console.log("agency", agency);
                // const newAgency = getFieldValue("agencylist");
                // const agencyKey = getFieldValue("agency");

                // if ((newAgency || []).length > 0 && (agencyKey || []).length > 0) {
                //   agency.push(...newAgency.filter(a => agencyKey.includes(a.organinfoid)).map(a => ({ data: a })))
                // }
                agency.forEach((b) => {
                  if (b.data) {
                    if (!itemList.find((a) => a.organinfoid === b.data.organinfoid)) {
                      dataList.push({
                        id: uuid(),
                        organinfoid: b.data.organinfoid,
                        companytype: b.data.companytype,
                        companyname: b.data.companyname,
                        fundcode: fundinfo.fundcode,
                        fundname: fundinfo.fundname,
                        fundid: fundinfo.fundid,
                        mainfundcode: fundinfo.mainfundcode,
                        mainfundid: fundinfo.mainfundid,
                        mainfundname: fundinfo.mainfundname,
                        agencydate: b.agencydate,
                        changetype: '新增代销机构',
                      });
                    }
                  }
                });
                dataList = [...itemList, ...dataList];
                setFieldValue('itemlist', dataList);
              }}
            >
              添加
            </Button>
          )
        );
      },
      // 添加
      renderExtendButtons: () => {
        return (
          <ModalForm
            labelCol={{ span: 10 }}
            wrapperCol={{ span: 14 }}
            title="设置代销时间"
            layout="horizontal"
            modalProps={{ maskClosable: false, closable: false, width: 420 }}
            trigger={
              <Button type="primary" size="small">
                设置代销时间
              </Button>
            }
            onFinish={async (values) => {
              if ((this.changeAgencySelectedkeys || []).length < 1) {
                this.antMessage.warning('未选中任何行');
                return false;
              }
              const itemList = this.formActions.getFieldValue('itemlist') || [];
              itemList.forEach((a, i) => {
                if ((this.changeAgencySelectedkeys || []).includes(i)) {
                  this.formActions.setFieldValue(`itemlist.${i}.agencydate`, values.agencydate);
                }
              });
              return true;
            }}
          >
            <ProFormDatePicker
              name="agencydate"
              label="代销上线/下线日期"
              style={{ width: 300 }}
              // rules={[{ required: true, message: '请选择日期' }]}
              placeholder="请选择日期"
            />
          </ModalForm>
        );
      },

      // 代销机构新增信息生成公告
      getAgencyInformationNotice: () => {
        this.antMessage.loading('公告文件生成中...');
        const id = this.formData.id;
        this.dispatcher
          .agencyInformationNotice({
            formid: id,
          })
          .then((res) => {
            if (res.data && !res.error) {
              this.antMessage.info('生成公告成功');
              this.filename = res.data.filename;
              this.filepath = res.data.filepaths;
              this.fileid = res.data.fileid;
              const { setFieldState } = this.formActions;
              setFieldState('detaillist', (state) => {
                state.value = [{ ...res.data, response: {} }];
                // state.editable = false;
              });
            } else {
              this.antMessage.info(res.msg || '公告文件生成失败！');
            }
          });
      },

      // 上市公告生成
      getListedNotice: () => {
        this.antMessage.loading('公告文件生成中...');
        const id = this.formData.id;
        this.dispatcher
          .agencyListedNotice({
            formid: id,
          })
          .then((res) => {
            if (res.data) {
              this.antMessage.info('生成公告成功');
              this.filename = res.data.filename;
              this.filepath = res.data.filepaths;
              this.fileid = res.data.fileid;
              const { setFieldState } = this.formActions;
              setFieldState('annlist', (state) => {
                state.value = [{ ...res.data, response: {} }];
                // state.editable = false;
              });
            } else {
              this.antMessage.info(res.msg || '公告文件生成失败！');
            }
          });
      },

      fileNoticeSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              newFileList = newFileList.slice(0, 1);
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
    };
  }
}
