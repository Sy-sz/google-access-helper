import React from 'react';
import store from '@/store';
import { FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/lib/components/ProcessLayout/pages/core/FormEffects';
const { onFieldValueChange$, onFieldInputChange$, onFieldInit$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    this.managerid = null;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag, readOnlyFlag } = getProcess() || {};
    this.managerid = null;
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
  }
  createFormEffects() {
    this.changeAgencyActionRef = React.useRef();
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      // onFieldInputChange$('futuresid').subscribe(({value,values}) => {
      //   const fundcode = getFieldValue('fundcode') ||'';
      //     this.dispatcher.listFuturesAccount({
      //       fundcode:fundcode,
      //       futuresid:value
      //     }).then(res=>{
      //      console.log(res,'.....res')
      //     })
      // });

    };
  }

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }
  formatData(values) {
    return {
      ...values,
    };
  }
  applySubmit(values) {
    const result = values;
    console.log('提交前数据：', values);
    let data = this.formatData(result);
    console.log('提交前数据：', data);
    return data;
  }

  auditSubmit(values) {
    console.log('提交前的数据auditSubmit', values);
    const result = values;
    let data = this.formatData(result);
    console.log('提交后的数据auditSubmit', data);
    return data;
  }



};


