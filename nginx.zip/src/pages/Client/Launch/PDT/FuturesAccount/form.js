
/**
 * 期货开户流程
 * 单秀雨 2022-04-08
 */

import React from 'react';
import {
  Field,
} from 'formily-antd';
import BasicFormCard from '@chinahorm/web-components/lib/components/BasicFormCard';
import {
  useDictList,
  // useBpmShareList,
  // useAgencyList,
} from '@chinahorm/web-components/lib/components/ProcessLayout/pages/shared/hooks';
import {
  useAgencyList,
  useBpmShareList
} from '@/hooks';

function Form(props) {
  const {
    context: { getProcess },
  } = props;
  const { elementCode, elementName, readOnlyFlag, firstTokenFlag, elementId, endElementId } =
    getProcess() || {};
  const endFlag = elementId === endElementId;


  const megaProps = {
    labelWidth: 110,
    responsive: { lg: 4, m: 2, s: 1 },
    contextResponsive: { lg: 4, m: 2, s: 1 },
  };
  const commissionTypeRequest = useDictList({ id: 'f993cf7a384343f281e6cb6ad9ed6173' });

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="填写信息" megaProps={megaProps}>
        <Field
          name="fundcode"
          title="产品名称"
          type="tree-select"
          required
          x-component-props={{
            filterOption: (value, option) =>
              option.data &&
              ((option.data.fundcode || '').includes(value) ||
                (option.data.fundname || '').includes(value) ||
                (option.data.businesstype || '').includes(value)),
            style: { maxWidth: 500 },
            placeholder: '请选择基金名称',
            ...useBpmShareList(),
          }}
          x-mega-props={{ span: 4 }}
        />

        <Field
          name="futuresid"
          title="期货公司"
          type="tree-select"
          required
          x-component-props={{
            style: { maxWidth: 500 },
            optionFilterProp: 'label',
            placeholder: '请选择期货公司',
            ...useAgencyList({
              businesstype: '期货公司',
              type: '期货公司',
            }),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="tradetype"
          title="交易类型"
          type="radio"
          enum={[
            { label: '交易型', value: '1' },
            { label: '现金管理', value: '0' },
          ]}
          required
          x-component-props={{ size: 'middle' }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="reason"
          title="申请理由"
          required
          type='textarea'
          x-component-props={{
            placeholder: `请填写申请理由`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="futurescode"
          title="期货账户"
          type="string"
          required
          visible={(!['10', '20', '30'].includes(elementCode) && !firstTokenFlag) || endFlag}
          editable={['40'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{ placeholder: '请输入期货账户' }}
        />

      </BasicFormCard>
    </>
  );
}
export default Form;
