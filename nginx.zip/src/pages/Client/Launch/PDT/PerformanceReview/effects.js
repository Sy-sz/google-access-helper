/* eslint-disable no-return-assign */
import React from 'react';
// import { FormEffectHooks } from '@formily/antd';
import { Button, Form } from 'antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
// import { useUserList } from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import { userList } from '@/common/axios/pdtSystem';
import store from '@/store';
import { ModalForm, ProFormSelect } from '@ant-design/pro-form';
import { perfapprList, generateemail, bpmFundSharelist } from '@/common/axios';
import forOwn from 'lodash/forOwn';
import ExtraElements from './ExtraElements';
import { dateOpts } from './data';
// const { onFieldInputChange$, onFieldValueChange$, onFieldInit$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.leaderEnum = [];
    this.leaderMap = {
      keyValue: {}, // eg: { zhangsan: '张三'}
      valueKey: {}, // eg: { 张三: 'zhangsan'}
    };
    const { readOnlyFlag } = props.context.getProcess() || {};
    this.readOnlyFlag = readOnlyFlag;
    this.fundsTableSelected = []; // 基金信息已选择的项
  }

  createFormEffects() {
    return ($, { dispatch, setFieldState, setFieldValue, getFieldValue }) => {};
  }

  auditFormatData(initValues) {
    return this.initValues(initValues);
  }

  // 初始化数据
  applyFormatData(initValues) {
    return this.initValues(initValues);
  }

  initValues(values = {}) {
    const itemList = values.itemList?.map((item) => {
      const newItem = { ...item };
      forOwn(newItem, (value, key) => {
        if (key.endsWith('Flag')) {
          const checkedKey = `${key.split('Flag')[0]}-checked`;
          newItem[checkedKey] = value === '1' ? true : value === '2' ? false : undefined;
        }
      });
      return newItem;
    });
    return {
      ...values,
      itemList,
    };
  }

  // 提交时，如果是流程第`1`步，且是`可编辑`状态时，调用 applySubmit；否则，调用 auditSubmit
  // 然后 再调用 submitConfirm
  applySubmit(values, file) {
    return this.formatData(values);
  }

  auditSubmit(values, file) {
    return this.formatData(values);
  }

  submitConfirm(values, next) {
    if (this.elementCode == 50 && !this.readOnlyFlag) {
      if (values.itemList.some((e) => e.apprStatus === '0')) {
        this.antMessage.error('有未复核的产品');
        next(false);
        return;
      }

      this.antModal.confirm({
        title: '提交确认？',
        content: '请确认选择的复核项内容无误！',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
      return;
    }

    next(true);
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  formatData(values) {
    const itemList = values.itemList?.map((item) => {
      const newItem = { ...item };
      // 首次提交表单时，可以将勾选的【其他】项
      if (this.elementCode == 10) {
        newItem.otherInfo = newItem.otherInfoSelect;
      }

      // 复核时，前端用-checked结尾做标记，后端要flag结尾做标记
      if (this.elementCode == 50) {
        forOwn(newItem, (value, key) => {
          if (key.endsWith('-checked')) {
            const flagKey = `${key.split('-checked')[0]}Flag`;
            newItem[flagKey] = value === undefined ? '0' : value ? '1' : '2';
          }
        });
      }
      return newItem;
    });

    return {
      ...values,
      itemList,
    };
  }

  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileId) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  get expressionScope() {
    return {
      onTableSelect: (val) => {
        this.fundsTableSelected = val;
      },
      renderExtendButtons: () => {
        let fundList = [];
        let accountantList = [];
        const { setFieldValue, getFieldValue } = this.formActions;
        const itemList = getFieldValue('itemList');
        const initDate = itemList?.[0]?.dataEndDate?.split(' ')?.[0] || dateOpts[0].value;
        return (
          <>
            {/* 添加基金 */}
            {this.elementCode == 10 && (
              <>
                <ModalForm
                  title="添加基金数据"
                  layout="horizontal"
                  trigger={
                    <Button size="small" type="primary">
                      添加基金
                    </Button>
                  }
                  modalProps={{ destroyOnClose: true }}
                  labelCol={{ span: 6 }}
                  wrapperCol={{ span: 18 }}
                  width={520}
                  initialValues={{
                    date: initDate,
                  }}
                  onFinish={async ({ date, funds }) => {
                    if (itemList.length) {
                      const selectedCode = itemList.map((e) => e.prodCode);
                      if (funds.some((e) => selectedCode.includes(e.fundcode))) {
                        this.antMessage.error('请勿重复添加');
                        return false;
                      }
                    }
                    const response = await perfapprList({
                      fundCodes: funds.map((e) => e.fundcode).join(','),
                      date,
                    });

                    if (response.data?.length) {
                      setFieldValue('itemList', [...itemList, ...response.data]);
                    }

                    return true;
                  }}
                >
                  <ProFormSelect.SearchSelect
                    name="funds"
                    label="基金"
                    mode="multiple"
                    width={250}
                    fieldProps={{
                      // notFoundContent: null,
                      // autoClearSearchValue: false,
                      optionFilterProp: 'filterword',
                      autoClearSearchValue: true,
                      // labelInValue: true,
                    }}
                    rules={[{ required: true, message: '请选择基金' }]}
                    placeholder="请输入基金代码、名称搜索"
                    // options={[]}
                    // debounceTime={1000}
                    request={async ({ keyWords = '' }) => {
                      if (fundList.length) {
                        return fundList;
                      }
                      const response = await bpmFundSharelist({ page: 1, size: 999, all: '0' });
                      if (response.data?.length) {
                        const data = response.data.map((e) => ({
                          // ...e,
                          // key: e.fundcode,
                          label: `${e.fundname}[${e.fundcode}]`,
                          value: e.fundcode,
                          fundcode: e.fundcode,
                          filterword: `${e.fundname} ${e.fundcode}`,
                        }));
                        fundList = data;

                        return fundList;
                      }
                      fundList = [];
                      return [];
                    }}
                  />

                  <ProFormSelect
                    name="date"
                    label="数据日期"
                    width={250}
                    disabled={itemList?.length}
                    rules={[{ required: true, message: '请选择日期' }]}
                    placeholder="请选择日期"
                    options={dateOpts}
                  />
                </ModalForm>

                <Button
                  type="link"
                  size="small"
                  disabled={!itemList.length}
                  onClick={async () => {
                    const response = await perfapprList({
                      fundCodes: itemList.map((e) => e.prodCode).join(','),
                      date: itemList[0].dataEndDate?.split(' ')?.[0],
                    });

                    if (Array.isArray(response.data)) {
                      setFieldValue('itemList', response.data);
                      this.antMessage.success('批量提取数据成功');
                    }
                  }}
                >
                  批量提取数据
                </Button>
              </>
            )}

            {/* 批量分配会计 */}
            {this.elementCode == 40 && !this.readOnlyFlag && (
              <ModalForm
                title="批量分配会计"
                layout="horizontal"
                trigger={
                  <Button size="small" type="primary">
                    批量分配会计
                  </Button>
                }
                labelCol={{ span: 6 }}
                wrapperCol={{ span: 18 }}
                width={520}
                onFinish={({ operator }) => {
                  if (!this.fundsTableSelected.length) {
                    this.antMessage.error('请勾选产品');
                    return;
                  }

                  const newItemlist = itemList.map((e, i) => {
                    if (this.fundsTableSelected.includes(i)) {
                      e.operator = operator;
                    }
                    return e;
                  });

                  setFieldValue('itemList', newItemlist);
                  return true;
                }}
              >
                <Form.Item label="产品名称">
                  <div style={{ width: 250 }}>
                    {itemList
                      ?.filter((e, i) => this.fundsTableSelected.includes(i))
                      ?.map((e) => e.prodName)
                      ?.join(' , ')}
                  </div>
                </Form.Item>
                <ProFormSelect
                  name="operator"
                  label="清算会计人员"
                  width={250}
                  showSearch
                  rules={[{ required: true, message: '请选择清算会计人员' }]}
                  placeholder="请选择清算会计人员"
                  fieldProps={{ optionFilterProp: 'filterword' }}
                  request={async () => {
                    if (accountantList?.length) {
                      return accountantList;
                    }
                    const departmentid = '979E99E7-9E37-4429-928B-62AA2BB91C7F';
                    const response = await userList({
                      page: 1,
                      size: 1000,
                      departmentid,
                    });

                    accountantList = response?.data
                      ?.filter((a) => Number(a.status) === 1 && a.departmentid === departmentid)
                      ?.map((e) => ({
                        // ...e,
                        label: e.userName,
                        value: e.id,
                        filterword: `${e.userName},${e.userId}`,
                      }));

                    return accountantList;
                  }}
                />
              </ModalForm>
            )}

            {this.elementCode >= 50 && !this.readOnlyFlag && (
              <>
                {/* 批量复核 */}
                <ExtraElements
                  formActions={this.formActions}
                  fundsTableSelected={this.fundsTableSelected}
                />

                <Button
                  size="small"
                  type="primary"
                  onClick={() => {
                    const date = itemList?.[0]?.dataEndDate?.split(' ')?.[0];
                    generateemail({ formId: this.formData.id, date }).then(() => {
                      this.antMessage.success('发送成功');
                    });
                  }}
                >
                  批量发送邮件
                </Button>
              </>
            )}
          </>
        );
      },
      changeAgencyTableRemove: () => {},
      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
    };
  }
}
