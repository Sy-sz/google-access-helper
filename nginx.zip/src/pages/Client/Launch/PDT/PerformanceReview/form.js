// 基金业绩复核流程

import React from 'react';
import { Field } from 'formily-antd';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { megaProps } from '@/utils';
import { useFieldsList, renderCardTitle } from './data';

function Form(props) {
  const {
    context: { getProcess },
    formEffects: { formActions },
  } = props;
  const { readOnlyFlag, elementCode } = getProcess() || {};
  console.log('🚀 ~ file: form.js:15 ~ Form ~ elementCode:', elementCode);

  const { baseInfo, fundsInfo } = useFieldsList();

  const hiddenColumns = () => {
    if (elementCode < 40) {
      return ['operator'];
    }
    return [];
  };

  return (
    <>
      <BaseFormCard name="baseInfoCard" title="基本信息" megaProps={megaProps}>
        {baseInfo.map(({ name, type = 'string', ...rest }) => (
          <Field key={name} name={name} type={type} editable={false} {...rest} />
        ))}
      </BaseFormCard>

      <BaseFormCard title={renderCardTitle()} megaLayout={false} name="iteminfo">
        <Field
          name="itemList"
          type="array"
          required
          x-component="form-table"
          editable={elementCode >= 10 && !readOnlyFlag}
          x-component-props={{
            operationsWidth: 80,
            selectedAllRows: true,
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            renderRemove: elementCode > 10 ? () => null : undefined,
            onSelect: '{{onTableSelect}}',
            renderExtendButtons: '{{renderExtendButtons}}',
            onRemove: '{{changeAgencyTableRemove}}',
            visibleColumns: hiddenColumns(),
          }}
        >
          <Field type="object">
            {fundsInfo({ formActions, elementCode, readOnlyFlag }).map((e) => (
              <Field key={e.name} type={e.type ?? 'string'} {...e} />
            ))}
          </Field>
        </Field>
      </BaseFormCard>
    </>
  );
}

export default Form;
