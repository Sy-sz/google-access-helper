import React from 'react';
import { Checkbox, Popover, Space, Typography } from 'antd';
import moment from 'moment';
import {
  CheckSquareOutlined,
  CloseSquareOutlined,
  MinusSquareOutlined,
  InfoCircleOutlined,
} from '@ant-design/icons';
import { useUserList } from '@/hooks';

const iconStyle = {
  fontSize: 18,
};
const apprStatusMap = {
  0: '未复核',
  1: '已复核',
  2: '复核失败',
};
const colorMap = {
  success: 'var(--tag-success-color)',
  fail: 'var(--tag-error-color)',
  undone: 'var(--tag-color)',
};

export const renderCardTitle = () => {
  return (
    <Popover
      placement="right"
      content={
        <Space direction="vertical" size={0}>
          <Typography.Text>
            <MinusSquareOutlined style={{ color: colorMap.undone }} /> 业绩数据未复核
          </Typography.Text>
          <Typography.Text>
            <CheckSquareOutlined style={{ color: colorMap.success }} /> 业绩数据已复核
          </Typography.Text>
          <Typography.Text>
            <CloseSquareOutlined style={{ color: colorMap.fail }} /> 业绩数据复核失败
          </Typography.Text>
        </Space>
      }
    >
      基金业绩信息 <InfoCircleOutlined />
    </Popover>
  );
};

const renderIcon = (isReview) => {
  if (isReview == null) {
    return <MinusSquareOutlined style={{ ...iconStyle, color: colorMap.undone }} />;
  }

  if (isReview) {
    return <CheckSquareOutlined style={{ ...iconStyle, color: colorMap.success }} />;
  }

  return <CloseSquareOutlined style={{ ...iconStyle, color: colorMap.fail }} />;
};

export const comProps = {
  size: 'middle',
};

export const dateOpts = [1, 2, 3, 4]
  .map((n) => moment().endOf('Q').subtract(n, 'Q').endOf('M').format('YYYY-MM-DD'))
  .map((e) => ({ label: e, value: e }));

export const useFetchData = () => {
  // 经办会计
  const operatorOpts = useUserList({ departmentid: '979E99E7-9E37-4429-928B-62AA2BB91C7F' });

  return { operatorOpts };
};

export const useFieldsList = () => {
  const { operatorOpts } = useFetchData();

  // 基本信息
  const baseInfo = [
    {
      name: 'code',
      title: '单据编号',
      default: '单据提交后自动生成',
    },
    {
      name: 'applydateTerm',
      type: 'date',
      title: '申请日期',
      'x-component-props': { format: 'YYYY-MM-DD' },
    },
    {
      name: 'applyUserName',
      title: '申请人',
    },
    {
      name: 'applyDeptName',
      title: '所属部门',
    },
  ];

  // 基金信息
  const fundsInfo = ({ formActions, elementCode, readOnlyFlag }) => {
    const renderLabel = (name) => (txt, record) =>
      (
        <span style={{ display: 'flex', alignItems: 'center' }}>
          <span style={{ flex: 1, textAlign: 'right', marginRight: 4 }}>
            {txt?.replace(/,/, '\n')}
          </span>
          {txt && Number(elementCode) >= 50 && renderIcon(record[`${name}-checked`])}
        </span>
      );

    return [
      { name: 'prodCode', title: '产品代码', editable: false, width: 100 },
      { name: 'prodName', title: '产品名称', editable: false, width: 300 },
      {
        name: 'dataEndDate',
        title: '数据截止日期',
        editable: false,
        width: 100,
        'x-component-props': {
          renderLabel: (txt) => txt?.split(' ')?.[0],
        },
      },
      {
        name: 'operator',
        title: '经办会计',
        type: 'tree-select',
        width: 200,
        required: true,
        'x-pattern': 'readOnly',
        editable: elementCode == 40 && !readOnlyFlag,
        'x-component-props': {
          placeholder: `请选择经办会计`,
          optionFilterProp: 'label',
          dropdownMatchSelectWidth: false,
          ...operatorOpts,
        },
      },
      {
        name: 'otherInfo',
        title: '其他',
        editable: false,
        width: 250,
        'x-component-props': {
          renderLabel: (txt, record) => {
            if (!txt) {
              return null;
            }

            // 首次提交表单时
            if (elementCode == 10 && !readOnlyFlag) {
              return (
                <Checkbox.Group
                  onChange={(val) => {
                    const list = formActions?.getFieldValue('itemList');
                    list?.forEach((e) => {
                      if (e.prodCode === record.prodCode) {
                        // 这里没有 setFieldValue 直接改了对象的引用地址
                        e.otherInfoSelect = val.join(',');
                      }
                    });
                  }}
                >
                  <Space direction="vertical">
                    {txt?.split(',')?.map((e) => (
                      <Checkbox key={e} value={e}>
                        {e}
                      </Checkbox>
                    ))}
                  </Space>
                </Checkbox.Group>
              );
            }

            return renderLabel('otherInfo')(txt, record);
            // return (
            //   <Space direction="vertical">
            //     {txt?.split(',')?.map((e) => (
            //       <div key={e}>{e}</div>
            //     ))}
            //   </Space>
            // );
          },
        },
      },
      {
        name: 'recentOneMonthYield',
        title: '近1个月收益率',
        editable: false,
        width: 100,
        'x-component-props': {
          renderLabel: renderLabel('recentOneMonthYield'),
        },
      },
      {
        name: 'recentThreeMonthYield',
        title: '近3个月收益率',
        editable: false,
        width: 100,
        'x-component-props': {
          renderLabel: renderLabel('recentThreeMonthYield'),
        },
      },
      {
        name: 'recentSixMonthYield',
        title: '近6个月收益率',
        editable: false,
        width: 100,
        'x-component-props': {
          renderLabel: renderLabel('recentSixMonthYield'),
        },
      },
      {
        name: 'yieldYtd',
        title: '今年以来收益率',
        editable: false,
        width: 110,
        'x-component-props': {
          renderLabel: renderLabel('yieldYtd'),
        },
      },
      {
        name: 'nearOneYYield',
        title: '近1年收益率',
        editable: false,
        width: 100,
        'x-component-props': {
          renderLabel: renderLabel('nearOneYYield'),
        },
      },
      {
        name: 'nearThreeYYield',
        title: '近3年收益率',
        editable: false,
        width: 100,
        'x-component-props': {
          renderLabel: renderLabel('nearThreeYYield'),
        },
      },
      {
        name: 'nearFiveYYield',
        title: '近5年收益率',
        editable: false,
        width: 100,
        'x-component-props': {
          renderLabel: renderLabel('nearFiveYYield'),
        },
      },
      {
        name: 'yieldSetup',
        title: '成立以来收益率',
        editable: false,
        width: 110,
        'x-component-props': {
          renderLabel: renderLabel('yieldSetup'),
        },
      },
      // 0未复核 1复核成功 2复核失败
      {
        name: 'apprStatus',
        title: '数据状态',
        editable: false,
        width: 100,
        'x-component-props': {
          renderLabel: (code) => apprStatusMap[code],
        },
      },
    ];
  };

  return { baseInfo, fundsInfo };
};
