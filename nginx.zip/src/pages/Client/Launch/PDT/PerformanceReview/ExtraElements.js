import React, { useState, useMemo } from 'react';
import { Button, Table, Checkbox, Modal, message } from 'antd';
import isEmpty from 'lodash/isEmpty';
import forOwn from 'lodash/forOwn';
import { useFieldsList } from './data';
import './style.less';

// 默认选中项
const defaultChecked = [
  'nearOneYYield',
  'nearThreeYYield',
  'nearFiveYYield',
  'yieldSetup',
  'recentThreeMonthYield',
  'recentSixMonthYield',
];
// 移除所有选中
const removeCheckedStatus = (data) => {
  return data.map((item) => {
    const newItem = { ...item };
    forOwn(newItem, (value, key) => {
      if (key.endsWith('-checked')) {
        delete newItem[`${key}`];
      }
    });
    return newItem;
  });
};

const ExtraElements = (props) => {
  const { formActions, fundsTableSelected } = props;
  const { getFieldValue, setFieldValue } = formActions;
  const [visible, setVisible] = useState(false);
  const [reviewType, setReviewType] = useState(true); // true: 复核正确的；false: 复核失败的
  const [modifyMap, setModifyMap] = useState({});
  const { fundsInfo } = useFieldsList();

  const dataSource = useMemo(() => {
    let data = getFieldValue('itemList').filter((e, i) => fundsTableSelected.includes(i));
    data = removeCheckedStatus(data);

    if (isEmpty(modifyMap)) {
      return data;
    }

    return data.map((item) => {
      const newItem = { ...item };
      forOwn(modifyMap, (value, key) => {
        if (item.prodCode === key) {
          Object.assign(newItem, value);
        }
      });
      return newItem;
    });
  }, [fundsTableSelected, modifyMap]);

  const onCheckItem = (checked, dataIndex, record) => {
    const newModifyMap = { ...modifyMap };
    const prodCode = record.prodCode;

    // if (reviewType) {
    //   checked = checked || undefined;
    // } else {
    //   checked = checked ? false : undefined;
    // }

    // const newData = dataSource.map((e, i) => {
    //   if (e.prodCode === record.prodCode) {
    //     e[`${dataIndex}-checked`] = checked;
    //     prodCode = record.prodCode;
    //   }
    //   return e;
    // });

    newModifyMap[prodCode] = Object.assign(newModifyMap[prodCode] || {}, {
      [`${dataIndex}-checked`]: checked || undefined,
    });

    setModifyMap(newModifyMap);
    // setDataSource(newData);
  };

  const columns = fundsInfo({ formActions })
    .filter((e) => !['数据截止日期', '经办会计', '数据状态'].includes(e.title))
    .map((e) => {
      const item = {
        title: e.title,
        dataIndex: e.name,
        key: e.name,
        width: e.width,
      };
      if (!['产品代码', '产品名称'].includes(e.title)) {
        item.render = (txt, record) => {
          return (
            <Checkbox
              disabled={!txt}
              className={e.name === 'otherInfo' ? 'PerformanceReview_checkbox' : ''}
              checked={record[`${e.name}-checked`]}
              onChange={({ target: { checked } }) => onCheckItem(checked, e.name, record)}
            >
              {e.name === 'otherInfo' ? (
                <span style={{ display: 'flex', flexDirection: 'column' }}>
                  {txt?.split(',').map((e) => (
                    <span key={e}>{e}</span>
                  ))}
                </span>
              ) : (
                txt
              )}
              {/* <span>{txt?.replace(/,/, '\n')}</span> */}
            </Checkbox>
          );
        };
      }
      return item;
    });

  const toggleVisible = () => {
    const open = !visible;

    if (!open) {
      setModifyMap({});
    }

    setVisible(open);
  };

  // 打开复核成功弹框时，先清除所有选中项，再勾选默认选中项
  const initReviewCorrect = () => {
    const modifyMap = {};
    const data = getFieldValue('itemList').filter((e, i) => fundsTableSelected.includes(i));

    data.forEach((e) => {
      const obj = {};
      defaultChecked.forEach((item) => {
        if (e[item]) {
          obj[`${item}-checked`] = true;
        }
      });

      modifyMap[e.prodCode] = obj;
    });

    setModifyMap(modifyMap);
  };

  // type为true表示复核正确的；为false则为复核失败的
  const handleReview = (type) => {
    setReviewType(type);
    toggleVisible(!visible);

    if (type) {
      initReviewCorrect();
    }
  };

  const reviewConfirm = () => {
    if (Object.keys(modifyMap).length < dataSource.length) {
      message.info('有未复核的产品');
      return;
    }

    const newData = dataSource.map((item) => {
      const newItem = { ...item };
      let modifyItem = modifyMap[newItem.prodCode];
      if (!modifyItem) {
        debugger;
        return newItem;
      }

      // 复核失败时，选中在外面表格的表示叉叉
      if (!reviewType) {
        forOwn(modifyItem, (value, key) => {
          if (value) {
            modifyItem[key] = false;
          }
        });
        newItem.apprStatus = '2';
      }

      Object.assign(newItem, { ...modifyItem, apprStatus: reviewType ? '1' : '2' }); // 0未复核 1复核成功 2复核失败

      return newItem;
    });

    const newItemList = getFieldValue('itemList').map((item) => {
      let newItem = { ...item };
      newData.forEach((e) => {
        if (item.prodCode === e.prodCode) {
          newItem = e;
        }
      });
      return newItem;
    });
    setFieldValue('itemList', newItemList);
    toggleVisible();
  };

  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      {/* 批量复核 */}
      <Button type="primary" size="small" onClick={() => handleReview(true)}>
        批量复核
      </Button>

      <Button type="primary" size="small" onClick={() => handleReview(false)}>
        批量处理失败
      </Button>
      <Modal
        visible={visible}
        footer={[
          <Button key="confirm" type="primary" onClick={reviewConfirm}>
            {reviewType ? '已复核，数据正确' : '复核失败'}
          </Button>,
        ]}
        title={reviewType ? '复核数据' : '批量复核失败'}
        width="80vw"
        onCancel={toggleVisible}
      >
        <Table
          size="small"
          columns={columns}
          rowKey="prodCode"
          dataSource={dataSource}
          pagination={false}
          scroll={{ x: columns.reduce((p, c) => p + c.width, 0) }}
        />
      </Modal>
    </div>
  );
};

export default ExtraElements;
