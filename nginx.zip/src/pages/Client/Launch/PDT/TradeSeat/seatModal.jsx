import React, { useState } from 'react';
import { DragModal } from '@cerdo/cerdo-design';
import { guid } from '@cerdo/cerdo-utils';
import {
  Button,
  ConfigProvider,
  Divider,
  Input,
  message,
  Modal,
  Popconfirm,
  Space,
  Table,
} from 'antd';
import { sortBy } from 'lodash';
import zhCN from 'antd/lib/locale/zh_CN';

const SeatModal = (props) => {
  const { open, title, onCancel, onOk, data, groupId, exch, editable = false } = props;
  const [tableData, setTableData] = useState((data ?? []).map((a) => ({ ...a, uid: guid() })));

  const handleOk = () => {
    // 空值、交易单元好相同直接拦截
    let hasError = tableData.some((item, index) => {
      if (!item.tradeunitno || !item.exch || !item.brok) {
        message.warning(`第${index + 1}行，存在空值，请核对！`);
        return true;
      }
      return false;
    });
    if (hasError) {
      return;
    }

    hasError = tableData.some((a, ai) => {
      return tableData.some((b, bi) => {
        if (a.uid !== b.uid && a.tradeunitno === b.tradeunitno) {
          message.warning(`第${ai + 1}行和第${bi + 1}行，交易单元号相同，请核对！`);
          return true;
        }
        return false;
      });
    });
    if (hasError) {
      return;
    }

    // 券商名称相同 弹窗提示
    let confirmArr = [];
    let hasConfirm = false;
    tableData.forEach((a, ai) => {
      tableData.forEach((b, bi) => {
        if (a.uid !== b.uid && a.brok === b.brok && bi > ai) {
          confirmArr.push(`第${ai + 1}行和第${bi + 1}行，券商名称相同！`);
          hasConfirm = true;
        }
      });
    });

    if (hasConfirm) {
      Modal.confirm({
        title: '确认提交？',
        content: (
          <Space direction="vertical" style={{ maxHeight: '200px', overflowY: 'auto' }}>
            {confirmArr.map((txt) => (
              <span key={txt}>{txt}</span>
            ))}
          </Space>
        ),
        onOk: () => {
          onOk({
            groupId,
            exch,
            data: tableData,
          });
        },
      });
      return;
    }

    onOk({
      groupId,
      exch,
      data: tableData,
    });
  };

  const handleFieldChange = (uid, key, value) => {
    let item = tableData.find((a) => a.uid === uid);
    if (item) {
      item[key] = value;
    }
    setTableData(tableData);
  };

  const handleTableChange = (pagination, filters, sorter) => {
    const { order = 'ascend', field = 'index' } = sorter;
    const newTableDate =
      order === 'ascend' ? sortBy(tableData, [field]) : sortBy(tableData, [field]).reverse();

    setTableData(newTableDate);
  };

  const handleDeleteClick = (uid) => {
    setTableData(tableData.filter((a) => a.uid !== uid));
  };

  const handleAddClick = (uid) => {
    const newTableData = [...tableData];
    const index = newTableData.findIndex((a) => a.uid === uid);
    newTableData.splice(index + 1, 0, { uid: guid(), groupid: groupId, exch: exch });
    setTableData(newTableData);
  };

  const getColumns = () => {
    let columns = [
      { dataIndex: 'index', title: '序号', width: '50px', render: (_, __, index) => index + 1 },
      {
        dataIndex: 'tradeunitno',
        title: '交易单元号',
        render: (text, record) => {
          return editable ? (
            <Input
              size="small"
              bordered={false}
              defaultValue={text}
              onChange={({ target: { value } }) =>
                handleFieldChange(record.uid, 'tradeunitno', value)
              }
            />
          ) : (
            text
          );
        },
      },
      {
        dataIndex: 'brok',
        title: '券商',
        render: (text, record) => {
          return editable ? (
            <Input
              size="small"
              bordered={false}
              defaultValue={text}
              onChange={({ target: { value } }) => handleFieldChange(record.uid, 'brok', value)}
            />
          ) : (
            text
          );
        },
      },
      { dataIndex: 'exch', title: '交易所' },
    ];

    if (editable) {
      columns.push({
        dataIndex: 'operation',
        title: '操作',
        width: '100px',
        render: (text, record) => {
          return (
            <Space direction="horizontal" split={<Divider type="vertical" />} size={0}>
              <Button type="link" onClick={() => handleAddClick(record.uid)}>
                新增
              </Button>
              <Popconfirm title="确定删除?" onConfirm={() => handleDeleteClick(record.uid)}>
                <Button type="link" danger size="small">
                  删除
                </Button>
              </Popconfirm>
            </Space>
          );
        },
      });
    }
    return columns;
  };

  return (
    <DragModal
      title={title ?? '原有席位号详情'}
      visible={open}
      width="calc(800px)"
      maskClosable={!editable}
      destroyOnClose
      closable={!editable}
      onCancel={onCancel}
      footer={
        <Space>
          <Button onClick={onCancel}>{editable ? '取消' : '关闭'}</Button>
          {editable && (
            <Button type="primary" onClick={handleOk}>
              保存
            </Button>
          )}
        </Space>
      }
      bodyStyle={{
        padding: '8px 12px',
      }}
    >
      <ConfigProvider locale={zhCN}>
        <Table
          columns={getColumns()}
          dataSource={tableData}
          scroll={{ y: 360 }}
          pagination={false}
          size="small"
          rowKey="uid"
          onChange={handleTableChange}
        />
      </ConfigProvider>
    </DragModal>
  );
};

export default SeatModal;
