import React from 'react';
import { Field } from 'formily-antd';
import {
  useTreeSelect,
  useTreeDepartment,
  useTreeUser,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { listAgency, bpmFundlist } from 'common/axios';
import { useUserList } from '@/hooks';
import { megaProps } from '@/utils';

export const comProps = {
  size: 'middle',
};

export const STOCK_EXCHANGE = {
  SH: '上海证券交易所',
  SZ: '深圳证券交易所',
};

export const useFetchData = () => {
  // 经办人
  const operatorOpts = useUserList({ departmentid: '3D1FF9C3-FC96-4DA4-8D69-657B2A67E4B7' });
  // 信息技术部联系人
  const InfoTechnologyOpts = useUserList({ departmentid: 'A52F4EC2-7A12-4DD5-92B3-6716EBCC7DF5' });
  // 基金托管人全称
  const trusteeOpts = useTreeSelect({
    request: () => async () => {
      const res = await listAgency({ businesstype: '托管人', page: 1, size: 1000 });
      if (Array.isArray(res.data)) {
        return res.data.map((a) => ({
          value: a.organinfoid,
          label: a.companyname,
        }));
      }
      return [];
    },
  });
  // 会签部门
  const deptMulProps = useTreeDepartment({
    multiple: true,
    type: undefined,
    tokenSeparators: [';'],
  });
  // 会签人/知会人
  const userMulProps = useTreeUser({
    multiple: true,
    tokenSeparators: [';'],
  });
  // 基金名称
  const fundsList = useTreeSelect({
    request: () => async () => {
      const res = await bpmFundlist({ all: '', keyword: '', page: 1, size: 1000 });
      if (res.data?.length) {
        return res.data.map((e) => ({
          ...e,
          value: e.fundcode,
          label: `${e.fundname}[${e.fundcode}]`,
        }));
      }
      return [];
    },
  });

  return { operatorOpts, InfoTechnologyOpts, trusteeOpts, deptMulProps, userMulProps, fundsList };
};

export const useFieldsList = () => {
  const { operatorOpts, InfoTechnologyOpts, trusteeOpts } = useFetchData();

  // 基本信息
  const baseInfo = [
    {
      name: 'code',
      title: '单据编号',
      default: '单据提交后自动生成',
    },
    {
      name: 'applydateTerm',
      type: 'date',
      title: '申请日期',
      'x-component-props': { format: 'YYYY-MM-DD' },
    },
    {
      name: 'applyUserName',
      title: '申请人',
    },
    {
      name: 'applyDeptName',
      title: '所属部门',
    },
  ];

  // 基金信息
  const fundInfo = ({ elementCode, readOnlyFlag }) => [
    {
      name: 'prodName',
      title: '产品名称',
      required: true,
      editable: Number(elementCode) === 20 && !readOnlyFlag,
    },
    {
      name: 'prodType',
      title: '产品类型',
      required: true,
      editable: Number(elementCode) === 20 && !readOnlyFlag,
    },
    {
      name: 'prodCode',
      title: '产品代码',
      required: true,
      editable: Number(elementCode) === 20 && !readOnlyFlag,
    },
    {
      name: 'trusterName',
      title: '基金托管人全称',
      required: true,
      visible: Number(elementCode) >= 30,
      editable: [30, 40, 50].includes(Number(elementCode)) && !readOnlyFlag,
      type: 'tree-select',
      'x-component-props': {
        optionFilterProp: 'label',
        ...trusteeOpts,
      },
    },
    {
      name: 'trusterContr',
      title: '基金托管人联系人',
      required: true,
      visible: Number(elementCode) >= 30,
      editable: [30, 40, 50].includes(Number(elementCode)) && !readOnlyFlag,
    },
    {
      name: 'trusterPhoneno',
      title: '基金托管人联系人电话',
      required: true,
      visible: Number(elementCode) >= 30,
      editable: [30, 40, 50].includes(Number(elementCode)) && !readOnlyFlag,
    },
  ];

  // 基础信息
  const basicInfo = ({ elementCode, readOnlyFlag }) => [
    // -----------上交所---------------
    {
      name: 'newSeatno',
      title: '新增席位号',
      required: true,
      pattern: /\d+/,
    },
    {
      name: 'newSeatOutUnit',
      title: '新增席位出租单位',
      required: true,
    },
    {
      name: '_placeholder',
      editable: false,
      title: '',
    },
    // --------------深交所---------
    {
      name: 'applyChgProdSeatno',
      title: '申请变更的基金席位号',
      required: true,
      visible: false,
      pattern: /\d+/,
    },
    {
      name: 'rentSeatBizName',
      title: '租用席位的营业部名称',
      required: true,
      visible: false,
    },
    {
      name: 'rentSeatBizAddr',
      title: '租用席位的营业部地址',
      required: true,
      visible: false,
    },
    // ----------------------------
    {
      name: 'operator',
      title: '选择经办人',
      required: true,
      visible: Number(elementCode) >= 20,
      editable: Number(elementCode) === 20 && !readOnlyFlag,
      type: 'tree-select',
      'x-component-props': {
        optionFilterProp: 'label',
        ...operatorOpts,
      },
    },
    {
      name: 'operatorTel',
      visible: Number(elementCode) >= 20,
      editable: Number(elementCode) === 20 && !readOnlyFlag,
      title: '经办人电话号码',
      required: true,
    },
    {
      name: 'operatorFax',
      visible: Number(elementCode) >= 20,
      editable: [20, 30, 40, 50].includes(Number(elementCode)) && !readOnlyFlag,
      title: '经办人传真',
    },
    {
      name: 'operatorEmail',
      visible: Number(elementCode) >= 20,
      editable: Number(elementCode) === 20 && !readOnlyFlag,
      title: '经办人邮箱',
      required: true,
      'x-rules': 'email',
    },
    {
      name: 'newSeatRelaBondSettleLeadSeat',
      title: '新增席位对应债券结算主席位',
      required: true,
      type: 'tree-select',
      visible: Number(elementCode) >= 20,
      editable: Number(elementCode) === 20 && !readOnlyFlag,
      'x-component-props': {
        tree: false,
        showSearch: true,
        optionFilterProp: 'label',
      },
      'x-mega-props': { span: 4 },
    },
    {
      name: 'itemsStr',
      title: '原有各席位号',
      required: true,
      type: 'textarea',
      visible: Number(elementCode) >= 20,
      editable: false, // elementCode === 20 && !readOnlyFlag
      className: 'items',
      pattern: /\d+/,
      'x-mega-props': {
        span: 4,
      },
      'x-component-props': {
        placeholder: '请输入备注信息',
        previewPlaceholder: '-',
        autoSize: { minRows: 3, maxRows: 20 },
      },
    },
  ];

  // 基金管理人信息
  const fundManagerInfo = [
    {
      name: 'fundMgmtCompName',
      title: '基金管理公司全称',
      required: true,
    },
    {
      name: 'fundMgmtCompAddr',
      title: '通讯地址',
      required: true,
    },
    {
      name: 'fundMgmtCompPostcode',
      title: '邮政编码',
      required: true,
      pattern: /^\d{6}$/,
    },
    {
      name: 'fundMgmtCompPrinc',
      title: '负责人',
      required: true,
    },
    {
      name: 'fundMgmtCompPrincTel',
      title: '负责人联系电话',
      required: true,
    },
  ];

  // 信息技术部信息
  const infoTechnology = [
    {
      name: 'userStarBsNo',
      title: '用户卫星小站号',
      required: true,
    },
    {
      name: 'userFloorBsNo',
      title: '用户地面小站号',
      required: true,
    },
    {
      name: 'itContr',
      title: '信息技术部联系人',
      required: true,
      type: 'tree-select',
      'x-component-props': {
        ...InfoTechnologyOpts,
      },
    },
    {
      name: 'itContrTel',
      title: '联系人电话号码',
      required: true,
    },
    {
      name: 'itContrFax',
      title: '联系人传真',
    },
  ];

  return { baseInfo, fundInfo, basicInfo, fundManagerInfo, infoTechnology };
};

// 文件上传
export const renderFileCard =
  ({ elementCode, readOnlyFlag }) =>
  (title, name, code) => {
    const display = Number(elementCode) >= code[0];
    const editable = code.includes(Number(elementCode)) && !readOnlyFlag;

    return (
      <BaseFormCard title={title} megaLayout={megaProps} display={display} name={`${name}Card`}>
        <Field
          title={`${title}文件`}
          name={name}
          type="bpm-upload-list"
          editable={editable}
          required={code.includes(Number(elementCode))}
          x-mega-props={{ span: 2 }}
          x-component-props={{
            onSuccess: `{{fileSuccess("${name}")}}`,
            onDel: `{{fileDel("${name}")}}`,
            accept: '',
            multiple: true,
            isFsfund: true,
            maxLength: 4,
          }}
        />

        <Field
          name="generatebtn"
          type="button"
          visible={name === 'seatDataFiles'}
          editable={editable}
          x-component-props={{
            text: '生成',
            onClick: '{{generateNotice}}',
          }}
        />
      </BaseFormCard>
    );
  };

// 会签
export const renderSignCard =
  ({ elementCode, readOnlyFlag }) =>
  (title, ext = '', code, upDownCode) => {
    const { deptMulProps, userMulProps } = useFetchData();
    const editable = Number(elementCode) === code && !readOnlyFlag;

    return (
      <BaseFormCard
        title={title}
        name={`${ext}Card`}
        megaProps={megaProps}
        display={elementCode >= code}
        upDown={elementCode >= upDownCode ? 'up' : 'down'}
      >
        <Field
          name={`isseal${ext}`}
          title="是否需要用印"
          type="radio"
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          default="1"
          editable={editable}
          required
          x-mega-props={{ span: 4 }}
        />
        <Field
          name={`countersigndeparts${ext}`}
          title="会签部门"
          type="tree-select"
          editable={editable}
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...comProps,
            ...deptMulProps,
            placeholder: `请选择会签部门`,
          }}
        />
        <Field
          name={`countersignusers${ext}`}
          title="会签人"
          type="tree-select"
          editable={editable}
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择会签人`,
          }}
        />
        <Field
          name={`leaderapprove${ext}`}
          title="领导是否同时审批"
          type="radio"
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          extraKey={ext}
          default="0"
          editable={editable}
          required
          x-mega-props={{ span: 4 }}
        />
        <Field
          name={`leader${ext}`}
          title="领导"
          type="checkbox"
          extraKey={ext}
          editable={editable}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name={`leaderrank${ext}`}
          title="领导审批顺序"
          type="string"
          editable={false}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name={`noticeusers${ext}`}
          title="知会人"
          type="tree-select"
          editable={editable}
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择知会人`,
          }}
        />
      </BaseFormCard>
    );
  };
