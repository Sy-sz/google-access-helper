import React from 'react';
import { Field } from 'formily-antd';
import { FormMegaLayout } from '@formily/antd-components';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { megaProps } from '@/utils';
import {
  useFieldsList,
  useFetchData,
  renderFileCard,
  renderSignCard,
  STOCK_EXCHANGE,
} from './data';

function Form(props) {
  const { getProcess } = props.context;
  const { readOnlyFlag, elementCode } = getProcess() || {};
  console.log('🚀 ~ file: form.js:17 ~ Form ~ elementCode:', elementCode);

  const { baseInfo, fundInfo, basicInfo, fundManagerInfo, infoTechnology } = useFieldsList();
  const { fundsList } = useFetchData();

  return (
    <>
      <BaseFormCard name="baseInfoCard" title="基本信息" megaProps={megaProps}>
        {baseInfo.map(({ name, type = 'string', ...rest }) => (
          <Field key={name} name={name} type={type} editable={false} {...rest} />
        ))}
      </BaseFormCard>

      <BaseFormCard name="stockExchangeCard" title="申请交易所" megaProps={megaProps}>
        <Field
          name="applyExch"
          type="radio"
          title="交易所"
          default={STOCK_EXCHANGE.SH}
          enum={[
            { label: STOCK_EXCHANGE.SH, value: STOCK_EXCHANGE.SH },
            { label: STOCK_EXCHANGE.SZ, value: STOCK_EXCHANGE.SZ },
          ]}
        />
      </BaseFormCard>

      <BaseFormCard
        name="seatInfoCard"
        title="基金信息"
        megaProps={megaProps}
        className="seatInfoCard"
        visible={elementCode >= 20}
      >
        <FormMegaLayout visible={elementCode == 20 && !readOnlyFlag}>
          <Field
            name="fund"
            title="选择产品"
            type="tree-select"
            required
            x-pattern="readOnly"
            editable={elementCode == 20 && !readOnlyFlag}
            x-component-props={{
              optionFilterProp: 'label',
              placeholder: '请选择基金名称',
              ...fundsList,
            }}
          />
          <Field
            name="fundMsg"
            type="string"
            editable={false}
            x-mega-props={{
              labelWidth: 0,
            }}
            x-component-props={{
              style: { color: 'orange' },
            }}
          />
        </FormMegaLayout>
        {fundInfo({ elementCode, readOnlyFlag }).map((e) => (
          <Field
            key={e.name}
            type={e.type ?? 'string'}
            {...e}
            x-component-props={{
              ...e['x-component-props'],
              placeholder: `请${
                ['string', 'number', undefined].includes(e.type) ? '输入' : '选择'
              }${e.title}`,
            }}
          />
        ))}
      </BaseFormCard>

      <BaseFormCard
        name="settleNoCard"
        title="产品清算编号"
        megaProps={megaProps}
        visible={elementCode >= 40}
      >
        <Field
          name="settleNo"
          type="string"
          required
          title="产品清算编号"
          editable={elementCode == 40 && !readOnlyFlag}
        />
      </BaseFormCard>

      <BaseFormCard name="basicInfoCard" title="基础信息" megaProps={megaProps}>
        {basicInfo({ elementCode, readOnlyFlag }).map((e) => {
          return (
            <Field
              key={e.name}
              type={e.type ?? 'string'}
              {...e}
              x-component-props={{
                ...e['x-component-props'],
                placeholder: `请${
                  ['string', 'number', undefined].includes(e.type) ? '输入' : '选择'
                }${e.title}`,
              }}
            />
          );
        })}
        {/* <Field
          title="原席位号"
          name="items"
          type="array"
          x-component="form-table"
          // display={visible}
          x-component-props={{
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            renderRemove: () => null,
            rowSelection: null,
            className: 'yScrollFix',
            tableScroll: { y: 300 },
            // visibleColumns: [{ name: 'largeStatus', visible: false }],
          }}
          x-mega-props={{ span: 2 }}
        >
          <Field type="object">
            <Field name="brok" title="券商" type="string" editable={false} />
            <Field name="exch" title="交易所" type="string" editable={false} />
            <Field name="tradeunitno" title="交易单元号" type="string" editable={false} />
            <Field name="itemsHandle" title="操作" type="string" editable={false} />
          </Field>
        </Field> */}
      </BaseFormCard>

      <BaseFormCard name="fundManagerCard" title="基金管理人信息" megaProps={megaProps}>
        {fundManagerInfo.map((e) => {
          return (
            <Field
              key={e.name}
              type={e.type ?? 'string'}
              {...e}
              x-component-props={{
                ...e['x-component-props'],
                placeholder: `请${
                  ['string', 'number', undefined].includes(e.type) ? '输入' : '选择'
                }${e.title}`,
              }}
            />
          );
        })}
      </BaseFormCard>

      <BaseFormCard
        name="infoTechnologyCard"
        title="信息技术部信息"
        megaProps={megaProps}
        visible={false}
      >
        {infoTechnology.map((e) => {
          return (
            <Field
              key={e.name}
              type={e.type ?? 'string'}
              {...e}
              x-component-props={{
                ...e['x-component-props'],
                placeholder: `请${
                  ['string', 'number', undefined].includes(e.type) ? '输入' : '选择'
                }${e.title}`,
              }}
            />
          );
        })}
      </BaseFormCard>

      {renderFileCard({ elementCode, readOnlyFlag })('席位协议上传', 'seatAgmtFiles', [10])}
      {renderFileCard({ elementCode, readOnlyFlag })('席位资料', 'seatDataFiles', [60, 90])}

      {renderSignCard({ elementCode, readOnlyFlag })('资料会签', '', 60, 90)}

      <BaseFormCard
        name="applydescCard"
        title="申请说明"
        megaProps={megaProps}
        visible={elementCode === '10'}
      >
        <Field name="applydesc" type="textarea" x-mega-props={{ span: 3 }} />
      </BaseFormCard>
    </>
  );
}

export default Form;
