/* eslint-disable no-return-assign */
import React from 'react';
import { getDictionary, openModal, defaultNoticeusers } from '@/utils';
import { FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import {
  detailAgency,
  pdtconfigDetail,
  prodTradeseatList,
  tradeseatContractlist,
} from 'common/axios';
import difference from 'lodash/difference';
import uniq from 'lodash/uniq';
import { STOCK_EXCHANGE } from './data';
import { Button } from 'antd';
import SeatModal from './seatModal';
import { fn } from '@cerdo/cerdo-utils';

const { onFieldInputChange$, onFieldValueChange$, onFieldInit$ } = FormEffectHooks;

const leaderSeparator = '-->';

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.leaderEnum = [];
    this.leaderMap = {
      keyValue: {}, // eg: { zhangsan: '张三'}
      valueKey: {}, // eg: { 张三: 'zhangsan'}
    };
    const { readOnlyFlag } = props.context.getProcess() || {};
    this.readOnlyFlag = readOnlyFlag;
    this.itemsData = this.formData?.items ?? [];
  }

  createFormEffects() {
    return ($, { dispatch, setFieldState, setFieldValue, getFieldValue }) => {
      // 基金名称 带出 产品类型、产品代码
      onFieldValueChange$('fund').subscribe((field) => {
        const record = field.values?.[1]?.data ?? {};
        const isspecial = record?.isspecial === '1';

        let fundMsg = `该产品为：${isspecial ? '专户' : '公募'}产品`;
        if (field.value === undefined) {
          fundMsg = '';
        }
        setFieldValue('fundMsg', fundMsg);
        setFieldValue('prodName', record.fundname);
        setFieldValue('prodType', isspecial ? record.businesstype : record.fundtype);
        setFieldValue('prodCode', field.value);
      });

      onFieldInit$('baseInfoCard').subscribe(async () => {
        // 添加使用说明
        const result = await pdtconfigDetail({ id: 'a7f561e1965d4538af9d9bc5e06a307d' });
        setFieldState('baseInfoCard', (s) => {
          if (fn.checkResponse(result)) {
            s.props['x-component-props'].extra = (
              <Button
                type="link"
                style={{ fontWeight: 'bold' }}
                onClick={() => window.open(result?.data?.value)}
              >
                {result?.data?.valuefield}
              </Button>
            );
          }
        });
      });

      // 初始化领导字典
      onFieldInit$('leader').subscribe(async () => {
        getDictionary('50bd7db1-aad6-4633-bffc-869810d4f868').then(([leaderDict]) => {
          const leaderEnum = leaderDict.map(({ name: label, value }) => {
            this.leaderMap.keyValue[value] = label;
            this.leaderMap.valueKey[label] = value;
            return { label, value };
          });
          const leaderrank =
            getFieldValue('leaderrank') || this.formData.counterSignList?.[0]?.leaderrank;
          const formatRank = leaderrank
            ?.split(',')
            ?.map((e) => this.leaderMap.keyValue[e])
            ?.join(leaderSeparator);

          setFieldState('leader', (state) => {
            state.props.enum = leaderEnum;
            state.value = leaderrank?.split(',') ?? [];
          });
          setFieldValue('leaderrank', formatRank);
        });
      });

      // 信息技术部 在深交所时 才显示
      onFieldInit$('infoTechnologyCard').subscribe((field) => {
        const applyExch = getFieldValue('applyExch');
        if (Number(this.elementCode) >= 30 && applyExch === STOCK_EXCHANGE.SZ) {
          setFieldState('infoTechnologyCard', (state) => (state.visible = true));
          if (Number(this.elementCode) === 30 && !this.readOnlyFlag) {
            setFieldState('infoTechnologyCard.*', (state) => (state.editable = true));
          }
        }
      });

      // 交易所
      onFieldValueChange$('applyExch').subscribe(async ({ value }) => {
        setFieldState(
          '*(applyChgProdSeatno,rentSeatBizName,rentSeatBizAddr)',
          (state) => (state.visible = value === STOCK_EXCHANGE.SZ),
        );
        setFieldState(
          '*(newSeatno,newSeatOutUnit,_placeholder)',
          (state) => (state.visible = value === STOCK_EXCHANGE.SH),
        );

        if (Number(this.elementCode) < 20) {
          return;
        }

        // 经办人传真 必填
        if (Number(this.elementCode) === 50 && value === STOCK_EXCHANGE.SZ) {
          setFieldState('operatorFax', (state) => {
            state.props.required = true;
          });
        }

        // 根据交易所 查 新增席位对应债券结算主席位 可选项
        const response = await prodTradeseatList({ exch: value.substring(0, 2), leadSeatNo: 1 });
        if (response.data?.length) {
          const treeData = response.data.map((e) => ({
            ...e,
            label: e.name,
            value: e.tradeunitno,
          }));
          setFieldState('newSeatRelaBondSettleLeadSeat', (state) => {
            state.props['x-component-props'].treeData = treeData;
          });
        }
      });

      if (this.itemsData?.length) {
        setFieldState(
          'itemsStr',
          (s) =>
            (s.props['x-mega-props'] = {
              ...s.props['x-mega-props'],
              addonAfter: (
                <Button
                  type="link"
                  onClick={() =>
                    openModal(SeatModal, {
                      data: this.itemsData,
                    })
                  }
                >
                  席位详情
                </Button>
              ),
            }),
        );
      }

      // 新增席位对应债券结算主席位 带出 原有各席位号
      onFieldInputChange$('newSeatRelaBondSettleLeadSeat').subscribe(async (field) => {
        const groupId = field.values?.[1]?.data?.groupid;
        const applyExch = getFieldValue('applyExch');
        const response = await prodTradeseatList({ exch: applyExch.substring(0, 2), groupId });
        if (fn.checkResponse(response)) {
          // const oriOwnSeatno = response.data.map((e) => e.tradeunitno);
          this.itemsData = response.data ?? [];
          setFieldValue('itemsStr', this.itemsData.map((a) => a.tradeunitno).join());
          setFieldState(
            'itemsStr',
            (s) =>
              (s.props['x-mega-props'] = {
                ...s.props['x-mega-props'],
                addonAfter: (
                  <Button
                    type="link"
                    onClick={() =>
                      openModal(SeatModal, {
                        groupId,
                        exch: applyExch.substring(0, 2),
                        data: this.itemsData?.length
                          ? this.itemsData
                          : [{ groupId, exch: applyExch.substring(0, 2) }],
                        onOk: this.handleModalOkClick,
                        editable: Number(this.elementCode) === 20 && !this.readOnlyFlag,
                      })
                    }
                  >
                    席位详情
                  </Button>
                ),
              }),
          );
        } else {
          this.itemsData = [];
          setFieldState(
            'itemsStr',
            (s) =>
              (s.props['x-mega-props'] = {
                ...s.props['x-mega-props'],
                addonAfter: null,
              }),
          );
        }
      });

      // 基金托管人全称 带出 托管人联系人、托管人联系人电话
      onFieldInputChange$('trusterName').subscribe(async ({ value }) => {
        let trusterContr;
        let trusterPhoneno;
        if (value === this.formData.trusterName) {
          trusterContr = this.formData.trusterContr;
          trusterPhoneno = this.formData.trusterPhoneno;
        } else if (value) {
          const details = await detailAgency({ organinfoid: value });
          trusterContr = details.data?.contactor;
          trusterPhoneno = details.data?.phone;
        }
        setFieldValue('trusterContr', trusterContr);
        setFieldValue('trusterPhoneno', trusterPhoneno);
      });

      // 经办人 带出 经办人邮箱、经办人电话
      onFieldValueChange$('operator').subscribe((field) => {
        const record = field.values?.[1]?.data;
        if (!record) {
          return;
        }

        /**
         * 为什么要同时加 elementCode 和 readOnlyFlag ？
         * 加这些是为了避免已保存的值不生效，被重新赋值覆盖掉；
         * 如果只加 code ，在表单刚提交后的页面中，code 不变，就会重新赋值；
         * 如果只加 readOnlyFlag ，在其他节可提交时，也会重新赋值；
         */
        if (Number(this.elementCode) === 20 && !this.readOnlyFlag) {
          setFieldValue('operatorEmail', record.email);
          tradeseatContractlist({ userId: record.id }).then((res) => {
            const phone = res.data?.[0]?.phone;
            setFieldValue('operatorTel', phone);
          });
        }
      });

      // 信息技术部联系人 带出 信息技术部联系人电话
      onFieldValueChange$('itContr').subscribe((field) => {
        const record = field.values?.[1]?.data;
        if (!record || this.readOnlyFlag) {
          return;
        }

        setFieldValue('itContrTel', record.telephone);
      });

      // 是否盖章 带出 知会人
      onFieldValueChange$('isseal').subscribe(({ value }) => {
        // backFlag: 1表示退回
        if (
          Number(this.elementCode) !== 60 ||
          this.readOnlyFlag ||
          this.formData.backFlag === '1'
        ) {
          return;
        }

        const noticeUsers =
          getFieldValue('noticeusers') || (this.formData.noticeusers || '').split(';');

        if (Number(value) === 1) {
          setFieldValue(
            'noticeusers',
            uniq([...noticeUsers, ...defaultNoticeusers]).filter(Boolean),
          );
        } else {
          setFieldValue(
            'noticeusers',
            noticeUsers.filter((id) => id && !defaultNoticeusers.includes(id)),
          );
        }
      });

      // 是否领导同时审批时 显示领导审批顺序
      onFieldValueChange$('leaderapprove').subscribe((field) => {
        setFieldState('leaderrank', (state) => (state.visible = field.value === '0'));
      });

      // 会签，点领导审批时，按点击顺序排序
      onFieldValueChange$('leader').subscribe((field) => {
        if (Number(this.elementCode) === 60 && !this.readOnlyFlag) {
          const leaderrank = getFieldValue('leaderrank') || undefined;
          let leaderOrderArr = leaderrank?.split(leaderSeparator) ?? [];
          leaderOrderArr = leaderOrderArr.map((e) => this.leaderMap.valueKey[e]);
          const isAdd = field.value.length > leaderOrderArr.length; // 是否为新增
          const active = isAdd
            ? difference(field.value, leaderOrderArr)
            : difference(leaderOrderArr, field.value);

          if (isAdd) {
            leaderOrderArr.push(...active);
          } else {
            leaderOrderArr = leaderOrderArr.filter((e) => e !== active[0]);
          }
          const leaderName = leaderOrderArr.map((e) => this.leaderMap.keyValue[e]);
          setFieldValue('leaderrank', leaderName.join(leaderSeparator));
        }
      });
    };
  }

  handleModalOkClick = (data) => {
    this.itemsData = data.data;
    this.formActions.setFieldValue(
      'itemsStr',
      (this.itemsData ?? []).map((a) => a.tradeunitno).join(),
    );
    this.formActions.setFieldState(
      'itemsStr',
      (s) =>
        (s.props['x-mega-props'] = {
          ...s.props['x-mega-props'],
          addonAfter: (
            <Button
              type="link"
              onClick={() =>
                openModal(SeatModal, {
                  ...data,
                  onOk: this.handleModalOkClick,
                  editable: Number(this.elementCode) === 20 && !this.readOnlyFlag,
                })
              }
            >
              席位详情
            </Button>
          ),
        }),
    );
  };

  auditFormatData(initValues) {
    return this.initValues(initValues);
  }

  // 初始化数据
  applyFormatData(initValues) {
    return this.initValues(initValues);
  }

  initValues(values = {}) {
    const { isseal, leaderrank, leaderapprove, countersigndeparts, countersignusers, noticeusers } =
      values.counterSignList?.[0] || {};
    return {
      ...values,
      isseal,
      leaderapprove,
      leaderrank,
      countersigndeparts: countersigndeparts?.split(','),
      countersignusers: countersignusers?.split(','),
      noticeusers: noticeusers?.split(','),
      itemsStr: (values.items ?? []).map((a) => a.tradeunitno).join(),
    };
  }

  // 提交时，如果是流程第`1`步，且是`可编辑`状态时，调用 applySubmit；否则，调用 auditSubmit
  // 然后 再调用 submitConfirm
  applySubmit(values, file) {
    return this.formatData(values);
  }

  auditSubmit(values, file) {
    // 会签部门和会签人，必填一项
    if (Number(this.elementCode) === 60 && !values.countersigndeparts && !values.countersignusers) {
      this.antMessage.error('会签部门和会签人，不能同时为空');
      return false;
    }
    values.items = this.itemsData;

    return this.formatData(values);
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  submitConfirm(values, next) {
    const { oriOwnSeatno, newSeatno, applyChgProdSeatno } = values;
    const oriOwnSeatnoArr = oriOwnSeatno?.split(';') || [];
    // 原席位号包含新增席位号
    const isIncludeNo =
      oriOwnSeatnoArr?.includes(newSeatno) || oriOwnSeatnoArr?.includes(applyChgProdSeatno);

    if (Number(this.elementCode) === 20 && isIncludeNo) {
      this.antModal.confirm({
        title: '请确认',
        content: '原有席位号包含申请席位号，确认提交吗？',
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
      return;
    }

    next();
  }

  formatData(values) {
    let counterSignList = values.counterSignList;
    if (Number(this.elementCode) >= 60) {
      // 领导，如果是同时审批(leaderapprove === 1)，取 leader 字段，否则取 leaderrank 字段
      const leaderrank =
        values.leaderapprove === '1'
          ? values.leader.join()
          : values.leaderrank
              ?.split(leaderSeparator)
              ?.map((e) => this.leaderMap.valueKey[e])
              ?.filter(Boolean)
              ?.join(',');
      counterSignList = [
        {
          ...values.counterSignList[0],
          leaderrank,
          isseal: values.isseal,
          leaderapprove: values.leaderapprove,
          countersigndeparts: values.countersigndeparts?.join(','),
          countersignusers: values.countersignusers?.join(','),
          noticeusers: values.noticeusers?.join(','),
        },
      ];
    }
    delete values.leaderrank;
    delete values.countersigndeparts;
    delete values.countersignusers;
    delete values.noticeusers;

    return {
      ...values,
      counterSignList,
      seatAgmtFiles: this.formatFiles(values.seatAgmtFiles),
      seatDataFiles: this.formatFiles(values.seatDataFiles),
    };
  }

  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileId) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  get expressionScope() {
    return {
      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
      generateNotice: () => {
        this.antMessage.loading('生成中...');
        this.dispatcher.seatapplydoc({ formid: this.formData.id }).then((res) => {
          if (res.data && !res.error) {
            this.antMessage.destroy();
            this.antMessage.info('生成成功');
            this.formActions.setFieldState('seatDataFiles', (state) => {
              state.value = res.data;
            });
          } else {
            this.antMessage.destroy();
            this.antMessage.error(res.message || '生成失败！');
          }
        });
      },
    };
  }
}
