/* eslint-disable array-callback-return */
/* eslint-disable no-return-assign */
import React, { useState } from 'react';
import { FormPath, FormEffectHooks } from 'formily-antd';
import { Button, Input } from 'antd';
import { isMobile, uuid, copyText, defaultNoticeusers } from '@/utils';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import Download from '@chinahorm/web-components/es/components/Download';
import Upload, { MessageShowType } from '@chinahorm/web-components/es/components/Upload';
import { importAgency } from '@/common/axios/pdtSystem';
import { ProFormDatePicker, ProFormSelect, ModalForm } from '@ant-design/pro-form';
import store from '@/store';
import { baseURL } from '@/setting';
import { fn } from '@cerdo/cerdo-utils/lib';
import sortBy from 'lodash/sortBy';
import uniq from 'lodash/uniq';
import { toggleSignType } from '../../utils';

const { onFieldValueChange$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
    } = props;
    const { readOnlyFlag } = getProcess() || {};
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.readOnlyFlag = readOnlyFlag;
  }

  createFormEffects() {
    // const dispatcher = store.useModelDispatchers('pdtSystem');
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      if (
        Array.isArray(this.formData?.sharelist) &&
        this.formData?.sharelist.length > 0 &&
        this.formData?.sharelist[0].listingtype === 'ETF'
      ) {
        setFieldState('curPosition', (s) => (s.display = true));
        setFieldState('positionInfoFile', (s) => (s.display = true));
      }

      // 是否盖章 选是，知会人自动选中三个人
      if (['30', '110', '160'].includes(this.elementCode) && !this.readOnlyFlag) {
        onFieldValueChange$('*(listed60.isseal,listed130.isseal,listed180.isseal)').subscribe(
          ({ value, name }) => {
            const signField = name.split('.')[0];
            const oldNoticeusers = this.formData[signField]?.noticeusers?.split(',');
            const noticeusers =
              value === '1'
                ? uniq([...oldNoticeusers, ...defaultNoticeusers])
                : oldNoticeusers.filter((id) => !defaultNoticeusers.includes(id));
            setFieldValue(`${signField}.noticeusers`, noticeusers);
          },
        );
      }

      onFieldValueChange$('itemlist').subscribe(({ value }) => {
        const length = value && Array.isArray(value) && value.length;
        setFieldState('iteminfo', (s) => {
          s.props['x-component-props'].title = (
            <div>
              代销关系信息 <small>(共{length}条代销关系)</small>
            </div>
          );
        });
      });

      // 是否上市 联动
      onFieldValueChange$('sharelist.*.islisted').subscribe(({ name, value }) => {
        const idx = FormPath.transform(name, /\d/, (i) => i);
        setFieldState(
          `*(sharelist.${idx}.listingplace, sharelist.${idx}.listingtype, sharelist.${idx}.listingdate)`,
          (state) => (state.display = value === '1'),
        );
      });
      // 是否为指数基金 联动
      onFieldValueChange$('isindexfund').subscribe(({ value }) => {
        setFieldState(
          '*(targetindexcode,targetindexname,indexorganization,indexfundtype)',
          (state) => (state.visible = value === '1'),
        );
      });
      // 指数基金类型 联动
      onFieldValueChange$('indexfundtype').subscribe(({ value }) => {
        setFieldState(
          '*(goalfundname,goalfundcode)',
          (state) => (state.visible = value === 'ETF联接基金'),
        );
        setFieldState('basketcode', (state) => (state.visible = value === 'ETF'));
      });
    };
  }

  auditFormatData(initValues) {
    return this.initValues(initValues);
  }

  // 初始化数据
  applyFormatData(initValues) {
    return this.initValues(initValues);
  }

  initValues(initValues = {}) {
    return {
      ...initValues,
      listed60: toggleSignType(initValues.listed60),
      listed130: toggleSignType(initValues.listed130),
      listed180: toggleSignType(initValues.listed180),
      managerid: initValues.managerid?.split(','),
    };
  }

  // 提交时，如果是流程第`1`步，且是`可编辑`状态时，调用 applySubmit
  // 其他场景提交时，调用 auditSubmit
  applySubmit(values, file) {
    return this.formatData(values);
  }

  auditSubmit(values, file) {
    return this.formatData(values);
  }

  submitConfirm(values, next) {
    if (this.elementCode === '22' && !values.itemlist?.length) {
      this.antModal.confirm({
        title: '请确认',
        content: '未填写代销关系信息，确认提交吗？',
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
      return;
    }

    if (values.itemlist?.some((e) => e.msg)) {
      this.antMessage.info('代销机构存在错误信息，请检查');
      next(false);
      return;
    }

    if (values.sharelist.some((e) => e.islisted === '0')) {
      this.antMessage.info('份额信息是否上市请选择是');
      next(false);
      return;
    }

    next();
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  formatData(values) {
    return {
      ...values,
      listed60: toggleSignType(values.listed60),
      listed130: toggleSignType(values.listed130),
      listed180: toggleSignType(values.listed180),
      managerid: values.managerid?.join(',') ?? '',
      issueDocfile: this.formatFiles(values.issueDocfile),
      listedAnnFile: this.formatFiles(values.listedAnnFile),
      issueNoticeFile: this.formatFiles(values.issueNoticeFile),
      listedLetterFile: this.formatFiles(values.listedLetterFile),
      positionInfoFile: this.formatFiles(values.positionInfoFile),
    };
  }

  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileId) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  generativeText() {
    const itemlist = this.formActions.getFieldValue('itemlist') || [];
    this.dispatcher.generateAgencyList({ itemlist, type: 0 }).then((res) => {
      if (fn.checkResponse(res)) {
        if (!res.data) {
          this.antMessage.error('生成失败');
          return;
        }
        this.antModal.info({
          icon: null,
          title: (
            <div>
              代销关系文档生成{' '}
              <Button size="small" type="link" onClick={() => copyText(res.data)}>
                复制文本
              </Button>
            </div>
          ),
          width: 800,
          okText: '关闭',
          content: (
            <Input.TextArea defaultValue={res.data} autoSize={{ minRows: 10, maxRows: 15 }} />
          ),
        });
      }
    });
  }

  get expressionScope() {
    return {
      changeAgencyTableOnSelect: (keys, rows) => {
        this.changeAgencySelectedkeys = keys;
      },
      changeAgencyTableRemove: () => {
        this.changeAgencySelectedkeys = [];
      },
      renderExtendButtons: () => {
        const [shareCodes, setSharecode] = useState([]);
        const editable = ['22'].includes(this.elementCode);
        const generateInfo = this.elementCode >= 22;
        return (
          <>
            {editable && (
              <ModalForm
                labelCol={{ span: 4 }}
                wrapperCol={{ span: 18 }}
                title={<div>新增代销关系 </div>}
                initialValues={{
                  agencyattr: '全部',
                }}
                layout="horizontal"
                modalProps={{ maskClosable: false, closable: false, destroyOnClose: true }}
                trigger={
                  <Button type="primary" size="small">
                    新增代销关系
                  </Button>
                }
                onFinish={async (values) => {
                  let result = true;
                  const itemList = this.formActions.getFieldValue('itemlist') || [];
                  let dataList = [];
                  values.funds &&
                    values.funds.some((a) => {
                      if (!result) {
                        return true;
                      }
                      values.agencys &&
                        values.agencys.some((b) => {
                          // 校验关系中 是否存在 互斥
                          let temp = itemList.find(
                            (c) => c.fundid === a.shareid && c.organinfoid === b.organinfoid,
                          );
                          if (temp) {
                            this.antMessage.info(
                              `代销关系不可冲突：关系中已包含【${temp.fundname}】-【${temp.companyname}】-【${temp.changetype}】`,
                            );
                            result = false;
                          }
                          if (!result) {
                            return true;
                          }
                          if (
                            !itemList.find(
                              (c) => c.fundid === a.fundid && c.organinfoid === b.organinfoid,
                            )
                          ) {
                            dataList.push({
                              id: uuid(),
                              organinfoid: b.organinfoid,
                              companytype: b.companytype,
                              companyname: b.companyname,
                              companycode: b.companycode,
                              partysimname: b.partysimname,
                              hotline: b.hotline,
                              website: b.website,
                              fundcode: a.value,
                              fundname: a.name,
                              fundid: a.shareid,
                              sharetype: a.sharetype,
                              mainfundcode: a.mainfundcode,
                              mainfundid: a.fundid,
                              mainfundname: a.mainfundname,
                              changetype: '代销关系建立',
                              agencyattr: values.agencyattr,
                              agencydate: '',
                            });
                          }
                        });
                    });
                  if (!result) {
                    return false;
                  }
                  dataList = [...itemList, ...dataList];
                  const sortList = sortBy(dataList, (item) => item.companycode);
                  this.formActions.setFieldValue('itemlist', sortList);
                  return true;
                }}
              >
                <ProFormSelect.SearchSelect
                  name="funds"
                  label="基金"
                  mode="multiple"
                  showSearch={false}
                  fieldProps={{
                    notFoundContent: null,
                    filterOption: () => true,
                    autoClearSearchValue: false,
                  }}
                  rules={[{ required: true, message: '请选择基金' }]}
                  placeholder="请输入基金代码、名称或类型搜索"
                  debounceTime={300}
                  request={async ({ keyWords }) => {
                    const sharelist = this.formActions.getFieldValue('sharelist') || [];
                    const mainfundcode = this.formActions.getFieldValue('fundcode') || '';
                    if (sharelist && Array.isArray(sharelist)) {
                      const data = sharelist
                        .map((a) => ({
                          label: (
                            <span>
                              {a.fundname}[{a.fundcode}]{' '}
                              <b style={{ float: 'right' }}>{a.businesstype}</b>
                            </span>
                          ),
                          value: a.fundcode,
                          name: a.fundname,
                          mainfundcode: mainfundcode,

                          id: uuid(),
                          ...a,
                        }))
                        .filter((a) => a.value);
                      this.prevFundsData = { keyword: keyWords, data: data };
                      return data;
                    }
                    return [];
                  }}
                />
                <ProFormSelect.SearchSelect
                  name="agencys"
                  label="代销机构"
                  showSearch={false}
                  fieldProps={{
                    notFoundContent: null,
                    filterOption: () => true,
                    autoClearSearchValue: false,
                  }}
                  debounceTime={300}
                  mode="multiple"
                  rules={[{ required: true, message: '请选择代销机构' }]}
                  placeholder="请输入代销机构名称或编号搜索"
                  request={async ({ keyWords }) => {
                    const res = await this.dispatcher.agencyList({
                      keyword: keyWords || '',
                      businesstype: '代销机构',
                      page: 1,
                      size: 100,
                    });
                    if (res.data && Array.isArray(res.data)) {
                      let resData = res.data
                        .filter((a) => a.businesstype === '代销机构')
                        .map((a) => ({
                          label: a.companyname,
                          value: a.organinfoid,
                          ...a,
                        }));
                      this.prevAgencysData = { keyword: keyWords, data: resData };
                      return resData;
                    }
                    return [];
                  }}
                />
                <ProFormSelect
                  name="agencyattr"
                  label="代销属性"
                  rules={[{ required: true, message: '请选择代销属性' }]}
                  placeholder="请选择代销属性"
                  request={async () => {
                    const res = await this.dispatcher.dictList({
                      dictids: '4767de5ffc244840971c6403a14e85d0',
                    });
                    if (
                      res.data &&
                      Array.isArray(res.data) &&
                      res.data.length > 0 &&
                      Array.isArray(res.data[0].children)
                    ) {
                      return res.data[0].children.map((a) => ({ ...a, ...{ label: a.name } }));
                    }
                    return [];
                  }}
                />
              </ModalForm>
            )}

            {(() => {
              const [visible, setVisible] = useState(false);
              if (editable) {
                return (
                  <ModalForm
                    labelCol={{ span: 10 }}
                    wrapperCol={{ span: 14 }}
                    title="设置代销时间"
                    visible={visible}
                    layout="horizontal"
                    modalProps={{ maskClosable: false, closable: false, width: 420 }}
                    onVisibleChange={(visible) => !visible && setVisible(false)}
                    trigger={
                      <Button
                        type="primary"
                        size="small"
                        onClick={() => {
                          if ((this.changeAgencySelectedkeys || []).length < 1) {
                            this.antMessage.info('请先选择要设置的行');
                            return;
                          }
                          setVisible(true);
                        }}
                      >
                        设置代销时间
                      </Button>
                    }
                    onFinish={async (values) => {
                      const itemList = this.formActions.getFieldValue('itemlist') || [];
                      itemList.forEach((a, i) => {
                        if ((this.changeAgencySelectedkeys || []).includes(i)) {
                          this.formActions.setFieldValue(
                            `itemlist.${i}.agencydate`,
                            values.agencydate,
                          );
                        }
                      });
                      return true;
                    }}
                  >
                    <ProFormDatePicker
                      name="agencydate"
                      label="代销上线/下线日期"
                      style={{ width: 300 }}
                      rules={[{ required: true, message: '请选择日期' }]}
                      placeholder="请选择日期"
                    />
                  </ModalForm>
                );
              }
            })()}

            {editable && (
              <Upload
                accept=".xls,.xlsx"
                multiple={true}
                messageShowType={MessageShowType.None}
                uploadFunc={importAgency}
                beforeUpload={() => {
                  const { getFieldValue } = this.formActions;
                  const sharelist = getFieldValue('sharelist') || [];
                  const newFundcode = [];
                  sharelist.map((item) => {
                    return newFundcode.push(item.fundcode);
                  });
                  setSharecode(newFundcode);
                }}
                data={{ fundcode: shareCodes.join(';') }}
                onSuccess={({ fileList, file }) => {
                  const { getFieldValue, setFieldValue } = this.formActions;
                  if (file && file.status === 'done') {
                    let exportItemList = getFieldValue('itemlist') || [];
                    let newExportItemList = [];
                    file.response.forEach((item) => {
                      const tmp = (exportItemList || []).find(
                        (b) => b.organinfoid === item.organinfoid,
                      );
                      // organinfoid 通过机构id进行过滤
                      if (!tmp) {
                        newExportItemList.push({
                          id: uuid(),
                          organinfoid: item.organinfoid,
                          companytype: item.companytype,
                          companyname: item.companyname,
                          companycode: item.companycode,
                          partysimname: item.partysimname,
                          hotline: item.hotline,
                          website: item.website,
                          fundcode: item.fundcode,
                          fundname: item.fundname,
                          fundid: item.fundid,
                          sharetype: item.sharetype,
                          mainfundcode: item.mainfundcode,
                          mainfundid: item.mainfundid,
                          mainfundname: item.mainfundname,
                          agencyattr: item.agencyattr,
                          agencydate: item.agencydate,
                          changetype: '代销关系建立',
                          msg: item.msg,
                        });
                      } else {
                        tmp.companytype = item.companytype;
                        tmp.companyname = item.companyname;
                        tmp.companycode = item.companycode;
                        tmp.partysimname = item.partysimname;
                        tmp.hotline = item.hotline;
                        tmp.website = item.website;
                        tmp.fundcode = item.fundcode;
                        tmp.fundname = item.fundname;
                        tmp.fundid = item.fundid;
                        tmp.sharetype = item.sharetype;
                        tmp.mainfundcode = item.mainfundcode;
                        tmp.mainfundid = item.mainfundid;
                        tmp.mainfundname = item.mainfundname;
                        tmp.agencyattr = item.agencyattr;
                        tmp.agencydate = item.agencydate;
                        tmp.changetype = '代销关系建立';
                        tmp.msg = item.msg;
                      }
                    });
                    newExportItemList = [...exportItemList, ...newExportItemList];
                    setFieldValue('itemlist', newExportItemList);
                  } else {
                    this.antMessage.loading('解析出错了~', 3);
                  }
                }}
                showUploadList={false}
                isFsfund={true}
              >
                <Button type="primary" size="small">
                  批量导入代销机构
                </Button>
              </Upload>
            )}

            {generateInfo && (
              <Button
                type="primary"
                size="small"
                onClick={() => {
                  const itemList = this.formActions.getFieldValue('itemlist') || [];
                  this.dispatcher.generateAgencyList({
                    itemlist: itemList,
                    type: 1,
                    filename: '代销机构清单.xls',
                  });
                }}
              >
                生成列表信息及基本信息
              </Button>
            )}

            {generateInfo && !isMobile() && (
              <Button
                type="primary"
                size="small"
                onClick={() => {
                  this.generativeText();
                }}
              >
                生成文本
              </Button>
            )}

            {editable && (
              <Download
                fileName="批量导入代销机构模板.xlsx"
                url={`${baseURL}/template/dossier/changeAgecyUploadMode.xlsx`}
              >
                <Button type="link">下载模板</Button>
              </Download>
            )}
          </>
        );
      },
      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
    };
  }
}
