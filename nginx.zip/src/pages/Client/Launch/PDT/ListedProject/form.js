import React from 'react';
import { Field } from 'formily-antd';
import { FormMegaLayout } from '@formily/antd-components';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import { useMegaLayoutProps } from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { useFieldsList } from './data';
import { renderSign } from '../../utils';

function Form(props) {
  const {
    context: { getProcess },
  } = props;
  const { readOnlyFlag, elementCode } = getProcess() || {};

  const megaProps = {
    labelWidth: 160,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };

  const megaLayoutProps = useMegaLayoutProps(megaProps);

  const { baseInfo, fundsInfo, shareList, fundSaleInfo, fundType, saleProxy, referencePrice } =
    useFieldsList();

  // 公告(文件)上传模块
  const renderFileCard = (title, name, code) => {
    let display = Number(elementCode) >= code[0];

    return (
      <BaseFormCard title={title} megaLayout={megaProps} display={display} name={`${name}Card`}>
        <Field
          title={`${title}文件`}
          name={name}
          type="bpm-upload-list"
          editable={code.includes(Number(elementCode)) && !readOnlyFlag}
          required={code.includes(Number(elementCode))}
          x-component-props={{
            onSuccess: `{{fileSuccess("${name}")}}`,
            onDel: `{{fileDel("${name}")}}`,
            accept: '',
            multiple: true,
            isFsfund: true,
            maxLength: 4,
          }}
          x-mega-props={{ span: 2 }}
        />
      </BaseFormCard>
    );
  };

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        {baseInfo.map((e) => (
          <Field key={e.name} type={e.type ?? 'string'} editable={false} {...e} />
        ))}
      </BasicFormCard>

      <BasicFormCard title="基金信息" megaProps={megaProps}>
        {fundsInfo.map((e) => (
          <Field
            key={e.name}
            type={e.type ?? 'string'}
            {...e}
            x-component-props={{
              ...e['x-component-props'],
              placeholder: `请${['string', 'number'].includes(e.type) ? '输入' : '选择'}${e.title}`,
            }}
          />
        ))}
      </BasicFormCard>

      <BasicFormCard title="份额信息" megaLayout={false}>
        <Field
          name="sharelist"
          minItems={1}
          maxItems={5}
          type="array"
          default={[{}]}
          x-component="bpm-array-card"
          x-component-props={{
            title: '份额',
            titlefield: 'fundname',
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderRemove: () => null,
            renderAddition: () => null,
          }}
        >
          <Field type="object">
            <FormMegaLayout {...megaLayoutProps}>
              {shareList.map((e) => (
                <Field
                  key={e.name}
                  type={e.type ?? 'string'}
                  {...e}
                  x-component-props={{
                    ...e['x-component-props'],
                    placeholder: `请${
                      ['string', 'number', undefined].includes(e.type) ? '输入' : '选择'
                    }${e.title}`,
                  }}
                />
              ))}
            </FormMegaLayout>
          </Field>
        </Field>
      </BasicFormCard>

      <BasicFormCard title="基金发售信息" megaProps={megaProps}>
        {fundSaleInfo.map((e) => (
          <Field key={e.name} type="date" {...e} x-component-props={{ format: 'YYYY-MM-DD' }} />
        ))}
      </BasicFormCard>

      <BaseFormCard
        title="基金类型"
        name="fundTypeCard"
        megaProps={megaProps}
        upDown={elementCode > 20 ? 'up' : 'down'}
      >
        {fundType.map((e) => {
          return (
            <Field
              key={e.name}
              type={e.type ?? 'string'}
              {...e}
              x-component-props={{
                ...e['x-component-props'],
                placeholder: `请选择${e.title}`,
              }}
            />
          );
        })}
      </BaseFormCard>

      {renderFileCard('上市资料', 'issueDocfile', [10, 30])}
      {renderFileCard('上市回函', 'listedLetterFile', [100])}
      {renderFileCard('上市类公告', 'listedAnnFile', [110])}
      {renderFileCard('上市提示公告', 'issueNoticeFile', [160])}

      {renderSign({
        name: 'listed60',
        title: '资料会签',
        display: elementCode >= 30,
        editable: elementCode === '30' && !readOnlyFlag,
        upDown: elementCode >= 90 ? 'up' : 'down',
        isseal: {
          show: true,
        },
      })}
      {renderSign({
        name: 'listed130',
        title: '上市公告会签',
        display: elementCode >= 110,
        editable: elementCode === '110' && !readOnlyFlag,
        upDown: elementCode >= 150 ? 'up' : 'down',
        isseal: {
          show: true,
        },
      })}
      {renderSign({
        name: 'listed180',
        title: '上市提示公告会签',
        display: elementCode >= 160,
        editable: elementCode === '160' && !readOnlyFlag,
        upDown: elementCode >= 200 ? 'up' : 'down',
        isseal: {
          show: true,
        },
      })}

      <BaseFormCard
        title="代销关系信息"
        megaLayout={false}
        name="iteminfo"
        visible={elementCode >= 22}
        upDown={elementCode > 30 ? 'up' : 'down'}
      >
        <Field
          name="itemlist"
          type="array"
          x-component="form-table"
          visible={elementCode >= 22}
          editable={elementCode >= 22 && !readOnlyFlag}
          x-component-props={{
            operationsWidth: 80,
            selectedAllRows: true,
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            renderRemove: elementCode > 22 ? () => null : undefined,
            onSelect: '{{changeAgencyTableOnSelect}}',
            renderExtendButtons: '{{renderExtendButtons}}',
            onRemove: '{{changeAgencyTableRemove}}',
          }}
        >
          <Field type="object">
            {saleProxy.map((e) => (
              <Field
                key={e.name}
                {...e}
                type={e.type ?? 'string'}
                {...(elementCode > 22 ? { editable: false } : {})}
              />
            ))}
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        title="上市首日参考价"
        megaProps={megaProps}
        name="referencePriceCard"
        visible={elementCode >= 220}
      >
        {referencePrice.map((e) => {
          return (
            <Field
              key={e.name}
              type={e.type ?? 'string'}
              {...e}
              // editable={true}
              editable={elementCode == 220 && !readOnlyFlag}
              x-component-props={{
                ...e['x-component-props'],
                placeholder: `请${
                  ['string', 'number', undefined].includes(e.type) ? '输入' : '选择'
                }${e.title}`,
              }}
            />
          );
        })}
      </BaseFormCard>
    </>
  );
}

export default Form;
