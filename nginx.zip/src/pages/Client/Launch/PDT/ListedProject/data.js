import React from 'react';
import {
  // useMegaLayoutProps,
  useDictList,
  useManagerList,
  useAgencyList,
  useTreeSelect,
  // useTreeDepartment,
  // useTreeUser,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import { listAgency } from 'common/axios';

const comProps = {
  size: 'middle',
};

export const useFieldsList = () => {
  const businessTypeProps = useDictList({ id: '9cd915e33daf4cd78430e8499642c39f' });
  const managerProps = useManagerList({ multiple: true, tokenSeparators: [','] });
  const riskLevelProps = useDictList({ id: '81e87383a78a486091eef2183e0cf163' });
  const currencyProps = useDictList({ id: '80e7fe7b84374cceb7fc921d4cf0362e' });
  const listingPlaceProps = useDictList({ id: '5ad101e1b15b466db717de898ab426bc' });
  const listingTypeProps = useDictList({ id: '3dfa7cb6cd474c4480457266aa402300' });
  const listFundsType = useDictList({ id: '086af717-93d2-4a11-ad4d-04cb8e576c85' });
  const indexfundtypeProps = useDictList({ id: '659ef3ea68d843c8ba2900029e3a288a' });
  const fundmanagerOpts = useTreeSelect({
    request: () => async () => {
      const res = await listAgency({ businesstype: '基金管理人', page: 1, size: 100 });
      if (Array.isArray(res.data)) {
        return res.data.map((a) => ({
          value: a.organinfoid,
          label: a.companyname,
        }));
      }
      return [];
    },
  });

  const baseInfo = [
    {
      name: 'code',
      title: '单据编号',
      default: '单据提交后自动生成',
    },
    {
      name: 'applydate',
      type: 'date',
      title: '申请日期',
      'x-component-props': { format: 'YYYY-MM-DD' },
    },
    {
      name: 'applyusername',
      title: '申请人',
    },
    {
      name: 'applydepartmentname',
      title: '所属部门',
    },
  ];

  const fundsInfo = [
    {
      name: 'fundcode',
      title: '基金代码',
      required: true,
    },
    {
      name: 'fundname',
      title: '基金名称',
      required: true,
    },
    {
      name: 'fundinnershortname',
      title: '基金简称',
      required: true,
    },
    {
      name: 'fundshortname',
      title: '信披简称',
    },
    {
      name: 'businesstype',
      title: '基金类别',
      required: true,
      type: 'tree-select',
      'x-component-props': {
        ...businessTypeProps,
      },
    },
    // FIXME: SuperTreeSelect 组件报错
    {
      name: 'managerid',
      title: '基金经理',
      required: true,
      type: 'tree-select',
      'x-component-props': {
        ...comProps,
        ...managerProps,
        optionFilterProp: 'label',
      },
    },
    {
      name: 'trusteeid',
      title: '托管人',
      required: true,
      type: 'tree-select',
      'x-component-props': {
        optionFilterProp: 'label',
        ...useAgencyList({ type: '托管人' }),
      },
    },
    {
      name: 'abroadfundcustodianid',
      title: '境外托管人',
      type: 'tree-select',
      'x-component-props': {
        optionFilterProp: 'label',
        ...useAgencyList({ type: '境外托管人' }),
      },
    },
    {
      name: 'risklevel',
      title: '基金风险等级',
      required: true,
      type: 'tree-select',
      'x-component-props': {
        ...comProps,
        ...riskLevelProps,
      },
    },
    {
      name: 'fundmanagerid',
      title: '基金管理人',
      required: true,
      type: 'tree-select',
      'x-component-props': {
        ...comProps,
        ...fundmanagerOpts,
        optionFilterProp: 'label',
      },
    },
  ];

  const shareList = [
    {
      name: 'ismainshare',
      title: '是否主份额',
      required: true,
      enum: [
        { label: '是', value: '1' },
        { label: '否', value: '0' },
      ],
    },
    {
      name: 'sharetype',
      title: '份额类型',
      required: true,
      enum: [
        { label: 'A', value: 'A' },
        { label: 'B', value: 'B' },
        { label: 'C', value: 'C' },
        { label: 'E', value: 'E' },
      ],
    },
    {
      name: 'fundcode',
      title: '份额代码',
      required: true,
    },
    {
      name: 'fundname',
      title: '网站简称',
      required: true,
    },
    {
      name: 'fundshortname',
      title: '信披简称',
      required: true,
    },
    {
      name: 'floortradecode',
      title: '份额场内代码',
    },
    {
      name: 'floortradename',
      title: '份额场内简称',
    },
    {
      name: 'currency',
      title: '交易币种',
      default: '人民币',
      type: 'tree-select',
      'x-component-props': {
        ...currencyProps,
      },
    },
    {
      name: 'islisted',
      title: '是否上市',
      required: true,
      enum: [
        { label: '是', value: '1' },
        { label: '否', value: '0' },
      ],
    },
    {
      name: 'listingplace',
      title: '上市场所',
      type: 'tree-select',
      'x-component-props': {
        ...listingPlaceProps,
      },
    },
    {
      name: 'listingtype',
      title: '上市基金类型',
      display: false,
      type: 'tree-select',
      'x-component-props': {
        ...listingTypeProps,
      },
    },
    {
      name: 'listingdate',
      title: '上市日期',
      display: false,
      type: 'date',
      'x-component-props': {
        format: 'YYYY-MM-DD',
      },
    },
    {
      name: 'salesfee',
      title: '销售服务费率',
      type: 'number',
      'x-component-props': {
        min: 0,
        max: 100,
        precision: 2,
        formatter: (value) => value && `${value}%`,
        parser: (value) => value.replace('%', ''),
      },
    },
  ];

  const fundSaleInfo = [
    {
      name: 'issuestartdate',
      title: '募集开始日(T日)',
      editable: false,
    },
    {
      name: 'issueenddate',
      title: '募集结束日(R日)',
      editable: false,
    },
    {
      name: 'realsetupdate',
      title: '实际基金成立日(P日)',
      editable: false,
    },
    {
      name: 'openday',
      title: '开放日(Q日)',
      editable: false,
    },
    {
      name: 'openanndate',
      title: '首次开放日公告日期',
    },
  ];

  const fundType = [
    {
      name: 'isinitiatingfund',
      title: '是否发起式基金',
      required: true,
      enum: [
        { label: '是', value: '1' },
        { label: '否', value: '0' },
      ],
    },
    {
      name: 'fundtype',
      title: '基金类型',
      type: 'tree-select',
      required: true,
      'x-component-props': {
        ...listFundsType,
      },
    },
    {
      name: 'isqdii',
      title: '是否QDII基金',
      required: true,
      enum: [
        { label: '是', value: '1' },
        { label: '否', value: '0' },
      ],
    },
    {
      name: 'isinstitutionpdt',
      title: '是否机构类产品',
      required: true,
      enum: [
        { label: '是', value: '1' },
        { label: '否', value: '0' },
      ],
    },
    {
      name: 'ismoreshares',
      title: '是否多份额类基金',
      required: true,
      enum: [
        { label: '是', value: '1' },
        { label: '否', value: '0' },
      ],
    },
    {
      name: 'isfuturesfunc',
      title: '是否需要期货功能',
      required: true,
      enum: [
        { label: '是', value: '1' },
        { label: '否', value: '0' },
      ],
    },
    {
      name: 'isindexfund',
      title: '是否为指数基金',
      required: true,
      enum: [
        { label: '是', value: '1' },
        { label: '否', value: '0' },
      ],
    },
    { name: 'targetindexcode', title: '标的指数代码', required: true },
    { name: 'targetindexname', title: '标的指数名称', required: true },
    { name: 'indexorganization', title: '指数公司', required: true },
    {
      name: 'indexfundtype',
      title: '指数基金类型',
      type: 'tree-select',
      required: true,
      'x-component-props': {
        ...indexfundtypeProps,
      },
    },
    { name: 'goalfundname', title: '目标基金名称', required: true },
    { name: 'goalfundcode', title: '目标基金代码', required: true },
    { name: 'basketcode', title: 'ETF定义文件编码', required: true },
  ];

  const saleProxy = [
    { name: 'fundcode', title: '基金代码', editable: false },
    { name: 'fundname', title: '基金名称', editable: false },
    { name: 'companycode', title: '机构代码', editable: false },
    { name: 'companyname', title: '机构名称', editable: false },
    { name: 'companytype', title: '机构类型', editable: false },
    { name: 'changetype', title: '操作类型', editable: false },
    { name: 'agencyattr', title: '代销属性', editable: false },
    { name: 'agencydate', title: '上线日期', type: 'date', required: true },
    {
      name: 'msg',
      title: '错误信息提示',
      editable: false,
      'x-component-props': {
        renderLabel: (_, record) => <span style={{ color: 'red' }}>{record.msg}</span>,
      },
    },
  ];

  const referencePrice = [
    {
      name: 'curNav',
      title: '上市首日参考价',
      required: true,
      pattern: /^\d+(\.\d{1,4})?$/,
    },
    {
      name: 'curPosition',
      title: '仓位(%)',
      required: true,
      display: false,
      pattern: /^\d+(\.\d{1,4})?$/,
    },
    {
      name: 'positionInfoFile',
      title: '仓位信息资料',
      required: true,
      display: false,
      type: 'bpm-upload-list',
      'x-mega-props': { span: 2 },
      'x-component-props': {
        onSuccess: `{{fileSuccess("positionInfoFile")}}`,
        onDel: `{{fileDel("positionInfoFile")}}`,
        accept: '',
        multiple: true,
        isFsfund: true,
        maxLength: 4,
      },
    },
  ];
  return { baseInfo, fundsInfo, shareList, fundSaleInfo, fundType, saleProxy, referencePrice };
};
