/* eslint-disable array-callback-return */
import React from 'react';
import { FormPath, FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import { Select, Space } from 'antd';
import store from '@/store';
import { toggleSignType } from '../../utils';
import { codeInRange } from './form';
const { onFieldValueChange$, onFieldInputChange$, onFieldInit$ } = FormEffectHooks;

// 会签节点
const signNode = ['declare32', 'declare42', 'declare74', 'declare82', 'declare110', 'declare160'];

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag, readOnlyFlag, processId } = getProcess() || {};
    this.processId = processId;
    this.managerid = null;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.orgDispatcher = store.useModelDispatchers('org');
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
    this.itemList = [];
    this.agencyMember = ''; // 退回人员
  }

  createFormEffects() {
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      onFieldInit$('fundmanagerid').subscribe(({ value }) => {
        if (typeof value === 'string') {
          const arr = (value || '').split(',');
          if (arr.length > 0) {
            setFieldValue('fundmanagerid', arr);
          }
        }
      });
      onFieldInputChange$('fundmanagerid').subscribe(({ value, values }) => {
        if (Array.isArray(values) && values.length > 0) {
          const account = (values[1].data || []).map((a) => a.account).join(';');
          setFieldValue('lawfileapprover', account);
        }
      });

      onFieldInputChange$('fundname').subscribe(({ value }) => {
        setFieldValue('sharelist.0.fundname', value);
      });

      onFieldInputChange$('fundshortname').subscribe(({ value }) => {
        setFieldValue('sharelist.0.fundshortname', value);
      });

      onFieldValueChange$('sharelist.*.islisted').subscribe((fieldState) => {
        const index = FormPath.transform(fieldState.name, /\d/, (index) => index);
        setFieldState(
          `*(sharelist.${index}.listingplace,sharelist.${index}.listingtype,sharelist.${index}.floortradename)`,
          (state) => {
            state.visible = fieldState.value === '1';
          },
        );
        if (fieldState.value && Number(fieldState.value) === 1) {
          setFieldState(
            `*(sharelist.${index}.subscribelist,sharelist.${index}.purchaselist,sharelist.${index}.redemptionlist)`,
            (s) => {
              s.props['x-component-props'].visibleColumns = [{ name: 'sharetype', visible: true }];
            },
          );
        } else {
          setFieldState(
            `*(sharelist.${index}.subscribelist,sharelist.${index}.purchaselist,sharelist.${index}.redemptionlist)`,
            (s) => {
              s.props['x-component-props'].visibleColumns = [{ name: 'sharetype', visible: false }];
            },
          );
        }
      });

      // 是否多份额 根据份额数量联动
      onFieldValueChange$('sharelist').subscribe((s) => {
        console.log('sharelist=====>', (s.value || []).length > 1 ? '1' : '0');
        setFieldValue('ismoreshares', (s.value || []).length > 1 ? '1' : '0');
      });

      // 是否指数基金
      onFieldValueChange$('isindexfund').subscribe(async ({ value, values }) => {
        if (value && Number(value) === 1) {
          setFieldState(
            '*(indexfundtype,targetindexcode,targetindexname,indexorganization)',
            (state) => {
              state.visible = true;
            },
          );
        } else {
          setFieldState(
            '*(indexfundtype,targetindexcode,targetindexname,indexorganization)',
            (state) => {
              state.visible = false;
            },
          );
        }
      });

      // 募集开始日期清空， 募集结束日也自动清空，否则会造成开始日选不到后面日期
      onFieldValueChange$('issuestartdate').subscribe(async ({ value }) => {
        if (!value) {
          setFieldValue('issueenddate', undefined);
        }
      });

      // 指数基金类型
      onFieldValueChange$('indexfundtype').subscribe(async ({ value }) => {
        setFieldState('*(goalfundcode,goalfundname)', (state) => {
          state.visible = value === 'ETF联接基金';
        });
        setFieldState('basketcode', (state) => {
          state.visible = value === 'ETF';
        });
      });

      onFieldInit$('*(bitype)').subscribe(({ value, name }) => {
        if (value) {
          if (value.length === 4) {
            setFieldValue(name, [value]);
          }
          if (value.length === 6) {
            setFieldValue(name, [value.substr(0, 4), value]);
          }
          if (value.length === 8) {
            setFieldValue(name, [value.substr(0, 4), value.substr(0, 6), value]);
          }
        }
      });

      // 如果是发起基金, 发起份额承诺函 必填
      onFieldInit$('isinitiatingfund').subscribe(({ value }) => {
        setFieldState('subcmtLetters', (state) => {
          state.display = value === '1';
        });
      });
      // 是否为指数基金
      onFieldInit$('isindexfund').subscribe(({ value }) => {
        setFieldState('*(indxauthuseagmtsCard,declare32Card)', (state) => {
          state.display =
            (value === '1' && codeInRange(this.elementCode, 30, 39)) || this.elementCode >= 100;
        });
      });
      // 是否是场内基金
      onFieldInit$('isexchinfund').subscribe(({ value }) => {
        setFieldState('*(exchnoobjlettersCard,declare42Card)', (state) => {
          state.display =
            (value === '1' && codeInRange(this.elementCode, 40, 49)) || this.elementCode >= 100;
        });
      });
      // 会计事务所 是否显示
      onFieldInit$('accountingfirmid').subscribe(({ value }) => {
        setFieldState('accountingfirmid', (state) => {
          state.display = Number(this.elementCode) === 14 || (this.elementCode > 14 && value);
        });
      });
    };
  }

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }

  setBiType = (value) => {
    if (Array.isArray(value)) {
      return value.slice(-1).join();
    }
    return value;
  };

  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileid) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  getBiType = (value) => {
    if (value) {
      return [value.substr(0, 4), value.substr(0, 6), value];
    }
    return value;
  };

  toggleSign = (values) => {
    return signNode.reduce((prev, next) => {
      prev[next] = toggleSignType(values[next]);
      return prev;
    }, {});
  };

  formatData(values) {
    return {
      ...values,
      ...this.toggleSign(values),
      apprvdept: values.apprvdept?.join(),
      apprvuser: values.apprvuser?.join(),
      apprvnoticeuser: values.apprvnoticeuser?.join(),

      managerofficefiles: this.formatFiles(values.managerofficefiles),
      subcmtLetters: this.formatFiles(values.subcmtLetters),
      indxauthuseagmts: this.formatFiles(values.indxauthuseagmts),
      exchnoobjletters: this.formatFiles(values.exchnoobjletters),
      trustagmtfiles: this.formatFiles(values.trustagmtfiles),
      contrfiles: this.formatFiles(values.contrfiles),
      fundprodgeneralfiles: this.formatFiles(values.fundprodgeneralfiles),
      elsefiles: this.formatFiles(values.elsefiles),
      liquidityfiles: this.formatFiles(values.liquidityfiles),
      riskfiles: this.formatFiles(values.riskfiles),
      commitmentfiles: this.formatFiles(values.commitmentfiles),
      fundmgrdeclareprocessoverletters: this.formatFiles(values.fundmgrdeclareprocessoverletters),
      rpttrustagmtfiles: this.formatFiles(values.rpttrustagmtfiles),
      rptcontrfiles: this.formatFiles(values.rptcontrfiles),
      rptfundprodgeneralfiles: this.formatFiles(values.rptfundprodgeneralfiles),
      recruitmanualfiles: this.formatFiles(values.recruitmanualfiles),
      rptelsefiles: this.formatFiles(values.rptelsefiles),
      apprvfiles: this.formatFiles(values.apprvfiles),
      risklawyerfiles: this.formatFiles(values.risklawyerfiles),
      riskrptfiles: this.formatFiles(values.riskrptfiles),
      revokefiles: this.formatFiles(values.revokefiles),
      prodapprvmaterialfiles: this.formatFiles(values.prodapprvmaterialfiles),

      sharelist: values.sharelist,
      fundmanagerid: this.joinArray(values.fundmanagerid),
      bitype: this.setBiType(values.bitype),
    };
  }

  applyFormatData(values) {
    values = {
      ...values,
      ...this.toggleSign(values),
      apprvdept: values.apprvdept?.split(','),
      apprvuser: values.apprvuser?.split(','),
      apprvnoticeuser: values.apprvnoticeuser?.split(','),
    };
    if (this.formData.status && Number(this.formData.status) === 1) {
      return {
        ...values,
      };
    }
    if (!this.formData.status && this.formData.fundid) {
      return {
        ...values,
      };
    }

    if (!this.formData.fundid) {
      // 复制份额
      const sharelist = [];
      if (
        this.formData.sharelist &&
        Array.isArray(this.formData.sharelist) &&
        this.formData.sharelist.length > 0
      ) {
        this.formData.sharelist.map((item) => {
          return sharelist.push({
            ...item,
            fundcode: '',
            fundname: '',
            fundshortname: '',
          });
        });
      }
      return {
        ...values,
        fundname: '',
        fundcode: '',
        fundshortname: '',
        trusteeid: '',
        fundmanagerid: [],
        // investgoal: '',
        // assetallratio: '',
        issuestartdate: '',
        issueenddate: '',
        raisedown: '',
        raiseup: '',
        approvaldate: '',
        docnumber: '',
        sharelist: sharelist,
      };
    }
  }

  auditFormatData(values) {
    return {
      ...values,
      ...this.toggleSign(values),
      apprvdept: values.apprvdept?.split(','),
      apprvuser: values.apprvuser?.split(','),
      apprvnoticeuser: values.apprvnoticeuser?.split(','),
    };
  }

  // 退回
  async backTo(values, next) {
    const _this = this;

    const allUsers = await _this.orgDispatcher.users();
    const allUserMap = {};

    allUsers.data?.forEach((item) => {
      allUserMap[item.id] = item;
    });
    const options = _this.formData.agencyMember?.split(';')?.reduce((prev, id) => {
      if (!id) {
        return prev;
      }
      prev.push({
        label: allUserMap[id]?.userName,
        value: id,
      });
      return prev;
    }, []);

    _this.antModal.confirm({
      title: null,
      icon: null,
      content: (
        <Space>
          <div>退回人员</div>
          <Select
            allowClear
            mode="multiple"
            placeholder="请选择"
            style={{ width: 200 }}
            onChange={(selectList) => {
              _this.agencyMember = selectList.join(';');
            }}
            options={options}
          />
        </Space>
      ),
      onOk(close) {
        if (!_this.agencyMember) {
          _this.antMessage.warning('请选择退回人员');
          return;
        }
        values.agencyMember = _this.agencyMember;
        close();
        next(true);
      },
      onCancel(close) {
        close();
        next(false);
      },
    });
  }

  applySubmit(values) {
    const result = values;
    console.log('提交前数据1：', values);
    let data = this.formatData(result);
    console.log('提交前数据2：', data);
    return data;
  }

  auditSubmit(values) {
    console.log('提交前数据3：', values);
    const result = values;
    let data = this.formatData(result);
    console.log('提交前数据4：', data);
    return data;
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  submitConfirm(values, next, { actionName }) {
    // 审批部门，审批人必填一项
    if (this.elementCode === '50' && !values.apprvdept && !values.apprvuser) {
      this.antMessage.warning('请选择审批部门或审批人');
      next(false);
      return;
    }

    // 会签部门，会签人必填一项
    for (const node of signNode) {
      const { countersignusers, countersigndeparts } = values[node] || {};

      if (!countersignusers && !countersigndeparts) {
        this.antMessage.warning('请选择会签部门或会签人');
        next(false);
        return;
      }
    }

    if (this.pageStatus.firstEditable || this.pageStatus.applyEditable) {
      this.antModal.confirm({
        title: '请确认',
        content: (
          <div style={{ color: 'red' }}>
            <div>请仔细确认您所填写的内容是否正确，如果送审，系统将不支持手工撤单；</div>
            <ul style={{ paddingLeft: '25px' }}>
              <li>如果确认送审 ，请点击“是”，</li>
              <li>否则请点击“否”，重新填写相关内容。</li>
            </ul>
          </div>
        ),
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
    } else {
      next(true);
    }
  }

  get expressionScope() {
    return {
      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },

      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
    };
  }
}
