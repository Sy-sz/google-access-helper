import React from 'react';
import Form from './form';
import Effects from './effects';
import BaseForm from '@chinahorm/web-components/es/components/BaseForm';

function Index(props) {
  const formEffects = new Effects(props);
  return (
    <BaseForm formEffects={formEffects} {...props}>
      <Form audit={formEffects.audit} formEffects={formEffects} {...props} />
    </BaseForm>
  );
}

export default Index;
