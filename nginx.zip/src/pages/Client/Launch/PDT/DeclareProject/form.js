/* eslint-disable complexity */
/** 申报流程 */
import React from 'react';
import { Field, FormSlot } from 'formily-antd';
import { FormMegaLayout } from '@formily/antd-components';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { DeleteOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { Button, Tooltip } from 'antd';
import {
  useMegaLayoutProps,
  useDictList,
  useManagerList,
  useAgencyList,
  useTreeDepartment,
  useTreeUser,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import { renderSign } from '@/pages/Client/Launch/utils';

/** 风险等级 */
const riskLevel = [
  { label: 'R1', value: 'R1' },
  { label: 'R2', value: 'R2' },
  { label: 'R3', value: 'R3' },
  { label: 'R4', value: 'R4' },
  { label: 'R5', value: 'R5' },
];

export const codeInRange = (code, min, max) => code >= min && code <= max;
const getFileProps = (name) => ({
  onSuccess: `{{fileSuccess("${name}")}}`,
  onDel: `{{fileDel("${name}")}}`,
  accept: '.pdf,.docx,.doc,.xls,.xlsx,.png,.jpg',
  multiple: true,
  isFsfund: true,
});

function Form(props) {
  const {
    context: { getProcess },
    formEffects: { formActions },
  } = props;
  const { elementCode, readOnlyFlag } = getProcess() || {};
  console.log('🚀 申报流程 elementCode:', elementCode);
  const comProps = {
    size: 'middle',
  };

  const megaProps = {
    labelWidth: 170,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };

  const megaLayoutProps = useMegaLayoutProps(megaProps);
  const managerProps = useManagerList({ multiple: true, tokenSeparators: [','] });
  const businessTypeProps = useDictList({ id: '9cd915e33daf4cd78430e8499642c39f' });
  // const riskLevelProps = useDictList({ id: '81e87383a78a486091eef2183e0cf163' });
  const indexfundtypeProps = useDictList({ id: '659ef3ea68d843c8ba2900029e3a288a' });
  const fundattributeProps = useDictList({ id: '086af717-93d2-4a11-ad4d-04cb8e576c85' });
  const listingPlaceProps = useDictList({ id: '5ad101e1b15b466db717de898ab426bc' });
  // const csrcFundTypeProps = useDictList({ id: 'f3e9f86d-c12c-44c9-bb02-38848e438bce' });
  const currencyProps = useDictList({ id: '80e7fe7b84374cceb7fc921d4cf0362e' });
  const listingTypeProps = useDictList({ id: '3dfa7cb6cd474c4480457266aa402300' });
  const biTypeProps = useDictList({
    type: 'cascader',
    multiple: true,
    id: 'e15090ac-bf96-467d-86b9-377ec8777368',
  });
  const deptMulProps = useTreeDepartment({
    multiple: true,
    type: undefined,
    tokenSeparators: [';'],
  });
  const userMulProps = useTreeUser({
    multiple: true,
    tokenSeparators: [';'],
  });

  const upInCode = (code) => (elementCode >= code ? 'up' : 'down');

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps} name="baseInfor">
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BaseFormCard title="基金信息" megaProps={megaProps} name="fundInfor">
        <Field name="fundid" type="string" display={false} required />
        <Field
          name="fundname"
          title="基金名称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金名称' }}
        />
        <Field
          name="fundshortname"
          title="基金信披简称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金信披简称' }}
        />
        <Field
          name="businesstype"
          title="基金类别"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金类别',
            previewPlaceholder: '-',
            ...businessTypeProps,
          }}
        />
        <Field
          name="fundmanagerid"
          title="基金经理"
          type="tree-select"
          required
          x-component-props={{
            ...comProps,
            placeholder: '请选择基金经理',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...managerProps,
          }}
        />
        <Field
          name="trusteeid"
          title="托管人"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择托管人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '托管人' }),
          }}
        />
        <Field
          name="abroadfundcustodianid"
          title="境外托管人"
          type="tree-select"
          x-component-props={{
            placeholder: '请选择境外托管人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '境外托管人' }),
          }}
        />
        <Field
          name="fundmanager"
          title="基金管理人"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金管理人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '基金管理人' }),
          }}
        />
        <Field
          name="lawfirmid"
          title="律师事务所"
          type="tree-select"
          x-component-props={{
            ...useAgencyList({ type: '律师事务所' }),
            placeholder: '请选择律师事务所',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="accountingfirmid"
          title="会计事务所"
          type="tree-select"
          required
          editable={elementCode === '14' && !readOnlyFlag}
          x-component-props={{
            ...useAgencyList({ type: '会计事务所' }),
            placeholder: '请选择会计事务所',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
          }}
        />
      </BaseFormCard>

      {/* 文件：立项资料 */}
      <BaseFormCard
        title="立项资料"
        name="projectInfoCard"
        megaLayout={megaProps}
        upDown={upInCode(13)}
      >
        <Field
          title="立项资料"
          name="prodapprvmaterialfiles"
          type="bpm-upload-list"
          x-component-props={{
            ...getFileProps('prodapprvmaterialfiles'),
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          name="prodapprvmaterialfilememo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      {/* 文件: 总经办决议文件 */}
      <BaseFormCard
        name="managerofficefilesCard"
        title="总经办决议"
        megaLayout={megaProps}
        upDown={elementCode > 16 ? 'up' : 'down'}
      >
        <Field
          title="总经办决议文件"
          name="managerofficefiles"
          type="bpm-upload-list"
          editable={['10', '16'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('managerofficefiles'),
          }}
          required={elementCode === '16'}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="mgrofficeresfilememo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={['10', '16'].includes(elementCode) && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      {/* 文件: 指数授权使用协议 30 */}
      <BaseFormCard
        title="指数授权使用协议"
        name="indxauthuseagmtsCard"
        megaLayout={megaProps}
        upDown={upInCode(100)}
      >
        <Field
          title="指数授权使用协议"
          name="indxauthuseagmts"
          type="bpm-upload-list"
          required
          editable={elementCode === '30' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('indxauthuseagmts'),
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          name="indxauthuseagmtmemo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '30' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>
      {/* 会签 */}
      {renderSign({
        name: 'declare32',
        title: '指数授权使用协议会签',
        showAuditcountersignusers: false,
        editable: elementCode === '30' && !readOnlyFlag,
        upDown: upInCode(100),
      })}

      {/* 文件: 交易所无异议函 40 */}
      <BaseFormCard
        title="交易所无异议函"
        name="exchnoobjlettersCard"
        megaLayout={megaProps}
        upDown={upInCode(100)}
      >
        <Field
          title="交易所无异议函文件"
          name="exchnoobjletters"
          type="bpm-upload-list"
          required
          editable={elementCode === '40' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('exchnoobjletters'),
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          name="exchnoobjlettermemo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '40' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>
      {/* 会签 */}
      {renderSign({
        name: 'declare42',
        title: '交易所无异议函会签信息',
        showAuditcountersignusers: false,
        editable: elementCode === '40' && !readOnlyFlag,
        upDown: upInCode(100),
      })}

      {/* 文件: 合同草案 50 */}
      <BaseFormCard
        name="draftCard"
        title="合同草案"
        megaLayout={megaProps}
        upDown={upInCode(100)}
        display={codeInRange(elementCode, 50, 59) || elementCode >= 100}
      >
        <Field
          title="托管协议"
          name="trustagmtfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '50' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('trustagmtfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="基金合同"
          name="contrfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '50' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('contrfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="其他文件"
          name="elsefiles"
          type="bpm-upload-list"
          editable={elementCode === '50' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('elsefiles'),
          }}
          x-mega-props={{ span: 4 }}
        />

        <Field
          name="apprvdept"
          title="审批部门"
          type="tree-select"
          editable={elementCode === '50' && !readOnlyFlag}
          x-component-props={{
            ...deptMulProps,
            placeholder: `请选择审批部门`,
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="apprvuser"
          title="审批人"
          type="tree-select"
          editable={elementCode === '50' && !readOnlyFlag}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择审批人`,
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="apprvnoticeuser"
          title="知会人"
          type="tree-select"
          editable={elementCode === '50' && !readOnlyFlag}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择知会人`,
          }}
          x-mega-props={{ span: 4 }}
        />

        <Field
          name="contrdraftmemo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '50' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      {/* 文件: 流动性风险评估 70 */}
      <BaseFormCard
        name="liquidityfilesCard"
        title="流动性风险评估"
        megaLayout={megaProps}
        upDown={elementCode >= 73 ? 'up' : 'down'}
        display={codeInRange(elementCode, 70, 79) || elementCode >= 120}
      >
        <FormSlot>
          <div>上传文件：评估表和上传要素表</div>
        </FormSlot>
        <Field
          name="prodliqdlv"
          title="风险等级"
          enum={riskLevel}
          type="string"
          editable={elementCode === '70' && !readOnlyFlag}
          x-component-props={{
            placeholder: '请选择风险等级',
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="文件"
          name="liquidityfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '70' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('liquidityfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="prodfilememo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '70' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      {/* 文件: 复核流动性风险评估 71 */}
      <BaseFormCard
        name="riskfilesCard"
        title="复核流动性风险评估"
        megaLayout={megaProps}
        upDown={elementCode >= 73 ? 'up' : 'down'}
        display={codeInRange(elementCode, 71, 79) || elementCode >= 120}
      >
        <FormSlot>
          <div>请提供流动性风险评估报告中风控部分</div>
        </FormSlot>
        <Field
          required
          name="riskliqdlv"
          title="风险等级"
          enum={riskLevel}
          type="string"
          editable={elementCode === '71' && !readOnlyFlag}
          x-component-props={{
            placeholder: '请选择风险等级',
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="文件"
          name="riskfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '71' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('riskfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="riskfilememo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '71' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>
      {/* 文件: 上传风险评估报告 72 */}
      <BaseFormCard
        name="riskassessfilesCard"
        title="上传风险评估报告"
        megaLayout={megaProps}
        upDown={upInCode(74)}
        display={codeInRange(elementCode, 72, 79) || elementCode >= 120}
      >
        <FormSlot>
          <div>文件为律师审核版</div>
        </FormSlot>
        <Field
          title="文件"
          name="risklawyerfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '72' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('risklawyerfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="risklawyermemo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '72' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>
      {/* 风险评估报告会签 73 */}
      {renderSign({
        name: 'declare74',
        title: '风险评估报告会签',
        display: codeInRange(elementCode, 73, 79) || elementCode >= 120,
        showAuditcountersignusers: false,
        editable: elementCode === '73' && !readOnlyFlag,
        upDown: upInCode(120),
        prefix: [
          {
            name: 'riskrptfiles',
            title: '风险评估报告文件',
            type: 'bpm-upload-list',
            required: true,
          },
        ],
      })}

      {/* 文件: 承诺函 80 */}
      <BaseFormCard
        title="承诺函"
        name="commitmentfilesCard"
        megaLayout={megaProps}
        upDown={upInCode(120)}
        display={codeInRange(elementCode, 80, 89) || elementCode >= 120}
      >
        <Field
          title="承诺函"
          name="commitmentfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '80' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('commitmentfiles'),
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          required
          title="发起份额承诺函"
          name="subcmtLetters"
          type="bpm-upload-list"
          editable={elementCode === '80' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('subcmtLetters'),
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          name="promiselettermemo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '80' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>
      {/* 会签: 承诺函 */}
      {renderSign({
        name: 'declare82',
        title: '承诺函会签',
        display: codeInRange(elementCode, 80, 89) || elementCode >= 120,
        showAuditcountersignusers: false,
        editable: elementCode === '80' && !readOnlyFlag,
        upDown: upInCode(120),
      })}

      {/* 文件：基金经理申报办理函 92 */}
      <BaseFormCard
        name="fundmgrdeclareprocessoverlettersCard"
        title="基金经理申报办理函"
        megaLayout={megaProps}
        upDown={upInCode(120)}
        display={codeInRange(elementCode, 92, 99) || elementCode >= 120}
      >
        <Field
          title="基金经理申报办理函"
          name="fundmgrdeclareprocessoverletters"
          type="bpm-upload-list"
          required
          editable={elementCode === '92' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('fundmgrdeclareprocessoverletters'),
          }}
          x-mega-props={{ labelWidth: 170 }}
        />
        <Field
          name="fundmgrdeclareprocessfilememo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '92' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      {/* 文件: 定稿报会材料准备 100 */}
      <BaseFormCard
        title="定稿报会材料准备"
        name="finalDraftCard"
        megaLayout={megaProps}
        display={elementCode >= 100}
        upDown={upInCode(120)}
      >
        <Field
          title="托管协议"
          name="rpttrustagmtfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '100' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('rpttrustagmtfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="合同协议"
          name="rptcontrfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '100' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('rptcontrfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="产品概要"
          name="rptfundprodgeneralfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '100' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('rptfundprodgeneralfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="招募说明书"
          name="recruitmanualfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '100' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('recruitmanualfiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="其他文件"
          name="rptelsefiles"
          type="bpm-upload-list"
          editable={elementCode === '100' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('rptelsefiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="rptdatamemo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '100' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>
      {/* 会签 */}
      {renderSign({
        name: 'declare110',
        title: '定稿报会材料会签',
        display: elementCode >= 100,
        showAuditcountersignusers: false,
        editable: elementCode === '100' && !readOnlyFlag,
        upDown: upInCode(120),
      })}

      {/* 文件：申报撤回 150 */}
      <BaseFormCard
        name="revokefileCard"
        title="申报撤回信息"
        megaLayout={megaProps}
        display={['150', '160'].includes(elementCode) || elementCode >= 180}
      >
        <Field
          title="文件"
          name="revokefiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '150' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('revokefiles'),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="revokefilememo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '150' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      {/* 文件: 综合管理部上传批文 170 */}
      <BaseFormCard
        name="apprvfilesCard"
        title="批文上传"
        megaLayout={megaProps}
        display={elementCode >= 170}
      >
        <Field
          title="申报获批文件上传"
          name="apprvfiles"
          type="bpm-upload-list"
          required
          editable={elementCode === '170' && !readOnlyFlag}
          x-component-props={{
            ...getFileProps('apprvfiles'),
          }}
          x-mega-props={{ labelWidth: 170, span: 3 }}
        />
        <Field
          name="declarebatchfilememo"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          editable={elementCode === '170' && !readOnlyFlag}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      {/* 会签 */}
      {renderSign({
        name: 'declare160',
        title: '撤回会签信息',
        display: ['150', '160'].includes(elementCode) || elementCode >= 190,
        showAuditcountersignusers: false,
        editable: elementCode === '150' && !readOnlyFlag,
      })}

      <BasicFormCard title="批文要素" megaLayout={megaProps} display={elementCode >= 180}>
        <Field
          name="fundcode"
          title="基金代码"
          type="string"
          required
          editable={elementCode === '180' && !readOnlyFlag}
          x-component-props={{ placeholder: '请输入基金代码' }}
        />
        <Field
          name="apprvdate"
          title="批文日期"
          type="date"
          required
          editable={elementCode === '180' && !readOnlyFlag}
          x-component-props={{ placeholder: '请选择批文日期', format: 'YYYY-MM-DD' }}
        />
        <Field
          name="docnumber"
          title="核准文号"
          type="string"
          required
          editable={elementCode === '180' && !readOnlyFlag}
          x-component-props={{
            placeholder: '请输入核准文号',
          }}
        />
      </BasicFormCard>

      <BaseFormCard
        title="基金运作费率"
        megaLayout={megaProps}
        name="fundsRate"
        upDown={Number(elementCode) >= 14 ? 'up' : 'down'}
      >
        <Field
          name="managerfee"
          title="管理费率"
          type="number"
          required
          x-component-props={{
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入管理费率(%)',
          }}
        />
        <Field
          name="floatmanagerfee"
          title="浮动管理费"
          type="number"
          x-component-props={{
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入管理费率(%)',
          }}
        />
        <Field
          name="hostfee"
          title="托管费"
          type="number"
          required
          x-component-props={{
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入托管费(%)',
          }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="基金类型"
        megaProps={megaProps}
        name="fundType"
        upDown={Number(elementCode) >= 14 ? 'up' : 'down'}
      >
        <Field
          name="fundattribute"
          title="基金类型"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金类型',
            previewPlaceholder: '-',
            ...comProps,
            ...fundattributeProps,
          }}
        />
        {[
          { key: 'isqdii', label: '是否QDII基金', required: true },
          { key: 'isinstitutionpdt', label: '是否机构类产品', required: true },
          {
            key: 'ismoreshares',
            label: (
              <>
                是否多份额类基金{' '}
                <Tooltip title="无须填写，根据份额数量自动判断">
                  <InfoCircleOutlined />
                </Tooltip>
              </>
            ),
            required: true,
            disabled: true,
          },
          { key: 'isinitiatingfund', label: '是否发起式基金', required: true },
          { key: 'isexchinfund', label: '是否是场内基金', required: true },
        ].map((item) => {
          return (
            <Field
              key={item.key}
              name={item.key}
              title={item.label}
              type="string"
              required={item.required}
              enum={[
                { label: '是', value: '1' },
                { label: '否', value: '0' },
              ]}
              x-component-props={{
                placeholder: `请选择${item.label}`,
                allowClear: true,
                disabled: item.disabled,
              }}
            />
          );
        })}
        <Field
          name="isindexfund"
          title="是否指数基金"
          type="string"
          required
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          x-component-props={{
            placeholder: `请选择是否指数基金`,
            allowClear: true,
          }}
        />
        <Field
          name="targetindexcode"
          title="标的指数代码"
          type="string"
          required
          x-component-props={{
            placeholder: '请输入标的指数代码',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="targetindexname"
          title="标的指数名称"
          type="string"
          required
          x-component-props={{
            placeholder: '请输入标的指数名称',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="indexorganization"
          title="指数公司"
          type="string"
          required
          x-component-props={{
            placeholder: '请输入指数公司',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="indexfundtype"
          title="指数基金类型"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择指数基金类型',
            previewPlaceholder: '-',
            ...comProps,
            ...indexfundtypeProps,
          }}
        />
        <Field
          name="goalfundcode"
          title="目标基金代码"
          type="string"
          required
          visible={false}
          x-component-props={{
            placeholder: '请输入目标基金代码',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="goalfundname"
          title="目标基金名称"
          type="string"
          visible={false}
          required
          x-component-props={{
            placeholder: '请输入目标基金名称',
            previewPlaceholder: '-',
          }}
        />
        {/* <Field
          name="basketcode"
          title="ETF定义文件编码"
          type="string"
          visible={false}
          required
          x-component-props={{
            placeholder: '请输入ETF定义文件编码',
            previewPlaceholder: '-',
          }}
        /> */}
        <Field
          name="bitype"
          title="BI分类"
          type="tree-select"
          x-component-props={{
            ...biTypeProps,
            placeholder: '请选择BI分类',
            separator: '',
            findedSeparator: '',
            renderText: (data, record) => {
              return data && data.namePath
                ? data.namePath.split('BI分类/').length > 1
                  ? data.namePath.split('BI分类/')[1]
                  : data.name
                : data?.name || '';
            },
          }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="份额信息"
        name="shareinfo"
        megaLayout={false}
        upDown={Number(elementCode) >= 14 ? 'up' : 'down'}
      >
        <Field
          name="sharelist"
          minItems={1}
          maxItems={5}
          type="array"
          default={[{}]}
          x-component="bpm-array-card"
          x-component-props={{
            title: '份额',
            titlefield: 'fundshortname',
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderRemove: (idx) => {
              const mutators = formActions.createMutators('sharelist');
              return (
                idx !== 0 && (
                  <Button
                    shape="circle"
                    icon={<DeleteOutlined />}
                    onClick={() => {
                      mutators.remove(idx);
                    }}
                  />
                )
              );
            },
            renderAddition: () => (
              <Button type="primary" size="small">
                添加子份额
              </Button>
            ),
          }}
        >
          <Field type="object">
            <FormMegaLayout {...megaLayoutProps}>
              <Field
                name="ismainshare"
                title="是否主份额"
                type="string"
                required
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否主份额`,
                }}
              />
              <Field
                name="sharetype"
                title="份额类型"
                type="string"
                required
                enum={[
                  { label: 'A', value: 'A' },
                  { label: 'B', value: 'B' },
                  { label: 'C', value: 'C' },
                ]}
                x-component-props={{
                  placeholder: `请选择份额类型`,
                }}
              />
              <Field
                name="fundshortname"
                title="份额信披简称"
                type="string"
                required
                x-component-props={{ placeholder: '请输入份额信披简称' }}
              />
              <Field
                name="currency"
                title="交易币种"
                default="人民币"
                type="tree-select"
                x-component-props={{
                  ...currencyProps,
                  placeholder: `请选择交易币种`,
                }}
              />
              <Field
                name="islisted"
                title="是否上市"
                type="string"
                required
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否上市`,
                }}
              />
              <Field
                name="floortradename"
                title="场内简称"
                type="string"
                x-component-props={{
                  placeholder: `请输入场内简称`,
                }}
              />
              <Field
                name="listingplace"
                title="上市场所"
                required
                visible={false}
                type="tree-select"
                x-component-props={{
                  ...listingPlaceProps,
                  placeholder: `请选择上市场所`,
                }}
              />
              <Field
                name="listingtype"
                title="上市基金类型"
                required
                visible={false}
                type="tree-select"
                x-component-props={{
                  ...listingTypeProps,
                  placeholder: `请选择上市基金类型`,
                }}
              />
              <Field
                name="salesfee"
                title="销售服务费率(单位: %)"
                type="number"
                x-component-props={{
                  style: {
                    marginBottom: 30,
                  },
                  min: 0,
                  max: 100,
                  precision: 2,
                  formatter: (value) => value && `${value}`,
                  parser: (value) => value.replace('%', ''),
                  placeholder: '请输入销售服务费率(%)',
                }}
              />
            </FormMegaLayout>
            <Field
              title="认购费"
              name="subscribelist"
              type="array"
              x-component="form-table"
              x-component-props={{
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                visibleColumns: ['sharetype'],
              }}
            >
              <Field type="object">
                <Field
                  name="minsum"
                  title={
                    <>
                      认购金额下限(包含)
                      <Tooltip title="最小值：0">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    placeholder: '请输入金额下限',
                  }}
                />
                <Field
                  name="maxsum"
                  title={
                    <>
                      认购金额上限(不包含)
                      <Tooltip title="最大值：999,999,999,999">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    min: 0,
                    precision: 0,
                    placeholder: '请输入金额上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharechargingmet"
                  title="收费方式"
                  type="string"
                  required
                  enum={[
                    { label: '前端收费', value: '前端收费' },
                    { label: '后端收费', value: '后端收费' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择收费方式',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>
            <Field
              title="申购费"
              name="purchaselist"
              type="array"
              x-component="form-table"
              x-component-props={{
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                visibleColumns: ['sharetype'],
              }}
            >
              <Field type="object">
                <Field
                  name="minsum"
                  title={
                    <>
                      申购金额下限(包含)
                      <Tooltip title="最小值：0">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    placeholder: '请输入金额下限',
                  }}
                />
                <Field
                  name="maxsum"
                  title={
                    <>
                      申购金额上限(不包含)
                      <Tooltip title="最大值：999,999,999,999">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    min: 0,
                    precision: 0,
                    placeholder: '请输入金额上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharechargingmet"
                  title="收费方式"
                  type="string"
                  required
                  enum={[
                    { label: '前端收费', value: '前端收费' },
                    { label: '后端收费', value: '后端收费' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择收费方式',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>
            <Field
              title="赎回费"
              name="redemptionlist"
              type="array"
              x-component="form-table"
              x-component-props={{
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                visibleColumns: ['sharetype'],
              }}
            >
              <Field type="object">
                <Field
                  name="minday"
                  title={
                    <>
                      持有期限下限(包含)
                      <Tooltip title="最小值：0">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    placeholder: '请输入下限',
                  }}
                />
                <Field
                  name="maxday"
                  title={
                    <>
                      持有期限上限(不包含)
                      <Tooltip title="最大值：999,999,999,999">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    placeholder: '请输入上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="homeretaprop"
                  title="归基金资产比例"
                  type="number"
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    formatter: (value) => value && `${value}%`,
                    parser: (value) => value.replace('%', ''),
                    placeholder: '请输入归基金资产比例(%)',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>
          </Field>
        </Field>
      </BaseFormCard>
    </>
  );
}

export default Form;
