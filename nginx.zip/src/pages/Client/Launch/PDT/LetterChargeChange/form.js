import React from 'react';
import { Field } from 'formily-antd';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import {
  useTreeUser,
  useBpmShareList,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import { useDictList } from '@/hooks';

function Form(props) {
  const megaProps = {
    labelWidth: 110,
    responsive: { lg: 4, m: 2, s: 1 },
    contextResponsive: { lg: 4, m: 2, s: 1 },
  };

  const userMulProps = useTreeUser({
    multiple: true,
    tokenSeparators: [';'],
  });

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="信批费率变更信息" megaLayout={false} name="feeinfo">
        <Field
          name="feelist"
          type="array"
          x-component="form-table"
          x-component-props={{
            renderMoveDown: () => null,
            renderMoveUp: () => null,
          }}
        >
          <Field type="object">
            <Field
              name="fundcode"
              title="基金"
              type="tree-select"
              required
              x-pattern="readOnly"
              x-component-props={{
                filterOption: (value, option) =>
                  option.data &&
                  ((option.data.fundcode || '').includes(value) ||
                    (option.data.fundname || '').includes(value) ||
                    (option.data.businesstype || '').includes(value)),
                style: { maxWidth: 500 },
                dropdownMatchSelectWidth: false,
                placeholder: '请选择基金',
                ...useBpmShareList(),
              }}
            />
            <Field
              name="feetype"
              title="费率类型"
              type="tree-select"
              required
              x-pattern="readOnly"
              x-component-props={{
                placeholder: '请输入调整费率类型',
                ...useDictList({ id: '7a3d35c3-adcf-4ce3-b15e-7a0851573f46' }),
              }}
            />
            <Field
              name="beforefee"
              title="原值"
              type="number"
              editable={false}
              x-component-props={{
                min: 0,
                max: 100,
                formatter: (value) => value && `${value}%`,
                parser: (value) => value.replace('%', ''),
              }}
            />
            <Field
              name="afterfee"
              title="新值"
              type="number"
              required
              x-component-props={{
                min: 0,
                max: 100,
                formatter: (value) => value && `${value}%`,
                parser: (value) => value.replace('%', ''),
                placeholder: '请输入新值(%)',
              }}
            />
            <Field
              name="effectdate"
              title="生效日期(生效日00:00生效)"
              type="date"
              required
              x-component-props={{
                placeholder: '请输入生效日期',
                format: 'YYYY-MM-DD',
              }}
            />
          </Field>
        </Field>
      </BasicFormCard>

      <BasicFormCard title="其他信息" megaProps={megaProps}>
        <Field
          name="noticeusers"
          title="知会人"
          type="tree-select"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择知会人`,
          }}
        />
        <Field
          name="remark"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
      </BasicFormCard>
    </>
  );
}

export default Form;
