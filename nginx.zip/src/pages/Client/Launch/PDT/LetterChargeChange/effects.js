import { FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import { fn, storage } from '@cerdo/cerdo-utils/lib';

const { onFieldValueChange$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
    } = props;
    const { firstTokenFlag, readOnlyFlag } = getProcess() || {};
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
    this.userInfo = storage.getUserInfo();

    this.dispatcher = store.useModelDispatchers('pdtSystem');
  }

  createFormEffects() {
    return ($, { setFieldValue, getFieldValue }) => {
      if (this.firstTokenFlag && !this.readOnlyFlag) {
        onFieldValueChange$('*(feelist.*.fundcode,feelist.*.feetype)').subscribe(async (state) => {
          const arr = (state.name || '').split('.');
          if (arr.length > 2) {
            const index = Number(arr[1]);
            const feeList = getFieldValue('feelist') || [];
            const feeItem = feeList[index];

            if (arr[2] === 'fundcode' && state?.values.length > 0) {
              feeItem.fundname = state?.values[1]?.data?.name || feeItem.fundname;
            }

            if (feeItem.fundcode && feeItem.feetype) {
              // 基金代码和变更的费率填写了，调用接口获取对应费率的历史值
              const result = await this.dispatcher.getFundFee({
                fundcode: feeItem.fundcode,
              });
              if (fn.checkResponse(result)) {
                const { data } = result;
                if (Array.isArray(data) && data.length > 0) {
                  feeItem.beforefee = data[0][feeItem.feetype];
                }
              }
            }

            setFieldValue('feelist', [...feeList]);
          }
        });
      }
    };
  }

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }

  formatData(values) {
    return {
      ...values,
      noticeusers: this.joinArray(values.noticeusers, ';'),
    };
  }

  splitArray(data, chr = ',') {
    if (data && typeof data === 'string') {
      return data.split(chr);
    }
    if (data instanceof Array) {
      return data;
    }
    return data;
  }

  applySubmit(values) {
    const result = values;
    if ((result.feelist || []).length < 1) {
      this.antMessage.warning('费率信息不能为空');
      return false;
    }
    let data = this.formatData(result);
    return data;
  }

  auditSubmit(values) {
    // console.log('提交前数据：', values);
    const result = values;
    // 流程过程中 fundname丢失问题修复
    let data = this.formatData(result);
    return data;
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  applyFormatData(values) {
    return {
      ...values,
      noticeusers: this.splitArray(values.noticeusers, ';'),
    };
  }

  auditFormatData(values) {
    return {
      ...values,
      noticeusers: this.splitArray(values.noticeusers, ';'),
    };
  }

  preSetVariables() {
    return {
      // 去掉规则文件 设置默认知会人
      bpmNoticeUser: this.userInfo.account,
    };
  }
}
