import React from 'react';
import { FormPath, FormEffectHooks } from 'formily-antd';
import { FormLifeCycleTypes, BpmFormEffectHooks } from '@/utils';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import { getCurrentUser } from '@/utils';
import { Button, message, Tooltip } from 'antd';
const { onFieldValueChange$, onFieldInputChange$, onFieldInit$ } = FormEffectHooks;
const { onToggleChange$ } = BpmFormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
      ...restProps
    } = props;
    const { elementCode } = getProcess() || {};
    this.elementCode = elementCode;
  }

  createFormEffects() {
    const dispatcher = store.useModelDispatchers('pdtSystem');

    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      onFieldInit$('*(countersigndeparts,countersignusers,noticeusers)').subscribe(
        ({ value, name }) => {
          setFieldValue(name, value ? value.split(';') : value);
        },
      );

      // onFieldInputChange$('fundmanagerid').subscribe(async ({ value, values }) => {
      //   if (value.length > 0) {
      //     const account = values[1][value.length - 1].data.account;
      //     const res = await dispatcher.userDetail({ accounts: account });
      //     const departs = getFieldValue("countersigndeparts");
      //     if (Array.isArray(res.data) && res.data.length > 0 && !departs.includes(res.data[0].departmentname)) {
      //       setFieldValue("countersigndeparts", [...departs, res.data[0].departmentname])
      //     }
      //   }
      // });

      onFieldInputChange$('fundname').subscribe(async ({ value }) => {
        setFieldValue('sharelist.0.fundname', value);
      });

      onFieldInputChange$('fundshortname').subscribe(async ({ value }) => {
        setFieldValue('sharelist.0.fundname', value);
        setFieldValue('sharelist.0.fundshortname', value);
      });

      onFieldValueChange$('sharelist.*.islisted').subscribe((fieldState) => {
        setFieldState(
          FormPath.transform(fieldState.name, /\d/, ($1) => `sharelist.${$1}.listingplace`),
          (state) => {
            state.visible = fieldState.value === '1';
          },
        );
      });

      if (['20'].includes(this.elementCode)) {
        getCurrentUser().then((user) => {
          setFieldState('managerid', (state) => {
            state.required = user.departmentname === '产品开发部';
            state.editable = user.departmentname === '产品开发部';
          });
        });
      }
    };
  }
  formatFiles = (result) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.id) {
        return file;
      }
      return {
        extname: file.response.fileExt,
        filename: file.response.fileName,
        filesize: file.response.fileSize,
        fileid: file.response.id,
        description: file.response.description,
        createuser: file.createuser,
        createtime: file.createtime,
        elementname: file.elementname,
      };
    };
    const attachments = (result.attachmentlist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }
  formatData(values) {
    return {
      ...values,
      // attachmentlist: this.formatFiles(values),
      // countersigndeparts: Array.isArray(values.countersigndeparts) ? values.countersigndeparts.join(";") : values.countersigndeparts,
      fundmanagerid: this.joinArray(values.fundmanagerid),
      countersigndeparts: this.joinArray(values.countersigndeparts, ';'),
      countersignusers: this.joinArray(values.countersignusers, ';'),
      noticeusers: this.joinArray(values.noticeusers, ';'),
    };
  }

  applySubmit(values) {
    const result = values;
    console.log('提交前数据：', values);
    let data = this.formatData(result);
    console.log('提交前数据：', data);
    return data;
  }

  auditSubmit(values) {
    console.log('提交前数据：', values);
    let data = this.formatData(values);
    return data;
  }
}
