import React from 'react';
import { Field } from 'formily-antd';
import { FormMegaLayout } from '@formily/antd-components';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import { DeleteOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { Button, Tooltip } from 'antd';
import {
  useMegaLayoutProps,
  useDictList,
  useAgencyList,
  useTreeDepartment,
  useTreeUser,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';

function Form(props) {
  const {
    context: { getProcess },
    formEffects: { formActions },
  } = props;
  const { elementCode, readOnlyFlag, elementId, endElementId } = getProcess() || {};

  const comProps = {
    size: 'middle',
  };

  const megaProps = {
    labelWidth: 160,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };

  const megaLayoutProps = useMegaLayoutProps(megaProps);

  const endFlag = elementId === endElementId;
  const businessTypeProps = useDictList({ id: '9cd915e33daf4cd78430e8499642c39f' });
  const shareTypeProps = useDictList({ id: '315a4574dc74451d9c9c79708df15d1d' });

  // const megaLayoutProps = useMegaLayoutProps(megaProps);
  const deptMulProps = useTreeDepartment({
    multiple: true,
    type: undefined,
    tokenSeparators: [';'],
  });
  const userMulProps = useTreeUser({
    multiple: true,
    tokenSeparators: [';'],
  });

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="会签信息" megaProps={megaProps}>
        <Field
          name="countersigndeparts"
          title="会签部门"
          type="tree-select"
          required
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...comProps,
            ...deptMulProps,
            placeholder: `请选择会签部门`,
          }}
        />
        <Field
          name="countersignusers"
          title="会签人"
          type="tree-select"
          // required
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择会签人`,
          }}
        />
        <Field
          name="noticeusers"
          title="知会人"
          type="tree-select"
          // required
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择知会人`,
          }}
        />
      </BasicFormCard>

      <BasicFormCard title="基金信息" megaProps={megaProps}>
        <Field
          name="isinnovation"
          title="是否为创新产品"
          type="string"
          required
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          x-component-props={{ placeholder: `请选择是否为创新产品` }}
        />
        <Field
          name="resolutionpassdate"
          title="总办会决议通过日期"
          type="date"
          visible={['50'].includes(elementCode) || endFlag}
          editable={['50'].includes(elementCode) && !readOnlyFlag}
          required={['50'].includes(elementCode)}
          x-component-props={{ format: 'YYYY-MM-DD', placeholder: '请选择日期' }}
        />
        <Field
          name="fundname"
          title="基金名称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金名称' }}
        />

        <Field
          name="fundshortname"
          title="基金简称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金简称' }}
        />
        <Field
          name="businesstype"
          title="基金类别"
          type="tree-select"
          x-component-props={{
            placeholder: '请选择基金类别',
            previewPlaceholder: '-',
            optionFilterProp: 'label',
            ...businessTypeProps,
          }}
        />
        <Field
          name="trusteeid"
          title="托管人"
          type="tree-select"
          x-component-props={{
            placeholder: '请选择托管人',
            previewPlaceholder: '-',
            optionFilterProp: 'label',
            ...useAgencyList({ type: '托管人' }),
          }}
        />
        <Field
          name="registcompanyid"
          title="注册登记机构"
          type="tree-select"
          x-component-props={{
            placeholder: '请选择注册登记机构',
            previewPlaceholder: '-',
            optionFilterProp: 'label',
            ...useAgencyList({ type: '注册登记机构' }),
          }}
        />
        {/* <Field
          name='fundmanagerid'
          title='基金经理'
          type='tree-select'
          x-component-props={{
            placeholder: '请选择基金经理',
            previewPlaceholder: '-',
            optionFilterProp: 'label',
            ...comProps,
            ...managerProps,
          }}
        /> */}
        {/* <Field
          name='managerid'
          title='产品负责人'
          type='tree-select'
          x-component-props={{
            ...comProps,
            placeholder: '请选择产品负责人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...productProps,
          }}
        /> */}
        {[
          { key: 'investgoal', label: '投资目标', required: false },
          { key: 'investschema', label: '投资策略', required: false },
          { key: 'investscope', label: '投资范围', required: false },
          { key: 'benchmark', label: '业绩比较基准', required: false },
        ].map((item) => {
          return (
            <Field
              key={item.key}
              name={item.key}
              title={item.label}
              type="textarea"
              previewPlaceholder="pre"
              required={item.required}
              x-component-props={{
                placeholder: `请输入${item.label}`,
                autoSize: { minRows: 3, maxRows: 20 },
              }}
              x-mega-props={{ span: 4 }}
            />
          );
        })}
        {/* <Field
          name='countersigndeparts'
          title='会签部门'
          type='bpm-checkbox'
          // required
          default={['营销管理部', '产品开发部']}
          x-rules={[{
            validator: (value) => {
              if (value && value.includes('产品开发部')) {
                return '';
              } else {
                return '【产品开发部】必选';
              }
            },
          }]}
          x-mega-props={{ span: 4 }}
          x-component-props={{ checkAll: false, tokenSeparators: [';'], request: departsRequest }}
        /> */}
        {/* <Field name='salesfeedescs'  */}
        {/* // title={<div>上一次流程<br />会签人<br />知会人<br />会签部门</div>}
        // type='tree-select'
          // previewPlaceholder='pre'
          // x-mega-props={{ */}
        {/* // addonAfter: '{{addonAfterRender()}}',

          // }}
          // x-component-props={{ */}
        {/* //   placeholder: '',
          // style: { maxWidth: 600 },
            // style: { marginBottom: 20 },
            // autoSize: { minRows: 2, maxRows:12  }
          // }}
          // x-mega-props={{ span: 3 }}
        // /> */}
      </BasicFormCard>

      <BasicFormCard title="基金运作费率" megaLayout={megaProps}>
        <Field
          name="managerfee"
          title="管理费率"
          type="number"
          x-component-props={{
            style: { maxWidth: 200 },
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入管理费率(%)',
          }}
        />
        <Field
          name="floatmanagerfee"
          title="浮动管理费"
          type="number"
          x-component-props={{
            style: { maxWidth: 200 },
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入管理费率(%)',
          }}
        />
        {/* <Field name='managerfeedesc' title='管理费描述' type='textarea'
          previewPlaceholder='pre'
          x-component-props={{
            placeholder: '请输入管理费描述',
            autoSize: { minRows: 3, maxRows: 20 }
          }}
          x-mega-props={{ span: 3 }}
        /> */}
        <Field
          name="hostfee"
          title="托管费"
          type="number"
          x-component-props={{
            style: { maxWidth: 200 },
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入托管费(%)',
          }}
        />
        {/* <Field name='hostfeedesc' title='托管费描述' type='textarea'
          previewPlaceholder='pre'
          x-component-props={{ placeholder: '请输入托管费描述', autoSize: { minRows: 3, maxRows: 20 } }}
          x-mega-props={{ span: 3 }}
        /> */}
        {/* <Field name='investfee' title='投顾费率' type='number'
          x-component-props={{
            style: { maxWidth: 200 },
            min: 0, max: 100, precision: 2,
            formatter: value => value && `${value}%`,
            parser: value => value.replace('%', ''),
            placeholder: '请输入托管费(%)',
          }}
        /> */}
        <Field
          name="otherfee"
          title="其他费率"
          type="number"
          x-component-props={{
            style: { maxWidth: 200 },
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入托管费(%)',
          }}
        />
      </BasicFormCard>

      <BasicFormCard title="基金类型" megaProps={megaProps}>
        {[
          { key: 'isqdii', label: '是否QDII基金', required: false },
          { key: 'isinstitutionpdt', label: '是否机构类产品', required: false },
          { key: 'isindexfund', label: '是否指数基金', required: false },
          { key: 'ismoreshares', label: '是否多份额类基金', required: false },
          { key: 'isinitiatingfund', label: '是否发起式基金', required: false },
        ].map((item) => {
          return (
            <Field
              key={item.key}
              name={item.key}
              title={item.label}
              type="string"
              enum={[
                { label: '是', value: '1' },
                { label: '否', value: '0' },
              ]}
              x-component-props={{
                style: { maxWidth: 200 },
                placeholder: `请选择${item.label}`,
                allowClear: true,
              }}
            />
          );
        })}
      </BasicFormCard>

      <BasicFormCard title="份额信息" megaLayout={false}>
        <Field
          name="sharelist"
          minItems={1}
          maxItems={5}
          type="array"
          default={[{}]}
          x-component="bpm-array-card"
          x-component-props={{
            title: '份额',
            titlefield: 'sharetype',
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderRemove: (idx) => {
              const mutators = formActions.createMutators('sharelist');
              return (
                idx !== 0 && (
                  <Button
                    shape="circle"
                    icon={<DeleteOutlined />}
                    onClick={() => {
                      mutators.remove(idx);
                    }}
                  />
                )
              );
            },
            renderAddition: () => (
              <Button type="primary" size="small">
                添加子份额
              </Button>
            ),
          }}
        >
          <Field type="object">
            <FormMegaLayout {...megaLayoutProps}>
              {/* <Field name='fundname' title='网站简称' type='string' required x-component-props={{ placeholder: '请输入网站简称' }} />
              <Field name='fundshortname' title='信披简称' type='string' required x-component-props={{ placeholder: '请输入信披简称' }} /> */}
              <Field
                name="sharetype"
                title="份额类别"
                required
                type="tree-select"
                x-component-props={{
                  ...shareTypeProps,
                  style: { maxWidth: 200, marginBottom: 30 },
                  placeholder: `请选择份额类别`,
                }}
              />
              <Field
                name="islisted"
                title="是否上市"
                type="string"
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  style: { maxWidth: 200, marginBottom: 30 },
                  placeholder: `请选择是否上市`,
                }}
              />
              {/* <Field name='listingplace' title='上市场所' visible={false} type='tree-select'
                x-component-props={{
                  placeholder: '请选择上市场所',
                  previewPlaceholder: '-',
                  ...comProps,
                  ...listingPlaceProps,
                }}
              /> */}
              {/* <Field
                name='salesfee'
                type='number'
                title='销售服务费'
                x-component-props={{
                  precision: 6,
                  style: { maxWidth: 200, marginBottom: 30 },
                  placeholder: '请输入销售服务费'
                }}
              /> */}
              <Field
                name="salesfee"
                title="销售服务费率"
                type="number"
                x-component-props={{
                  style: { maxWidth: 200 },
                  min: 0,
                  max: 100,
                  precision: 2,
                  formatter: (value) => value && `${value}%`,
                  parser: (value) => value.replace('%', ''),
                  placeholder: '请输入销售服务费率(%)',
                }}
              />
              {/* <Field name='investfeee' title='认申赎费率' type='number'
                x-component-props={{
                  style: { maxWidth: 200 },
                  min: 0, max: 100, precision: 2,
                  formatter: value => value && `${value}%`,
                  parser: value => value.replace('%', ''),
                  placeholder: '请输入认申赎费率(%)',
                }}
              /> */}
              {/* <Field name='salesfeedesc' title='销售服务费描述' type='textarea'
                previewPlaceholder='pre'
                x-component-props={{
                  placeholder: '请输入销售服务费描述',
                  style: { marginBottom: 20 },
                  autoSize: { minRows: 3, maxRows: 20 }
                }}
                x-mega-props={{ span: 3 }}
              /> */}
            </FormMegaLayout>
            <Field
              title="认购费"
              name="subscribelist"
              type="array"
              x-component="form-table"
              x-component-props={{
                style: { marginBottom: 20 },
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                // renderAddition: () => <Button block={false} type='primary'>添加</Button>,
              }}
            >
              <Field type="object">
                <Field
                  name="minsum"
                  title={
                    <>
                      认购金额下限(包含)
                      <Tooltip title="最小值：0"> <InfoCircleOutlined /></Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    placeholder: '请输入金额下限',
                  }}
                />
                <Field
                  name="maxsum"
                  title={
                    <>
                      认购金额上限(不包含)
                      <Tooltip title="最大值：999,999,999,999"> <InfoCircleOutlined /></Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    min: 0,
                    precision: 0,
                    placeholder: '请输入金额上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharechargingmet"
                  title="收费方式"
                  type="string"
                  required
                  enum={[
                    { label: '前端收费', value: '前端收费' },
                    { label: '后端收费', value: '后端收费' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择收费方式',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>

            <Field
              title="申购费"
              name="purchaselist"
              type="array"
              x-component="form-table"
              x-component-props={{
                style: { marginBottom: 20 },
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                // renderAddition: () => <Button block={false} type='primary'>添加</Button>,
              }}
            >
              <Field type="object">
                <Field
                  name="minsum"
                  title={
                    <>
                      申购金额下限(包含)
                      <Tooltip title="最小值：0"> <InfoCircleOutlined /></Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    placeholder: '请输入金额下限',
                  }}
                />
                <Field
                  name="maxsum"
                  title={
                    <>
                      申购金额上限(不包含)
                      <Tooltip title="最大值：999,999,999,999"> <InfoCircleOutlined /></Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    min: 0,
                    precision: 0,
                    placeholder: '请输入金额上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharechargingmet"
                  title="收费方式"
                  type="string"
                  required
                  enum={[
                    { label: '前端收费', value: '前端收费' },
                    { label: '后端收费', value: '后端收费' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择收费方式',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>
            <Field
              title="赎回费"
              name="redemptionlist"
              type="array"
              x-component="form-table"
              x-component-props={{
                style: { marginBottom: 20 },
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                // renderAddition: () => <Button block={false} type='primary'>添加</Button>,
              }}
            >
              <Field type="object">
                <Field
                  name="minday"
                  title={
                    <>
                      持有期限下限(包含)
                      <Tooltip title="最小值：0"> <InfoCircleOutlined /></Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    placeholder: '请输入下限',
                  }}
                />
                <Field
                  name="maxday"
                  title={
                    <>
                      持有期限上限(不包含)
                      <Tooltip title="最大值：999,999,999,999"> <InfoCircleOutlined /></Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    placeholder: '请输入上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="homeretaprop"
                  title="归基金资产比例"
                  type="number"
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    formatter: (value) => value && `${value}%`,
                    parser: (value) => value.replace('%', ''),
                    placeholder: '请输入归基金资产比例(%)',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>
          </Field>
        </Field>
      </BasicFormCard>
    </>
  );
}

export default Form;
