
/**
 * 期货评分流程
 * 单秀雨 2022-04-08
 */
import React from 'react';
import {
  Field,
} from 'formily-antd';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import {
  FormMegaLayout,
} from '@formily/antd-components';
import { Button } from 'antd';
import Download from '@chinahorm/web-components/es/components/Download';
import {
  useMegaLayoutProps,
  useAgencyList,
  useDictList
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import {
  useBpmShareList
} from '@/hooks';
import { pdtOrigin } from '../../../../../utils/appUrl';
const appBaseUrL = pdtOrigin.replace('#', '');


function Form(props) {
  const {
    context: { getProcess },
  } = props;
  const { elementCode, readOnlyFlag, firstTokenFlag, elementId, endElementId } =
    getProcess() || {};
  const endFlag = elementId === endElementId;
  const agencyEditable =
    (!['10', '20', '25', '30', '80'].includes(elementCode) && !firstTokenFlag) || endFlag;


  const megaProps = {
    labelWidth: 140,
    responsive: { lg: 4, m: 2, s: 1 },
    contextResponsive: { lg: 4, m: 2, s: 1 },
  };
  const megaProp = {
    labelWidth: 160,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };

  const megaLayoutProps = useMegaLayoutProps(megaProp);

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="填写信息" megaProps={megaProps}>
        <Field
          name="fundcode"
          title="产品名称"
          type="tree-select"
          required
          x-component-props={{
            filterOption: (value, option) =>
              option.data &&
              ((option.data.fundcode || '').includes(value) ||
                (option.data.fundname || '').includes(value) ||
                (option.data.businesstype || '').includes(value)),
            style: { maxWidth: 500 },
            placeholder: '请选择基金名称',
            ...useBpmShareList(),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="futuresid"
          title="期货公司"
          type="tree-select"
          required
          x-component-props={{
            style: { maxWidth: 500 },
            optionFilterProp: 'label',
            placeholder: '请选择期货公司',
            ...useAgencyList({
              businesstype: '期货公司',
              type: '期货公司',
            }),
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="tradetype"
          title="交易类型"
          type="radio"
          enum={[
            { label: '交易型', value: '1' },
            { label: '现金管理', value: '2' },
          ]}
          required
          x-component-props={{ size: 'middle' }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="reason"
          title="申请理由"
          required
          type='textarea'
          x-component-props={{
            placeholder: `请填写申请理由`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="necessary"
          title="必要性"
          required
          type='textarea'
          x-component-props={{
            placeholder: `请填写必要性`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />


      </BasicFormCard>

      <BasicFormCard
        title="调查问卷"
        megaLayout={megaProps}
        tips={<b style={{ display: 'inline' }}>
          <Download
            style={{ display: 'inline' }}
            fileName="华宝基金管理有限公司选择期货公司调查问卷(模板).doc"
            url={`${appBaseUrL}assets/template/template/dossier/questionnaireScoringTemplate.doc`}
          >
            <Button type="link" style={{ display: 'inline' }}>下载问卷模板</Button>
            &emsp;请期货公司填完调查问卷后，上传问卷
          </Download>
        </b>}
      >
        <Field
          title="调查问卷"
          name="attachmentlist"
          type="bpm-upload-list"
          required
          x-component-props={{
            onSuccess: '{{fileSuccess("attachmentlist")}}',
            onDel: '{{fileDel("attachmentlist")}}',
          }}
          x-mega-props={{ span: 2 }}
        />
      </BasicFormCard>
      <BasicFormCard
        title='预审意见'
        megaLayout={false}
        visible={(!['10'].includes(elementCode) && !firstTokenFlag) || endFlag}
      >
        <Field
          name="advice"
          title="[量化部] 预审意见"
          required
          type='textarea'
          visible={(!['10'].includes(elementCode) && !firstTokenFlag) || endFlag}
          editable={['20'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            placeholder: `请填写预审意见`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="nextadvice"
          title="[投资部] 预审意见"
          required
          visible={(!['10', '20'].includes(elementCode) && !firstTokenFlag) || endFlag}
          editable={['25'].includes(elementCode) && !readOnlyFlag}
          type='textarea'
          x-component-props={{
            placeholder: `请填写预审意见`,
            autoSize: { minRows: 3, maxRows: 20 },
            style: { marginTop:'10px'},
          
          }}
          x-mega-props={{ span: 4 }}
        />
      </BasicFormCard>

      <BasicFormCard
        title="评分内容"
        megaLayout={false}
        name="agencyinfo"
        visible={agencyEditable}
      >
        <Field
          name="itemlist"
          minItems={0}
          maxItems={10}
          type="array"
          default={[]}
          x-component="bpm-array-card"
          editable={['40'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            // key: 'organinfoid',
            title: '部门评分',
            titlefield: 'departmentname',
            renderMoveDown: () => <React.Fragment />,
            renderMoveUp: () => <React.Fragment />,
            renderAddition: () => (
              <Button type="primary" size="small">
                添加评分项
              </Button>
            ),
          }}
        >
          <Field type="object">
            <FormMegaLayout {...megaLayoutProps}>
              <Field
                name="departmentname"
                title="评分部门"
                required
                type="tree-select"
                editable={['40'].includes(elementCode) && !readOnlyFlag}
                x-component-props={{
                  placeholder: '请选择评分部门',
                  optionFilterProp: 'label',
                  ...useDictList({ id: 'b21f3d0b-da50-4754-b13f-1fc1a5874f9f' }),
                }}
              />
              <Field
                name="weights"
                title="权重%"
                required
                type="number"
                editable={['40'].includes(elementCode) && !readOnlyFlag}
                x-component-props={{
                  precision: 0,
                  placeholder: '请填写权重',
                  previewPlaceholder: ' ',
                }}
              />
              <Field
                name="score"
                title="得分"
                required
                type="number"
                editable={['50', '60'].includes(elementCode) && !readOnlyFlag}
                x-component-props={{

                  min: 0,
                  max: 10,
                  placeholder: '请输入得分',
                  previewPlaceholder: ' ',
                }}
              />
              <Field
                name="standard"
                title="评分标准"
                required
                type='textarea'
                editable={['40'].includes(elementCode) && !readOnlyFlag}
                x-component-props={{
                  placeholder: `请填写评分标准`,
                  autoSize: { minRows: 3, maxRows: 20 },
                }}
                x-mega-props={{ span: 4 }}
              />
              <Field
                name="advice"
                title="部门整体意见"
                required
                type='textarea'
                editable={['50', '60'].includes(elementCode) && !readOnlyFlag}
                x-component-props={{
                  placeholder: `请填写部门整体意见`,
                  autoSize: { minRows: 3, maxRows: 20 },
                }}
                x-mega-props={{ span: 4 }}
              />
            </FormMegaLayout>
          </Field>
        </Field>
      </BasicFormCard>

      <BasicFormCard
        title="加权汇总得分"
        megaLayout={megaProps}
        visible={(!['10', '20', '25', '30', '80', '40', '50', '60'].includes(elementCode) && !firstTokenFlag) || endFlag}
      >
        <Field
          name="score"
          title="加权汇总得分"
          required
          type="number"
          x-component-props={{
            placeholder: '请输入加权汇总得分',
            previewPlaceholder: ' ',
            style: { maxWidth: 500, fontWeight: 'bold', fontSize: '16px' },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="isaccess"
          title={<span>确定基金公司是否<br />符合准入条件</span>}
          type="radio"
          editable={['70'].includes(elementCode) && !readOnlyFlag}
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          x-component-props={{
            placeholder: '请选择确定基金公司是否符合准入条件',
            previewPlaceholder: ' ',
            style: { maxWidth: 500, marginBottom: 30 },
          }}
          x-mega-props={{ span: 4 }}
        />
      </BasicFormCard>

    </>
  );
}
export default Form;
