import React from 'react';
import store from '@/store';
import { FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
const { onFieldInputChange$, onFieldInit$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    this.managerid = null;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag, readOnlyFlag } = getProcess() || {};
    this.managerid = null;
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
  }
  createFormEffects() {
    this.changeAgencyActionRef = React.useRef();
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      onFieldInputChange$('fundcode').subscribe(({value,values}) => {
          this.dispatcher.listFuturesAccount({
            fundcode:value,
          }).then(res=>{
            if(res && res.data&&Array.isArray(res.data)&&res.data.length>=2){
              setFieldState('anndate', (state) => {
                state.description = <span>一个产品最多申请两家期货公司 提示产品是否开过，两家期货公司，开过两个期货公司，无法再申请</span>;
              });
            }else{
              setFieldState('anndate', (state) => {
                state.description = <span></span>;
              });
            }
          })
      });
      if (['70'].includes(this.elementCode)){
        onFieldInit$('itemlist').subscribe((state) => {
          const itemlist = getFieldValue('itemlist') || [];
          console.log(itemlist,'....itemlist')
          const totalNum=itemlist.reduce((prev,next)=>{
            let itemSum=(Number(next.score)*Number(next.weights))/10
            return prev+itemSum
          },0)
          setFieldValue('score', Number(totalNum));
          if(totalNum>=60){
            setFieldValue('isaccess', String(1));
          }else{
            setFieldValue('isaccess', String(0));
          }
        });
      }

    };
  }

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }

  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileId) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    console.log(attachments)
    return attachments;
  };

  formatData(values) {
    return {
      ...values,
      attachmentlist: this.formatFiles(values.attachmentlist),
    };
  }
  applySubmit(values) {
    const result = values;
    console.log('提交前数据：', values);
    let data = this.formatData(result);
    console.log('提交前数据：', data);
    return data;
  }

  auditSubmit(values) {
    console.log('提交前的数据auditSubmit', values);
    const result = values;
    let data = this.formatData(result);
    console.log('提交后的数据auditSubmit', data);
    return data;
  }


  get expressionScope() {
    return {
      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              newFileList = newFileList.slice(0, 1);
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
    };
  }
}
