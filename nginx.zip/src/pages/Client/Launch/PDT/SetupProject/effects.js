import React from 'react';
import { FormPath, FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import { Tooltip, Button, Input, Radio } from 'antd';
import { fn } from '@cerdo/cerdo-utils/lib';
import moment from 'moment';
import { isMobile, defaultNoticeusers } from '@/utils';
import { uniq } from 'lodash';
import { toggleSignType } from '@/pages/Client/Launch/utils';

const { onFieldValueChange$, onFormInit$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);

    const {
      context: { getProcess },
    } = props;
    const { elementCode, readOnlyFlag, firstTokenFlag } = getProcess() || {};
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.beforeOpenDay = null;
  }

  createFormEffects() {
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      onFormInit$().subscribe(() => {
        this.dispatcher.getWorkDay({ offset: 3 }).then((result) => {
          if (result && result.data) {
            setFieldValue('afterthreeopenday', result.data);
          }
        });

        if (this.formData.openanndate) {
          this.dispatcher
            .getWorkDate({ offset: -10, date: this.formData.openanndate })
            .then((result) => {
              if (result && result.data) {
                this.beforeOpenDay = result.data;
              }
            });
        }

        // 无批文文件 则不展示
        setFieldState('approvalfile', (s) => {
          s.display = (this.formData.approvalfile || []).length > 0;
        });
      });

      // 指数基金联动
      onFieldValueChange$('isindexfund').subscribe(({ value, name }) => {
        setFieldState('*(indexfundtype,targetindexcode,targetindexname,indexorganization)', (s) => {
          s.display = Number(value) === 1;
        });
      });

      // 指数基金类型联动
      onFieldValueChange$('indexfundtype').subscribe(({ value, name }) => {
        setFieldState('basketcode', (s) => {
          s.display = value === 'ETF';
        });
        setFieldState('*(goalfundcode,goalfundname)', (s) => {
          s.display = value === 'ETF联接基金';
        });
      });

      // 上市联动
      onFieldValueChange$('sharelist.*.islisted').subscribe(({ value, name }) => {
        setFieldState(
          FormPath.transform(name, /\d/, ($1) => `*(sharelist.${$1}.*(listingplace,listingtype))`),
          (s) => {
            s.display = Number(value) === 1;
          },
        );
      });

      // 是否盖章
      onFieldValueChange$('establish50.isseal').subscribe(({ value }) => {
        const oldNoticeusers = this.formData.establish50?.noticeusers?.split(',');
        const noticeusers =
          value === '1'
            ? uniq([...oldNoticeusers, ...defaultNoticeusers])
            : oldNoticeusers.filter((id) => !defaultNoticeusers.includes(id));
        setFieldValue('establish50.noticeusers', noticeusers);
      });
    };
  }

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }

  formatFiles = (result) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileId) {
        return file;
      }
      return {
        filename: file.response.fileName,
        filesize: file.response.fileSize,
        fileid: file.response.fileId,
        filepath: file.response.filePath,
        createuser: file.response.createUser,
        createtime: file.response.createTime,
      };
    };
    const attachments = (result || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  formatData(values) {
    return {
      ...values,
      establish50: toggleSignType(values.establish50),
      establish120: toggleSignType(values.establish120),
      checkassetfilelist: this.formatFiles(values.checkassetfilelist || []),
      setupletterfilelist: this.formatFiles(values.setupletterfilelist || []),
      subrednoticefilelist: this.formatFiles(values.subrednoticefilelist || []),
      setupnoticefilelist: this.formatFiles(values.setupnoticefilelist || []),
      setupfilelist: this.formatFiles(values.setupfilelist || []),
      liquidfilelist: this.formatFiles(values.liquidfilelist || []),
      managerid: this.joinArray(values.managerid),
      fundmanagerid: this.joinArray(values.fundmanagerid),
      bitype: this.setBiType(values.bitype),
    };
  }

  applySubmit(values) {
    const result = values;
    console.log('提交前数据：', values);
    let data = this.formatData(result);
    console.log('提交前数据：', data);
    return data;
  }

  auditSubmit(values) {
    if (Number(this.elementCode) === 40) {
      if (
        (values.establish50.countersigndeparts || []).length === 0 &&
        (values.establish50.countersignusers || []).length === 0
      ) {
        this.antMessage.info('成立公告会签部门、会签人必须选填其中一项');
        return false;
      }
    }

    if (Number(this.elementCode) === 110) {
      if (
        (values.establish120.countersigndeparts || []).length === 0 &&
        (values.establish120.countersignusers || []).length === 0
      ) {
        this.antMessage.info('申赎公告会签部门、会签人必须选填其中一项');
        return false;
      }
    }

    if (Number(this.elementCode) === 100) {
      if (moment().isBefore(moment(this.beforeOpenDay))) {
        this.antMessage.info(
          `请在首次开放日公告日期10个工作日内（${this.beforeOpenDay}后）提交，以防代销数据不准确`,
        );
        return false;
      }
    }

    console.log('提交前数据：', values);
    let data = this.formatData(values);
    return data;
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  splitArray(data, chr = ',') {
    if (data && typeof data === 'string') {
      return data.split(chr);
    }
    if (data instanceof Array) {
      return data;
    }
    return data;
  }

  getBiType = (value) => {
    if (value) {
      if (value.length === 4) {
        return [value];
      }
      if (value.length === 6) {
        return [value.substr(0, 4), value];
      }
      if (value.length === 8) {
        return [value.substr(0, 4), value.substr(0, 6), value];
      }
    }
    return value;
  };

  setBiType = (value) => {
    if (Array.isArray(value)) {
      return value.slice(-1).join();
    }
    return value;
  };

  applyFormatData(values) {
    return {
      ...values,
      establish50: toggleSignType(values.establish50),
      establish120: toggleSignType(values.establish120),
      managerid: this.splitArray(values.managerid),
      bitype: this.getBiType(values.bitype),
    };
  }

  auditFormatData(values) {
    return {
      ...values,
      establish50: toggleSignType(values.establish50),
      establish120: toggleSignType(values.establish120),
      managerid: this.splitArray(values.managerid),
      bitype: this.getBiType(values.bitype),
    };
  }

  copyText = (txt) => {
    try {
      navigator.clipboard.writeText(txt).then(
        () => {
          this.antMessage.success(`复制成功`);
        },
        () => {
          this.antMessage.error(`复制失败，请手动复制`);
        },
      );
    } catch {
      let oInput = document.createElement('input');
      oInput.value = txt;
      document.body.appendChild(oInput);
      oInput.select(); // 选择对象
      document.execCommand('Copy'); // 执行浏览器复制命令
      this.antMessage.success(`复制成功`);
      oInput.remove();
    }
  };

  handleRadioClick = ({ target: { value } }) => {
    this.formActions.setFieldValue(
      'orginfolist',
      value === '全部'
        ? this.formData.orginfolist || []
        : (this.formData.orginfolist || []).filter((a) => a.companytype === value),
    );
  };

  get expressionScope() {
    return {
      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response?.fileid || file.response?.fileId || '', ...file },
                ...currentFileList,
              ];
              // newFileList = newFileList.slice(0, 1);
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
      renderExtendButtons: () => (
        <div style={{ height: '24px' }}>
          {!isMobile() && (
            <Tooltip title="生成申赎公告中代销机构名称文本">
              <Button
                type="primary"
                size="small"
                onClick={() => {
                  if ((this.formData.orginfolist || []).length === 0) {
                    this.antMessage.warning('未检测到代销机构信息，无法生成');
                    return;
                  }
                  this.dispatcher
                    .agencyRelease({
                      dataid: this.formData.id,
                      fundid: this.formData.fundid,
                      isnew: Number(this.elementCode) === 100 && !this.readOnlyFlag ? '1' : '0', // 判断是否取最新的代销机构
                    })
                    .then((result) => {
                      if (fn.checkResponse(result)) {
                        if (result.data) {
                          const value = `${
                            result.data ? `${result.data}。\n` : ''
                          }基金管理人可根据有关法律法规的要求，选择其它符合要求的机构销售本基金，并在基金管理人网站公示。`;
                          this.antModal.info({
                            icon: null,
                            title: (
                              <div>
                                代销机构名称文本{' '}
                                <Button
                                  size="small"
                                  type="link"
                                  onClick={() => this.copyText(value)}
                                >
                                  复制文本
                                </Button>
                              </div>
                            ),
                            width: 800,
                            okText: '关闭',
                            content: (
                              <Input.TextArea
                                defaultValue={value}
                                autoSize={{ minRows: 10, maxRows: 15 }}
                              />
                            ),
                          });
                        } else {
                          this.antMessage.error('生成失败');
                        }
                      }
                    });
                }}
              >
                生成文本
              </Button>
            </Tooltip>
          )}
          <Radio.Group
            defaultValue="全部"
            size="small"
            style={{ position: 'absolute', right: 5 }}
            onChange={this.handleRadioClick}
          >
            <Radio.Button value="全部">全部({this.formData.orginfolist.length})</Radio.Button>
            <Radio.Button value="银行">
              银行({this.formData.orginfolist.filter((a) => a.companytype === '银行').length})
            </Radio.Button>
            <Radio.Button value="券商">
              券商({this.formData.orginfolist.filter((a) => a.companytype === '券商').length})
            </Radio.Button>
            <Radio.Button value="第三方">
              第三方({this.formData.orginfolist.filter((a) => a.companytype === '第三方').length})
            </Radio.Button>
            <Radio.Button value="其他">
              其他({this.formData.orginfolist.filter((a) => a.companytype === '其他').length})
            </Radio.Button>
          </Radio.Group>
        </div>
      ),
    };
  }
}
