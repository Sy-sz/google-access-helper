import React from 'react';
import { Field } from 'formily-antd';
import { FormMegaLayout } from '@formily/antd-components';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { Button } from 'antd';
import {
  useMegaLayoutProps,
  useDictList,
  useManagerList,
  useAgencyList,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import { DeleteOutlined } from '@ant-design/icons';
import moment from 'moment';
import { renderSign } from '@/pages/Client/Launch/utils';

function Form(props) {
  const {
    context: { formData, getProcess },
    formEffects: { formActions },
  } = props;
  const { elementCode, readOnlyFlag } = getProcess() || {};
  // 清算成立资料 折叠
  const liquidfilelistCollapse = elementCode > 30 || (elementCode === 30 && readOnlyFlag);

  const comProps = {
    size: 'middle',
  };

  const megaProps = {
    labelWidth: 160,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };

  const megaLayoutProps = useMegaLayoutProps(megaProps);

  const managerProps = useManagerList({ multiple: true, tokenSeparators: [','] });
  const businessTypeProps = useDictList({ id: '9cd915e33daf4cd78430e8499642c39f' });
  const riskLevelProps = useDictList({ id: '81e87383a78a486091eef2183e0cf163' });
  const fundtypeProps = useDictList({ id: '086af717-93d2-4a11-ad4d-04cb8e576c85' });
  const indexTypeProps = useDictList({ id: '659ef3ea68d843c8ba2900029e3a288a' });
  const csrcFundTypeProps = useDictList({ id: 'f3e9f86d-c12c-44c9-bb02-38848e438bce' });
  const shareTypeProps = useDictList({ id: '315a4574dc74451d9c9c79708df15d1d' });
  const currencyProps = useDictList({ id: '80e7fe7b84374cceb7fc921d4cf0362e' });
  const listingPlaceProps = useDictList({ id: '5ad101e1b15b466db717de898ab426bc' });
  const listingTypeProps = useDictList({ id: '3dfa7cb6cd474c4480457266aa402300' });
  const biTypeProps = useDictList({
    type: 'cascader',
    multiple: true,
    id: 'e15090ac-bf96-467d-86b9-377ec8777368',
  });

  const renderFileCard = (title, name, code, opts = {}) => {
    let display = Number(elementCode) >= code[0];
    // 验资报告节点 未传文件 后续节点不展示
    if (code[0] === 31 && !code.includes(Number(elementCode))) {
      display = (formData[name] || []).length > 0;
    }

    return (
      <BaseFormCard
        title={title}
        megaLayout={megaProps}
        display={display}
        name={`${name}Card`}
        {...opts}
      >
        <Field
          title={`${title}文件`}
          name={name}
          type="bpm-upload-list"
          editable={code.includes(Number(elementCode)) && !readOnlyFlag}
          required={code.includes(Number(elementCode))}
          x-component-props={{
            onSuccess: `{{fileSuccess("${name}")}}`,
            onDel: `{{fileDel("${name}")}}`,
            accept: '',
            multiple: true,
            isFsfund: true,
            maxLength: 4,
          }}
          x-mega-props={{ span: 2 }}
        />
      </BaseFormCard>
    );
  };

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BaseFormCard
        title="基金信息"
        name="fundInfoCard"
        megaProps={megaProps}
        upDown={Number(elementCode) >= 40 ? 'up' : 'down'}
      >
        {/* <Field
          name="isinnovation"
          title="是否为创新产品"
          type="string"
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          x-component-props={{ placeholder: `请选择是否为创新产品` }}
        /> */}
        <Field name="fundid" type="string" display={false} required />
        <Field
          name="fundcode"
          title="基金代码"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金代码' }}
        />
        <Field
          name="fundname"
          title="基金名称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金名称' }}
        />
        <Field
          name="fundinnershortname"
          title="基金简称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金简称' }}
        />
        <Field
          name="fundshortname"
          title="信披简称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入信披简称' }}
        />
        <Field
          name="businesstype"
          title="基金类别"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金类别',
            previewPlaceholder: '-',
            ...businessTypeProps,
          }}
        />
        <Field
          name="managerid"
          title="基金经理"
          type="tree-select"
          required
          x-component-props={{
            ...comProps,
            placeholder: '请选择基金经理',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...managerProps,
          }}
        />
        <Field
          name="risklevel"
          title="基金风险等级"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金风险等级',
            previewPlaceholder: '-',
            ...comProps,
            ...riskLevelProps,
          }}
        />
        <Field
          name="trusteeid"
          title="托管人"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择托管人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '托管人' }),
          }}
        />
        <Field
          name="abroadfundcustodianid"
          title="境外托管人"
          type="tree-select"
          x-component-props={{
            placeholder: '请选择境外托管人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '境外托管人' }),
          }}
        />
        <Field
          name="fundmanagerid"
          title="基金管理人"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金管理人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '基金管理人' }),
          }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="基金类型"
        megaProps={megaProps}
        upDown={Number(elementCode) > 20 ? 'up' : 'down'}
        name="fundTypeCard"
      >
        <Field
          name="fundtype"
          title="基金类型"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金类型',
            previewPlaceholder: '-',
            ...comProps,
            ...fundtypeProps,
          }}
        />
        {[
          { key: 'isinitiatingfund', label: '是否发起式基金', required: true },
          { key: 'isqdii', label: '是否QDII基金', required: true },
          { key: 'isinstitutionpdt', label: '是否机构类产品', required: true },
          { key: 'ismoreshares', label: '是否多份额类基金', required: true },
          { key: 'isfuturesfunc', label: '是否需要期货功能', required: true },
          { key: 'isindexfund', label: '是否指数基金', required: true },
        ].map((item) => {
          return (
            <Field
              key={item.key}
              name={item.key}
              title={item.label}
              type="string"
              required={item.required}
              enum={[
                { label: '是', value: '1' },
                { label: '否', value: '0' },
              ]}
              x-component-props={{
                placeholder: `请选择${item.label}`,
                allowClear: true,
              }}
            />
          );
        })}
        <Field
          name="indexfundtype"
          title="指数基金类型"
          type="tree-select"
          display={false}
          required
          x-component-props={{
            placeholder: '请选择指数基金类型',
            previewPlaceholder: '-',
            ...comProps,
            ...indexTypeProps,
          }}
        />
        <Field
          name="goalfundcode"
          title="目标基金代码"
          type="string"
          display={false}
          required
          x-component-props={{ placeholder: '请输入目标基金代码' }}
        />
        <Field
          name="goalfundname"
          title="目标基金名称"
          type="string"
          display={false}
          required
          x-component-props={{ placeholder: '请输入目标基金名称' }}
        />
        <Field
          name="targetindexcode"
          title="标的指数代码"
          type="string"
          display={false}
          required
          x-component-props={{ placeholder: '请输入标的指数代码' }}
        />
        <Field
          name="targetindexname"
          title="标的指数名称"
          type="string"
          display={false}
          required
          x-component-props={{ placeholder: '请输入标的指数名称' }}
        />
        <Field
          name="indexorganization"
          title="指数公司"
          type="string"
          display={false}
          required
          x-component-props={{ placeholder: '请输入指数公司' }}
        />
        <Field
          name="basketcode"
          title="ETF定义文件编码"
          type="string"
          display={false}
          // required
          x-component-props={{ placeholder: '请输入ETF定义文件编码' }}
        />
        <Field
          name="bitype"
          title="BI分类"
          type="tree-select"
          required
          x-component-props={{
            ...biTypeProps,
            placeholder: '请选择BI分类',
            separator: '',
            findedSeparator: '',
            renderText: (data, record) => {
              return data && data.namePath
                ? data.namePath.split('BI分类/').length > 1
                  ? data.namePath.split('BI分类/')[1]
                  : data.name
                : data?.name || '';
            },
          }}
        />
        <Field
          name="csrcfundtype"
          title="产品类别(证监会)"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择产品类别(证监会)',
            previewPlaceholder: '-',
            ...comProps,
            ...csrcFundTypeProps,
          }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="发售信息"
        name="issueInfoCard"
        megaProps={megaProps}
        upDown={['40', '110'].includes(elementCode) ? 'up' : 'down'}
      >
        <Field
          name="issuestartdate"
          title="募集开始日(T)"
          type="date"
          required
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          name="issueenddate"
          title="募集结束日(R)"
          type="date"
          required
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          name="expectsetupdate"
          title="预计成立日(P)"
          type="date"
          required
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={[
            {
              validator: (value) => {
                const { getFieldValue } = formActions;
                const issueenddate = getFieldValue('issueenddate');
                if (moment(value).isBefore(moment(issueenddate))) {
                  return '预计成立日必须大于募集结束日';
                }
                return '';
              },
            },
          ]}
        />
        <Field
          name="realsetupdate"
          title="实际成立日(P)"
          type="date"
          editable={Number(elementCode) === 70 && !readOnlyFlag}
          required={Number(elementCode) === 70}
          display={Number(elementCode) >= 70}
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={[
            {
              validator: (value) => {
                const { getFieldValue } = formActions;
                const issueenddate = getFieldValue('issueenddate');
                if (moment(value).isBefore(moment(issueenddate))) {
                  return '实际成立日必须大于募集结束日';
                }
                return '';
              },
            },
          ]}
        />
        <Field name="afterthreeopenday" type="string" display={false} />
        <Field
          name="openday"
          title="开放日(Q)"
          type="date"
          editable={Number(elementCode) === 80 && !readOnlyFlag}
          required={Number(elementCode) === 80}
          display={Number(elementCode) >= 80}
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={[
            {
              validator: (value) => {
                const { getFieldValue } = formActions;
                const afterthreeopenday = getFieldValue('afterthreeopenday');
                if (afterthreeopenday && moment(value).isBefore(moment(afterthreeopenday))) {
                  return '开放日必须为当前日期的3个工作日后';
                }
                return '';
              },
            },
          ]}
        />
        <Field
          name="openanndate"
          title="首次开放日公告日期"
          type="date"
          editable={Number(elementCode) === 90 && !readOnlyFlag}
          required={Number(elementCode) === 90}
          display={Number(elementCode) >= 90}
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={[
            {
              validator: (value) => {
                const { getFieldValue } = formActions;
                const openday = getFieldValue('openday');
                if (openday && !moment(value).isBefore(moment(openday))) {
                  return '需小于实际开放日';
                }
                return '';
              },
            },
          ]}
        />
        <Field
          name="remark"
          title="备注信息"
          type="textarea"
          x-component-props={{
            placeholder: '请输入备注信息',
            previewPlaceholder: '-',
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="运营要素"
        megaProps={megaProps}
        upDown={Number(elementCode) > 20 ? 'up' : 'down'}
        name="elementsCard"
      >
        <Field
          name="approvaldate"
          title="批复日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field name="docnumber" title="核准文号" type="string" />
        <Field
          title="批文"
          name="approvalfile"
          type="bpm-upload-list"
          required
          editable={false}
          x-mega-props={{ span: 2 }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="份额信息"
        megaLayout={false}
        upDown={Number(elementCode) > 20 ? 'up' : 'down'}
        name="sharesCard"
      >
        <Field
          name="sharelist"
          minItems={1}
          maxItems={5}
          type="array"
          default={[{}]}
          x-component="bpm-array-card"
          x-component-props={{
            title: '份额',
            titlefield: 'sharetype',
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderRemove: (idx) => {
              const mutators = formActions.createMutators('sharelist');
              return (
                idx !== 0 && (
                  <Button
                    shape="circle"
                    icon={<DeleteOutlined />}
                    onClick={() => {
                      mutators.remove(idx);
                    }}
                  />
                )
              );
            },
            renderAddition: () => (
              <Button type="primary" size="small">
                添加子份额
              </Button>
            ),
          }}
        >
          <Field type="object">
            <FormMegaLayout {...megaLayoutProps}>
              <Field
                name="ismainshare"
                title="是否主份额"
                type="string"
                required
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否主份额`,
                }}
              />
              <Field
                name="sharetype"
                title="份额类型"
                required
                type="tree-select"
                x-component-props={{
                  ...shareTypeProps,
                  placeholder: `请选择份额类型`,
                }}
              />
              <Field
                name="fundcode"
                title="份额代码"
                type="string"
                required
                x-component-props={{ placeholder: '请输入份额代码' }}
              />
              <Field
                name="fundname"
                title="网站简称"
                type="string"
                required
                x-component-props={{ placeholder: '请输入网站简称' }}
              />
              <Field
                name="fundshortname"
                title="信披简称"
                type="string"
                required
                x-component-props={{ placeholder: '请输入信披简称' }}
              />
              {/* <Field
                name="setupdate"
                title="份额生效日期"
                type="date"
                required
                x-component-props={{ format: 'YYYY-MM-DD' }}
              /> */}
              {/* <Field
                name="setupassets"
                title="成立规模(亿)"
                type="number"
                x-component-props={{
                  min: 0,
                  max: 100,
                  precision: 2,
                  formatter: (value) => value && `${value}%`,
                  parser: (value) => value.replace('%', ''),
                  placeholder: '请输入成立规模',
                }}
              /> */}
              <Field
                name="floortradecode"
                title="份额场内代码"
                type="string"
                // required
                x-component-props={{ placeholder: '请输入份额场内代码' }}
              />
              <Field
                name="floortradename"
                title="份额场内简称"
                type="string"
                // required
                x-component-props={{ placeholder: '请输入份额场内简称' }}
              />
              <Field
                name="currency"
                title="交易币种"
                default="人民币"
                type="tree-select"
                x-component-props={{
                  ...currencyProps,
                  placeholder: `请选择交易币种`,
                }}
              />
              <Field
                name="islisted"
                title="是否上市"
                type="string"
                required
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否上市`,
                }}
              />
              <Field
                name="listingplace"
                title="上市场所"
                required
                display={false}
                type="tree-select"
                x-component-props={{
                  ...listingPlaceProps,
                  placeholder: `请选择上市场所`,
                }}
              />
              <Field
                name="listingtype"
                title="上市基金类型"
                required
                display={false}
                type="tree-select"
                x-component-props={{
                  ...listingTypeProps,
                  placeholder: `请选择上市基金类型`,
                }}
              />
              <Field
                name="salesfee"
                title="销售服务费率"
                type="number"
                x-component-props={{
                  min: 0,
                  max: 100,
                  precision: 2,
                  formatter: (value) => value && `${value}%`,
                  parser: (value) => value.replace('%', ''),
                  placeholder: '请输入销售服务费率(%)',
                }}
              />
            </FormMegaLayout>
          </Field>
        </Field>
      </BaseFormCard>
      {renderFileCard('成立资料', 'setupfilelist', [20, 40], {
        upDown: elementCode >= 110 ? 'up' : 'down',
      })}

      {renderFileCard('清算成立资料', 'liquidfilelist', [30], {
        upDown: liquidfilelistCollapse ? 'up' : 'down',
        title: liquidfilelistCollapse ? '清算成立资料 （原始数据 无需审批）' : '清算成立资料',
      })}

      {renderFileCard('验资报告', 'checkassetfilelist', [31])}

      {renderFileCard('成立公告', 'setupnoticefilelist', [70], {
        upDown: elementCode >= 110 ? 'up' : 'down',
      })}

      {renderFileCard('成立回函', 'setupletterfilelist', [70], {
        upDown: elementCode >= 110 ? 'up' : 'down',
      })}

      {renderSign({
        name: 'establish50',
        title: '成立公告会签信息',
        display: elementCode >= 40,
        editable: elementCode === '40' && !readOnlyFlag,
        isseal: {
          show: true,
          title: '成立公告资料',
        },
        upDown: elementCode > 40 ? 'up' : 'down',
      })}

      {renderFileCard('开放申赎公告', 'subrednoticefilelist', [110])}

      {renderSign({
        name: 'establish120',
        title: '开放申赎公告会签信息',
        display: elementCode >= 110,
        editable: elementCode === '110' && !readOnlyFlag,
        upDown: elementCode > 110 ? 'up' : 'down',
      })}

      <BaseFormCard
        title="代销机构信息"
        megaLayout={false}
        name="orginfoCard"
        display={Number(elementCode) >= 100}
        upDown={Number(elementCode) > 100 ? 'up' : 'down'}
      >
        <Field
          name="orginfolist"
          type="array"
          x-component="form-table"
          x-component-props={{
            editable: true,
            pagination: true,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            renderRemove: () => null,
            rowSelection: null,
            renderExtendButtons: '{{renderExtendButtons}}',
          }}
        >
          <Field type="object">
            <Field
              name="fundcode"
              title="基金代码"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="fundname"
              title="基金名称"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companycode"
              title="机构代码"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companyname"
              title="机构名称"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companytype"
              title="机构类型"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="onlinedate"
              title="代销上线时间"
              editable={false}
              type="date"
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
          </Field>
        </Field>
      </BaseFormCard>
      {/* <Field
          title="发布公告"
          name="publishnotice"
          type="button"
          x-component-props={{
            text: '点击跳转发布',
            // onClick: '{{publishNotice}}',
          }}
          x-mega-props={{ span: 4 }}
        /> */}
    </>
  );
}

export default Form;
