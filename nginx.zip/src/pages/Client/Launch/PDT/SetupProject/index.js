// 成立流程

import React from 'react';
import Form from './form';
import Effects from './effects';
import BaseForm from '@chinahorm/web-components/es/components/BaseForm';

function Index(props) {
  const formEffects = new Effects(props);

  // 成立资料收集以公告节点【40】，页面可编辑
  if (Number(formEffects.elementCode) === 40 && !formEffects.readOnlyFlag) {
    formEffects.editable = true;
  }

  return (
    <BaseForm formEffects={formEffects} {...props}>
      <Form audit={formEffects.audit} formEffects={formEffects} {...props} />
    </BaseForm>
  );
}

export default Index;
