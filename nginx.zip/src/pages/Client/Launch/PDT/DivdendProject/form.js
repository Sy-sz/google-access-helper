/* eslint-disable complexity */
import React from 'react';
import { Field } from 'formily-antd';
import moment from 'moment';
import {
  useFundFullList,
  useUserList,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import { convert } from '@cerdo/cerdo-utils';
import { renderSign } from '../../utils';

const Form = (props) => {
  const {
    context: { formData, getProcess },
    formEffects: { formActions },
  } = props;
  const { elementCode, readOnlyFlag, firstTokenFlag, elementId, endElementId } = getProcess() || {};

  const megaProps = {
    labelWidth: 160,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };
  const liquidationProps = useUserList({ departmentid: '979E99E7-9E37-4429-928B-62AA2BB91C7F' });
  const endFlag = elementId === endElementId;
  return (
    <>
      <BasicFormCard
        title="基本信息"
        megaProps={megaProps}
        tips={<b style={{ color: 'red' }}>分红流程发起涉及人员，请准时保守秘密。</b>}
      >
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard
        title="基金信息"
        megaProps={megaProps}
        tips={
          firstTokenFlag && !readOnlyFlag ? (
            <b style={{ color: 'blue' }}>
              选择公告日或红利发放日，其他日期自动计算, (建议首先选择公告日 或 红利发放日)
            </b>
          ) : (
            ''
          )
        }
      >
        <Field
          name="fundcode"
          title="基金名称"
          type="tree-select"
          required
          x-component-props={{
            style: { maxWidth: 500 },
            optionFilterProp: 'label',
            placeholder: '请输入基金名称',
            ...useFundFullList({
              fundperiod: '存续期',
              dropdownMatchSelectWidth: false,
            }),
          }}
        />
        <Field
          name="sharecode"
          type="bpm-checkbox"
          required
          visible={false}
          x-mega-props={{ span: 2 }}
          x-component-props={{
            style: { maxWidth: 500 },
            checkAll: false,
            tokenSeparators: [','],
          }}
        />
        <Field
          name="largepurmsg"
          title={
            <span>
              过去20个工作日该基金
              <br />
              该基金发生大额申购次数
            </span>
          }
          type="number"
          visible={false}
          editable={false}
          x-mega-props={{ span: 4 }}
          x-component-props={{
            style: { maxWidth: 500 },
            placeholder: '请输入过去20个工作日该基金发生大额申购次数',
          }}
        />
        <Field
          name="incomedistributebasedate"
          title="收益分配基准日"
          type="date"
          x-rules={[
            {
              validator: (value) => {
                const { registrationprofitdate } = formData;
                if (moment(registrationprofitdate).isBefore(moment(value))) {
                  return '收益分配基准日不能大于权益登记日';
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            placeholder: '请输入收益分配基准日',
            format: 'YYYY-MM-DD',
          }}
          required
        />
        <Field
          name="anndate"
          title="公告日"
          type="date"
          x-rules={[
            {
              validator: (value) => {
                const { incomedistributebasedate, registrationprofitdate } = formData;
                if (moment(incomedistributebasedate).isAfter(moment(value))) {
                  return '公告日不能小于收益分配基准日';
                } else if (moment(registrationprofitdate).isBefore(moment(value))) {
                  return '公告日日不能大于权益权益登记日';
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            placeholder: '请输入公告日',
            format: 'YYYY-MM-DD',
          }}
          required
        />
        <Field
          name="registrationprofitdate"
          title="权益登记日"
          type="date"
          required
          x-rules={[
            {
              validator: (value) => {
                const { incomedistributebasedate, exdividendate } = formData;
                if (moment(incomedistributebasedate).isAfter(moment(value))) {
                  return '权益登记日不能小于收益分配基准日';
                } else if (moment(exdividendate).isBefore(moment(value))) {
                  return '权益登记日不能大于除息日';
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
          }}
        />

        <Field
          name="exdividendate"
          title="除息日"
          type="date"
          required
          x-rules={[
            {
              validator: (value) => {
                const { registrationprofitdate, dividendpaymentdate } = formData;
                if (moment(registrationprofitdate).isAfter(moment(value))) {
                  return '除息日不能小于权益登记日';
                } else if (moment(dividendpaymentdate).isBefore(moment(value))) {
                  return '除息日不能大于红利发放日';
                }
                formActions.setFieldState(
                  '*(registrationprofitdate,dividendpaymentdate)',
                  (state) => {
                    state.ruleErrors = [''];
                  },
                );
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
          }}
        />
        <Field
          name="dividendpaymentdate"
          title="红利发放日"
          type="date"
          required
          x-rules={[
            {
              validator: (value) => {
                const { exdividendate } = formData;
                if (moment(exdividendate).isAfter(moment(value))) {
                  return '红利发放日不能小于除息日';
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
          }}
        />
        <Field
          name="dividentamount"
          title="本次分红方案"
          type="number"
          description="单位:元/10份额"
          required
          x-component-props={{
            placeholder: '请输入本次分红方案',
            previewPlaceholder: ' ',
            min: 0,
            step: 0.01,
            parser: (value) => value.replace('元/10份额', ''),
          }}
        />
        <Field
          name="remark"
          title="备注信息"
          type="textarea"
          x-component-props={{
            placeholder: `涉及场外日期，请填写备注信息中，如除息日（场外）`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />

        <Field
          name="pauselargetransactions"
          title="是否需要暂停大额交易"
          type="radio"
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          visible={(!['10', '20'].includes(elementCode) && !firstTokenFlag) || endFlag}
          editable={['30'].includes(elementCode) && !readOnlyFlag}
          required
          x-component-props={{ size: 'middle' }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="profitratio"
          title="基金收益比例情况"
          type="textarea"
          visible={(!['10', '20'].includes(elementCode) && !firstTokenFlag) || endFlag}
          editable={['30'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            placeholder: `请填写基金收益比例情况`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="remarks"
          description={<h4 style={{ color: 'red' }}>提示 ： 请恢复大额交易</h4>}
          visible={['80'].includes(elementCode)}
          type="string"
          x-mega-props={{ span: 4 }}
        />
      </BasicFormCard>

      {renderSign({
        name: 'dividend60',
        title: '会签信息',
        display:
          (!['10', '20', '30', '40', '200', '210'].includes(elementCode) && !firstTokenFlag) ||
          endFlag,
        editable: ['50'].includes(elementCode) && !readOnlyFlag,
      })}

      <BasicFormCard
        title="分红方案"
        megaLayout={megaProps}
        visible={(!['10', '20', '30', '200'].includes(elementCode) && !firstTokenFlag) || endFlag}
      >
        <Field
          name="itemlist"
          type="array"
          x-component="form-table"
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            selectedAllRows: true,
          }}
          x-mega-props={{ span: 4 }}
          visible={(!['10', '20', '30', '200'].includes(elementCode) && !firstTokenFlag) || endFlag}
        >
          <Field type="object">
            <Field
              name="fundcode"
              title="基金代码"
              required
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="basedatefundshare"
              title="基准日基金份额净值（单位：人民币元）"
              required
              type="number"
              editable={['40'].includes(elementCode) && !readOnlyFlag}
              x-component-props={{
                precision: 6,
                placeholder: '请输入基准日基金份额净值',
                previewPlaceholder: ' ',
              }}
            />
            <Field
              name="basedatadistibuteprofit"
              title="基准日基金可供分配利润（单位：人民币元）"
              required
              type="number"
              editable={['40'].includes(elementCode) && !readOnlyFlag}
              x-component-props={{
                placeholder: '请输入基准日基金可供分配利润',
                previewPlaceholder: ' ',
                formatter: (value) => {
                  const decimals = String(value).split('.')[1] || '';
                  return convert.toThousands(value, Math.min(decimals.length, 2));
                },
                parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
              }}
            />
            <Field
              name="limitbasedateamount"
              title="截止基准日按照基金合同约定的分红比例计算的应分配金额（单位：人民币元）"
              type="number"
              editable={['40'].includes(elementCode) && !readOnlyFlag}
              x-component-props={{
                placeholder: '请输入截止基准日按照基金合同约定的分红比例计算的应分配金额',
                previewPlaceholder: ' ',
                formatter: (value) => {
                  const decimals = String(value).split('.')[1] || '';
                  return convert.toThousands(value, Math.min(decimals.length, 2));
                },
                parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
              }}
            />
          </Field>
        </Field>
        <Field
          name="reviewer"
          title="分红数据复核人员"
          type="tree-select"
          editable={['40'].includes(elementCode) && !readOnlyFlag}
          required
          x-component-props={{
            style: { maxWidth: 500 },
            optionFilterProp: 'label',
            ...liquidationProps,
            placeholder: '请选择复核人员',
          }}
        />
      </BasicFormCard>

      <BasicFormCard
        title="公告信息"
        megaLayout={megaProps}
        visible={
          (!['10', '20', '30', '40', '200', '210'].includes(elementCode) && !firstTokenFlag) ||
          endFlag
        }
      >
        <Field
          title="公告文件"
          name="noticefile"
          type="bpm-upload-list"
          editable={['50'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            onSuccess: '{{fileSuccess("noticefile")}}',
            onDel: '{{fileDel("noticefile")}}',
            accept: '.pdf,.docx,.doc',
            multiple: false,
            isFsfund: true,
            maxLength: 4,
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          name="generatebtn"
          type="button"
          visible={['50'].includes(elementCode) && !readOnlyFlag}
          editable={['50'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            text: '生成公告',
            onClick: '{{generateNotice}}',
          }}
        />
      </BasicFormCard>

      <BasicFormCard
        title="落实"
        megaLayout={megaProps}
        visible={(['110'].includes(elementCode) && !firstTokenFlag) || endFlag}
      >
        <Field
          title="发布公告"
          name="publishnotice"
          type="button"
          editable={['110'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            text: '点击跳转发布',
            onClick: '{{publishNotice}}',
          }}
          x-mega-props={{ span: 4 }}
        />
      </BasicFormCard>
      <BasicFormCard
        title="上传分红报告"
        megaLayout={megaProps}
        visible={(['90'].includes(elementCode) && !firstTokenFlag) || endFlag}
      >
        <Field
          name="isupload"
          title="本次分红报告是否上传"
          type="radio"
          required
          default="0"
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          editable={['90'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{ size: 'middle' }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          title="请上传报告"
          name="dividendfile"
          type="bpm-upload-list"
          visible={false}
          editable={['90'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            onSuccess: '{{fileSuccess("dividendfile")}}',
            onDel: '{{fileDel("dividendfile")}}',
            accept: '.pdf,.docx,.doc',
            multiple: false,
            isFsfund: true,
            maxLength: 4,
          }}
          x-mega-props={{ span: 2 }}
        />
      </BasicFormCard>
    </>
  );
};
export default Form;
