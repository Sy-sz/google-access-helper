import React from 'react';
import { FormPath, FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import moment from 'moment';
import { Table } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import { toggleSignType } from '../../utils';

const { onFieldValueChange$, onFieldInputChange$, onFieldInit$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag } = getProcess() || {};
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.orgDispatcher = store.getModelDispatchers('org');
    this.sharecodeList = [];
  }

  createFormEffects() {
    const dispatcher = store.useModelDispatchers('pdtSystem');
    const {
      context: { getProcess },
    } = this.props;
    const { firstTokenFlag, elementCode } = getProcess() || {};
    return ($, { setFieldState, setFieldValue, getFieldValue }) => {
      onFieldValueChange$(
        '*(anndate,incomedistributebasedate,registrationprofitdate,exdividendate,dividendpaymentdate,basedatefundshare)',
      ).subscribe(({ value, name }) => {
        this.formData[name] = value;
      });

      // 红利发放日
      onFieldInputChange$('dividendpaymentdate').subscribe(async ({ value }) => {
        if (value) {
          this.antMessage.loading('日期自动计算中...', 0);
          const divdate = await dispatcher.dividendDates({ divdate: value });
          this.antMessage.destroy();
          if (divdate.data && moment(divdate.data.date).isAfter(moment(divdate.data.anndate))) {
            setFieldValue('anndate', divdate.data.anndate);
            setFieldState('anndate', (state) => {
              state.description = (
                <div style={{ color: 'red' }}>
                  建议公告日必须大于当前工作日5个工作日，且公告日期不能为周一或者节假日的第一个工作日
                </div>
              );
            });
          } else if (
            divdate.data &&
            moment(divdate.data.date).isBefore(moment(divdate.data.anndate))
          ) {
            setFieldValue('incomedistributebasedate', divdate.data.incomedistributebasedate);
            setFieldValue('anndate', divdate.data.anndate);
            setFieldValue('registrationprofitdate', divdate.data.registrationprofitdate);
            setFieldValue('exdividendate', divdate.data.exdividendate);
            setFieldState('anndate', (state) => {
              state.description = null;
            });
            this.clearDateError();
          }
        }
      });
      // 公告日计算
      onFieldInputChange$('anndate').subscribe(async ({ value }) => {
        if (value) {
          this.antMessage.loading('日期自动计算中...', 0);
          const res = await dispatcher.dividendDates({ anndate: value });
          this.antMessage.destroy();
          if (res.data && moment(res.data.date).isAfter(moment(value))) {
            setFieldState('anndate', (state) => {
              state.description = (
                <div style={{ color: 'red' }}>
                  建议公告日必须大于当前工作日5个工作日，且公告日期不能为周一或者节假日的第一个工作日
                </div>
              );
            });
          } else if (res.data && !moment(res.data.date).isAfter(moment(value))) {
            setFieldValue('incomedistributebasedate', res.data.incomedistributebasedate);
            setFieldValue('registrationprofitdate', res.data.registrationprofitdate);
            setFieldValue('exdividendate', res.data.exdividendate);
            setFieldValue('dividendpaymentdate', res.data.dividendpaymentdate);
            setFieldState('anndate', (state) => {
              state.description = null;
            });
            this.clearDateError();
          }
        }
      });
      onFieldInputChange$('sharecode').subscribe((fieldState) => {
        let newarrList = [];
        // const itemList = this.formActions.getFieldValue('itemlist') || [];
        fieldState.value.forEach(async (item) => {
          this.sharecodeList.forEach((items) => {
            if (item === items.fundcode) {
              newarrList.push({
                fundcode: items.fundcode,
                fundname: items.fundname,
              });
              newarrList = [...newarrList];
              setFieldValue('itemlist', newarrList);
            }
          });
        });
      });

      onFieldInputChange$('isupload').subscribe(({ value }) => {
        setFieldState('dividendfile', (state) => {
          state.visible = Number(value) === 1;
        });
      });
      onFieldInit$('isupload').subscribe(({ value }) => {
        setFieldState('dividendfile', (state) => {
          state.visible = Number(value) === 1;
        });
      });
      onFieldInit$('fundcode').subscribe(async (fieldState) => {
        const { value } = fieldState;
        const res = await dispatcher.fundFullList({ keyword: value, fundperiod: '存续期' });
        if (Array.isArray(res.data) && res.data.length > 0) {
          const data = res.data.find((a) => a.fundcode === value);
          if (data) {
            setFieldState('sharecode', (state) => {
              this.managerid = data.managerid;
              state.visible = true;
              const shareData = data.sharelist.map((a) => ({
                label: `${a.fundshortname}[${a.fundcode}]`,
                value: a.fundcode,
              }));
              FormPath.setIn(state, 'props.enum', shareData);
              state.value = (this.formData.sharecode || '').split(';');
            });
          }
        }
      });
      // 过去20个工作日大额申购次数
      if (
        (elementCode === '60' || elementCode === '100') &&
        Number(this.formData.showlarge) === 1
      ) {
        setFieldState('largepurmsg', (state) => {
          state.visible = true;
        });
      }
      if (firstTokenFlag) {
        onFieldInputChange$('dividentamount').subscribe((state) => {
          const fundcode = getFieldValue('fundcode') || '';
          dispatcher
            .dividendFundday({
              fundcode: fundcode,
              date: this.formData.incomedistributebasedate,
              page: 1,
              size: 1,
            })
            .then((res) => {
              if (Array.isArray(res.data)) {
                const navunit = res.data[0].navunit;
                const navunits = Number(state.value) / navunit / 10;
                if (navunits > 0.05 && navunit) {
                  setFieldState(state.name, (state) => {
                    state.description = <div style={{ color: 'red' }}>大比例分红</div>;
                  });
                } else {
                  setFieldState(state.name, (state) => {
                    state.description = null;
                  });
                }
              }
            });
        });
      } else {
        onFieldInit$('dividentamount').subscribe((state) => {
          const fundcode = getFieldValue('fundcode') || '';
          dispatcher
            .dividendFundday({
              fundcode: fundcode,
              date: this.formData.incomedistributebasedate,
              page: 1,
              size: 1,
            })
            .then((res) => {
              if (Array.isArray(res.data)) {
                const navunit = res.data[0].navunit;
                const navunits = Number(state.value) / navunit / 10;
                if (navunits > 0.05 && navunit) {
                  setFieldState(state.name, (state) => {
                    state.description = <div style={{ color: 'red' }}>大比例分红</div>;
                  });
                } else {
                  setFieldState(state.name, (state) => {
                    state.description = null;
                  });
                }
              }
            });
        });
      }
      if (firstTokenFlag) {
        onFieldInputChange$('fundcode').subscribe((fieldState) => {
          const { value, values } = fieldState;
          this.sharecodeList = fieldState.values[1].data.sharelist;
          setFieldState('sharecode', (state) => {
            if (values.length > 0 && values[1].data) {
              this.managerid = values[1].data.managerid;
              state.visible = true;
              const data = values[1].data.sharelist.map((a) => ({
                label: `${a.fundshortname}[${a.fundcode}]`,
                value: a.fundcode,
              }));
              FormPath.setIn(state, 'props.enum', data);
              const stateValue = data.find((a) => a.value === this.formData.sharecode)
                ? this.formData.sharecode.split(';')
                : data.map((a) => a.value);
              state.value = stateValue;
              this.getDividendCount(stateValue.join(';') || '');
            }
            if (value) {
              const fundcode = getFieldValue('fundcode') || '';
              // 过去20个工作日大额申购次数
              dispatcher.dividendPurchase({ fundcode }).then((res) => {
                if (res) {
                  setFieldState('largepurmsg', (state) => {
                    state.visible = true;
                    state.value = Number(res.count);
                  });
                }
              });
            }
          });
        });
      } else {
        this.getDividendCount(this.formData.sharecode || '');
      }
    };
  }

  clearDateError() {
    let timer = setTimeout(() => {
      this.formActions.setFieldState(
        '*(dividendpaymentdate,anndate,incomedistributebasedate,exdividendate,registrationprofitdate)',
        (s) => {
          s.ruleErrors = [];
        },
      );
      if (timer) {
        clearTimeout(timer);
      }
    }, 200);
  }

  getDividendCount(shareCode) {
    const { setFieldValue, setFieldState, getFieldValue } = this.formActions;
    const shareCodeList = shareCode.split(';');
    const fundList =
      (this.formData.itemlist || []).length === 0
        ? shareCodeList.map((a) => ({ fundcode: a }))
        : this.formData.itemlist;
    setFieldValue('itemlist', fundList);
    setFieldState('fundcode', (state) => {
      state.description = (
        <div>
          该基金成立以来,总计分红
          <LoadingOutlined />次
        </div>
      );
    });
    this.dispatcher
      .dividendcount({ fundcode: getFieldValue('fundcode') || this.formData.fundcode })
      .then((res) => {
        if (res) {
          setFieldState('fundcode', (state) => {
            state.description =
              Number(res.data) > 0 ? (
                <span onClick={() => this.getDividendRecord(shareCodeList.join())}>
                  该基金成立以来,总计分红<b style={{ color: 'red' }}>{res.data}</b>次，
                  <a>点击查看历史数据</a>
                </span>
              ) : (
                <span>
                  该基金成立以来,总计分红<b style={{ color: 'red' }}>{res.data}</b>次
                </span>
              );
          });
        }
      });
  }

  getDividendRecord(fundCodes) {
    this.antMessage.loading('分红记录加载中...', 0);
    this.dispatcher.sharebonusList({ fundcode: fundCodes }).then((res) => {
      this.antMessage.destroy();
      if (Array.isArray(res.data)) {
        const dataList = res.data.map((item) => {
          return {
            fundcode: item.fundcode,
            rn: item.rn,
            unitdivdten: `每10份派现金${item.unitdivdten}元`,
            divddistridate: moment(item.divddistridate).format('YYYY-MM-DD'),
          };
        });
        this.antModal.info({
          title: '历史分红数据',
          icon: false,
          width: '50%',
          content: (
            <Table
              size="small"
              columns={[
                {
                  title: '基金代码',
                  dataIndex: 'fundcode',
                  key: 'fundcode',
                  align: 'center',
                },
                {
                  title: '分红期数',
                  dataIndex: 'rn',
                  key: 'rn',
                  align: 'center',
                },
                {
                  title: '分红方案',
                  dataIndex: 'unitdivdten',
                  key: 'unitdivdten',
                  align: 'center',
                },
                {
                  title: '分红发放日',
                  dataIndex: 'divddistridate',
                  key: 'divddistridate',
                  align: 'center',
                },
              ]}
              dataSource={dataList}
              bordered
            />
          ),
          okText: '确定',
          onOk(close) {
            close();
          },
        });
      }
    });
  }
  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }

  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileid) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  initValues = (values) => ({
    ...values,
    dividend60: toggleSignType(values.dividend60),
  });
  auditFormatData(values) {
    return this.initValues(values);
  }
  applyFormatData(values) {
    return this.initValues(values);
  }

  formatData(values) {
    return {
      ...values,
      dividend60: toggleSignType(values.dividend60),
      noticefile: this.formatFiles(values.noticefile),
      dividendfile: this.formatFiles(values.dividendfile),
      pauselargetransactions: this.joinArray(values.pauselargetransactions, ';'),
      fundcode: this.joinArray(values.fundcode, ';'),
      sharecode: this.joinArray(values.sharecode, ';'),
    };
  }

  applySubmit(values) {
    console.log('提交前的数据', values);
    const result = values;
    let data = this.formatData(result);
    return data;
  }

  auditSubmit(values) {
    console.log('提交前的数据auditSubmit', values);
    const result = values;
    if (this.elementCode === '50') {
      if (
        (result.dividend60.countersigndeparts || []).length === 0 &&
        (result.dividend60.countersignusers || []).length === 0
      ) {
        this.antMessage.info('会签部门、会签人必须选填其中一项');
        return false;
      }
    }
    if (this.elementCode === '40') {
      if (values.profitratio && values.itemlist.find((a) => Number(a.limitbasedateamount) === 0)) {
        this.antMessage.info('【截止基准日按照基金合同约定的分红比例计算的应分配金额】需要填写');
        return false;
      }
    }
    let data = this.formatData(result);
    console.log('提交后的数据auditSubmit', data);
    return data;
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  /**
   * 提交前置提示
   * @param values
   * @param next
   * @returns {boolean}
   */
  submitConfirm(values, next) {
    const { getFieldValue } = this.formActions;
    const pauselargetransactions = getFieldValue('pauselargetransactions') || '';
    if (this.pageStatus.firstEditable || this.pageStatus.applyEditable) {
      this.antModal.confirm({
        title: '请确认',
        content: (
          <div style={{ color: 'red' }}>
            <div>1. 请仔细确认您所填写的内容是否正确，如果送审，系统将不支持手工撤单；</div>
            <div>2. 请仔细确认是否与基金会计确认分红方案；</div>
            <ul style={{ paddingLeft: '25px' }}>
              <li>如果确认送审，请点击“是”，</li>
              <li>否则请点击“否”，重新填写相关内容。</li>
            </ul>
          </div>
        ),
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
    } else if (['110'].includes(this.elementCode)) {
      this.antModal.confirm({
        title: '请确认',
        content: <span style={{ color: 'red' }}>确认公告已发布？</span>,
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
    } else if (['50'].includes(this.elementCode)) {
      this.antModal.confirm({
        title: '',
        content: <span style={{ color: 'red' }}>请记得发起托管行审核</span>,
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
    } else if (['30'].includes(this.elementCode) && Number(pauselargetransactions) === 1) {
      this.antModal.confirm({
        title: '',
        content: <span style={{ color: 'red' }}>请产品经理自行发起暂停大额流程</span>,
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
    } else if (['80'].includes(this.elementCode)) {
      this.antModal.confirm({
        title: '',
        content: <span style={{ color: 'red' }}>请产品经理自行发起恢复大额流程</span>,
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
    } else {
      next(true);
    }
  }

  get expressionScope() {
    return {
      generateNotice: () => {
        this.antMessage.loading('公告文件生成中...', 0);
        // const fundcode = this.formActions.getFieldValue('fundcode') || '';
        // const addate = this.formActions.getFieldValue('addate') || '';
        const id = this.formData.id;
        this.dispatcher
          .dividendNotice({
            formid: id,
          })
          .then((res) => {
            this.antMessage.destroy();
            if (res.data && !res.error) {
              this.filename = res.data.filename;
              this.filepath = res.data.filepaths;
              this.fileid = res.data.fileid;
              this.antMessage.info('生成公告成功');
              // const { setFieldState } = this.formActions;
              this.formActions.setFieldState('noticefile', (state) => {
                state.value = [{ ...res.data, response: {} }];
              });
            } else {
              this.antMessage.info(res.message || '公告文件生成失败！');
            }
          });
      },

      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              newFileList = newFileList.slice(0, 1);
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
      publishNotice: async () => {
        const { variables } = this.props.context;
        const noticeFile = this.formData.noticefile || [];
        if (Array.isArray(noticeFile) && noticeFile.length > 0) {
          const fileid = noticeFile[0].fileid;
          const fundcode = this.formData.fundcode;
          this.antMessage.loading('发布公告中...', 0);
          const res = await this.dispatcher.pubNotice({
            fileid: fileid,
            mainfundcodes: fundcode,
            processcode: variables?.processCode,
          });
          this.antMessage.destroy();
          if (res && res.data) {
            // let url = '';
            // const hostname = window.location.hostname || '';
            // if (hostname.includes('localhost') || hostname.includes('172.30')) {
            //   url = '172.30.81.91/pdt/';
            // }
            // if (hostname.includes('apptest')) {
            //   url = 'apptest.fsfund.com:7171/fsyy/pdt-web/';
            // }
            // if (hostname.includes('fsapi') || hostname.includes('research')) {
            //   url = 'research.fsfund.com/web/pdt/';
            // }
            this.antMessage.success('公告生成成功，即将跳转发布页面', 1.5, () => {
              window.open(`#/app/pdt/notice/list?eid=${res.data}`);
              // window.open(`//${url}#/app/pdt/notice/list?eid=${res.data}`);
            });
          } else {
            this.antMessage.info(res.msg || '公告发布失败');
          }
        }
      },
    };
  }
}
