import React from 'react';
import moment from 'moment';
import { Field, FormSlot } from 'formily-antd';
import { megaProps } from '@/utils';
import { renderSign, getFundFullList } from '@/pages/Client/Launch/utils';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { signMap } from './effects';
import './index.less';

const issyncEnum = [
  { label: '未发布', value: '0' },
  { label: '已发布', value: '1' },
  { label: '已发布', value: '2' },
];

function Form(props) {
  const {
    context: { getProcess, formData },
  } = props;
  const { readOnlyFlag, elementCode } = getProcess() || {};
  // donenodecode：已经走过的code
  const { donenodecode, finaloprday } = formData;
  const currCode = Number(elementCode);
  console.log('清盘code currCode', currCode);
  console.log('清盘code donenodecode', donenodecode);

  const getFileProps = (name) => ({
    onSuccess: `{{fileSuccess("${name}")}}`,
    onDel: `{{fileDel("${name}")}}`,
    accept: '.pdf,.docx,.doc,.xls,.xlsx,.png,.jpg',
    multiple: true,
    isFsfund: true,
  });

  const editableInCode = (code) => code.includes(currCode) && !readOnlyFlag;
  const upInCode = (code) => (currCode >= Number(code) ? 'up' : 'down');
  const displayInCode = (codeStart, codeEnd) => {
    const codeS = Number(codeStart);
    const codeE = Number(codeEnd);

    if (!codeEnd) {
      return currCode === codeS || (currCode > codeS && donenodecode.includes(codeS));
    }

    return currCode >= codeS && currCode <= codeE;
  };

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="清盘信息" megaProps={megaProps}>
        <Field
          required
          name="fundcode"
          title="基金名称"
          type="tree-select"
          x-component-props={{
            optionFilterProp: 'label',
            placeholder: '请选择基金名称',
            ...getFundFullList({
              fundperiod: '存续期',
              dropdownMatchSelectWidth: false,
            }),
          }}
        />
        <Field
          name="lowenddate"
          type="date"
          editable={false}
          title={
            <div>
              连续60个工作日低于5000
              <br />
              万或200人的截止时间
            </div>
          }
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          name="miniplan"
          type="string"
          editable={false}
          title={
            <div>
              合同规定迷你
              <br />
              超60日后方案
            </div>
          }
        />
        <Field name="haholdasset" type="AmountField" editable={false} title="基金净资产" />
        <Field name="custcnt" type="string" editable={false} title="户数" />
        <Field name="formModal" title={null} type="NoticeModal" />
        <Field
          name="liqddesc"
          type="textarea"
          title="清盘说明"
          x-component-props={{
            placeholder: '请输入',
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          editable
          type="array"
          name="minitipsnotices"
          title="已发布迷你提示性公告"
          x-component="form-table"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              type="date"
              editable={false}
              name="publishdate"
              title="公告日期"
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
          </Field>
        </Field>
      </BasicFormCard>

      {/* {renderSign({
        name: 'liquid10',
        title: '清盘会签',
        editable: editableInCode(signMap.liquid10),
        upDown: upInCode('30'),
      })} */}

      {/* <BaseFormCard
        title="决议文件"
        name="liqdresfileidCard"
        megaLayout={megaProps}
        visible={displayInCode('30')}
        upDown={upInCode('50')}
      >
        <Field
          required
          title="上传决议文件"
          name="liqdresfile"
          type="bpm-upload-list"
          x-mega-props={{ span: 4 }}
          editable={editableInCode('30')}
          x-component-props={{
            ...getFileProps('liqdresfile'),
          }}
        />
      </BaseFormCard> */}

      <BaseFormCard
        name="holdrnoticesCard"
        title="召开持有人大会流程"
        megaLayout={megaProps}
        display={displayInCode('50')}
        upDown={upInCode('60')}
      >
        <Field
          type="button"
          name="initiationHoldProcess"
          title="该基金暂未发起召开持有人大会流程"
          x-component-props={{
            text: '发起召开持有人大会流程',
            type: 'primary',
            ghost: true,
            onClick: '{{initiationProcess("holdrMeet")}}',
          }}
          editable={editableInCode('50')}
          x-mega-props={{ span: 4, labelWidth: 230 }}
        />
        <Field type="object" name="bpmHoldrMeetInfo" x-mega-props={{ span: 4 }}>
          <Field
            name="status"
            title="当前步骤"
            type="string"
            editable={false}
            x-mega-props={{
              span: 3,
              addonAfter: '{{flowTracking("bpmHoldrMeetInfo")}}',
            }}
          />
        </Field>
        <Field
          editable
          type="array"
          name="holdrnotices"
          x-component="form-table"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              type="date"
              editable={false}
              name="publishdate"
              title="公告日期"
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field
              name="issync"
              type="string"
              title="发布状态"
              enum={issyncEnum}
              editable={false}
            />
            <Field
              name="action"
              title="操作"
              type="ButtonField"
              visible={false}
              editable={editableInCode('50')}
              x-component-props={{ text: '去发布', type: 'primary' }}
            />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="pauseCard"
        title="发起暂停申购、转换转入及定期定额投资业务"
        megaLayout={megaProps}
        display={displayInCode('60')}
        upDown={upInCode('70')}
      >
        <Field
          type="button"
          name="initiationProcess"
          title="该基金未发起申赎流程"
          x-component-props={{
            text: '发起申赎流程',
            type: 'primary',
            ghost: true,
            onClick: '{{initiationProcess("subRedProject")}}',
          }}
          editable={editableInCode('60')}
          x-mega-props={{ span: 4 }}
        />
        <Field type="object" name="liquidSubredInfo" x-mega-props={{ span: 4 }}>
          <Field
            name="status"
            title="当前步骤"
            type="string"
            editable={false}
            x-mega-props={{
              span: 3,
              addonAfter: '{{flowTracking("liquidSubredInfo")}}',
            }}
          />
          <Field name="tradetype" title="交易类型" type="string" editable={false} />
          <Field
            type="date"
            name="pausepurdate"
            title="暂停申购起始日期"
            editable={false}
            x-component-props={{ format: 'YYYY-MM-DD' }}
          />
          <Field
            type="date"
            name="pausereddate"
            title="暂停赎回起始日期"
            editable={false}
            x-component-props={{ format: 'YYYY-MM-DD' }}
          />
          <Field
            type="date"
            name="pausequantdate"
            title="暂停定期定额起始日期"
            editable={false}
            x-component-props={{ format: 'YYYY-MM-DD' }}
          />
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="finaloprdayCard"
        title="确定最后运作日"
        megaLayout={megaProps}
        display={displayInCode('90')}
        upDown={upInCode('106')}
      >
        <Field
          required
          type="date"
          name="finaloprday"
          title="最后运作日"
          editable={editableInCode('90')}
          x-mega-props={{ labelWidth: 170 }}
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          required
          type="date"
          name="VfI1FCi9UPK"
          title="清算开始日"
          editable={editableInCode('90')}
          x-mega-props={{ labelWidth: 170 }}
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          required
          type="date"
          title="公告日期"
          editable={editableInCode('90')}
          name="contrendandsettleannodate"
          x-mega-props={{ labelWidth: 170 }}
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          required
          title={
            <div>
              基金合同终止及
              <br />
              财产清算公告
            </div>
          }
          name="contrendandsettleannofile"
          type="bpm-upload-list"
          x-mega-props={{ span: 4, labelWidth: 170 }}
          x-rules={{
            required: true,
            message: '基金合同终止及财产清算不能为空',
          }}
          editable={editableInCode('90')}
          x-component-props={{
            ...getFileProps('contrendandsettleannofile'),
          }}
        />
        {renderSign({
          name: 'liquid90',
          editable: editableInCode(signMap.liquid90),
          independentModule: false,
          leaderapprove: true,
          labelWidth: 170,
        })}

        <Field
          editable
          type="array"
          name="fundsharereseffectannonotices"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              type="date"
              title="公告日期"
              name="publishdate"
              editable={false}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field
              name="issync"
              type="string"
              title="发布状态"
              enum={issyncEnum}
              editable={false}
            />
          </Field>
        </Field>

        <Field
          type="text"
          name="textFinaloprday"
          x-component-props={{ style: { color: 'red' } }}
          default="召开持有人大会流程中，此公告已会签通过"
        />
      </BaseFormCard>

      <BaseFormCard
        name="contrendandsettlean"
        title="基金合同终止及基金财产清算的公告发布"
        megaLayout={megaProps}
        display={displayInCode('105')}
        upDown={upInCode('106')}
      >
        <Field
          editable
          type="array"
          name="contrendandsettleannonotices"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              name="publishdate"
              title="公告日期"
              type="date"
              editable={false}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field
              name="issync"
              title="发布状态"
              enum={issyncEnum}
              type="string"
              editable={false}
            />
            <Field
              name="action"
              title="操作"
              type="ButtonField"
              visible={false}
              editable={editableInCode('105')}
              x-component-props={{ text: '去发布', type: 'primary' }}
            />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="remndistrblassetCard"
        title="准备清算报告及审计报告"
        megaLayout={megaProps}
        display={displayInCode('120')}
        upDown={upInCode('125')}
      >
        <Field
          required
          type="dateRange"
          name="[settlestdate,settleenddate]"
          title="清算起止日期"
          editable={editableInCode('120')}
          x-mega-props={{ labelWidth: 180 }}
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          required
          name="nextsub"
          title="是否需要二次分配"
          type="radio"
          default="0"
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          editable={editableInCode('120')}
          x-mega-props={{ labelWidth: 180 }}
        />
        <Field
          required
          title="清算报告(word版)"
          name="settlerptwordfile"
          type="bpm-upload-list"
          editable={editableInCode('120')}
          x-mega-props={{ span: 4, labelWidth: 180 }}
          x-component-props={{
            ...getFileProps('settlerptwordfile'),
            accept: '.doc',
          }}
        />
        <Field
          required
          title="清算报告(盖章版)(pdf版)"
          name="settlerptpdffile"
          type="bpm-upload-list"
          editable={editableInCode('120')}
          x-mega-props={{ span: 4, labelWidth: 180 }}
          x-component-props={{
            ...getFileProps('settlerptpdffile'),
            accept: '.pdf',
          }}
        />
        <Field
          required
          title="清算审计报告(pdf版)"
          name="settleauditrptfile"
          type="bpm-upload-list"
          editable={editableInCode('120')}
          x-mega-props={{ span: 4, labelWidth: 180 }}
          x-component-props={{
            ...getFileProps('settleauditrptfile'),
            accept: '.pdf',
          }}
        />
        <Field
          type="text"
          name="text-remndistrblassetCard"
          default={`本基金最后运作日(${moment(finaloprday).format(
            'YYYY-MM-DD',
          )})持有的全部停牌股票明细如下：`}
        />
        <Field
          editable
          type="array"
          name="suspendStks"
          x-component="form-table"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="symbol" title="股票代码" type="string" editable={false} />
            <Field name="csname" title="股票名称" type="string" editable={false} />
            <Field name="suspenddate" title="停牌日期" type="string" editable={false} />
            <Field name="suspendtype" title="停牌原因" type="string" editable={false} />
            <Field name="acctiprice" title="最后运作日估值单价" type="string" editable={false} />
            <Field name="acctiqty" title="数量（单位：股）" type="string" editable={false} />
            <Field name="accticost" title="最后运作日成本总额" type="string" editable={false} />
            <Field name="acctimktval" title="最后运作日估值总额" type="string" editable={false} />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="LiquidationReportCard"
        title="发起清算报告公告及会签"
        megaLayout={megaProps}
        display={displayInCode('130')}
        upDown={upInCode('150')}
      >
        {/*
            转换结构
            1. 清算报告提示性公告 文件: settlerpttipsactannofile 日期: settlerpttipsactannodate
            2. 清算报告公告 文件: settlerptannofile 日期: settlerptannodate
        */}
        <Field
          editable
          type="array"
          name="liquidationReportAnnounce"
          x-component="form-table"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field
              type="string"
              name="filetype"
              title="文件类型"
              default="default"
              editable={false}
            />
            <Field
              required
              name="filename"
              title="上传文件"
              type="bpm-upload-list"
              editable={editableInCode('130')}
              x-component-props={{
                accept: '.pdf,.docx,.doc,.xls,.xlsx,.png,.jpg',
                multiple: true,
                isFsfund: true,
              }}
            />
            <Field
              required
              type="date"
              name="filedate"
              title="公告日期"
              editable={editableInCode('130')}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
          </Field>
        </Field>

        {renderSign({
          name: 'liquid130',
          editable: editableInCode(signMap.liquid130),
          labelWidth: 100,
          leaderapprove: true,
          independentModule: false,
        })}
      </BaseFormCard>

      <BaseFormCard
        name="settlerptannonoticesCard"
        title="清算报告公告发布"
        megaLayout={megaProps}
        display={displayInCode('150')}
        upDown={upInCode('210')}
      >
        <Field
          editable
          type="array"
          name="settlerptannonotices"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              name="publishdate"
              title="公告日期"
              type="date"
              editable={false}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field
              name="issync"
              title="发布状态"
              type="string"
              enum={issyncEnum}
              editable={false}
            />
            <Field
              title="操作"
              name="action"
              type="ButtonField"
              visible={false}
              editable={editableInCode('150')}
              x-component-props={{ text: '去发布', type: 'primary' }}
            />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="qq3RsTNZ"
        title="清算部准备剩余资产分配数据--new"
        megaLayout={megaProps}
        // display={displayInCode('180')}
        upDown={upInCode('190')}
      >
        <Field
          editable
          type="array"
          name="sharelist"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="fundshareName" title="份额名称" type="string" editable={false} />
            <Field
              required
              type="date"
              title="资金发放日"
              // editable={false}
              name="capdistrday"
              x-component-props={{ format: 'YYYY-MM-DD' }}
              // editable={editableInCode('180')}
            />
            <Field
              required
              type="date"
              title="权益登记日"
              // editable={false}
              name="rightregistday"
              // x-component-props={{ format: 'YYYY-MM-DD' }}
              // editable={editableInCode('180')}
            />
            <Field
              name="curhundfundshareactldistrcap"
              title={
                <div>
                  本次每百份基金份额
                  <br />
                  实际发放资金(元)
                </div>
              }
              type="AmountField"
              x-rules={{
                required: true,
                message: '本次每百份基金份额实际发放资金不能为空',
              }}
              // editable={editableInCode('180')}
            />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="remnassetdistrannoCard"
        title="产品部发起剩余资产分配公告及会签"
        megaLayout={megaProps}
        display={displayInCode('190')}
        upDown={upInCode('210')}
      >
        <Field
          required
          type="date"
          title="公告日期"
          name="remnassetdistrannodate"
          editable={editableInCode('190')}
          x-mega-props={{ labelWidth: 150 }}
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          required
          title="剩余资产分配公告文件"
          name="remnassetdistrrptfile"
          type="bpm-upload-list"
          editable={editableInCode('190')}
          x-mega-props={{ span: 4, labelWidth: 150 }}
          x-component-props={{
            ...getFileProps('remnassetdistrrptfile'),
          }}
        />
        {renderSign({
          name: 'liquid190',
          editable: editableInCode(signMap.liquid190),
          independentModule: false,
          leaderapprove: true,
          labelWidth: 150,
        })}
      </BaseFormCard>

      <BaseFormCard
        name="qXN9eLjQPjzCIY7IzRT"
        title="清算部准备剩余资产二次分配数据--new"
        megaLayout={megaProps}
        // display={displayInCode('260')}
        upDown={upInCode('290')}
      >
        <Field
          editable
          type="array"
          name="sharelist2"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="fundshareName" title="份额名称" type="string" editable={false} />
            <Field
              required
              type="date"
              title="资金发放日"
              // editable={false}
              name="nextcapdistrday"
              x-component-props={{ format: 'YYYY-MM-DD' }}
              //   editable={editableInCode('260')}
            />
            <Field
              required
              type="date"
              title="权益登记日"
              // editable={false}
              name="nextrightregistday"
              // x-component-props={{ format: 'YYYY-MM-DD' }}
              // editable={editableInCode('260')}
            />
            <Field
              name="nextcurhundfundshareactldistrcap"
              title={
                <div>
                  本次每百份基金份额
                  <br />
                  实际发放资金(元)
                </div>
              }
              type="AmountField"
              x-rules={{
                required: true,
                message: '本次每百份基金份额实际发放资金不能为空',
              }}
              // editable={editableInCode('260')}
            />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="nextremnassetdistrannoCard"
        title="发起剩余资产二次分配公告及会签"
        megaLayout={megaProps}
        display={displayInCode('270')}
        upDown={upInCode('290')}
      >
        <Field
          type="date"
          title="公告日期"
          name="nextremnassetdistrannodate"
          editable={editableInCode('270')}
          x-mega-props={{ labelWidth: 150 }}
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          required
          title="剩余资产二次分配公告"
          type="bpm-upload-list"
          name="nextremnassetdistrannofile"
          editable={editableInCode('270')}
          x-mega-props={{ span: 4, labelWidth: 150 }}
          x-component-props={{
            ...getFileProps('nextremnassetdistrannofile'),
          }}
        />

        {renderSign({
          name: 'liquid270',
          editable: editableInCode(signMap.liquid270),
          independentModule: false,
          leaderapprove: true,
          labelWidth: 150,
        })}
      </BaseFormCard>

      <BaseFormCard
        name="nextremnassetdistrrptnoticesCard"
        title="剩余资产二次分配公告发布"
        megaLayout={megaProps}
        display={displayInCode('290')}
        upDown={upInCode('300')}
      >
        <Field
          editable
          type="array"
          name="nextremnassetdistrrptnotices"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              name="publishdate"
              title="公告日期"
              type="date"
              editable={false}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field
              name="issync"
              title="发布状态"
              type="string"
              enum={issyncEnum}
              editable={false}
            />
            <Field
              title="操作"
              name="action"
              type="ButtonField"
              visible={false}
              editable={editableInCode('290')}
              x-component-props={{ text: '去发布', type: 'primary' }}
            />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="prepareDelistingFileCard"
        title="准备退市公告文件"
        megaLayout={megaProps}
        display={displayInCode('310')}
      >
        <FormSlot>
          <div style={{ color: 'red', marginLeft: 12 }}>
            提示：请在终止上市日提前10个工作日完成交易所事项。
          </div>
        </FormSlot>
        <Field
          required
          type="date"
          name="endlistday"
          title="终止上市日"
          editable={editableInCode('310')}
          x-mega-props={{ span: 4, labelWidth: 100, wrapperWidth: 200 }}
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          editable
          type="array"
          name="prepareForDelisting"
          x-component="form-table"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          {/*
            转换结构
            1. 基金终止上市公告 文件: fundendlistannofile 日期: fundendlistannodate
            2. 终止上市的提示性公告 文件: endlisttipsactannofile 日期: endlisttipsactannodate
          */}
          <Field type="object">
            <Field
              type="string"
              name="filetype"
              title="文件类型"
              default="default"
              editable={false}
            />
            <Field
              required
              name="filename"
              title="上传文件"
              type="bpm-upload-list"
              editable={editableInCode('310')}
              x-component-props={{
                accept: '.pdf,.docx,.doc,.xls,.xlsx,.png,.jpg',
                multiple: true,
                isFsfund: true,
              }}
            />
            <Field
              required
              type="date"
              name="filedate"
              title="公告日期"
              editable={editableInCode('310')}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
          </Field>
        </Field>

        {renderSign({
          name: 'liquid310',
          editable: editableInCode(signMap.liquid310),
          labelWidth: 100,
          leaderapprove: true,
          independentModule: false,
        })}
      </BaseFormCard>

      <BaseFormCard
        name="delistannonoticesCard"
        title="退市公告发布"
        megaLayout={megaProps}
        display={displayInCode('340')}
      >
        <Field
          editable
          type="array"
          name="delistannonotices"
          x-component="form-table"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" type="string" title="公告文件" default="default" editable={false} />
            <Field
              type="date"
              name="publishdate"
              title="公告日期"
              editable={false}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field name="issync" title="发布状态" type="date" enum={issyncEnum} editable={false} />
            <Field
              name="action"
              title="操作"
              type="ButtonField"
              visible={false}
              editable={editableInCode('340')}
              x-component-props={{ text: '去发布', type: 'primary' }}
            />
          </Field>
        </Field>
      </BaseFormCard>
    </>
  );
}

export default Form;
