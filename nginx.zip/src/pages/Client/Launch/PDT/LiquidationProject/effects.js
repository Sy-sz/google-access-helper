import React from 'react';
import { Button } from 'antd';
import { isEmpty, uniqBy, difference } from 'lodash';
import moment from 'moment';
import { FormPath, FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import { minifundLiquidFund, listNoticeMatch, getWorkDate, getdesigndate } from '@/common/axios';
import {
  batchToggleSignType,
  batchFormatFile,
  convertFileFlatToArray,
  convertFileArrayToFlat,
  validateSign,
  leaderSeparator,
} from '../../utils';
import { genJumpProcess, getDictionary, D } from '@/utils';

const { onFieldValueChange$, onFieldInit$, onFieldInputChange$ } = FormEffectHooks;
// const { onToggleChange$ } = BpmFormEffectHooks;

/** 这几个文件 数据是平铺的，但展示在表格里，需要来回转化一下 */
const fileFlatToArrayMap = {
  liquidationReportAnnounce: [
    {
      filetype: '清算报告提示性公告',
      filekey: 'settlerpttipsactannofile',
      datekey: 'settlerpttipsactannodate',
    },
    {
      filetype: '清算报告公告',
      filekey: 'settlerptannofile',
      datekey: 'settlerptannodate',
    },
  ],
  prepareForDelisting: [
    {
      filetype: '基金终止上市公告',
      filekey: 'fundendlistannofile',
      datekey: 'fundendlistannodate',
    },
    {
      filetype: '终止上市的提示性公告',
      filekey: 'endlisttipsactannofile',
      datekey: 'endlisttipsactannodate',
    },
  ],
};
/** 会签字段名与可编辑节点的映射 */
export const signMap = {
  // liquid10: '10',
  liquid90: '90',
  liquid130: '130',
  liquid190: '190',
  liquid270: '270',
  liquid310: '310',
};
// 需要格式化的文件
const fileNames = [
  'liqdresfile',
  'contrendandsettleannofile',
  'settlerptwordfile',
  'settlerptpdffile',
  'settleauditrptfile',
  'remnassetdistrrptfile',
  'nextremnassetdistrannofile',
];
// 包含去发布按钮的节点，存在未发布的公告提交时给提示
const publishCode = {
  50: 'holdrnotices',
  105: 'contrendandsettleannonotices',
  150: 'settlerptannonotices',
  210: 'remnassetdistrrptnotices',
  290: 'nextremnassetdistrrptnotices',
  340: 'delistannonotices',
};
const associatedDatesMap = {
  capdistrday: 'rightregistday',
  nextcapdistrday: 'nextrightregistday',
};

// 所有节点的 领导、领导审批顺序，字符串格式
const { leaderFields, leaderapproveFields } = Object.keys(signMap).reduce(
  (acc, e) => {
    acc.leaderFields.push(`${e}.leader`);
    acc.leaderapproveFields.push(`${e}.leaderapprove`);
    return acc;
  },
  { leaderFields: [], leaderapproveFields: [] },
);

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag } = getProcess() || {};
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.leaderMap = {};
  }

  createFormEffects() {
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      // 选择基金代码, 带出其他字段的值
      onFieldValueChange$('fundcode').subscribe(async (field) => {
        if (this.elementCode !== '10' || !field.value) {
          return;
        }

        const [err, res] = await minifundLiquidFund({ fundcode: field.value }); // '009263'
        if (err) {
          return;
        }

        const defaultData = {
          custcnt: null,
          datadate: null,
          haholdasset: null,
          lowenddate: null,
          miniplan: null,
        };
        const extra = ['haholdasset', 'custcnt']; // 要拼上截止日期的字段
        const datadate = res.data?.datadate && moment(res.data.datadate).format('YYYY-MM-DD');

        Object.entries(res.data || defaultData).forEach(([key, value]) => {
          if (extra.includes(key)) {
            const megaProps = datadate ? { addonAfter: `(截止：${datadate})` } : {};
            setFieldState(key, (state) => {
              state.props['x-mega-props'] = megaProps;
            });
          }

          setFieldValue(key, value);
        });
      });

      // 是否展示发起申赎流程按钮
      onFieldInit$('liquidSubredInfo').subscribe((field) => {
        const isValueEmpty = isEmpty(field.value);
        setFieldState('initiationProcess', (state) => {
          state.visible = isValueEmpty;
        });
        setFieldState('liquidSubredInfo', (state) => {
          state.visible = !isValueEmpty;
        });
      });

      // 是否展示发起召开持有人大会流程按钮
      onFieldInit$('bpmHoldrMeetInfo').subscribe((field) => {
        const isValueEmpty = isEmpty(field.value);
        setFieldState('initiationHoldProcess', (state) => {
          state.visible = isValueEmpty;
        });
        setFieldState('bpmHoldrMeetInfo', (state) => {
          state.visible = !isValueEmpty;
        });
      });

      // 根据是否召开持有人大会展示不同的字段
      onFieldValueChange$('miniplan').subscribe((field) => {
        setFieldState(
          '*(fundsharereseffectannonotices,textFinaloprday,minitipsnotices,VfI1FCi9UPK)',
          (state) => {
            state.visible = field.value === '召开持有人大会';
          },
        );
        setFieldState(
          '*(contrendandsettleannofile,liquid90,contrendandsettlean,contrendandsettleannodate)',
          (state) => {
            state.visible = field.value !== '召开持有人大会';
          },
        );
      });

      // 去发布 显隐（基金合同终止及基金财产清算的公告发布;清算报告公告发布;剩余资产分配公告发布;退市公告发布)
      onFieldInit$(
        '*(contrendandsettleannonotices.*.action,settlerptannonotices.*.action,remnassetdistrrptnotices.*.action,delistannonotices.*.action,holdrnotices.*.action,nextremnassetdistrrptnotices.*.action)',
      ).subscribe((field) => {
        const { segments } = FormPath.parse(field.name);
        const [fieldName, idx] = segments;
        const { issync } = getFieldValue(fieldName)[idx] || {};
        if (issync === '0') {
          setFieldState(`${fieldName}.${idx}.action`, (state) => {
            state.visible = true;
          });
        }
      });

      // 去发布 打开弹框 (基金合同终止及基金财产清算的公告发布;清算报告公告发布;剩余资产分配公告发布;退市公告发布)
      onFieldValueChange$(
        '*(contrendandsettleannonotices.*.action,settlerptannonotices.*.action,remnassetdistrrptnotices.*.action,delistannonotices.*.action,holdrnotices.*.action,nextremnassetdistrrptnotices.*.action)',
      ).subscribe(async (field) => {
        const { segments } = FormPath.parse(field.name);
        const [fieldName, idx] = segments;
        const { noticeid, publishdate } = getFieldValue(fieldName)[idx] || {};

        const res = await listNoticeMatch({ size: 1000 });
        const noticetypeOptions = uniqBy(res.data, 'noticetypeid').map(
          ({ noticetypename, noticetypeid, ...rest }) => ({
            ...rest,
            dictLabel: noticetypename,
            dictValue: noticetypeid,
            label: noticetypename,
            value: noticetypeid,
          }),
        );

        setFieldState('formModal', (state) => {
          state.props['x-component-props'] = {
            visible: true,
            noticeid,
            setFieldState,
            noticetypeOptions,
            publishdate: moment(publishdate).format('YYYY-MM-DD'),
          };
        });
      });

      onFieldInputChange$('*(sharelist.*.capdistrday,sharelist2.*.nextcapdistrday)').subscribe(
        async (field) => {
          const { segments } = FormPath.parse(field.name);
          const [fieldName, idx, itemName] = segments;
          console.log(
            '🚀 ~ file: effects.js:226 ~ Effects ~ onFieldInputChange$ ~ segments:',
            segments,
          );
          const [err, res] = await getWorkDate({ date: field.value, offset: -4 });
          if (err) {
            return;
          }

          setFieldValue(`${fieldName}.${idx}.${associatedDatesMap[itemName]}`, res.data);
        },
      );

      // 查 领导字典； 设置 领导options； 设置 领导审批顺序；
      onFieldInit$('code').subscribe(async () => {
        getDictionary(D.LEADER_LIST).then(([leaderDict]) => {
          const leaderEnum = [];
          this.leaderMap = leaderDict.reduce((acc, { name: label, value }) => {
            leaderEnum.push({ label, value });
            acc[value] = label;
            acc[label] = value;
            return acc;
          }, {});

          Object.keys(signMap).forEach((item) => {
            const { leaderrank } = getFieldValue(item) || {};
            if (leaderrank) {
              const rank = leaderrank
                .split(leaderSeparator)
                .map((e) => this.leaderMap[e])
                .join(leaderSeparator);

              setFieldValue(`${item}.leaderrank`, rank);
            }
          });

          setFieldState(`*(${leaderFields})`, (state) => {
            state.props.enum = leaderEnum;
          });
        });
      });

      // 领导不是同时审批时，显示领导、领导审批顺序，否则隐藏
      onFieldValueChange$(`*(${leaderapproveFields})`).subscribe((field) => {
        const { segments } = FormPath.parse(field.name);

        setFieldState(`${segments[0]}.leaderrank`, (state) => {
          state.visible = field.value === '0';
        });
      });

      // 会签，点领导审批时，按点击顺序排序
      onFieldInputChange$(`*(${leaderFields})`).subscribe((field) => {
        const { segments } = FormPath.parse(field.name);
        const leaderrank = getFieldValue(`${segments[0]}.leaderrank`) || undefined;
        let leaderOrderArr = leaderrank?.split(leaderSeparator) ?? [];
        leaderOrderArr = leaderOrderArr.map((e) => this.leaderMap[e]);
        const isAdd = field.value.length > leaderOrderArr.length; // 是否为新增
        const active = isAdd
          ? difference(field.value, leaderOrderArr)
          : difference(leaderOrderArr, field.value);

        if (isAdd) {
          leaderOrderArr.push(...active);
        } else {
          leaderOrderArr = leaderOrderArr.filter((e) => e !== active[0]);
        }
        const leaderName = leaderOrderArr.map((e) => this.leaderMap[e]);
        setFieldValue(`${segments[0]}.leaderrank`, leaderName.join(leaderSeparator));
      });

      // 选最后运作日带出清算开始日(+1工作日)
      onFieldInputChange$('finaloprday').subscribe(async (field) => {
        const [err, res] = await getdesigndate({ date: field.value, workflag: '1', offset: 1 });
        if (err) {
          return;
        }

        setFieldValue('VfI1FCi9UPK', res.data);
      });
    };
  }

  /** 格式化 传入的数据 */
  formatInitData(values) {
    values.leaderMap = this.leaderMap;
    values.sharelist = [
      {
        fundshareName: '份额A',
        ismainshare: '1',
      },
      {
        fundshareName: '份额B',
        ismainshare: '0',
      },
      {
        fundshareName: '份额C',
        ismainshare: '2',
      },
    ];
    values.sharelist2 = [
      {
        fundshareName: '份额AA',
        ismainshare: '1',
      },
      {
        fundshareName: '份额BB',
        ismainshare: '0',
      },
      {
        fundshareName: '份额CC',
        ismainshare: '2',
      },
    ];

    return {
      ...values,
      ...convertFileFlatToArray(values, fileFlatToArrayMap),
      ...batchToggleSignType(values, Object.keys(signMap)),
    };
  }

  /** 格式化 传出的数据 */
  formatSubmitData(values) {
    values.leaderMap = this.leaderMap;
    return {
      ...values,
      ...convertFileArrayToFlat(values, fileFlatToArrayMap),
      ...batchToggleSignType(values, Object.keys(signMap)),
      ...batchFormatFile(values, fileNames),
    };
  }

  applyFormatData(values) {
    return this.formatInitData(values);
  }

  auditFormatData(values) {
    return this.formatInitData(values);
  }

  applySubmit(values, file) {
    return this.formatSubmitData(values);
  }

  auditSubmit(values, file) {
    return this.formatSubmitData(values);
  }

  daftSubmit(values) {
    return this.formatSubmitData(values);
  }

  submitConfirm(values, next, { actionName }) {
    // 退回不校验
    if (actionName.includes('退回')) {
      next(true);
      return;
    }

    // 会签人、会签部门必填一项
    const isSignPass = validateSign({
      values,
      signMap,
      elementCode: this.elementCode,
      formActions: this.formActions,
    });
    if (!isSignPass) {
      next(false);
      return;
    }

    // 存在未发布的公告时弹框提示
    const publishField = publishCode[this.elementCode];
    if (publishField) {
      const hasNoPublish = values[publishField]?.some(({ issync }) => issync === '0');
      if (hasNoPublish) {
        this.antModal.confirm({
          title: '提示',
          content: '有未发布的公告，是否继续？',
          onOk: () => next(true),
          onCancel: () => next(false),
        });
        return;
      }
    }

    next(true);
  }

  validatePublishCode() {}

  get expressionScope() {
    const nameMap = {
      liquidSubredInfo: 'SUBRED_PROJECT',
      bpmHoldrMeetInfo: 'HOLDR_MEET',
    };
    return {
      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
      flowTracking: (name) => {
        if (!this.formData[name]?.status) {
          return null;
        }

        return (
          <Button type="primary" ghost>
            {genJumpProcess({
              code: nameMap[name],
              title: '流程跟踪',
              tokenId: this.formData[name]?.tokenid,
              tag: 'trace',
            })}
          </Button>
        );
      },
      initiationProcess: (processName) => () => {
        window.open(`#/app/bpm/process/pdt/${processName}?fundid=${this.formData.fundid}&type=1`);
      },
    };
  }
}
