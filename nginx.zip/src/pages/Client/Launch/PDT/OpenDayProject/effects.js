import { FormPath, FormEffectHooks } from 'formily-antd';
import { FormLifeCycleTypes, BpmFormEffectHooks } from '@/utils';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import { getCurrentUser } from '@/utils';

const { onFieldValueChange$, onFieldInputChange$ } = FormEffectHooks;
const { onToggleChange$ } = BpmFormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
      ...restProps
    } = props;
    const { elementCode } = getProcess() || {};
    this.elementCode = elementCode;
  }

  createFormEffects() {
    const dispatcher = store.useModelDispatchers('pdtSystem');

    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      onFieldInputChange$('sellers').subscribe((fieldState) => {
        const { value } = fieldState;
        console.log('=====>', value);
        if (value.length > 1) {
          if (value[value.length - 1] === 'all') {
            setFieldValue('sellers', ['all']);
          } else if (value.includes('all')) {
            setFieldValue(
              'sellers',
              value.filter((a) => a !== 'all'),
            );
          }
        }
      });
      onFieldInputChange$('startdate').subscribe(async ({ value }) => {
        // 产品开放起始日期
        this.formData.startdate = value;
      });
      onFieldInputChange$('enddate').subscribe(async ({ value }) => {
        // 产品开放结束日期
        this.formData.enddate = value;
      });
    };
  }

  joinArray(data) {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(',');
    }
    return data;
  }

  formatData(values) {
    return {
      ...values,
      countersigndeparts: Array.isArray(values.countersigndeparts)
        ? values.countersigndeparts.join(';')
        : values.countersigndeparts,
      tradetype: Array.isArray(values.tradetype) ? values.tradetype.join(',') : values.tradetype,
      sellers: Array.isArray(values.sellers) ? values.sellers.join(',') : values.sellers,
      fundmanagerid: this.joinArray(values.fundmanagerid),
    };
  }

  applySubmit(values) {
    console.log(values, '...valuessss');
    const result = values;
    let data = this.formatData(result);
    return data;
  }

  auditSubmit(values) {
    let data = {
      ...values,
    };
    return data;
  }
}
