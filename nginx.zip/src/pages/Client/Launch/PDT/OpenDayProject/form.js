import React from 'react';
import { Field, registerValidationFormats } from 'formily-antd';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import {
  // useMegaLayoutProps,
  useAgencyList,
  useFundFullList,
  useTreeDepartment,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import moment from 'moment';
// import store from '@/store';

function Form(props) {
  const {
    context: {
      formData, // , getProcess
    },
  } = props;
  console.log(formData, '...formData');
  // const {
  // elementCode, firstTokenFlag,
  // elementId,
  // endElementId,
  // } = getProcess() || {};

  const deptMulProps = useTreeDepartment({
    multiple: true,
    type: undefined,
    tokenSeparators: [';'],
  });
  const comProps = {
    size: 'middle',
  };

  const megaProps = {
    labelWidth: 160,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };

  // const megaLayoutProps = useMegaLayoutProps(megaProps);

  // const endFlag = elementId === endElementId;

  // const departsRequest = async () => {
  //   const pdtDispatcher = store.getModelDispatchers('pdtSystem');
  //   const res = await pdtDispatcher.dictList({ dictids: '4fd190dd74164968b722bd13e92b5d80' });
  //   if (
  //     res.data &&
  //     Array.isArray(res.data) &&
  //     res.data.length > 0 &&
  //     Array.isArray(res.data[0].children)
  //   ) {
  //     return res.data[0].children.map((a) => ({ ...a, ...{ label: a.name } }));
  //   }
  // };

  // const tradetypeRequest = async () => {
  //   const pdtDispatcher = store.getModelDispatchers('pdtSystem');
  //   const res = await pdtDispatcher.dictList({ dictids: '41e9adb99d934f73b92fc62cd5f25de3' });
  //   if (res.data && Array.isArray(res.data) && res.data.length > 0 && Array.isArray(res.data[0].children)) {
  //     return res.data[0].children.map(a => ({ ...a, ...{ label: a.name } }));
  //   }
  // };
  // 基金名称只匹配数字

  registerValidationFormats({
    custom_format: /^[1-9]\d*|0$/,
  });

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="基金信息" megaProps={megaProps}>
        <Field
          name="fundcode"
          title="基金名称"
          type="tree-select"
          required
          x-mega-props={{ span: 4 }}
          x-component-props={{
            style: { maxWidth: 500 },
            optionFilterProp: 'label',
            placeholder: '请输入基金名称',
            ...useFundFullList({
              fundperiod: '存续期',
              dropdownMatchSelectWidth: false,
            }),
          }}
        />

        <Field
          name="isqdii"
          title="是否为ODII"
          type="radio"
          required
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          // visible={(!["10", "20"].includes(elementCode) && !firstTokenFlag) || endFlag}
          // editable={["30"].includes(elementCode)}
          x-component-props={{ size: 'middle' }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="startdate"
          title="产品开放起始日期"
          type="date"
          required
          x-rules={[
            {
              validator: (value) => {
                const { enddate } = formData;
                if (moment(enddate).isBefore(moment(value))) {
                  return '开始日期不能小于结束日期';
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
          }}
        />

        <Field
          name="enddate"
          title="产品开放结束日期"
          type="date"
          required
          x-rules={[
            {
              validator: (value) => {
                const { startdate } = formData;
                console.log(startdate, value);
                if (moment(startdate).isAfter(moment(value))) {
                  return '结束日期不能大于开始日期';
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
          }}
        />
        {/* <Field
          name='sellers'
          title='选择销售商'
          type='tree-select'
          required
          default={["all"]}
          x-component-props={{
            placeholder: '请选择销售商',
            //  previewPlaceholder: '-',
            filterOption: false,
            ...useAgencyList({
              businesstype: '销售商',
              type: "销售商",
              onSearch: {
                filterKeys: ['value']
              },
              multiple: true,
              tokenSeparators: [',']
            }),
            ...comProps,
          }}
          x-mega-props={{ span: 4 }}
        /> */}

        <Field
          name="sellers"
          title="选择销售商"
          type="tree-select"
          default={['all']}
          x-component-props={{
            placeholder: '请选择销售商',
            optionFilterProp: 'label',
            ...useAgencyList({
              businesstype: '代销机构',
              type: '代销机构',
              showall: 1,
              multiple: true,
              tokenSeparators: [','],
            }),
            ...comProps,
          }}
          x-mega-props={{ span: 4 }}
        />
        {/* <Field
          name="countersigndeparts"
          title="会签部门"
          type="tree-select"
          default={['产品开发部']}
          required
          x-mega-props={{ span: 4 }}
          x-component-props={{ checkAll: false, tokenSeparators: [';'], request: departsRequest }}
        /> */}
        <Field
          name="countersigndeparts"
          title="会签部门"
          type="tree-select"
          required
          default={['53479972-4DC3-461C-A004-45AC49B5AB81']}
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...comProps,
            ...deptMulProps,
            placeholder: `请选择会签部门`,
          }}
        />
      </BasicFormCard>
    </>
  );
}

export default Form;
