import React, { useState } from 'react';
import { FormPath, FormEffectHooks } from 'formily-antd';
import {
  FormLifeCycleTypes,
  BpmFormEffectHooks,
  uuid,
  getCurrentUser,
  stringify,
  flattenChildren,
  cloneDeep,
  set,
} from '@/utils';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import { Button, message } from 'antd';
import ProForm, {
  LightFilter,
  ProFormDatePicker,
  ProFormFieldSet,
  ProFormSelect,
  ModalForm,
  ProFormText,
  ProFormDigit,
} from '@ant-design/pro-form';
import moment from 'moment';
import { DeleteOutlined, RestFilled } from '@ant-design/icons';
import { isArray } from 'lodash';
import { useLinkageUtils } from '@chinahorm/web-components/es/components/ProcessLayout/hooks';
import { array } from 'prop-types';
const {
  onFieldValueChange$,
  onFieldInputChange$,
  onFieldInit$,
  onFieldMount$,
  onFormGraphChange$,
} = FormEffectHooks;
const { onToggleChange$ } = BpmFormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    this.managerid = null;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    const {
      context: { getProcess, isDraft },
    } = props;
    const { elementCode, firstTokenFlag, readOnlyFlag } = getProcess() || {};
    this.managerid = null;
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
  }
  createFormEffects() {
    this.changeAgencyActionRef = React.useRef();
    const dispatcher = store.useModelDispatchers('pdtSystem');
    const {
      context: { getProcess },
    } = this.props;
    const { firstTokenFlag, elementCode } = getProcess() || {};
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      onFieldInit$('*(countersigndeparts,countersignusers,noticeusers,noticedeparts)').subscribe(
        ({ value, name }) => {
          setFieldValue(name, value ? value.split(';') : value);
        },
      );
      if (firstTokenFlag && ['10'].includes(elementCode)) {
        onFieldInit$('fundcode').subscribe(async (state) => {
          const res = await this.dispatcher.fundDataList({
            fundcode: state.value,
            page: 1,
            size: 1,
          });
          if (!res.error && res.data && Array.isArray(res.data)) {
            if (res.data.length > 0) {
              setFieldState('fundcode', (state) => {
                state.description = <span></span>;
              });
            } else {
              setFieldState('fundcode', (state) => {
                state.description = (
                  <span style={{ color: 'red' }}>
                    本基金没有设置过【最小申购、赎回单位（单位:份）】 参数 请设置
                  </span>
                );
              });
            }
          }
        });
      }
    };
  }

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }
  formatData(values) {
    return {
      ...values,
      countersigndeparts: this.joinArray(values.countersigndeparts, ';'),
      countersignusers: this.joinArray(values.countersignusers, ';'),
      noticeusers: this.joinArray(values.noticeusers, ';'),
      noticedeparts: this.joinArray(values.noticedeparts, ';'),
    };
  }

  applySubmit(values) {
    const result = values;
    let data = this.formatData(result);
    return data;
  }

  auditSubmit(values) {
    let data = this.formatData(values);
    return data;
  }

  get expressionScope() {
    return {
      rendeRquery: () => {
        return (
          <>
            {['10'].includes(this.elementCode) && !this.readOnlyFlag && (
              <Button
                onClick={async () => {
                  const { getFieldState, setFieldValue, setFieldState } = this.formActions;
                  const state = this.formActions.getFieldState('fundcode') || {};
                  if (state.value) {
                    this.antMessage.loading('数据加载中...', 0);
                    const res = await this.dispatcher.fundDataList({
                      fundcode: state.value,
                      page: 1,
                      size: 1,
                    });
                    this.antMessage.destroy();
                    if (res.data && Array.isArray(res.data)) {
                      let dataList = res.data;
                      let newArrlist = [];
                      dataList.forEach((b) => {
                        newArrlist.push({
                          fundcode: b.fundcode,
                          fundname: b.fundname,
                          information: '最小申购、赎回单位（单位:份）'
                            ? '最小申购、赎回单位（单位:份）'
                            : '',
                          beforunit: b.unit ? b.unit : '',
                        });
                      });
                      newArrlist = [...newArrlist];
                      if (newArrlist.length > 0) {
                        setFieldState('fundcode', (state) => {
                          state.description = <span></span>;
                        });
                      } else {
                        setFieldState('fundcode', (state) => {
                          state.description = (
                            <span style={{ color: 'red' }}>
                              本基金没有设置过【最小申购、赎回单位（单位:份）】 参数 请设置
                            </span>
                          );
                        });
                        const result = await this.dispatcher.fundDataList({
                          fundcode: state.value,
                          distinct: 1,
                        });
                        if (result.data && Array.isArray(result.data) && result.data.length > 0) {
                          var fundList = [
                            {
                              fundcode: state.value,
                              beforunit: result.data[0].unit ? result.data[0].unit : '',
                              fundname: result.data[0].fundname,
                              information: '最小申购、赎回单位（单位:份）'
                                ? '最小申购、赎回单位（单位:份）'
                                : '',
                            },
                          ];
                        }
                      }

                      setFieldState('itemList', (state) => {
                        state.value = newArrlist.length > 0 ? newArrlist : fundList;
                        state.visible = true;
                      });
                      setFieldState(
                        'itemList',
                        (s) =>
                          (s.props['x-component-props'].visibleColumns = [
                            { name: 'effectdate', visible: false },
                            { name: 'afterunit', visible: false },
                          ]),
                      );
                    }
                  } else {
                    this.antMessage.warning('请选择基金名称');
                    setFieldValue('itemList', []);
                    setTimeout(() => {
                      this.antMessage.destroy();
                    }, 2000);
                  }
                }}
              >
                查询
              </Button>
            )}
          </>
        );
      },

      // 添加
      renderExtendButtons: () => {
        const [visible, setVisible] = useState(false);
        const { getFieldValue } = this.formActions;
        const data = getFieldValue('itemList') || [];
        return (
          <>
            <ModalForm
              labelCol={{ span: 6 }}
              wrapperCol={{ span: 14 }}
              title="设置参数"
              layout={'horizontal'}
              visible={visible}
              initialValues={{
                ...(isArray(data) && data.length > 0 ? data[0] : {}),
              }}
              modalProps={{
                maskClosable: false,
                closable: false,
                destroyOnClose: true,
                width: 600,
              }}
              onVisibleChange={(visible) => !visible && setVisible(false)}
              trigger={
                <Button
                  type="primary"
                  size={'small'}
                  onClick={() => {
                    if ((data || []).length < 1) {
                      this.antMessage.info('请先选择要设置的行');
                      return;
                    } else {
                      const itemLists = this.formActions.getFieldValue('itemList') || [];
                      setVisible(true);
                    }
                  }}
                >
                  设置参数
                </Button>
              }
              onFinish={async (values) => {
                const { setFieldState, setFieldValue } = this.formActions;
                setFieldState(
                  'itemList',
                  (s) =>
                    (s.props['x-component-props'].visibleColumns = [
                      { name: 'effectdate', visible: true },
                      { name: 'afterunit', visible: true },
                    ]),
                );
                const itemList = getFieldValue('itemList') || [];
                setFieldValue(
                  'itemList',
                  itemList.map((a) => {
                    a.afterunit = values.afterunit;
                    a.effectdate = values.effectdate;
                    return a;
                  }),
                );
                return setVisible(false);
              }}
            >
              {data.length > 0 && data[0].hasOwnProperty('beforunit') ? (
                <ProFormDigit
                  name="beforunit"
                  label="调整前参数(/份)"
                  min={1}
                  readonly={true}
                  style={{ width: 500 }}
                  fieldProps={{
                    precision: 6,
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                  }}
                  placeholder="请输入调整前参数（最小申购，赎回单位：份）"
                />
              ) : null}
              <ProFormDigit
                name="afterunit"
                label="调整后参数"
                min={1}
                style={{ width: 500 }}
                rules={[{ required: true, message: '请输入调整后参数（最小申购，赎回单位：份）' }]}
                fieldProps={{
                  precision: 6,
                  formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                  parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                }}
                placeholder="请输入调整后参数（最小申购，赎回单位：份）"
              />
              <ProFormDatePicker
                rules={[{ required: true, message: '请选择生效日期' }]}
                name="effectdate"
                label="生效日期"
                width="md"
                placeholder="请选择生效日期"
              />
            </ModalForm>
          </>
        );
      },
    };
  }
}
