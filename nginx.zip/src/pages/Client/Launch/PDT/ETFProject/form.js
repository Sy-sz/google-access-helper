import React, { useContext, useState } from 'react';
import {
  Field,
  // SchemaForm,
  // FormEffectHooks,
  // createFormActions,
  // FormPath,
  // FormSpy,
  // FormButtonGroup,
} from 'formily-antd';
// import {
//   FormBlock,
//   FormCard,
//   FormItemGrid,
//   FormMegaLayout,
//   FormTab,
//   FormLayout,
//   Input,
//   FormItem,
// } from '@formily/antd-components';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import { Button, Modal } from 'antd';
import {
  useMegaLayoutProps,
  useDictList,
  useTreeDepartment,
  useTreeUser,
  useBpmShareList,
  useAgencyLists,
  useFundEtfList,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import moment from 'moment';
import { DeleteOutlined } from '@ant-design/icons';
import store from '@/store';
import { cloneDeep, getCurrentUser, set, uuid } from '@/utils';
import { numberToAmount } from '@/utils';
import Download from '@chinahorm/web-components/es/components/Download';
import { baseURL } from '@/setting';

function Form(props) {
  const {
    context: { formData, getProcess, tokenId, isDraft },
    formEffects: { pageStatus, formActions },
    audit,
    ...restProps
  } = props;
  const { elementCode, elementName, readOnlyFlag, firstTokenFlag, elementId, endElementId } =
    getProcess() || {};
  const visibaleCode = Number(endElementId) === 10;

  console.log('props111111', firstTokenFlag);

  const dispatchers = store.useModelDispatchers('pdtSystem');
  const AgencyLists = useAgencyLists('pdtSystem'); // 代销机构源数据

  const comProps = {
    size: 'middle',
  };
  const megaProps = {
    labelWidth: 110,
    responsive: { lg: 4, m: 2, s: 1 },
    contextResponsive: { lg: 4, m: 2, s: 1 },
  };

  const megaLayoutProps = useMegaLayoutProps(megaProps);

  const deptMulProps = useTreeDepartment({
    multiple: true,
    type: undefined,
    tokenSeparators: [';'],
  });
  const userMulProps = useTreeUser({
    multiple: true,
    tokenSeparators: [';'],
  });

  const endFlag = elementId === endElementId;
  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="会签信息" megaProps={megaProps}>
        <Field
          name="countersigndeparts"
          title="会签部门"
          type="tree-select"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...comProps,
            ...deptMulProps,
            placeholder: `请选择会签部门`,
          }}
        />
        <Field
          name="countersignusers"
          title="会签人"
          type="tree-select"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择会签人`,
          }}
        />
        <Field
          name="noticeusers"
          title="知会人"
          type="tree-select"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...userMulProps,
            placeholder: `请选择知会人`,
          }}
        />
        <Field
          name="noticedeparts"
          title="知会部门"
          type="tree-select"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            ...comProps,
            ...deptMulProps,
            placeholder: `请选择知会部门`,
          }}
        />
      </BasicFormCard>

      <BasicFormCard title="基金信息" megaLayout={megaProps}>
        <Field
          name="fundcode"
          type="tree-select"
          title="基金名称"
          required
          x-mega-props={{
            addonAfter: '{{rendeRquery()}}',
          }}
          x-component-props={{
            style: { maxWidth: 500 },
            optionFilterProp: 'label',
            placeholder: '请输入基金名称简称',
            ...useFundEtfList({
              dropdownMatchSelectWidth: false,
            }),
          }}
        />
        <Field
          name="itemList"
          type="array"
          x-component="form-table"
          x-component-props={{
            operationsWidth: 80,
            selectedAllRows: true,
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            renderExtendButtons: '{{renderExtendButtons}}',
            visibleColumns:
              ['10'].includes(elementCode) && firstTokenFlag && !isDraft
                ? ['afterunit', 'effectdate']
                : [],
          }}
          x-mega-props={{ span: 4 }}
        >
          <Field type="object">
            <Field
              name="fundname"
              title="基金名称"
              type="string"
              editable={false}
              x-component-props={{
                renderLabel: (text, record) => `${record.fundname}[${record.fundcode}]`,
              }}
            />
            <Field name="information" title="信息类别（单位：份）" type="string" editable={false} />
            <Field
              name="beforunit"
              title="调整前参数"
              required
              type="number"
              editable={false}
              x-component-props={{
                precision: 2,
                formatter: (value) => numberToAmount(value),
              }}
            />
            <Field
              name="afterunit"
              title="调整后参数"
              required
              editable={false}
              type="number"
              x-component-props={{
                renderLabel: (text, record) => (
                  <span style={{ color: 'red' }}>
                    {numberToAmount((record.afterunit || '') + '') + '.00'}
                  </span>
                ),
              }}
            />
            <Field
              name="effectdate"
              title="生效日期"
              type="date"
              editable={false}
              required
              x-component-props={{
                format: 'YYYY-MM-DD',
                renderLabel: (text, record) => (
                  <span style={{ color: 'red' }}>
                    {moment(record.effectdate).format('YYYY-MM-DD') || ''}
                  </span>
                ),
              }}
            />
          </Field>
        </Field>
      </BasicFormCard>
    </>
  );
}
export default Form;
