import React from 'react';
import { forOwn, findLastIndex } from 'lodash';

const infoList = [
  { key: '人', value: 'opUser' },
  { key: '分数', value: 'score' },
  { key: '等级', value: 'riskLv' },
  { key: '时间', value: 'createtime' },
];

const AntiMoneyEvalInfo = ({ antiMoneyEvalInfo }) => {
  const { children = [] } = antiMoneyEvalInfo || {};

  const formatData = () => {
    if (!children.length) {
      return [];
    }

    const list = [];
    const result = [];
    const getLastIndex = (cb) => findLastIndex(children, cb);
    // 都取最新的打分记录，且复评和审批取同意的记录
    const lastIndexMap = {
      初评: ({ status }) => status === '1' || status === '0',
      复评: ({ status, opResult }) => opResult === '1' && (status === '12' || status === '11'),
      审批: ({ status, opResult }) => opResult === '1' && status === '20',
    };
    forOwn(lastIndexMap, (value, key) => {
      const idx = getLastIndex(value);
      if (idx !== -1) {
        const { opUser, score, riskLv, createtime, memo } = children[idx];
        list.push({ prefix: key, opUser, score, riskLv, createtime, memo });
      }
    });

    list.forEach((item) => {
      infoList.forEach(({ key, value }) => {
        // 审批的时候，不显示分数和等级，跟反洗钱打分页面保持一致
        const hideItem = item.prefix === '审批' && ['score', 'riskLv'].includes(value);
        if (!hideItem) {
          result.push({ key: `${item.prefix}${key}`, value: item[value] });
        }
      });
    });
    return result;
  };

  return formatData().map((item) => (
    <div key={item.key}>
      <span style={{ display: 'inline-block', textAlign: 'right', width: 160 }}>{item.key} :</span>
      <span> {item.value}</span>
    </div>
  ));
};

export default AntiMoneyEvalInfo;
