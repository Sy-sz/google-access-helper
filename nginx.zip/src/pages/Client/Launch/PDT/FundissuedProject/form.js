/** 发行流程 */
import React from 'react';
import { Field, FormSlot } from 'formily-antd';
import { omit } from 'lodash';
import { FormMegaLayout } from '@formily/antd-components';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { DeleteOutlined, InfoCircleOutlined, UploadOutlined } from '@ant-design/icons';
import { UploadFile } from '@cerdo/cerdo-design';
import { Button, Tooltip } from 'antd';
import {
  useMegaLayoutProps,
  useDictList,
  useManagerList,
  useTreeUser,
  useAgencyList,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import { usePagerList } from '@/hooks';
import moment from 'moment';
import { downloadFileApi, ossBaseFileApi } from 'common/axios/config';
import store from '@/store';
import { renderSign } from '@/pages/Client/Launch/utils';
import { D } from '@/utils';
import AntiMoney from './AntiMoney';
import './style.less';

const fundprodgeneralfilesTitle = (
  <>
    基金产品资料概要&nbsp;
    <Tooltip title="涉及多份额时，每个份额需要上传一份">
      <InfoCircleOutlined />
    </Tooltip>
  </>
);
const noticeInfo = [
  { keyWords: ['基金合同'], title: '基金合同', dataIndex: 'fundcontrfiles' },
  { keyWords: ['托管', '托管协议'], title: '托管协议', dataIndex: 'trustagmtfiles' },
  { keyWords: ['招募说明书'], title: '招募说明书', dataIndex: 'recruitinstfiles' },
  { keyWords: ['发售公告', '发售'], title: '发售公告', dataIndex: 'saleannofiles' },
  {
    keyWords: ['基金产品资料概要', '资料概要'],
    title: fundprodgeneralfilesTitle,
    dataIndex: 'fundprodgeneralfiles',
  },
  {
    keyWords: ['基金合同和招募说明书提示性公告', '提示性公告'],
    title: '基金合同和招募说明书提示性公告',
    dataIndex: 'tipactannofiles',
  },
];

// eslint-disable-next-line complexity
function Form(props) {
  const {
    context: { getProcess, formData },
    formEffects: { formActions, dispatcher },
  } = props;
  const { elementCode, readOnlyFlag, firstTokenFlag } = getProcess() || {};
  const comProps = {
    size: 'middle',
  };

  const orgDispatcher = store.useModelDispatchers('org');

  const megaProps = {
    labelWidth: 170,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };

  const userProps = useTreeUser({
    // 经办人过滤出清算部所有人
    request: async () =>
      orgDispatcher.usersByDept().then((result) => {
        if (result && Array.isArray(result.data)) {
          result.data = result.data.filter(
            (a) => a.departmentId === '979E99E7-9E37-4429-928B-62AA2BB91C7F',
          );
        }
        return result;
      }),
    // state: { departmentId: '979E99E7-9E37-4429-928B-62AA2BB91C7F' },
    showSearchButton: false,
  });
  const megaLayoutProps = useMegaLayoutProps(megaProps);
  const managerProps = useManagerList({ multiple: true, tokenSeparators: [','] });
  const businessTypeProps = useDictList({ id: '9cd915e33daf4cd78430e8499642c39f' });
  const riskLevelProps = useDictList({ id: '81e87383a78a486091eef2183e0cf163' });
  const adjusttypeProps = useDictList({ id: '0e4ec184-7be5-45d9-aa72-5fcd729793b3' });
  const indexfundtypeProps = useDictList({ id: '659ef3ea68d843c8ba2900029e3a288a' });
  const fundattributeProps = useDictList({ id: '086af717-93d2-4a11-ad4d-04cb8e576c85' });
  const listingPlaceProps = useDictList({ id: '5ad101e1b15b466db717de898ab426bc' });
  const csrcFundTypeProps = useDictList({ id: 'f3e9f86d-c12c-44c9-bb02-38848e438bce' });
  const currencyProps = useDictList({ id: '80e7fe7b84374cceb7fc921d4cf0362e' });
  const listingTypeProps = useDictList({ id: '3dfa7cb6cd474c4480457266aa402300' });
  const apprvFundTypeProps = useDictList({ id: '960ebe34-373a-4540-9f56-94939e8e4c71' });
  const overseasInvestmentPlace = useDictList({ multiple: true, id: D.OVERSEAS_INVESTMENT_PLACE });
  const biTypeProps = useDictList({
    type: 'cascader',
    multiple: true,
    id: 'e15090ac-bf96-467d-86b9-377ec8777368',
  });
  // 代销关系显示逻辑
  const iteminfoVisible = ['40', '41', '42', '43'].includes(elementCode) || elementCode >= 160;

  const itemlistProps = {};
  if (elementCode === '160') {
    itemlistProps.renderRemove = () => null;
  }

  const handleUploadChange = (file) => {
    let fileKey;
    noticeInfo.forEach(({ keyWords, dataIndex }) => {
      keyWords.forEach((keyWord) => {
        if (file.fileName.includes(keyWord)) {
          fileKey = dataIndex;
        }
      });
    });
    if (fileKey) {
      formActions.setFieldState(fileKey, (state) => {
        state.value = [{ ...omit(file, ['status']), name: file.fileName }];
      });
    }
  };

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps} name="baseInfor">
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      {renderSign({
        name: 'release170',
        title: '发行会签信息',
        display: Number(elementCode) > 150 && !firstTokenFlag,
        editable: ['160'].includes(elementCode) && !readOnlyFlag,
      })}

      <BaseFormCard
        title="基金信息"
        megaProps={megaProps}
        name="fundInfor"
        // upDown={Number(elementCode) > 20 ? 'up' : 'down'}
      >
        <Field name="fundid" type="string" display={false} required />
        <Field
          name="fundcode"
          title="基金代码"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金代码' }}
        />
        <Field
          name="fundname"
          title="基金名称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金名称' }}
        />
        <Field
          name="fundshortname"
          title="基金信披简称"
          type="string"
          required
          x-component-props={{ placeholder: '请输入基金信披简称' }}
        />
        <Field
          name="businesstype"
          title="基金类别"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金类别',
            previewPlaceholder: '-',
            ...businessTypeProps,
          }}
        />
        <Field
          name="fundmanagerid"
          title="基金经理"
          type="tree-select"
          required
          x-component-props={{
            ...comProps,
            placeholder: '请选择基金经理',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...managerProps,
          }}
        />
        <Field
          name="trusteeid"
          title="托管人"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择托管人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '托管人' }),
          }}
        />
        <Field
          name="abroadfundcustodianid"
          title="境外托管人"
          type="tree-select"
          x-component-props={{
            placeholder: '请选择境外托管人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '境外托管人' }),
          }}
        />
        <Field
          name="fundmanager"
          title="基金管理人"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金管理人',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...useAgencyList({ type: '基金管理人' }),
          }}
        />
        <Field
          name="risklevel"
          title="基金风险等级"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金风险等级',
            previewPlaceholder: '-',
            ...comProps,
            ...riskLevelProps,
          }}
        />
        {[
          {
            key: 'minstockratio',
            label: '股票类资产投资最低比例(%)',
            placeholder: '股票类资产投资最低比例(%)',
            required: true,
          },
          {
            key: 'maxstockratio',
            label: '股票类资产投资最高比例(%)',
            placeholder: '股票类资产投资最高比例(%)',
            required: true,
          },
          {
            key: 'minbondsratio',
            label: '债权类资产投资最低比例(%)',
            placeholder: '债权类资产投资最低比例(%)',
            required: true,
          },
          {
            key: 'maxbondsratio',
            label: '债权类资产投资最高比例(%)',
            placeholder: '债权类资产投资最高比例(%)',
            required: true,
          },
          {
            key: 'minmoneyratio',
            label: '货币类资产投资最低比例(%)',
            placeholder: '货币类资产投资最低比例(%)',
            required: true,
          },
          {
            key: 'maxmoneyratio',
            label: '货币类资产投资最高比例(%)',
            placeholder: '货币类资产投资最高比例(%)',
            required: true,
          },
          {
            key: 'hkmaxstockratio',
            label: (
              <span>
                香港市场的股票类资产
                <br />
                投资最高比例(%)
              </span>
            ),
            placeholder: '香港市场的股票类资产投资最高比例(%)',
            required: true,
          },
        ].map((item) => {
          return (
            <Field
              name={item.key}
              title={item.label}
              key={item.key}
              type="number"
              required={item.required}
              x-component-props={{
                min: 0,
                max: 100,
                precision: 2,
                // formatter: (value) => value && `${value}%`,
                // parser: (value) => value.replace('%', ''),
                placeholder: item.placeholder,
              }}
            />
          );
        })}
        <Field
          required
          name="investarea"
          title="境外投资地"
          type="tree-select"
          x-component-props={{
            placeholder: '请选择境外投资地',
            ...overseasInvestmentPlace,
          }}
        />
        <Field
          required
          type="string"
          name="ishkinvest"
          title="是否通过港股通投资港股"
          x-component-props={{ placeholder: '是否通过港股通机制投资港股' }}
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
        />

        {/* {[
          { key: 'investgoal', label: '投资目标', required: true },
          { key: 'assetallratio', label: '资产配置比例', required: true },
        ].map((item) => {
          return (
            <Field
              key={item.key}
              name={item.key}
              title={item.label}
              type="textarea"
              previewPlaceholder="pre"
              required={item.required}
              x-component-props={{
                placeholder: `请输入${item.label}`,
                autoSize: { minRows: 3, maxRows: 20 },
              }}
              x-mega-props={{ span: 4 }}
            />
          );
        })} */}
      </BaseFormCard>

      <BaseFormCard
        title="报社信息"
        name="pagerinfo"
        megaProps={megaProps}
        visible={Number(elementCode) >= 21}
        upDown={Number(elementCode) > 170 ? 'up' : 'down'}
      >
        <Field
          name="organinfoid"
          title="报社"
          type="tree-select"
          required
          editable={Number(elementCode) === 21 && !readOnlyFlag}
          x-component-props={{
            placeholder: '请选择报社',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...usePagerList({ type: '报社' }),
          }}
        />
        {/* <Field
          name="sdate"
          title="生效日期"
          type="date"
          required
          editable={Number(elementCode) === 21 && !readOnlyFlag}
          x-component-props={{
            format: 'YYYY-MM-DD',
            placeholder: '请选择生效日期',
          }}
        /> */}
        <Field
          name="apprvfundtype"
          title="基金类型(信披)"
          type="tree-select"
          required
          editable={Number(elementCode) === 21 && !readOnlyFlag}
          x-component-props={{
            placeholder: '请选择基金类型(信披)',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...apprvFundTypeProps,
          }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="基金发售信息"
        megaLayout={megaProps}
        name="fundOfferingInfor"
        // upDown={!['10', '15', '210', '270'].includes(elementCode) ? 'up' : 'down'}
      >
        <Field
          name="issuestartdate"
          title={
            <>
              募集开始日(T日)
              <Tooltip title="申请日必须在募集开始日往前推3个自然日，再推2个工作日之前（包含）">
                {' '}
                <InfoCircleOutlined />
              </Tooltip>
            </>
          }
          type="date"
          required
          x-rules={[
            {
              validator: async (value) => {
                if (!value) {
                  return;
                }
                // 申请日 必须在 募集开始日期先往前推3个自然日、在加上2个工作日之前（包含）
                const applydate = moment(formActions.getFieldValue('applydate')).format('YYYYMMDD');

                const sub3date = moment(value).add(-3, 'days').format('YYYYMMDD');
                const result = await dispatcher.getWorkDate({ date: sub3date, offset: -2 });
                const sub2date = result?.data;

                if (sub2date && value && moment(sub2date).isBefore(moment(applydate))) {
                  return `申请日期必须在(${sub2date})之前，请调整募集开始日`;
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
            placeholder: '请选择募集开始日',
            disabledDate: (currentDate) => {
              const issueenddate = formActions.getFieldValue('issueenddate');
              if (issueenddate && moment(issueenddate).isBefore(currentDate)) {
                return true;
              }
              return false;
            },
          }}
        />
        <Field
          name="issueenddate"
          title="募集结束日(R日)"
          type="date"
          required
          x-rules={[
            {
              validator: (value) => {
                const issuestartdate = formActions.getFieldValue('issuestartdate');
                if (
                  issuestartdate &&
                  value &&
                  moment(issuestartdate).add(3, 'months').isBefore(value, 'day')
                ) {
                  return '募集期不可超过三个月';
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
            placeholder: '请选择募集结束日',
            disabledDate: (currentDate) => {
              const issuestartdate = formActions.getFieldValue('issuestartdate');
              if (issuestartdate && moment(issuestartdate).isAfter(currentDate, 'day')) {
                return true;
              }
              return false;
            },
          }}
        />
        <Field
          name="adjustraisedate"
          title="是否调整募集期"
          type="string"
          visible={Number(elementCode) > 200 && !firstTokenFlag}
          editable={['210'].includes(elementCode) && !readOnlyFlag}
          required
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          x-component-props={{
            placeholder: `请选择是否调整募集期`,
          }}
        />
        <Field
          name="adjusttype"
          title="调整募集类型"
          type="tree-select"
          visible={Number(elementCode) > 200 && !firstTokenFlag}
          editable={['210'].includes(elementCode) && !readOnlyFlag}
          required
          x-component-props={{
            placeholder: '请选择调整募集类型',
            optionFilterProp: 'label',
            previewPlaceholder: '-',
            ...adjusttypeProps,
          }}
        />
        <Field
          name="delayraiseenddate"
          title="延后募集结束日"
          type="date"
          required
          visible={Number(elementCode) > 200 && !firstTokenFlag}
          editable={['210'].includes(elementCode) && !readOnlyFlag}
          x-rules={[
            {
              validator: async () => {
                // ETF基金 提交日 必须在（修改的募集结束日和募集结束日孰早）的前10个工作日之前提交
                const indexfundtype = formActions.getFieldValue('indexfundtype');
                if (indexfundtype === 'ETF') {
                  const issueenddate = moment(formActions.getFieldValue('issueenddate')).format(
                    'YYYYMMDD',
                  );

                  const result = await dispatcher.getWorkDate({ date: issueenddate, offset: -10 });
                  const sub10date = result?.data;

                  if (sub10date && moment(sub10date).isBefore(moment(), 'day')) {
                    return `ETF基金延后募集必须在(${sub10date})之前提交，已无法调整`;
                  }
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
            placeholder: '请选择延长募集日期',
            disabledDate: (currentDate) => {
              const issueenddate = formActions.getFieldValue('issueenddate');
              if (issueenddate && moment(issueenddate).add(1, 'days').isAfter(currentDate, 'day')) {
                return true;
              }
              return false;
            },
          }}
        />
        <Field
          name="advanceraiseenddate"
          title="提前募集结束日"
          type="date"
          required
          visible={Number(elementCode) > 200 && !firstTokenFlag}
          editable={['210'].includes(elementCode) && !readOnlyFlag}
          x-rules={[
            {
              validator: async (value) => {
                // 提交日 必须在（修改的募集结束日和募集结束日孰早）的前10个工作日之前提交
                if (!value) {
                  return;
                }
                const indexfundtype = formActions.getFieldValue('indexfundtype');
                if (indexfundtype === 'ETF') {
                  const advanceraiseenddate = moment(value).format('YYYYMMDD');

                  const result = await dispatcher.getWorkDate({
                    date: advanceraiseenddate,
                    offset: -10,
                  });
                  const sub10date = result?.data;

                  if (sub10date && moment(sub10date).isBefore(moment(), 'day')) {
                    return `ETF基金提前募集必须在(${sub10date})之前提交，请调整提前募集结束日`;
                  }
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            format: 'YYYY-MM-DD',
            placeholder: '请选择提前募集结束日期',
            disabledDate: (currentDate) => {
              const issueenddate = formActions.getFieldValue('issueenddate');
              if (
                issueenddate &&
                moment(issueenddate).add(-1, 'days').isBefore(currentDate, 'day')
              ) {
                return true;
              }
              return false;
            },
          }}
        />
        <Field
          name="parvalue"
          title="面值"
          type="number"
          x-component-props={{
            min: 0,
            precision: 2,
            placeholder: '请输入面值',
          }}
        />
        <Field
          name="prosetupdate"
          title="预计基金成立日(P日)"
          type="date"
          required
          visible={Number(elementCode) > 260 && !firstTokenFlag}
          editable={['270'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            format: 'YYYY-MM-DD',
            placeholder: '请选择预计基金成立日(P日)',
          }}
        />
        <Field
          name="raisedown"
          title="募集规模下限"
          type="number"
          x-component-props={{
            min: 0,
            formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
            parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
            placeholder: '请输入募集下限',
          }}
        />
        <Field
          name="raiseup"
          title="募集规模上限"
          type="number"
          x-component-props={{
            min: 0,
            formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
            parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
            placeholder: '请输入募集下限',
          }}
        />
        <Field
          name="pubprice"
          title="发行价格"
          type="number"
          x-component-props={{
            min: 0,
            precision: 2,
            placeholder: '请输入发行价格',
          }}
        />
        {/* <Field
          name="leastsubscription"
          title="最低认购金额"
          type="number"
          x-component-props={{
            min: 0,
            formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
            parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
            placeholder: '请输入金额下限',
          }}
        />
        <Field
          name="leastsubscriptionadd"
          title="追加认购最低限额"
          type="number"
          x-component-props={{
            min: 0,
            formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
            parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
            placeholder: '请输入追加认购最低限额下限',
          }}
        /> */}
      </BaseFormCard>

      <BaseFormCard
        title="代销关系信息"
        megaLayout={false}
        name="iteminfo"
        visible={iteminfoVisible}
        editable={['40', '41', '42', '43', '160'].includes(elementCode) && !readOnlyFlag}
        upDown={Number(elementCode) > 43 ? 'up' : 'down'}
      >
        <Field
          name="itemlist"
          type="array"
          x-component="form-table"
          visible={iteminfoVisible}
          editable={['40', '41', '42', '43', '160'].includes(elementCode) && !readOnlyFlag} // TODO: 复核、退回时可编辑 去掉了readOnlyFlag
          x-component-props={{
            ...itemlistProps,
            operationsWidth: 80,
            selectedAllRows: true,
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            onSelect: '{{changeAgencyTableOnSelect}}',
            renderExtendButtons: '{{renderExtendButtons}}',
            onRemove: '{{changeAgencyTableRemove}}',
          }}
        >
          <Field type="object">
            <Field
              name="fundcode"
              title="基金代码"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="fundname"
              title="基金名称"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companycode"
              title="机构代码"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companyname"
              title="机构名称"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companytype"
              title="机构类型"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="changetype"
              title="操作类型"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="agencyattr"
              title="代销属性"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field name="agencydate" title="上线日期" required type="date" x-component-props={{}} />
            <Field
              name="msg"
              title="错误信息提示"
              type="string"
              editable={false}
              x-component-props={{
                renderLabel: (_text, record) => <span style={{ color: 'red' }}>{record.msg}</span>,
              }}
            />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        name="prepareAnnouncement"
        title="公告信息"
        megaProps={{ ...megaProps, labelWidth: 220 }}
        visible={Number(elementCode) >= 160}
        extra={
          <UploadFile
            multiple
            accept=".xls,.xlsx,.pdf,.docx,.doc"
            showUploadList={false}
            uploadUrl={ossBaseFileApi}
            downloadUrl={downloadFileApi}
            onChange={handleUploadChange}
          >
            <Button icon={<UploadOutlined />} disabled={elementCode !== '160' || readOnlyFlag}>
              一键上传
            </Button>
          </UploadFile>
        }
      >
        {noticeInfo.map((item) => {
          return (
            <Field
              key={item.dataIndex}
              title={item.title}
              name={item.dataIndex}
              type="bpm-upload-list"
              editable={['160'].includes(elementCode) && !readOnlyFlag}
              required
              x-mega-props={{ span: 2 }}
              x-component-props={{
                onSuccess: `{{fileSuccess("${item.dataIndex}")}}`,
                onDel: `{{fileDel("${item.dataIndex}")}}`,
                accept: '',
                multiple: true,
                isFsfund: true,
                maxLength: 4,
              }}
            />
          );
        })}
      </BaseFormCard>

      <BasicFormCard
        title="调整募集期公告"
        megaLayout={megaProps}
        visible={
          Number(elementCode) >= 215 && Number(formData.adjustraisedate) === 1 && !firstTokenFlag
        }
      >
        <Field
          title="公告文件"
          name="updateNoticeFiles"
          type="bpm-upload-list"
          // visible={Number(elementCode) >= 215 && !firstTokenFlag}
          editable={['215'].includes(elementCode) && !readOnlyFlag}
          required
          x-component-props={{
            onSuccess: '{{fileSuccess("updateNoticeFiles")}}',
            onDel: '{{fileDel("updateNoticeFiles")}}',
            accept: '.pdf,.docx,.doc',
            multiple: true,
            isFsfund: true,
            maxLength: 4,
          }}
          x-mega-props={{ span: 2 }}
        />
      </BasicFormCard>

      {renderSign({
        name: 'release216',
        title: '调整募集期公告会签信息',
        display:
          Number(elementCode) >= 215 && Number(formData.adjustraisedate) === 1 && !firstTokenFlag,
        editable: ['215'].includes(elementCode) && !readOnlyFlag,
      })}

      <BasicFormCard title="发行批文" megaLayout={megaProps}>
        <Field
          title="发行批文文件"
          name="approvalfile"
          type="bpm-upload-list"
          required
          x-component-props={{
            onSuccess: '{{fileSuccess("approvalfile")}}',
            onDel: '{{fileDel("approvalfile")}}',
            accept: '.pdf,.docx,.doc',
            multiple: true,
            isFsfund: true,
            placeholder: '请上传发行批文文件',
          }}
          x-mega-props={{ span: 2 }}
        />
      </BasicFormCard>

      <BasicFormCard title="运营要素" megaLayout={megaProps}>
        <Field
          name="approvaldate"
          title="批复日期"
          type="date"
          required
          x-component-props={{
            format: 'YYYY-MM-DD',
            placeholder: '请选择批复日期',
          }}
        />
        <Field
          name="docnumber"
          title="核准文号"
          type="string"
          required
          x-component-props={{
            placeholder: '请输入核准文号',
          }}
        />
      </BasicFormCard>

      <BasicFormCard
        title="经办会计信息"
        megaLayout={megaProps}
        display={['25'].includes(elementCode)}
      >
        <Field
          name="trusteeapproveruser"
          title="开通托管行账户经办会计"
          type="tree-select"
          editable={['25'].includes(elementCode) && !readOnlyFlag}
          required
          x-component-props={{
            ...userProps,
            placeholder: `请选择开通托管行账户经办会计`,
          }}
          x-mega-props={{ labelWidth: 170 }}
        />
        <Field
          name="holderapproveruser"
          title="股东代码开户经办会计"
          type="tree-select"
          editable={['25'].includes(elementCode) && !readOnlyFlag}
          required
          x-component-props={{
            ...userProps,
            placeholder: `请选择股东代码开户经办会计`,
          }}
          x-mega-props={{ labelWidth: 170 }}
        />
      </BasicFormCard>

      <BaseFormCard
        title="基金运作费率"
        megaLayout={megaProps}
        name="fundsRate"
        upDown={Number(elementCode) > 10 ? 'up' : 'down'}
      >
        <Field
          name="managerfee"
          title="管理费率"
          type="number"
          required
          x-component-props={{
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入管理费率(%)',
          }}
        />
        <Field
          name="floatmanagerfee"
          title="浮动管理费"
          type="number"
          x-component-props={{
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入管理费率(%)',
          }}
        />
        <Field
          name="hostfee"
          title="托管费"
          type="number"
          required
          x-component-props={{
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入托管费(%)',
          }}
        />
        {/* <Field
          name="otherfee"
          title="其他费率"
          type="number"
          x-component-props={{
            min: 0,
            max: 100,
            precision: 2,
            formatter: (value) => value && `${value}%`,
            parser: (value) => value.replace('%', ''),
            placeholder: '请输入其他费(%)',
          }}
        /> */}
      </BaseFormCard>

      <BaseFormCard
        title="基金类型"
        megaProps={megaProps}
        name="fundType"
        upDown={Number(elementCode) > 10 ? 'up' : 'down'}
      >
        <Field
          name="fundattribute"
          title="基金类型"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择基金类型',
            previewPlaceholder: '-',
            ...comProps,
            ...fundattributeProps,
          }}
        />
        {[
          { key: 'isqdii', label: '是否QDII基金', required: true },
          { key: 'isinstitutionpdt', label: '是否机构类产品', required: true },
          {
            key: 'ismoreshares',
            label: (
              <>
                是否多份额类基金{' '}
                <Tooltip title="无须填写，根据份额数量自动判断">
                  <InfoCircleOutlined />
                </Tooltip>
              </>
            ),
            required: true,
            disabled: true,
          },
          { key: 'isinitiatingfund', label: '是否发起式基金', required: true },
          { key: 'needfutures', label: '是否需要期货功能', required: true },
        ].map((item) => {
          return (
            <Field
              key={item.key}
              name={item.key}
              title={item.label}
              type="string"
              required={item.required}
              enum={[
                { label: '是', value: '1' },
                { label: '否', value: '0' },
              ]}
              x-component-props={{
                placeholder: `请选择${item.label}`,
                allowClear: true,
                disabled: item.disabled,
              }}
            />
          );
        })}
        <Field
          name="isindexfund"
          title="是否指数基金"
          type="string"
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          x-component-props={{
            placeholder: `请选择是否指数基金`,
            allowClear: true,
          }}
        />
        <Field
          name="targetindexcode"
          title="标的指数代码"
          type="string"
          required
          x-component-props={{
            placeholder: '请输入标的指数代码',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="targetindexname"
          title="标的指数名称"
          type="string"
          required
          x-component-props={{
            placeholder: '请输入标的指数名称',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="indexorganization"
          title="指数公司"
          type="string"
          required
          x-component-props={{
            placeholder: '请输入指数公司',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="indexfundtype"
          title="指数基金类型"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择指数基金类型',
            previewPlaceholder: '-',
            ...comProps,
            ...indexfundtypeProps,
          }}
        />
        <Field
          name="goalfundcode"
          title="目标基金代码"
          type="string"
          required
          visible={false}
          x-component-props={{
            placeholder: '请输入目标基金代码',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="goalfundname"
          title="目标基金名称"
          type="string"
          visible={false}
          required
          x-component-props={{
            placeholder: '请输入目标基金名称',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="basketcode"
          title="ETF定义文件编码"
          type="string"
          visible={false}
          required
          x-component-props={{
            placeholder: '请输入ETF定义文件编码',
            previewPlaceholder: '-',
          }}
        />
        <Field
          name="bitype"
          title="BI分类"
          type="tree-select"
          x-component-props={{
            ...biTypeProps,
            placeholder: '请选择BI分类',
            separator: '',
            findedSeparator: '',
            renderText: (data, record) => {
              return data && data.namePath
                ? data.namePath.split('BI分类/').length > 1
                  ? data.namePath.split('BI分类/')[1]
                  : data.name
                : data?.name || '';
            },
          }}
        />
        <Field
          name="csrcfundtype"
          title="产品类别(证监会)"
          type="tree-select"
          required
          x-component-props={{
            placeholder: '请选择产品类别(证监会)',
            previewPlaceholder: '-',
            ...comProps,
            ...csrcFundTypeProps,
          }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="反洗钱评测"
        name="antiMoneyCard"
        className="antiMoneyCard"
        upDown={Number(elementCode) > 160 ? 'up' : 'down'}
      >
        <FormSlot>
          <AntiMoney antiMoneyEvalInfo={formData.antiMoneyEvalInfo} />
        </FormSlot>
        <Field
          name="linkAntiMoney"
          type="button"
          editable={['92', '94', '96'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            text: '去评测',
            size: 'small',
            type: 'primary',
            style: { marginLeft: 10 },
            onClick: '{{linkAntiMoney}}',
          }}
          x-mega-props={{ span: 4 }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="份额信息"
        name="shareinfo"
        megaLayout={false}
        upDown={Number(elementCode) > 20 ? 'up' : 'down'}
      >
        <Field
          name="sharelist"
          minItems={1}
          maxItems={5}
          type="array"
          default={[{}]}
          x-component="bpm-array-card"
          x-component-props={{
            title: '份额',
            titlefield: 'fundname',
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderRemove: (idx) => {
              const mutators = formActions.createMutators('sharelist');
              return (
                idx !== 0 && (
                  <Button
                    shape="circle"
                    icon={<DeleteOutlined />}
                    onClick={() => {
                      mutators.remove(idx);
                    }}
                  />
                )
              );
            },
            renderAddition: () => (
              <Button type="primary" size="small">
                添加子份额
              </Button>
            ),
          }}
        >
          <Field type="object">
            <FormMegaLayout {...megaLayoutProps}>
              <Field
                name="ismainshare"
                title="是否主份额"
                type="string"
                required
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否主份额`,
                }}
              />
              <Field
                name="sharetype"
                title="份额类型"
                type="string"
                required
                enum={[
                  { label: 'A', value: 'A' },
                  { label: 'B', value: 'B' },
                  { label: 'C', value: 'C' },
                ]}
                x-component-props={{
                  placeholder: `请选择份额类型`,
                }}
              />
              <Field
                name="fundcode"
                title="份额代码"
                type="string"
                required
                x-component-props={{
                  placeholder: `请输入份额代码`,
                }}
              />
              <Field
                name="fundname"
                title="份额网站简称"
                type="string"
                required
                x-component-props={{
                  placeholder: `请输入份额网站简称`,
                }}
              />
              <Field
                name="fundshortname"
                title="份额信披简称"
                type="string"
                required
                x-component-props={{ placeholder: '请输入份额信披简称' }}
              />
              <Field
                name="currency"
                title="交易币种"
                default="人民币"
                type="tree-select"
                x-component-props={{
                  ...currencyProps,
                  placeholder: `请选择交易币种`,
                }}
              />
              <Field
                name="islisted"
                title="是否上市"
                type="string"
                required
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否上市`,
                }}
              />
              <Field
                name="floortradecode"
                title="场内代码"
                type="string"
                required
                x-component-props={{
                  placeholder: `请输入场内代码`,
                }}
              />
              <Field
                name="floortradename"
                title="场内简称"
                type="string"
                required
                x-component-props={{
                  placeholder: `请输入场内简称`,
                }}
              />
              <Field
                name="listingplace"
                title="上市场所"
                required
                visible={false}
                type="tree-select"
                x-component-props={{
                  ...listingPlaceProps,
                  placeholder: `请选择上市场所`,
                }}
              />
              <Field
                name="listingtype"
                title="上市基金类型"
                required
                visible={false}
                type="tree-select"
                x-component-props={{
                  ...listingTypeProps,
                  placeholder: `请选择上市基金类型`,
                }}
              />
              <Field
                name="salesfee"
                title="销售服务费率(单位: %)"
                type="number"
                x-component-props={{
                  style: {
                    marginBottom: 30,
                  },
                  min: 0,
                  max: 100,
                  precision: 2,
                  formatter: (value) => value && `${value}`,
                  parser: (value) => value.replace('%', ''),
                  placeholder: '请输入销售服务费率(%)',
                }}
              />
            </FormMegaLayout>
            <Field
              title="认购费"
              name="subscribelist"
              type="array"
              x-component="form-table"
              x-component-props={{
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                visibleColumns: ['sharetype'],
              }}
            >
              <Field type="object">
                <Field
                  name="minsum"
                  title={
                    <>
                      认购金额下限(包含)
                      <Tooltip title="最小值：0">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    placeholder: '请输入金额下限',
                  }}
                />
                <Field
                  name="maxsum"
                  title={
                    <>
                      认购金额上限(不包含)
                      <Tooltip title="最大值：999,999,999,999">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    min: 0,
                    precision: 0,
                    placeholder: '请输入金额上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharechargingmet"
                  title="收费方式"
                  type="string"
                  required
                  enum={[
                    { label: '前端收费', value: '前端收费' },
                    { label: '后端收费', value: '后端收费' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择收费方式',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>
            <Field
              title="申购费"
              name="purchaselist"
              type="array"
              x-component="form-table"
              x-component-props={{
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                visibleColumns: ['sharetype'],
              }}
            >
              <Field type="object">
                <Field
                  name="minsum"
                  title={
                    <>
                      申购金额下限(包含)
                      <Tooltip title="最小值：0">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    placeholder: '请输入金额下限',
                  }}
                />
                <Field
                  name="maxsum"
                  title={
                    <>
                      申购金额上限(不包含)
                      <Tooltip title="最大值：999,999,999,999">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    formatter: (value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','),
                    parser: (value) => value.replace(/\$\s?|(,*)/g, ''),
                    min: 0,
                    precision: 0,
                    placeholder: '请输入金额上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharechargingmet"
                  title="收费方式"
                  type="string"
                  required
                  enum={[
                    { label: '前端收费', value: '前端收费' },
                    { label: '后端收费', value: '后端收费' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择收费方式',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>
            <Field
              title="赎回费"
              name="redemptionlist"
              type="array"
              x-component="form-table"
              x-component-props={{
                operationsWidth: 80,
                renderMoveDown: () => null,
                renderMoveUp: () => null,
                visibleColumns: ['sharetype'],
              }}
            >
              <Field type="object">
                <Field
                  name="minday"
                  title={
                    <>
                      持有期限下限(包含)
                      <Tooltip title="最小值：0">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    placeholder: '请输入下限',
                  }}
                />
                <Field
                  name="maxday"
                  title={
                    <>
                      持有期限上限(不包含)
                      <Tooltip title="最大值：999,999,999,999">
                        {' '}
                        <InfoCircleOutlined />
                      </Tooltip>
                    </>
                  }
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 0,
                    placeholder: '请输入上限',
                  }}
                />
                <Field
                  name="rate"
                  title="费率"
                  type="number"
                  required
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请输入费率',
                  }}
                />
                <Field
                  name="ratename"
                  title="费率单位"
                  type="number"
                  required
                  enum={[
                    { label: '%', value: '%' },
                    { label: '元/笔', value: '元/笔' },
                  ]}
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    placeholder: '请选择费率单位',
                  }}
                />
                <Field
                  name="sharetype"
                  title="份额类型"
                  type="string"
                  enum={[
                    { label: '场内份额', value: '场内份额' },
                    { label: '场外份额', value: '场外份额' },
                  ]}
                  x-component-props={{
                    placeholder: '请选择份额类型',
                  }}
                />
                <Field
                  name="homeretaprop"
                  title="归基金资产比例"
                  type="number"
                  x-component-props={{
                    min: 0,
                    precision: 2,
                    formatter: (value) => value && `${value}%`,
                    parser: (value) => value.replace('%', ''),
                    placeholder: '请输入归基金资产比例(%)',
                  }}
                />
                <Field
                  name="description"
                  title="描述"
                  type="string"
                  x-component-props={{ placeholder: '请输入描述' }}
                />
              </Field>
            </Field>
          </Field>
        </Field>
      </BaseFormCard>
    </>
  );
}

export default Form;
