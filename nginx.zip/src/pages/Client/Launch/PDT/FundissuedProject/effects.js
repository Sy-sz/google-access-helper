/* eslint-disable array-callback-return */
import { FormPath, FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import { Button, Select, Space, Input } from 'antd';
import React, { useState } from 'react';
import moment from 'moment';
import { isEmpty } from 'lodash';
import { uuid, isMobile, copyText } from '@/utils';
import store from '@/store';
import Upload, { MessageShowType } from '@chinahorm/web-components/es/components/Upload';
import { importAgency } from '@/common/axios/pdtSystem';
import Download from '@chinahorm/web-components/es/components/Download';
import { baseURL } from '@/setting';
import { ProFormDatePicker, ProFormSelect, ModalForm } from '@ant-design/pro-form';
import { fn } from '@cerdo/cerdo-utils/lib';
import { toggleSignType } from '../../utils';
import { queryNewByFundCode } from '@/common/axios';
const { onFieldValueChange$, onFieldInputChange$, onFieldInit$ } = FormEffectHooks;

const antiMoneyCodeMap = {
  初评: '92',
  复评: '94',
  审批: '96',
  92: '初评',
  94: '复评',
  96: '审批',
};

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag, readOnlyFlag, processId } = getProcess() || {};
    this.processId = processId;
    this.managerid = null;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.orgDispatcher = store.useModelDispatchers('org');
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
    this.itemList = [];
    this.agencyMember = ''; // 退回人员
  }

  createFormEffects() {
    // const { getProcess } = this.props.context;
    // const { firstTokenFlag } = getProcess() || {};
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      onFieldInit$('fundmanagerid').subscribe(({ value }) => {
        if (typeof value === 'string') {
          const arr = (value || '').split(',');
          if (arr.length > 0) {
            setFieldValue('fundmanagerid', arr);
          }
        }
      });
      // onFieldInit$('fundsummary').subscribe(() => {
      //   setFieldState('fundsummary', (state) => {
      //     state.description =
      //       '说明：【基金合同】【托管协议】【招募说明书】【发售公告】【基金产品资料概要】每个份额一份';
      //   });
      // });

      onFieldInputChange$('fundmanagerid').subscribe(({ value, values }) => {
        if (Array.isArray(values) && values.length > 0) {
          const account = (values[1].data || []).map((a) => a.account).join(';');
          setFieldValue('lawfileapprover', account);
        }
      });

      onFieldInputChange$('fundname').subscribe(({ value }) => {
        setFieldValue('sharelist.0.fundname', value);
      });

      onFieldInputChange$('fundshortname').subscribe(({ value }) => {
        setFieldValue('sharelist.0.fundshortname', value);
      });

      onFieldValueChange$('sharelist.*.islisted').subscribe((fieldState) => {
        const index = FormPath.transform(fieldState.name, /\d/, (index) => index);
        setFieldState(
          `*(sharelist.${index}.listingplace,sharelist.${index}.listingtype,sharelist.${index}.floortradecode,sharelist.${index}.floortradename)`,
          (state) => {
            state.visible = fieldState.value === '1';
          },
        );
        if (fieldState.value && Number(fieldState.value) === 1) {
          setFieldState(
            `*(sharelist.${index}.subscribelist,sharelist.${index}.purchaselist,sharelist.${index}.redemptionlist)`,
            (s) => {
              s.props['x-component-props'].visibleColumns = [{ name: 'sharetype', visible: true }];
            },
          );
        } else {
          setFieldState(
            `*(sharelist.${index}.subscribelist,sharelist.${index}.purchaselist,sharelist.${index}.redemptionlist)`,
            (s) => {
              s.props['x-component-props'].visibleColumns = [{ name: 'sharetype', visible: false }];
            },
          );
        }
      });

      // 是否多份额 根据份额数量联动
      onFieldValueChange$('sharelist').subscribe((s) => {
        console.log('sharelist=====>', (s.value || []).length > 1 ? '1' : '0');
        setFieldValue('ismoreshares', (s.value || []).length > 1 ? '1' : '0');
      });

      // onFieldValueChange$('baseInfor').subscribe((state) => {
      //   // eslint-disable-next-line
      //   this.formActions.setFieldState('baseInfor', (state) => (state.visible = !visible));
      // });

      // 是否指数基金
      onFieldValueChange$('isindexfund').subscribe(async ({ value, values }) => {
        if (value && Number(value) === 1) {
          setFieldState(
            '*(indexfundtype,targetindexcode,targetindexname,indexorganization)',
            (state) => {
              state.visible = true;
            },
          );
        } else {
          setFieldState(
            '*(indexfundtype,targetindexcode,targetindexname,indexorganization)',
            (state) => {
              state.visible = false;
            },
          );
        }
      });

      // 募集开始日期清空， 募集结束日也自动清空，否则会造成开始日选不到后面日期
      onFieldValueChange$('issuestartdate').subscribe(async ({ value }) => {
        if (!value) {
          setFieldValue('issueenddate', undefined);
        }
      });

      // 是否调整募集期
      onFieldValueChange$('adjustraisedate').subscribe(async ({ value, values }) => {
        if (value && Number(value) === 1) {
          setFieldState('*(adjusttype)', (state) => {
            state.visible = true;
          });
        } else {
          setFieldState('*(adjusttype,extendraisedate,preraisedate)', (state) => {
            state.visible = false;
          });
        }
      });

      // 募集日期类型
      onFieldValueChange$('adjusttype').subscribe(async ({ value, values }) => {
        if (value) {
          if (value && value === '延后募集结束日') {
            setFieldState('delayraiseenddate', (state) => {
              state.visible = true;
            });
            setFieldState('advanceraiseenddate', (state) => {
              state.visible = false;
            });
          }
          if (value && value === '提前募集结束日') {
            setFieldState('delayraiseenddate', (state) => {
              state.visible = false;
            });
            setFieldState('advanceraiseenddate', (state) => {
              state.visible = true;
            });
          }
        } else {
          setFieldState('*(advanceraiseenddate,delayraiseenddate)', (state) => {
            state.visible = false;
          });
        }
      });

      onFieldValueChange$('itemlist').subscribe(({ value }) => {
        const length = value && Array.isArray(value) && value.length;
        setFieldState('iteminfo', (s) => {
          s.props['x-component-props'].title = (
            <div>
              代销关系信息 <small>(共{length}条代销关系)</small>
            </div>
          );
        });
      });

      // 指数基金类型
      onFieldValueChange$('indexfundtype').subscribe(async ({ value, values }) => {
        if (value) {
          if (value && value === 'ETF联接基金') {
            setFieldState('*(goalfundcode,goalfundname)', (state) => {
              state.visible = true;
            });
            setFieldState('basketcode', (state) => {
              state.visible = false;
            });
          }
          if (value && value === 'ETF') {
            setFieldState('*(goalfundcode,goalfundname)', (state) => {
              state.visible = false;
            });
            setFieldState('basketcode', (state) => {
              state.visible = true;
            });
          }
          if (value && value !== 'ETF联接基金' && value !== 'ETF') {
            setFieldState('*(goalfundcode,goalfundname,basketcode)', (state) => {
              state.visible = false;
            });
          }
        } else {
          setFieldState('*(goalfundcode,goalfundname,basketcode)', (state) => {
            state.visible = false;
          });
        }
      });

      onFieldInit$('*(bitype)').subscribe(({ value, name }) => {
        if (value) {
          if (value.length === 4) {
            setFieldValue(name, [value]);
          }
          if (value.length === 6) {
            setFieldValue(name, [value.substr(0, 4), value]);
          }
          if (value.length === 8) {
            setFieldValue(name, [value.substr(0, 4), value.substr(0, 6), value]);
          }
        }
      });

      // 是否通过港股通投资港股和isqdii，有一个为是，那么境外投资地必填
      onFieldValueChange$('*(ishkinvest,isqdii)').subscribe((field) => {
        console.log('field.ishkinvest', field);
        if (field.value === '1') {
          setFieldState('investarea', (state) => {
            state.required = true;
          });
          return;
        }

        const another = field.name === 'ishkinvest' ? 'isqdii' : 'ishkinvest';
        const anotherValue = getFieldValue(another);
        setFieldState('investarea', (state) => {
          state.required = anotherValue === '1';
        });
      });
    };
  }

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }

  setBiType = (value) => {
    if (Array.isArray(value)) {
      return value.slice(-1).join();
    }
    return value;
  };

  formatFiles = (result) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.id) {
        return file;
      }
      return {
        extname: file.response.fileExt,
        filename: file.response.fileName,
        filesize: file.response.fileSize,
        fileid: file.response.id,
        description: file.response.description,
        createuser: file.createuser,
        createtime: file.createtime,
        elementname: file.elementname,
      };
    };
    const attachments = (result.attachmentlist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };
  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileid) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  getBiType = (value) => {
    if (value) {
      return [value.substr(0, 4), value.substr(0, 6), value];
    }
    return value;
  };

  formatData(values) {
    return {
      ...values,
      release170: toggleSignType(values.release170),
      release216: toggleSignType(values.release216),
      agencyfile: this.formatFiles(values.agencyfile),
      // releasefile: this.formatFiles(values.releasefile),
      approvalfile: this.formatFiles(values.approvalfile),
      updateNoticeFiles: this.formatFiles(values.updateNoticeFiles),

      fundcontrfiles: this.formatFiles(values.fundcontrfiles),
      trustagmtfiles: this.formatFiles(values.trustagmtfiles),
      recruitinstfiles: this.formatFiles(values.recruitinstfiles),
      saleannofiles: this.formatFiles(values.saleannofiles),
      fundprodgeneralfiles: this.formatFiles(values.fundprodgeneralfiles),
      tipactannofiles: this.formatFiles(values.tipactannofiles),

      sharelist: values.sharelist,
      fundmanagerid: this.joinArray(values.fundmanagerid),
      bitype: this.setBiType(values.bitype),
      investarea: values.investarea?.join(','),
    };
  }

  applyFormatData(values) {
    values.release170 = toggleSignType(values.release170);
    values.release216 = toggleSignType(values.release216);
    values.investarea = values.investarea?.split(',');
    if (this.formData.status && Number(this.formData.status) === 1) {
      return {
        ...values,
      };
    }
    if (!this.formData.status && this.formData.fundid) {
      return {
        ...values,
      };
    }

    if (!this.formData.fundid) {
      // 复制份额
      const sharelist = [];
      if (
        this.formData.sharelist &&
        Array.isArray(this.formData.sharelist) &&
        this.formData.sharelist.length > 0
      ) {
        this.formData.sharelist.map((item) => {
          return sharelist.push({
            ...item,
            fundcode: '',
            fundname: '',
            fundshortname: '',
          });
        });
      }
      return {
        ...values,
        fundname: '',
        fundcode: '',
        fundshortname: '',
        trusteeid: '',
        fundmanagerid: [],
        // investgoal: '',
        // assetallratio: '',
        issuestartdate: '',
        issueenddate: '',
        raisedown: '',
        raiseup: '',
        approvaldate: '',
        docnumber: '',
        sharelist: sharelist,
      };
    }
  }

  auditFormatData(values) {
    values.release170 = toggleSignType(values.release170, 'toArray');
    values.release216 = toggleSignType(values.release216, 'toArray');
    values.investarea = values.investarea?.split(',');
    return { ...values };
  }

  // "10010101"

  // 生成文本
  generativeText() {
    // if (!this.formData.itemlist?.length) {
    //   this.antMessage.warning('未检测到代销关系信息，无法生成');
    //   return;
    // }
    const itemlist = this.formActions.getFieldValue('itemlist') || [];
    this.dispatcher.generateAgencyList({ itemlist, type: 0 }).then((res) => {
      if (fn.checkResponse(res)) {
        if (!res.data) {
          this.antMessage.error('生成失败');
          return;
        }
        this.antModal.info({
          icon: null,
          title: (
            <div>
              代销关系文档生成{' '}
              <Button size="small" type="link" onClick={() => copyText(res.data)}>
                复制文本
              </Button>
            </div>
          ),
          width: 800,
          okText: '关闭',
          content: (
            <Input.TextArea defaultValue={res.data} autoSize={{ minRows: 10, maxRows: 15 }} />
          ),
        });
      }
    });
  }

  // 退回
  async backTo(values, next) {
    const _this = this;

    const allUsers = await _this.orgDispatcher.users();
    const allUserMap = {};

    allUsers.data?.forEach((item) => {
      allUserMap[item.id] = item;
    });
    const options = _this.formData.agencyMember?.split(';')?.reduce((prev, id) => {
      if (!id) {
        return prev;
      }
      prev.push({
        label: allUserMap[id]?.userName,
        value: id,
      });
      return prev;
    }, []);

    _this.antModal.confirm({
      title: null,
      icon: null,
      content: (
        <Space>
          <div>退回人员</div>
          <Select
            allowClear
            mode="multiple"
            placeholder="请选择"
            style={{ width: 200 }}
            onChange={(selectList) => {
              _this.agencyMember = selectList.join(';');
            }}
            options={options}
          />
        </Space>
      ),
      onOk(close) {
        if (!_this.agencyMember) {
          _this.antMessage.warning('请选择退回人员');
          return;
        }
        values.agencyMember = _this.agencyMember;
        close();
        next(true);
      },
      onCancel(close) {
        close();
        next(false);
      },
    });
  }

  applySubmit(values) {
    const result = values;
    console.log('提交前数据1：', values);
    let data = this.formatData(result);
    console.log('提交前数据2：', data);
    return data;
  }

  auditSubmit(values) {
    console.log('提交前数据3：', values);
    const result = values;
    let data = this.formatData(result);
    console.log('提交前数据4：', data);
    return data;
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  submitConfirm(values, next, { actionName }) {
    if (this.pageStatus.firstEditable || this.pageStatus.applyEditable) {
      this.antModal.confirm({
        title: '请确认',
        content: (
          <div style={{ color: 'red' }}>
            <div>请仔细确认您所填写的内容是否正确，如果送审，系统将不支持手工撤单；</div>
            <ul style={{ paddingLeft: '25px' }}>
              <li>如果确认送审 ，请点击“是”，</li>
              <li>否则请点击“否”，重新填写相关内容。</li>
            </ul>
          </div>
        ),
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
    } else {
      if (['40', '41', '42', '43'].includes(this.elementCode)) {
        if (actionName === '退回') {
          ['42'].includes(this.elementCode) && this.backTo(values, next);
        } else {
          if (Array.isArray(values.itemlist) && values.itemlist.length > 0) {
            if (values.itemlist.some((a) => a.msg)) {
              this.antMessage.info('代销机构存在错误信息，请检查');
              next(false);
            } else {
              next(true);
            }
          } else {
            this.antModal.confirm({
              title: '请确认',
              content: <span style={{ color: 'red' }}>检测到未填写代销信息，确认提交？</span>,
              okText: '是',
              cancelText: '否',
              onOk(close) {
                close();
                next(true);
              },
              onCancel(close) {
                close();
                next(false);
              },
            });
          }
        }
      } else if (
        this.elementCode === '160' &&
        values.sharelist?.length !== values.fundprodgeneralfiles?.length
      ) {
        this.antMessage.info(
          '当前表单份额信息数量与基金产品资料概要上传文件数量不一致(概要文件请根据份额数量上传)',
        );
        next(false);
      } else {
        next(true);
      }
    }
  }

  get expressionScope() {
    return {
      changeAgencyTableOnSelect: (keys, rows) => {
        this.changeAgencySelectedkeys = keys;
      },
      changeAgencyTableRemove: () => {
        this.changeAgencySelectedkeys = [];
      },

      renderExtendButtons: () => {
        const [shareCodes, setSharecode] = useState([]);
        return (
          <>
            {['40', '41', '42', '43'].includes(this.elementCode) && (
              <ModalForm
                labelCol={{ span: 4 }}
                wrapperCol={{ span: 18 }}
                title={<div>新增代销关系 </div>}
                initialValues={{
                  agencyattr: '全部',
                }}
                layout="horizontal"
                modalProps={{ maskClosable: false, closable: false, destroyOnClose: true }}
                trigger={
                  <Button type="primary" size="small">
                    新增代销关系
                  </Button>
                }
                onFinish={async (values) => {
                  let result = true;
                  const itemList = this.formActions.getFieldValue('itemlist') || [];
                  let dataList = [];
                  values.funds &&
                    values.funds.some((a) => {
                      if (!result) {
                        return true;
                      }
                      values.agencys &&
                        values.agencys.some((b) => {
                          // 校验关系中 是否存在 互斥
                          let temp = itemList.find(
                            (c) => c.fundid === a.shareid && c.organinfoid === b.organinfoid,
                          );
                          if (temp) {
                            this.antMessage.info(
                              `代销关系不可冲突：关系中已包含【${temp.fundname}】-【${temp.companyname}】-【${temp.changetype}】`,
                            );
                            result = false;
                          }
                          if (!result) {
                            return true;
                          }
                          if (
                            !itemList.find(
                              (c) => c.fundid === a.fundid && c.organinfoid === b.organinfoid,
                            )
                          ) {
                            dataList.push({
                              id: uuid(),
                              organinfoid: b.organinfoid,
                              companytype: b.companytype,
                              companyname: b.companyname,
                              companycode: b.companycode,
                              partysimname: b.partysimname,
                              hotline: b.hotline,
                              website: b.website,
                              fundcode: a.value,
                              fundname: a.name,
                              fundid: a.shareid,
                              sharetype: a.sharetype,
                              mainfundcode: a.mainfundcode,
                              mainfundid: a.fundid,
                              mainfundname: a.mainfundname,
                              changetype: '代销关系建立',
                              agencyattr: values.agencyattr,
                              agencydate: '',
                            });
                          }
                        });
                    });
                  if (!result) {
                    return false;
                  }
                  dataList = [...itemList, ...dataList];

                  // 排序规则：机构类型(指定顺序) --> 机构代码(升序) --> 基金代码(升序)
                  const companytypeOrder = ['银行', '券商', '第三方', '其他'];
                  const sortByFields = (a, b) => {
                    if (a.companytype !== b.companytype) {
                      return (
                        companytypeOrder.indexOf(a.companytype) -
                        companytypeOrder.indexOf(b.companytype)
                      );
                    } else if (a.companycode !== b.companycode) {
                      return a.companycode - b.companycode;
                    }
                    return a.fundcode - b.fundcode;
                  };
                  const sortList = dataList.sort(sortByFields);
                  this.formActions.setFieldValue('itemlist', sortList);
                  return true;
                }}
              >
                <ProFormSelect.SearchSelect
                  name="funds"
                  label="基金"
                  mode="multiple"
                  showSearch={false}
                  fieldProps={{
                    notFoundContent: null,
                    filterOption: () => true,
                    autoClearSearchValue: false,
                  }}
                  rules={[{ required: true, message: '请选择基金' }]}
                  placeholder="请输入基金代码、名称或类型搜索"
                  debounceTime={300}
                  request={async ({ keyWords }) => {
                    const sharelist = this.formActions.getFieldValue('sharelist') || [];
                    const mainfundcode = this.formActions.getFieldValue('fundcode') || '';
                    if (sharelist && Array.isArray(sharelist)) {
                      const data = sharelist
                        .map((a) => ({
                          label: (
                            <span>
                              {a.fundname}[{a.fundcode}]{' '}
                              <b style={{ float: 'right' }}>{a.businesstype}</b>
                            </span>
                          ),
                          value: a.fundcode,
                          name: a.fundname,
                          mainfundcode: mainfundcode,

                          id: uuid(),
                          ...a,
                        }))
                        .filter((a) => a.value);
                      this.prevFundsData = { keyword: keyWords, data: data };
                      return data;
                    }
                    return [];
                  }}
                />
                <ProFormSelect.SearchSelect
                  name="agencys"
                  label="代销机构"
                  showSearch={false}
                  fieldProps={{
                    notFoundContent: null,
                    filterOption: () => true,
                    autoClearSearchValue: false,
                  }}
                  debounceTime={300}
                  mode="multiple"
                  rules={[{ required: true, message: '请选择代销机构' }]}
                  placeholder="请输入代销机构名称或编号搜索"
                  request={async ({ keyWords }) => {
                    if (!keyWords) {
                      return [];
                    }

                    const res = await this.dispatcher.agencyList({
                      keyword: keyWords || '',
                      businesstype: '代销机构',
                      page: 1,
                      size: 100,
                    });
                    if (res.data && Array.isArray(res.data)) {
                      let resData = res.data
                        .filter((a) => a.businesstype === '代销机构')
                        .map((a) => ({
                          label: a.companyname,
                          value: a.organinfoid,
                          ...a,
                        }));
                      this.prevAgencysData = { keyword: keyWords, data: resData };
                      return resData;
                    }
                    return [];
                  }}
                />
                <ProFormSelect
                  name="agencyattr"
                  label="代销属性"
                  rules={[{ required: true, message: '请选择代销属性' }]}
                  placeholder="请选择代销属性"
                  request={async () => {
                    const res = await this.dispatcher.dictList({
                      dictids: '4767de5ffc244840971c6403a14e85d0',
                    });
                    if (
                      res.data &&
                      Array.isArray(res.data) &&
                      res.data.length > 0 &&
                      Array.isArray(res.data[0].children)
                    ) {
                      return res.data[0].children.map((a) => ({ ...a, ...{ label: a.name } }));
                    }
                    return [];
                  }}
                />
              </ModalForm>
            )}

            {(() => {
              const [visible, setVisible] = useState(false);
              if (['40', '41', '42', '43'].includes(this.elementCode)) {
                return (
                  <ModalForm
                    labelCol={{ span: 10 }}
                    wrapperCol={{ span: 14 }}
                    title="设置代销时间"
                    visible={visible}
                    layout="horizontal"
                    modalProps={{ maskClosable: false, closable: false, width: 420 }}
                    onVisibleChange={(visible) => !visible && setVisible(false)}
                    trigger={
                      <Button
                        type="primary"
                        size="small"
                        onClick={() => {
                          if ((this.changeAgencySelectedkeys || []).length < 1) {
                            this.antMessage.info('请先选择要设置的行');
                            return;
                          }
                          setVisible(true);
                        }}
                      >
                        设置代销时间
                      </Button>
                    }
                    onFinish={async (values) => {
                      const itemList = this.formActions.getFieldValue('itemlist') || [];
                      itemList.forEach((a, i) => {
                        if ((this.changeAgencySelectedkeys || []).includes(i)) {
                          this.formActions.setFieldValue(
                            `itemlist.${i}.agencydate`,
                            values.agencydate,
                          );
                        }
                      });
                      return true;
                    }}
                  >
                    <ProFormDatePicker
                      name="agencydate"
                      label="代销上线/下线日期"
                      style={{ width: 300 }}
                      rules={[{ required: true, message: '请选择日期' }]}
                      placeholder="请选择日期"
                    />
                  </ModalForm>
                );
              }
            })()}

            {['40', '41', '42', '43'].includes(this.elementCode) && (
              <Upload
                accept=".xls,.xlsx"
                multiple={true}
                messageShowType={MessageShowType.None}
                uploadFunc={importAgency}
                beforeUpload={() => {
                  const { getFieldValue } = this.formActions;
                  const sharelist = getFieldValue('sharelist') || [];
                  const newFundcode = [];
                  sharelist.map((item) => {
                    return newFundcode.push(item.fundcode);
                  });
                  setSharecode(newFundcode);
                }}
                data={{ fundcode: shareCodes.join(';') }}
                onSuccess={({ fileList, file }) => {
                  const { getFieldValue, setFieldValue } = this.formActions;
                  if (file && file.status === 'done') {
                    let exportItemList = getFieldValue('itemlist') || [];
                    let newExportItemList = [];
                    file.response.forEach((item) => {
                      const tmp = (exportItemList || []).find(
                        (b) => b.organinfoid === item.organinfoid,
                      );
                      // organinfoid 通过机构id进行过滤
                      if (!tmp) {
                        newExportItemList.push({
                          id: uuid(),
                          organinfoid: item.organinfoid,
                          companytype: item.companytype,
                          companyname: item.companyname,
                          companycode: item.companycode,
                          partysimname: item.partysimname,
                          hotline: item.hotline,
                          website: item.website,
                          fundcode: item.fundcode,
                          fundname: item.fundname,
                          fundid: item.fundid,
                          sharetype: item.sharetype,
                          mainfundcode: item.mainfundcode,
                          mainfundid: item.mainfundid,
                          mainfundname: item.mainfundname,
                          agencyattr: item.agencyattr,
                          agencydate: item.agencydate,
                          changetype: '代销关系建立',
                          msg: item.msg,
                        });
                      } else {
                        tmp.companytype = item.companytype;
                        tmp.companyname = item.companyname;
                        tmp.companycode = item.companycode;
                        tmp.partysimname = item.partysimname;
                        tmp.hotline = item.hotline;
                        tmp.website = item.website;
                        tmp.fundcode = item.fundcode;
                        tmp.fundname = item.fundname;
                        tmp.fundid = item.fundid;
                        tmp.sharetype = item.sharetype;
                        tmp.mainfundcode = item.mainfundcode;
                        tmp.mainfundid = item.mainfundid;
                        tmp.mainfundname = item.mainfundname;
                        tmp.agencyattr = item.agencyattr;
                        tmp.agencydate = item.agencydate;
                        tmp.changetype = '代销关系建立';
                        tmp.msg = item.msg;
                      }
                    });
                    newExportItemList = [...exportItemList, ...newExportItemList];
                    setFieldValue('itemlist', newExportItemList);
                  } else {
                    this.antMessage.loading('解析出错了~', 3);
                  }
                }}
                showUploadList={false}
                isFsfund={true}
              >
                <Button type="primary" size="small">
                  批量导入代销机构
                </Button>
              </Upload>
            )}

            {['42', '43'].includes(this.elementCode) && (
              <Button
                type="primary"
                size="small"
                onClick={() => {
                  const itemList = this.formActions.getFieldValue('itemlist') || [];
                  this.dispatcher.generateAgencyList({
                    itemlist: itemList,
                    type: 1,
                    filename: '代销机构清单.xls',
                  });
                }}
              >
                生成列表信息及基本信息
              </Button>
            )}

            {['42', '43', '160'].includes(this.elementCode) && !isMobile() && (
              <Button
                type="primary"
                size="small"
                onClick={() => {
                  this.generativeText();
                }}
              >
                生成文本
              </Button>
            )}

            {['40', '41', '42', '43'].includes(this.elementCode) && (
              <Download
                fileName="批量导入代销机构模板.xlsx"
                url={`${baseURL}/template/dossier/changeAgecyUploadMode.xlsx`}
              >
                <Button type="link">下载模板</Button>
              </Download>
            )}
          </>
        );
      },

      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },

      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },

      linkAntiMoney: async () => {
        const { fundcode: fundCode, fundshortname: fundName, antiMoneyEvalInfo } = this.formData;
        const antimoneyActiveRow = { fundCode, fundName, evalDate: moment().format('YYYY-MM-DD') };

        const stage = antiMoneyCodeMap[this.elementCode];
        const [err] = await queryNewByFundCode({ fundCode, stage });
        if (err?.message) {
          return;
        }

        this.dispatcher.updateState({
          antimoneyActiveRow: { ...antimoneyActiveRow, ...antiMoneyEvalInfo },
        });
        let path = '#/app/pdt/doc/antimoney/score?type=new';
        if (stage === '初评' && isEmpty(antiMoneyEvalInfo)) {
          path += '&fetchRuleTree=true';
        }
        window.open(path, '_blank');
      },
    };
  }
}
