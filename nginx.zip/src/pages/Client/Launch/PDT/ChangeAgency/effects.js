import React, { useState } from 'react';
import { FormEffectHooks, FormPath } from 'formily-antd';
import { uuid } from '@/utils';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
import { Button, Table, Typography, message } from 'antd';
import { ProFormDatePicker, ProFormSelect, ModalForm } from '@ant-design/pro-form';
import Upload, { MessageShowType } from '@chinahorm/web-components/es/components/Upload';
import { importAgency } from '@/common/axios/pdtSystem';
import Download from '@chinahorm/web-components/es/components/Download';
import { baseURL } from '@/setting';
import _lodsh from 'lodash';
import moment from 'moment';
import { toggleSignType, agencyNoticetypeid } from '../../utils';
import { fn } from '@cerdo/cerdo-utils/es';
import { checkAgecyAttr, agencyExport, listNoticeMatch } from '@/common/axios';

const { onFieldValueChange$, onFieldInputChange$, onFieldInit$, onFieldMount$ } = FormEffectHooks;

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag, readOnlyFlag, processId } = getProcess() || {};

    this.processId = processId;
    this.managerid = null;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
    // this.length = null;
    this.itemCount = 0;
    this.auditcountersignusers = [];
    // this.prevTname = '';
  }

  createFormEffects() {
    return ($, { setFieldState, setFieldValue, getFieldValue }) => {
      if (this.firstTokenFlag) {
        onFieldInit$('*(generatebtn)').subscribe(() => {
          setFieldState('generatebtn', (state) => {
            state.visible =
              !this.readOnlyFlag &&
              (getFieldValue('itemlist') || []).filter((a) => a.changetype === '代销关系建立')
                .length > 0;
          });
        });

        onFieldValueChange$('itemlist').subscribe(({ value }) => {
          const length = value && Array.isArray(value) && value.length;
          setFieldState('iteminfo', (s) => {
            s.props['x-component-props'].title = (
              <div>
                代销关系信息 <small>(共{length}条代销关系)</small>
              </div>
            );
          });
          if ((value || []).find((a) => a.changetype === '代销关系建立')) {
            setFieldState('generatebtn', (state) => {
              state.visible = true;
            });
            setFieldState('attachmentlist', (state) => {
              state.required = true;
            });

            const attachmentlist = this.formActions.getFieldValue('attachmentlist') || [];
            if (
              attachmentlist.length > 0 &&
              Number(this.firstTokenFlag) === 1 &&
              !this.readOnlyFlag &&
              this.itemCount !== length
            ) {
              setFieldState('attachmentlist', (state) => {
                state.description = (
                  <span style={{ color: 'orange' }}>
                    检测到代销关系信息发生变化，请注意生成的公告文件是否需要重新生成或删除
                  </span>
                );
              });
            }
          } else {
            setFieldState('generatebtn', (state) => {
              state.visible = false;
            });
            setFieldState('attachmentlist', (state) => {
              state.required = false;
            });
          }
          this.itemCount = length;
        });
      }
      onFieldMount$('itemlist').subscribe(({ name }) => {
        const itemList = this.formData.itemlist || [];
        if (itemList.length > 0) {
          setFieldValue(name, itemList);
        }
        this.itemCount = itemList.length;
        setFieldState('iteminfo', (s) => {
          s.props['x-component-props'].title = (
            <div>
              代销关系信息 <small>(共{this.itemCount}条代销关系)</small>
            </div>
          );
        });
      });

      // 公告生成类型为代销上线产品通知，显示公告发布
      onFieldInit$('tname').subscribe((field) => {
        if (Number(this.elementCode) >= 80) {
          setFieldState('noticesCard', (state) => {
            state.visible = true;
          });
        }
      });

      // 公告发布中，去发布按钮是否显示
      onFieldInit$('notices.*.action').subscribe((field) => {
        const { segments } = FormPath.parse(field.name);
        const [fieldName, idx] = segments;
        const { issync } = getFieldValue(fieldName)[idx] || {};
        setFieldState(`${fieldName}.${idx}.action`, (state) => {
          state.visible = issync === '0';
          state.editable = issync === '0';
        });
      });

      // 去发布，点击打开弹框
      onFieldValueChange$('notices.*.action').subscribe(async (field) => {
        const { segments } = FormPath.parse(field.name);
        const [fieldName, idx] = segments;
        const { noticeid, publishdate } = getFieldValue(fieldName)[idx] || {};

        const res = await listNoticeMatch({ size: 1000 });
        const noticetypeOptions = res.data?.map(({ noticetypename, noticetypeid, ...rest }) => ({
          ...rest,
          dictLabel: noticetypename,
          dictValue: noticetypeid,
          label: noticetypename,
          value: noticetypeid,
        }));

        const tname = getFieldValue('tname');
        setFieldState('formModal', (state) => {
          state.props['x-component-props'] = {
            visible: true,
            noticeid,
            setFieldState,
            noticetypeOptions,
            noticetypeid: agencyNoticetypeid[tname],
            fundcode: this.formData.itemlist.map((e) => e.fundcode)?.join(),
            publishdate: moment(publishdate).format('YYYY-MM-DD'),
          };
        });
      });

      onFieldValueChange$(
        '*(agencylist.*.companyname,agencylist.*.companytype,agencylist.*.partysimname,agencylist.*.hotline,agencylist.*.website.*.companycode)',
      ).subscribe(({ name }) => {
        const arr = (name || '').split('.');
        if (name.length > 2) {
          const agencyList = getFieldValue('agencylist') || [];
          const itemList = getFieldValue('itemlist') || [];
          const agency = agencyList[Number(arr[1])];
          if (agency && itemList.find((a) => a.organinfoid === agency.organinfoid)) {
            setFieldValue(
              'itemlist',
              itemList.map((a) => {
                if (a.organinfoid === agency.organinfoid) {
                  a[arr[2]] = agency[arr[2]];
                }
                return a;
              }),
            );
          }
        }
      });

      onFieldValueChange$('itemlist~.*.agencydate').subscribe(({ value }) => {
        const itemList = getFieldValue('itemlist') || [];
        if (value && itemList.find((a) => a.agencydate && a.agencydate !== value)) {
          this.antMessage.info('【代销上线/下线日期】不一致');
        }
      });

      // 把合规会签人员 缓存下来
      onFieldInputChange$('agency50.auditcountersignusers').subscribe(({ value }) => {
        this.auditcountersignusers = value;
      });

      onFieldInputChange$('tname').subscribe(({ value }) => {
        // if (this.prevTname === '代销上线产品通知') {
        //   setFieldValue('agency50.auditcountersignusers', [...this.auditcountersignusers]);
        // }
        // if (value === '代销上线产品通知') {
        //   setFieldValue('agency50.auditcountersignusers', []);
        // }
        // setFieldState("itemlist~.*.agencytype", s => s.visible = value === '股票换购')
        setFieldState('itemlist', (s) => {
          s.props['x-component-props'].visibleColumns = [
            { name: 'agencytype', visible: value === '股票换购' },
          ];
        });
        // this.prevTname = value;
      });
    };
  }

  formatFiles = (result) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileid) {
        return file;
      }
      return file.response;
    };
    const attachmentlist = (result.attachmentlist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachmentlist;
  };

  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }

  initValues = (values) => ({
    ...values,
    agency50: toggleSignType(values.agency50),
  });
  auditFormatData(values) {
    return this.initValues(values);
  }
  applyFormatData(values) {
    return this.initValues(values);
  }

  formatData(values) {
    return {
      ...values,
      agency50: toggleSignType(values.agency50),
      attachmentlist: this.formatFiles(values),
    };
  }

  applySubmit(values) {
    const result = values;
    if (
      (result.agency50.countersigndeparts || []).length === 0 &&
      (result.agency50.countersignusers || []).length === 0
    ) {
      this.antMessage.warning('会签部门、会签人必须选填其中一项');
      return false;
    }
    if ((result.itemlist || []).length < 1) {
      this.antMessage.warning('代销关系信息不能为空');
      return false;
    }

    // console.log('提交前数据：', values);
    let data = this.formatData(result);
    // console.log('提交后数据：', data);
    return data;
  }

  auditSubmit(values) {
    // console.log('提交前数据：', values);
    let data = {
      ...values,
      agency50: toggleSignType(values.agency50),
    };

    if ((data.itemlist || []).length < 1) {
      this.antMessage.warning('代销关系信息不能为空，请刷新页面重试');
      return false;
    }

    return data;
  }

  daftSubmit(values) {
    return this.formatData(values);
  }

  /**
   * 提交前置提示
   * @param values
   * @param next
   * @returns {boolean}
   */
  submitConfirm(values, next) {
    if (this.pageStatus.firstEditable || this.pageStatus.applyEditable) {
      // 校验代销关系属性
      let itemList = this.formActions.getFieldValue('itemlist') || [];
      const tname = this.formActions.getFieldValue('tname');
      const agencyList = this.formActions.getFieldValue('agencylist') || [];
      checkAgecyAttr({
        tname: tname,
        itemlist: itemList,
        agencylist: agencyList,
      }).then((result) => {
        if (fn.checkResponse(result)) {
          if (Array.isArray(result.data)) {
            this.antModal.confirm({
              title: '请确认',
              width: 800,
              okText: '是',
              cancelText: '否',
              content:
                result.data.length > 0 ? (
                  <>
                    <Typography.Text type="danger">
                      以下代销关系已存在，仅代销属性发生变更
                    </Typography.Text>
                    <Table
                      size="small"
                      pagination={false}
                      scroll={{ y: 500 }}
                      columns={[
                        { dataIndex: 'fundcode', title: '基金代码' },
                        { dataIndex: 'fundname', title: '基金名称' },
                        { dataIndex: 'companycode', title: '机构代码' },
                        { dataIndex: 'companyname', title: '机构名称' },
                        { dataIndex: 'oriattr', title: '原代销属性' },
                        {
                          dataIndex: 'agencyattr',
                          title: '修改后',
                          render(_, record) {
                            return record.agencyattr === '全部' ? (
                              <span style={{ color: 'red' }}>{record.agencyattr}</span>
                            ) : (
                              <span>
                                {record.oriattr}、
                                <span style={{ color: 'red' }}>{record.agencyattr}</span>
                              </span>
                            );
                          },
                        },
                      ]}
                      dataSource={result.data || []}
                    />
                  </>
                ) : (
                  <div style={{ color: 'red' }}>
                    <div>1. 请仔细确认您所填写的内容是否正确，如果送审，系统将不支持手工撤单；</div>
                    <ul style={{ paddingLeft: '25px' }}>
                      <li>如果确认送审，请点击“是”，</li>
                      <li>否则请点击“否”，重新填写相关内容。</li>
                    </ul>
                  </div>
                ),
              onOk(close) {
                close();
                next(true);
              },
              onCancel(close) {
                close();
                next(false);
              },
            });
          } else {
            next(true);
          }
        } else {
          next(false);
        }
      });
    } else {
      const hasNoPublish = values.notices.some((e) => e.issync === '0');
      if (['80'].includes(this.elementCode) && hasNoPublish) {
        this.antModal.confirm({
          title: '请确认',
          content: <span style={{ color: 'red' }}>有公告未发布，请确认是否继续提交落实？</span>,
          okText: '确认提交',
          cancelText: '取消',
          onOk(close) {
            close();
            next(true);
          },
          onCancel(close) {
            close();
            next(false);
          },
        });
      } else {
        next(true);
      }
    }
  }

  get expressionScope() {
    return {
      changeAgencyTableOnSelect: (keys) => {
        this.changeAgencySelectedkeys = keys;
      },
      changeAgencyTableRemove: () => {
        this.changeAgencySelectedkeys = [];
      },
      renderRemove: (idx) => {
        const mutators = this.formActions.createMutators('agencylist');
        return (
          <Button
            type="link"
            style={{ color: 'red' }}
            onClick={() => {
              const agencyList = this.formActions.getFieldValue('agencylist') || [];
              const itemList = this.formActions.getFieldValue('itemlist') || [];
              const agency = agencyList.length > idx ? agencyList[idx] : null;
              if (agency && itemList.find((a) => a.organinfoid === agency.organinfoid)) {
                this.antMessage.info('不可删除，【代销关系信息】中已包含该代销机构');
                return;
              }
              mutators.remove(idx);
              this.antMessage.success('删除成功', 0.5, () => {
                agencyList.length <= 1 &&
                  this.formActions.setFieldState('agencyinfo', (state) => {
                    state.visible = false;
                  });
              });
            }}
          >
            删除
          </Button>
        );
      },
      upDownAgencyInfo: () => {
        const visible = this.formActions.getFieldState('agencyinfo', (state) => state.visible);
        this.formActions.setFieldState('*(agencyinfo,iteminfo)', (state) => {
          state.visible = !visible;
        });
        this.formActions.setFieldState('updownbtn', (state) => {
          state.props['x-component-props'] = {
            ...state.props['x-component-props'],
            text: visible ? '显示代销信息' : '隐藏代销信息',
          };
        });
      },
      generateNotice: async () => {
        let itemList = this.formActions.getFieldValue('itemlist') || [];
        const tname = this.formActions.getFieldValue('tname');
        const agencyList = this.formActions.getFieldValue('agencylist') || [];
        itemList = itemList.filter((a) => a.changetype === '代销关系建立');
        if (itemList.find((item) => item.msg)) {
          message.warning('导入代销错误信息，请及时处理');
        } else {
          if (!tname) {
            this.antMessage.info('请先选择公告生成类型');
            return;
          }
          if (itemList.length < 1) {
            this.antMessage.info('【代销关系信息】中未包含【代销关系建立】类型，无需生成公告');
            return;
          }
          if (tname === '股票换购' && itemList.find((a) => !a.agencytype)) {
            this.antMessage.info('公告类型为【股票换构】，【代理类型】必填');
            return;
          }
          if (itemList.find((a) => !a.agencydate)) {
            this.antMessage.info('【代销上线/下线日期】必填');
            return;
          }
          if (itemList.find((a) => a.agencydate !== itemList[0].agencydate)) {
            this.antMessage.info('【代销上线/下线日期】不一致');
            return;
          }
          if (
            itemList.find((a) => a.organinfoid !== itemList[0].organinfoid) &&
            itemList.find((a) => a.mainfundcode !== itemList[0].mainfundcode)
          ) {
            this.antMessage.info('代销关系不可同时存在多个代销机构和多个基金');
            return;
          }
          this.antMessage.loading('公告文件生成中...', 0);
          const res = await this.dispatcher.genAgencyNotice({
            tname: tname,
            itemlist: itemList,
            agencylist: agencyList,
          });
          this.antMessage.destroy();
          if (res && res.data) {
            this.antMessage.success('生成成功');
            this.formActions.setFieldState('attachmentlist', (state) => {
              state.description = '';
              state.value = [{ ...res.data.file, response: {} }];
            });
            this.formActions.setFieldState('itemlist', (state) => {
              state.value = res.data.itemlist;
            });
            this.formActions.setFieldState('attachmentlist', (state) => {
              state.description = '';
            });
          } else {
            this.antMessage.info(res.msg || '公告文件生成失败！');
          }
        }
      },
      publishNotice: async () => {
        const attachmentList = this.formData.attachmentlist || [];
        const itemList = this.formData.itemlist || [];
        if (attachmentList.length < 1) {
          this.antMessage.info('公告文件不存在，无需发布');
          return;
        }
        this.antMessage.loading('公告生成中...', 0);
        const res = await this.dispatcher.pubAgencyNotice({
          fileid: attachmentList[0].fileid,
          mainfundcodes: _lodsh.uniq(itemList.map((a) => a.mainfundcode)).join(','),
        });
        this.antMessage.destroy();
        if (res && res.data) {
          // let url = '';
          // const hostname = window.location.hostname || '';
          // if (hostname.includes('localhost') || hostname.includes('172.30')) {
          //   url = '172.30.81.91/pdt/';
          // }
          // if (hostname.includes('apptest')) {
          //   url = 'apptest.fsfund.com:7171/pdt/';
          // }
          // if (hostname.includes('fsapi') || hostname.includes('research')) {
          //   url = 'research.fsfund.com/web/pdt/';
          // }
          this.antMessage.success('公告生成成功，即将跳转发布页面', 2, () => {
            // window.open(`//${url}#/app/pdt/notice/list?eid=${res.data}`);
            window.open(`#/app/pdt/notice/list?eid=${res.data}`);
          });
        } else {
          this.antMessage.info(res.msg || '公告生成失败');
        }
      },
      fileSuccess: (name) => {
        // const dispatcher = store.useModelDispatchers('pdtSystem');
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response?.fileid || file.response?.fileId || '', ...file },
                ...currentFileList,
              ];
              // 只支持 一个公告文件
              newFileList = newFileList.slice(0, 1);
              state.value = newFileList;
              state.description = '';
            });
            // this.antMessage.loading('文件解析中...')
            // dispatcher
            //   .changeImportFile({
            //     filename: file.response.filename,
            //     fileid: file.response.fileid,
            //   })
            //   .then((result) => {
            //     // console.log(result, "...批量导入文件返回数据")
            //     console.log(11111, '....111');
            //   });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
      renderExtendButtons: () => {
        const itemList = this.formActions.getFieldValue('itemlist') || [];
        return (
          <>
            <ModalForm
              labelCol={{ span: 4 }}
              wrapperCol={{ span: 18 }}
              title={
                <div>
                  新增代销关系{' '}
                  <span style={{ color: 'red', fontSize: 14 }}>
                    本栏目操作为代销机构上线公募基金产品，或单只公募基金产品在多家代销机构上线
                  </span>
                </div>
              }
              layout="horizontal"
              modalProps={{ maskClosable: false, closable: false, destroyOnClose: true }}
              trigger={
                <Button type="primary" size="small">
                  新增代销关系
                </Button>
              }
              initialValues={{
                agencyattr: '全部',
              }}
              onFinish={async (values) => {
                let result = true;
                const itemList = this.formActions.getFieldValue('itemlist') || [];
                // const agencyList = this.formActions.getFieldValue('agencylist') || [];
                let dataList = [];
                values.funds &&
                  values.funds.some((a) => {
                    if (!result) {
                      return true;
                    }
                    values.agencys &&
                      values.agencys.some((b) => {
                        // 校验关系中 是否存在 互斥
                        let temp = itemList.find(
                          (c) =>
                            c.fundid === a.fundid &&
                            c.organinfoid === b.organinfoid &&
                            c.changetype !== values.changetype,
                        );
                        if (temp) {
                          this.antMessage.info(
                            `代销关系不可冲突：关系中已包含【${temp.fundname}】-【${temp.companyname}】-【${temp.changetype}】`,
                          );
                          result = false;
                        }

                        temp = [...itemList, ...dataList].find(
                          (c) =>
                            c.mainfundcode !== a.mainfundcode && c.organinfoid !== b.organinfoid,
                        );
                        if (temp) {
                          this.antMessage.info(`不可设置多个基金对多个代销机构关系`);
                          result = false;
                        }

                        // 新增的代销机构 不能添加解除关系
                        // temp = agencyList.find(c => c.organinfoid === b.organinfoid);
                        // if (values.changetype === '代销关系解除' && temp) {
                        //   this.antMessage.info(`新增的代销机构【${b.companyname}】，不可解除关系`);
                        //   result = false;
                        // }

                        if (!result) {
                          return true;
                        }
                        if (
                          !itemList.find(
                            (c) => c.fundid === a.fundid && c.organinfoid === b.organinfoid,
                          )
                        ) {
                          dataList.push({
                            id: uuid(),
                            organinfoid: b.organinfoid,
                            companytype: b.companytype,
                            companyname: b.companyname,
                            companycode: b.companycode,
                            partysimname: b.partysimname,
                            hotline: b.hotline,
                            website: b.website,
                            fundcode: a.value,
                            fundname: a.name,
                            fundid: a.fundid,
                            sharetype: a.sharetype,
                            mainfundcode: a.mainfundcode,
                            mainfundid: a.mainfundid,
                            mainfundname: a.mainfundname,
                            changetype: '代销关系建立', // values.changetype,
                            agencyattr: values.agencyattr,
                            agencydate: null,
                          });
                        }
                        return false;
                      });
                    return false;
                  });
                if (!result) {
                  return false;
                }
                dataList = [...itemList, ...dataList];
                const sortList = _lodsh.sortBy(dataList, (item) => item.companycode);
                this.formActions.setFieldValue('itemlist', sortList);
                return true;
              }}
            >
              <ProFormSelect.SearchSelect
                name="funds"
                label="基金"
                mode="multiple"
                showSearch={false}
                fieldProps={{
                  notFoundContent: null,
                  filterOption: () => true,
                  autoClearSearchValue: false,
                }}
                rules={[{ required: true, message: '请选择基金' }]}
                placeholder="请输入基金代码、名称或类型搜索"
                debounceTime={300}
                request={async ({ keyWords }) => {
                  if (!keyWords) {
                    return null;
                  }
                  if (this.prevFundsData && this.prevFundsData.keyword === keyWords) {
                    return this.prevFundsData.data;
                  }

                  const res = await this.dispatcher.bpmShareList({
                    keyword: keyWords,
                    page: 1,
                    size: 100,
                    excludeperiod: '清盘期',
                  });
                  if (res.data && Array.isArray(res.data)) {
                    const data = res.data
                      .map((a) => ({
                        label: (
                          <span>
                            {a.fundname}[{a.fundcode}]{' '}
                            <b style={{ float: 'right' }}>{a.businesstype}</b>
                          </span>
                        ),
                        value: a.fundcode,
                        name: a.fundname,
                        ...a,
                      }))
                      .filter((a) => a.value);
                    this.prevFundsData = { keyword: keyWords, data: data };
                    return data;
                  }
                  return [];
                }}
              />
              <ProFormSelect.SearchSelect
                name="agencys"
                label="代销机构"
                showSearch={false}
                fieldProps={{
                  notFoundContent: null,
                  filterOption: () => true,
                  autoClearSearchValue: false,
                }}
                debounceTime={300}
                mode="multiple"
                rules={[{ required: true, message: '请选择代销机构' }]}
                placeholder="请输入代销机构名称或编号搜索"
                request={async ({ keyWords }) => {
                  const newAgencyList = this.formActions.getFieldValue('agencylist') || [];
                  if (!keyWords) {
                    return [
                      ...newAgencyList
                        .filter((a) => a.companyname && a.partysimname)
                        .map((a) => ({
                          label: (
                            <span>
                              {a.companyname}{' '}
                              <b style={{ float: 'right', color: 'red', fontSize: 12 }}>新</b>
                            </span>
                          ),
                          value: a.organinfoid,
                          ...a,
                        })),
                    ];
                  }

                  if (this.prevAgencysData && this.prevAgencysData.keyword === keyWords) {
                    return this.prevAgencysData.data;
                  }

                  const res = await this.dispatcher.agencyList({
                    keyword: keyWords || '',
                    businesstype: '代销机构',
                    page: 1,
                    size: 100,
                  });
                  if (res.data && Array.isArray(res.data)) {
                    let resData = res.data
                      .filter((a) => a.businesstype === '代销机构')
                      .map((a) => ({
                        label: a.companyname,
                        value: a.organinfoid,
                        ...a,
                      }));
                    resData = [
                      ...newAgencyList
                        .filter((a) => a.companyname && a.partysimname)
                        .map((a) => ({
                          label: (
                            <span>
                              {a.companyname}{' '}
                              <b style={{ float: 'right', color: 'red', fontSize: 12 }}>新</b>
                            </span>
                          ),
                          value: a.organinfoid,
                          ...a,
                        })),
                      ...resData,
                    ];
                    this.prevAgencysData = { keyword: keyWords, data: resData };
                    return resData;
                  }
                  return [];
                }}
              />
              <ProFormSelect
                name="agencyattr"
                label="代销属性"
                rules={[{ required: true, message: '请选择代销属性' }]}
                placeholder="请选择代销属性"
                request={async () => {
                  const res = await this.dispatcher.dictList({
                    dictids: '4767de5ffc244840971c6403a14e85d0',
                  });
                  if (
                    res.data &&
                    Array.isArray(res.data) &&
                    res.data.length > 0 &&
                    Array.isArray(res.data[0].children)
                  ) {
                    return res.data[0].children.map((a) => ({ ...a, ...{ label: a.name } }));
                  }
                  return [];
                }}
              />
              {/* <ProFormSelect
                name="changetype"
                label="变更类型"
                disabled
                rules={[{ required: true, message: '请选择变更类型' }]}
                placeholder="请选择变更类型"
                request={async () => {
                  const res = await this.dispatcher.dictList({ dictids: '91357a44a41d4b17bb7f2e0b5eec8d34' });
                  if (res.data && Array.isArray(res.data) && res.data.length > 0 && Array.isArray(res.data[0].children)) {
                    return res.data[0].children.map(a => ({ ...a, ...{ label: a.name } }));
                  }
                  return [];
                }}
              /> */}
            </ModalForm>

            {(() => {
              const [visible, setVisible] = useState(false);
              return (
                <ModalForm
                  labelCol={{ span: 10 }}
                  wrapperCol={{ span: 14 }}
                  title="设置代销时间"
                  visible={visible}
                  layout="horizontal"
                  modalProps={{ maskClosable: false, closable: false, width: 420 }}
                  onVisibleChange={(visible) => !visible && setVisible(false)}
                  trigger={
                    <Button
                      type="primary"
                      size="small"
                      onClick={() => {
                        if ((this.changeAgencySelectedkeys || []).length < 1) {
                          this.antMessage.info('请先选择要设置的行');
                          return;
                        }
                        setVisible(true);
                      }}
                    >
                      设置代销时间
                    </Button>
                  }
                  onFinish={async (values) => {
                    const itemList = this.formActions.getFieldValue('itemlist') || [];
                    itemList.forEach((a, i) => {
                      if ((this.changeAgencySelectedkeys || []).includes(i)) {
                        this.formActions.setFieldValue(
                          `itemlist.${i}.agencydate`,
                          values.agencydate,
                        );
                      }
                    });
                    return true;
                  }}
                >
                  <ProFormDatePicker
                    name="agencydate"
                    label="代销上线/下线日期"
                    style={{ width: 300 }}
                    rules={[{ required: true, message: '请选择日期' }]}
                    placeholder="请选择日期"
                  />
                </ModalForm>
              );
            })()}

            <Button
              type="primary"
              size="small"
              onClick={() => {
                this.formActions.setFieldState('agencyinfo', (state) => {
                  state.visible = true;
                });
                this.formActions.setFieldValue('agencylist', [
                  ...(this.formActions.getFieldValue('agencylist') || []),
                  { organinfoid: uuid() },
                ]);
              }}
            >
              新增代销机构
            </Button>

            <Upload
              accept=".xls,.xlsx"
              multiple={true}
              messageShowType={MessageShowType.None}
              uploadFunc={importAgency}
              onSuccess={({ file }) => {
                const { getFieldValue, setFieldValue } = this.formActions;
                if (file && file.status === 'done') {
                  let exportItemList = getFieldValue('itemlist') || [];
                  let newExportItemList = [];
                  file.response.forEach((item) => {
                    const tmp = (exportItemList || []).find(
                      (b) => b.organinfoid === item.organinfoid,
                    );
                    if (!tmp) {
                      newExportItemList.push({
                        id: uuid(),
                        organinfoid: item.organinfoid,
                        companytype: item.companytype,
                        companyname: item.companyname,
                        companycode: item.companycode,
                        partysimname: item.partysimname,
                        hotline: item.hotline,
                        website: item.website,
                        fundcode: item.fundcode,
                        fundname: item.fundname,
                        fundid: item.fundid,
                        sharetype: item.sharetype,
                        mainfundcode: item.mainfundcode,
                        mainfundid: item.mainfundid,
                        mainfundname: item.mainfundname,
                        agencyattr: item.agencyattr,
                        agencydate: item.agencydate,
                        changetype: '代销关系建立',
                        msg: item.msg,
                      });
                    } else {
                      tmp.companytype = item.companytype;
                      tmp.companyname = item.companyname;
                      tmp.companycode = item.companycode;
                      tmp.partysimname = item.partysimname;
                      tmp.hotline = item.hotline;
                      tmp.website = item.website;
                      tmp.fundcode = item.fundcode;
                      tmp.fundname = item.fundname;
                      tmp.fundid = item.fundid;
                      tmp.sharetype = item.sharetype;
                      tmp.mainfundcode = item.mainfundcode;
                      tmp.mainfundid = item.mainfundid;
                      tmp.mainfundname = item.mainfundname;
                      tmp.agencyattr = item.agencyattr;
                      tmp.agencydate = item.agencydate;
                      tmp.changetype = '代销关系建立';
                      tmp.msg = item.msg;
                    }
                  });
                  newExportItemList = [...exportItemList, ...newExportItemList];
                  setFieldValue('itemlist', newExportItemList);
                } else {
                  this.antMessage.loading('解析出错了~', 3);
                }
              }}
              showUploadList={false}
              isFsfund={true}
            >
              <Button type="primary" size="small">
                批量导入代销机构
              </Button>
            </Upload>
            <Download
              fileName="批量导入代销机构模板.xlsx"
              url={`${baseURL}/template/dossier/changeAgecyUploadMode.xlsx`}
            >
              <Button type="link">下载模板</Button>
            </Download>

            <Button
              type="link"
              disabled={!itemList.length}
              onClick={() => {
                agencyExport({
                  itemlist: this.formActions.getFieldValue('itemlist'),
                  filename: '代销机构信息.xls',
                });
              }}
            >
              列表导出
            </Button>
          </>
        );
      },
    };
  }
}
