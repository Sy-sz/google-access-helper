// 代销机构变更流程
// 代销机构上线及公告

import React from 'react';
import Form from './form';
import Effects from './effects';
import BaseForm from '@chinahorm/web-components/es/components/BaseForm';
import NoticeModal from '@/pages/Client/Launch/components/noticeModal';
import ButtonField from '@/pages/Client/Launch/components/buttonField';

function Index(props) {
  const formEffects = new Effects(props);
  return (
    <BaseForm formEffects={formEffects} {...props} components={{ NoticeModal, ButtonField }}>
      <Form audit={formEffects.audit} formEffects={formEffects} {...props} />
    </BaseForm>
  );
}

export default Index;
