import React from 'react';
import { Field } from 'formily-antd';
import { FormMegaLayout } from '@formily/antd-components';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { Button } from 'antd';
import {
  useMegaLayoutProps,
  useDictList,
  useTreeSelect,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import { dictv1Listchild } from '@/common/axios';
import { D } from '@/utils';
import { renderSign } from '../../utils';

const issyncEnum = [
  { label: '未发布', value: '0' },
  { label: '已发布', value: '1' },
  { label: '已发布', value: '2' },
];

function Form(props) {
  const {
    context: { formData, getProcess },
    formEffects: { formActions, length },
  } = props;
  console.log(length, '...lentg');
  // console.log(length,'...length')
  const { elementCode, readOnlyFlag, firstTokenFlag } = getProcess() || {};

  const editableInCode = (code) => code.includes(elementCode) && !readOnlyFlag;

  // 代销机构显示 第一步并且有代销机构信息 或者 非第一步、没有生成公告、并且有代销机构信息
  const agencyVisible =
    (firstTokenFlag && (formData.agencylist || []).length > 0 && !readOnlyFlag) ||
    ((formData.attachmentlist || []).length < 1 &&
      (formData.agencylist || []).length > 0 &&
      Number(firstTokenFlag) === 0);
  const itemVisible =
    (formData.attachmentlist || []).length < 1 || (Number(firstTokenFlag) === 1 && !readOnlyFlag);
  const agencyTypeVisible = formData.tname === '股票换购';

  const comProps = {
    size: 'middle',
  };

  const megaProps = {
    labelWidth: 110,
    responsive: { lg: 4, m: 2, s: 1 },
    contextResponsive: { lg: 4, m: 2, s: 1 },
  };

  const megaLayoutProps = useMegaLayoutProps(megaProps);

  const tNameProps = useDictList({ id: '19796938d23b429fbb2754dfd17e8861' });
  const agencyTypeProps = useDictList({ id: '80c2933d575443569ba6ba6f0b6606c9' });
  const agencyattrProps = useTreeSelect({
    request: () => async () => {
      const res = await dictv1Listchild({ dictids: D.AGENCYATTR_LIST });
      const children = res.data?.[0]?.children;
      if (children.length) {
        return children.map(({ name }) => ({ value: name, label: name }));
      }
      return [];
    },
  });

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      {renderSign({ name: 'agency50', title: '会签信息' })}

      <BasicFormCard title="代销上线说明" megaLayout={megaProps}>
        <Field
          name="remark"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
      </BasicFormCard>

      <Field
        name="updownbtn"
        type="button"
        editable
        visible={!itemVisible}
        x-component-props={{
          text: '显示代销信息',
          style: { float: 'right' },
          onClick: '{{upDownAgencyInfo}}',
        }}
        x-mega-props={{ span: 4 }}
      />
      <BasicFormCard
        title="代销机构信息"
        megaLayout={false}
        name="agencyinfo"
        visible={agencyVisible}
      >
        <Field
          name="agencylist"
          minItems={0}
          maxItems={10}
          type="array"
          default={[]}
          x-component="bpm-array-card"
          x-component-props={{
            key: 'organinfoid',
            title: '代销机构',
            titlefield: 'companyname',
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderRemove: '{{renderRemove}}',
            renderAddition: () => (
              <Button type="primary" size="small">
                新增代销机构
              </Button>
            ),
          }}
        >
          <Field type="object">
            <FormMegaLayout {...megaLayoutProps}>
              {/* <Field name='organinfoid' title='ID' type='string' display={false} default={uuid()} x-component-props={{}} /> */}
              <Field
                name="companycode"
                title="机构编号"
                type="string"
                required
                x-component-props={{ placeholder: '请输入机构编号' }}
              />
              <Field
                name="companyname"
                title="机构名称"
                type="string"
                required
                x-rules={[
                  {
                    validator: (value) => {
                      const { getFieldValue } = formActions;
                      const agencylist = getFieldValue('agencylist') || [];
                      if (agencylist.filter((a) => a.companyname === value).length > 1) {
                        return '机构名称重复';
                      }
                      return '';
                    },
                  },
                ]}
                x-component-props={{ placeholder: '请输入机构名称' }}
              />
              <Field
                name="partysimname"
                title="机构简称"
                type="string"
                required
                x-rules={[
                  {
                    validator: (value) => {
                      const { getFieldValue } = formActions;
                      const agencylist = getFieldValue('agencylist') || [];
                      if (agencylist.filter((a) => a.partysimname === value).length > 1) {
                        return '机构简称重复';
                      }
                      return '';
                    },
                  },
                ]}
                x-component-props={{ placeholder: '请输入机构简称' }}
              />
              <Field
                name="englishname"
                title="英文名称"
                type="string"
                x-component-props={{ placeholder: '请输入英文名称' }}
              />
              <Field
                name="companytype"
                title="机构类型"
                type="tree-select"
                required
                x-component-props={{
                  placeholder: '请输入机构类型',
                  optionFilterProp: 'label',
                  ...useDictList({ id: 'f993cf7a384343f281e6cb6ad9ed6173' }),
                }}
              />
              <Field
                name="lawman"
                title="法人代表"
                type="string"
                x-component-props={{ placeholder: '请输入法人代表' }}
              />
              <Field
                name="regaddress"
                title="注册地址"
                type="string"
                required
                x-component-props={{ placeholder: '请输入注册地址' }}
              />
              <Field
                name="regcapital"
                title="注册金额"
                type="number"
                x-component-props={{ placeholder: '请输入注册金额' }}
              />
              <Field
                name="contactor"
                title="联系人"
                type="string"
                x-component-props={{ placeholder: '请输入联系人' }}
              />
              <Field
                name="duty"
                title="职务"
                type="string"
                x-component-props={{ placeholder: '请输入职务' }}
              />
              <Field
                name="mobileno"
                title="手机号码"
                type="string"
                x-component-props={{ placeholder: '请输入手机号码' }}
              />
              <Field
                name="phone"
                title="联系电话"
                type="string"
                x-component-props={{ placeholder: '请输入联系电话' }}
              />
              <Field
                name="address"
                title="联系地址"
                type="string"
                x-component-props={{ placeholder: '请输入联系地址' }}
              />
              <Field
                name="email"
                title="邮箱地址"
                type="string"
                x-component-props={{ placeholder: '请输入邮箱地址' }}
              />
              <Field
                name="fax"
                title="传真"
                type="string"
                x-component-props={{ placeholder: '请输入传真' }}
              />
              <Field
                name="hotline"
                title="客服热线"
                type="string"
                required
                x-component-props={{ placeholder: '请输入客服热线' }}
              />
              <Field
                name="website"
                title="公司网址"
                type="string"
                required
                x-component-props={{ placeholder: '请输入公司网址' }}
              />
              <Field
                name="foundtime"
                title="成立时间"
                type="date"
                x-component-props={{ placeholder: '请输入成立时间' }}
              />
              <Field
                name="issigned"
                title="签署年度框架"
                type="radio"
                default="0"
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否签署年度框架`,
                }}
              />
              <Field
                name="ispdtparams"
                title="有独立产品参数表"
                type="radio"
                default="0"
                enum={[
                  { label: '是', value: '1' },
                  { label: '否', value: '0' },
                ]}
                x-component-props={{
                  placeholder: `请选择是否有独立产品参数表`,
                }}
              />
            </FormMegaLayout>
          </Field>
        </Field>
      </BasicFormCard>
      <BasicFormCard title="代销关系信息" megaLayout={false} name="iteminfo" visible={itemVisible}>
        <Field
          name="itemlist"
          type="array"
          x-component="form-table"
          x-component-props={{
            operationsWidth: 80,
            selectedAllRows: true,
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            onSelect: '{{changeAgencyTableOnSelect}}',
            renderExtendButtons: '{{renderExtendButtons}}',
            onRemove: '{{changeAgencyTableRemove}}',
            visibleColumns: agencyTypeVisible ? [] : ['agencytype'],
          }}
        >
          <Field type="object">
            <Field
              name="fundcode"
              title="基金代码"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="fundname"
              title="基金名称"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companycode"
              title="机构代码"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companyname"
              title="机构名称"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="companytype"
              title="机构类型"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              name="changetype"
              title="操作类型"
              type="string"
              editable={false}
              x-component-props={{}}
            />
            <Field
              required
              name="agencyattr"
              title="代销属性"
              type="tree-select"
              x-component-props={{
                ...agencyattrProps,
              }}
            />
            <Field
              title="代理类型"
              name="agencytype"
              type="tree-select"
              required
              x-component-props={{
                style: { width: '200px' },
                ...comProps,
                ...agencyTypeProps,
              }}
            />
            <Field
              name="agencydate"
              title="代销上线/下线日期"
              required
              type="date"
              label={undefined}
              x-component-props={{}}
            />
            <Field
              name="msg"
              title="错误信息提示"
              required
              type="string"
              editable={false}
              x-component-props={{
                renderLabel: (text, record) => <span style={{ color: 'red' }}>{record.msg}</span>,
              }}
            />
          </Field>
        </Field>
      </BasicFormCard>

      <BasicFormCard title="公告信息" megaLayout={megaProps}>
        <Field
          title="公告生成类型"
          name="tname"
          type="tree-select"
          required
          x-mega-props={{ span: 4 }}
          x-component-props={{
            style: { maxWidth: 400 },
            ...comProps,
            ...tNameProps,
          }}
        />
        <Field
          title="公告文件"
          name="attachmentlist"
          type="bpm-upload-list"
          x-rules={[
            {
              validator: (value) => {
                const { getFieldValue } = formActions;
                const itemList = getFieldValue('itemlist') || [];
                if (
                  itemList.find((a) => a.changetype === '新增代销机构') &&
                  (value || []).length < 1
                ) {
                  return '关系中包含【新增代销机构】，公告文件不可为空';
                }
                return '';
              },
            },
          ]}
          x-component-props={{
            onSuccess: '{{fileSuccess("attachmentlist")}}',
            onDel: '{{fileDel("attachmentlist")}}',
            accept: '.doc,.docx',
            multiple: false,
            isFsfund: true,
            maxLength: 4,
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          name="generatebtn"
          type="button"
          visible={false}
          x-component-props={{
            text: '生成公告',
            onClick: '{{generateNotice}}',
          }}
        />
        <Field name="formModal" title={null} type="NoticeModal" />
      </BasicFormCard>

      <BaseFormCard visible={false} title="公告发布" name="noticesCard" megaLayout={megaProps}>
        <Field
          editable
          type="array"
          name="notices"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              type="date"
              title="公告日期"
              name="publishdate"
              editable={editableInCode('80')}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field
              name="issync"
              title="发布状态"
              enum={issyncEnum}
              type="string"
              editable={false}
            />
            <Field
              name="action"
              title="操作"
              type="ButtonField"
              visible
              editable
              x-component-props={{ text: '去发布', type: 'primary' }}
            />
          </Field>
        </Field>
      </BaseFormCard>
    </>
  );
}

export default Form;
