import React from 'react';
import { Field } from 'formily-antd';
import moment from 'moment';
import { megaProps } from '@/utils';
import { renderSign, getFundFullList } from '@/pages/Client/Launch/utils';
import { getWorkDate, getdesigndate } from '@/common/axios';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import BaseFormCard from '@chinahorm/web-components/es/components/BaseFormCard';
import { signMap } from './effects';

const issyncEnum = [
  { label: '未发布', value: '0' },
  { label: '已发布', value: '1' },
  { label: '已发布', value: '2' },
];

function Form(props) {
  const {
    context: { getProcess },
    formEffects: { formActions },
  } = props;
  const { readOnlyFlag, elementCode } = getProcess() || {};
  const { getFieldState, setFieldState } = formActions;
  console.log('🚀 ~ 持有人大会流程 elementCode:', elementCode);

  const getFileProps = (name) => ({
    onSuccess: `{{fileSuccess("${name}")}}`,
    onDel: `{{fileDel("${name}")}}`,
    accept: '.pdf,.docx,.doc,.xls,.xlsx,.png,.jpg',
    multiple: true,
    isFsfund: true,
  });

  const editableInCode = (code) => code.includes(elementCode) && !readOnlyFlag;
  const upInCode = (code) => (Number(elementCode) >= Number(code) ? 'up' : 'down');
  const displayInCode = (codeS, codeE) => {
    if (!codeE) {
      return Number(elementCode) >= Number(codeS);
    }

    return Number(elementCode) >= Number(codeS) && Number(elementCode) <= Number(codeE);
  };

  return (
    <>
      <BasicFormCard
        title={
          <div>
            <span>基本信息</span>
            <span style={{ color: 'red', fontSize: 14, marginLeft: 10 }}>
              温馨提示：针对上市基金，请确保已提前10个工作日完成交易所事项。
            </span>
          </div>
        }
        megaProps={megaProps}
      >
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="清盘信息" megaProps={megaProps}>
        <Field
          required
          name="fundcode"
          title="基金名称"
          type="tree-select"
          x-component-props={{
            optionFilterProp: 'label',
            placeholder: '请选择基金名称',
            ...getFundFullList({
              fundperiod: '存续期',
              dropdownMatchSelectWidth: false,
            }),
          }}
        />
        <Field
          required
          name="holdrmeettype"
          title="召开持有人大会类型"
          type="radio"
          default="清盘"
          x-mega-props={{ wrapperWidth: 400, span: 3 }}
          enum={[
            { label: '清盘', value: '清盘' },
            { label: '持续运作', value: '持续运作' },
            { label: '修改基金合同', value: '修改基金合同' },
            { label: '其他', value: '其他' },
          ]}
        />
        <Field
          required
          type="date"
          name="lowenddate"
          editable={false}
          title="连续60个工作日低于5000万或200人的截止时间"
          x-mega-props={{ labelWidth: 300 }}
          x-component-props={{ format: 'YYYY-MM-DD' }}
        />
        <Field
          type="string"
          name="miniplan"
          editable={false}
          title="合同规定迷你超60日后方案"
          x-mega-props={{ labelWidth: 170 }}
        />
        <Field name="haholdasset" type="AmountField" editable={false} title="基金净资产" />
        <Field name="custcnt" type="string" editable={false} title="户数" />
        <Field
          required
          name="annodate"
          type="date"
          title="公告日"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={{
            validator: async (value) => {
              if (!value) {
                return '';
              }

              // 公告日与计票日必须相隔30天以上
              const calcday = getFieldState('calcday');
              if (calcday.value) {
                if (moment(calcday.value).diff(moment(value), 'days') < 30) {
                  return '公告日与计票日必须相隔30天以上';
                }
                if (calcday.ruleErrors) {
                  setFieldState('calcday', (state) => {
                    state.ruleErrors = [];
                  });
                }
              }

              // 权益登记日必须在公告日30个自然日之后
              const registrattionprofitdate = getFieldState('registrattionprofitdate');
              if (registrattionprofitdate.value) {
                if (moment(registrattionprofitdate.value).diff(moment(value), 'days') < 30) {
                  return '权益登记日必须在公告日30个自然日之后';
                }
                if (registrattionprofitdate.ruleErrors) {
                  setFieldState('registrattionprofitdate', (state) => {
                    state.ruleErrors = [];
                  });
                }
              }

              // 不能假期的前一工作日(value为工作日，且value + 1不为工作日)
              const nextDay = moment(value).add(1, 'd').format('YYYY-MM-DD');
              const [[err1, res1], [err2, res2]] = await Promise.all([
                getWorkDate({ date: value, offset: '0' }),
                getWorkDate({ date: nextDay, offset: '0' }),
              ]);

              if (err1 || err2) {
                return '网络错误，请稍后再试';
              }

              if (value === res1.data && nextDay !== res2.data) {
                return '不能为节假前的最后一个工作日';
              }

              return '';
            },
          }}
        />
        <Field
          required
          name="registrattionprofitdate"
          type="date"
          title="权益登记日"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={{
            validator: async (value) => {
              if (!value) {
                return '';
              }

              // 权益登记日必须在公告日30个自然日之后
              const annodate = getFieldState('annodate');
              if (annodate.value) {
                if (moment(value).diff(moment(annodate.value), 'days') < 30) {
                  return '权益登记日必须在公告日30个自然日之后';
                }
                if (annodate.ruleErrors) {
                  setFieldState('annodate', (state) => {
                    state.ruleErrors = [];
                  });
                }
              }

              return '';
            },
          }}
        />

        <Field
          required
          name="startdate"
          type="date"
          title="会议投票表决开始时间"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={{
            validator: (value) => {
              const { value: enddate, ruleErrors } = getFieldState('enddate');
              if (!value || !enddate) {
                return '';
              }

              // 开始时间不能在结束时间之后
              if (moment(enddate).isBefore(value)) {
                return '开始时间不能在结束时间之后';
              }

              if (ruleErrors) {
                setFieldState('enddate', (state) => {
                  state.ruleErrors = state.ruleErrors.filter(
                    (e) => !['开始时间不能在结束时间之后'].includes(e),
                  );
                });
              }

              return '';
            },
          }}
        />
        <Field
          required
          name="enddate"
          type="date"
          title="会议投票表决结束时间"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={{
            validator: async (value) => {
              const calcday = getFieldState('calcday');
              const startdate = getFieldState('startdate');
              if (!value) {
                return '';
              }

              // 开始时间不能在结束时间之后
              if (startdate.value && moment(startdate.value).isAfter(value)) {
                return '开始时间不能在结束时间之后';
              }

              if (startdate.ruleErrors) {
                setFieldState('startdate', (state) => {
                  state.ruleErrors = state.ruleErrors.filter(
                    (e) => !['开始时间不能在结束时间之后'].includes(e),
                  );
                });
              }

              // 计票日应大于投票截止日
              if (!calcday.value) {
                return;
              }

              if (moment(calcday.value).diff(moment(value), 'days') <= 0) {
                return '计票日应大于投票截止日';
              }

              const date = moment(value).format('YYYY-MM-DD');
              const [[err1, res1], [err2, res2]] = await Promise.all([
                getdesigndate({ date, workflag: '1', offset: 1 }),
                getdesigndate({ date, workflag: '1', offset: 2 }),
              ]);
              if (err1 || err2) {
                return '网络错误，请稍后再试';
              }

              const calcdayStr = moment(calcday.value).format('YYYY-MM-DD');
              if (calcdayStr !== res1.data && calcdayStr !== res2.data) {
                return '计票日在投票截止日2个工作日内';
              }

              if (calcday.ruleErrors) {
                setFieldState('calcday', (state) => {
                  state.ruleErrors = state.ruleErrors.filter(
                    (e) => !['计票日应大于投票截止日', '计票日在投票截止日2个工作日内'].includes(e),
                  );
                });
              }
            },
          }}
        />

        <Field
          required
          name="[startdate1, enddate2]"
          type="dateRange"
          visible={false}
          title="会议投票表决起止时间"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={{
            validator: async (value) => {
              const calcday = getFieldState('calcday');
              const [, enddate] = value;
              if (!value || !calcday.value) {
                return '';
              }

              // 计票日应大于投票截止日
              if (moment(calcday.value).diff(moment(enddate), 'days') <= 0) {
                return '计票日应大于投票截止日';
              }

              const date = moment(enddate).format('YYYY-MM-DD');
              const [[err1, res1], [err2, res2]] = await Promise.all([
                getdesigndate({ date, workflag: '1', offset: 1 }),
                getdesigndate({ date, workflag: '1', offset: 2 }),
              ]);
              if (err1 || err2) {
                return '网络错误，请稍后再试';
              }

              const calcdayStr = moment(calcday.value).format('YYYY-MM-DD');
              if (calcdayStr !== res1.data && calcdayStr !== res2.data) {
                return '计票日在投票截止日2个工作日内';
              }

              if (calcday.ruleErrors) {
                setFieldState('calcday', (state) => {
                  state.ruleErrors = state.ruleErrors.filter(
                    (e) => !['计票日应大于投票截止日', '计票日在投票截止日2个工作日内'].includes(e),
                  );
                });
              }
            },
          }}
        />
        <Field
          required
          name="calcday"
          type="date"
          title="计票日"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          x-rules={{
            validator: async (value) => {
              if (!value) {
                return '';
              }

              // 公告日与计票日必须相隔30天以上
              const annodate = getFieldState('annodate');

              if (annodate.value) {
                if (moment(value).diff(moment(annodate.value), 'days') < 30) {
                  return '公告日与计票日必须相隔30天以上';
                }
                if (annodate.ruleErrors) {
                  setFieldState('annodate', (state) => {
                    state.ruleErrors = state.ruleErrors.filter(
                      (e) => e !== '公告日与计票日必须相隔30天以上',
                    );
                  });
                }
              }

              // 计票日在投票截止日2个工作日内
              // const dateRange = getFieldState('[startdate, enddate]') || {};
              const enddateState = getFieldState('enddate');
              const { value: enddate, ruleErrors } = enddateState;

              // const [, enddate] = dateRange.value || [];
              if (!enddate) {
                return '';
              }

              // 计票日应大于投票截止日
              if (moment(value).diff(moment(enddate), 'days') <= 0) {
                return '计票日应大于投票截止日';
              }

              const date = moment(enddate).format('YYYY-MM-DD');
              const [[err1, res1], [err2, res2]] = await Promise.all([
                getdesigndate({ date, workflag: '1', offset: 1 }),
                getdesigndate({ date, workflag: '1', offset: 2 }),
              ]);
              if (err1 || err2) {
                return '网络错误，请稍后再试';
              }

              const calcdayStr = moment(value).format('YYYY-MM-DD');
              if (calcdayStr !== res1.data && calcdayStr !== res2.data) {
                return '计票日在投票截止日2个工作日内';
              }

              if (ruleErrors) {
                setFieldState('enddate', (state) => {
                  state.ruleErrors = state.ruleErrors.filter(
                    (e) => !['计票日应大于投票截止日', '计票日在投票截止日2个工作日内'].includes(e),
                  );
                });
              }

              return '';
            },
          }}
        />
        {/* 弹框组件，随便找个位置放进来，保证一定会被加载即可 */}
        <Field name="formModal" title={null} type="NoticeModal" />

        <Field
          type="text"
          name="CoTme7LHF3tdqol"
          default="基金份额持有人大会公告文件："
          x-mega-props={{ span: 4 }}
        />
        <Field
          // editable
          type="array"
          name="fundshareholdrannoCard"
          title={null}
          x-component="form-table"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field
              type="string"
              name="filetype"
              title="文件类型"
              default="default"
              editable={false}
            />
            <Field
              required
              name="filename"
              title="上传文件"
              type="bpm-upload-list"
              editable={editableInCode('10')}
              x-component-props={{
                accept: '.pdf,.docx,.doc,.xls,.xlsx,.png,.jpg',
                multiple: true,
                isFsfund: true,
              }}
            />
            <Field
              required
              type="date"
              name="filedate"
              title="公告日期"
              editable={editableInCode('10')}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
          </Field>
        </Field>
        {renderSign({
          name: 'holdrmeet10',
          editable: editableInCode(signMap.holdrmeet10),
          labelWidth: 100,
          leaderapprove: true,
          independentModule: false,
        })}

        <Field
          type="textarea"
          title="说明"
          name="description"
          x-mega-props={{ span: 4, labelWidth: 100 }}
          x-component-props={{
            placeholder: `请输入`,
            autoSize: { minRows: 3, maxRows: 20 },
          }}
        />
      </BasicFormCard>

      <BaseFormCard
        title="公告发布"
        name="qwstoptLxhLgOX1ge"
        megaLayout={megaProps}
        visible={displayInCode('40')}
        upDown={upInCode('50')}
      >
        <Field
          editable
          type="array"
          name="fundshareholdrannonotices"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              name="publishdate"
              title="公告日期"
              type="date"
              editable={editableInCode('40')}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field
              name="issync"
              title="发布状态"
              enum={issyncEnum}
              type="string"
              editable={false}
            />
            <Field
              name="action"
              title="操作"
              type="ButtonField"
              visible={false}
              editable={editableInCode('40')}
              x-component-props={{ text: '去发布', type: 'primary' }}
            />
          </Field>
        </Field>
      </BaseFormCard>

      <BaseFormCard
        title="上传公证材料会签"
        name="UvFC1oP4bB"
        megaLayout={megaProps}
        visible={displayInCode('50')}
        upDown={upInCode('80')}
      >
        <Field
          required
          title="公证材料文件"
          name="materialfile"
          type="bpm-upload-list"
          x-mega-props={{ span: 4 }}
          editable={editableInCode('50')}
          x-component-props={{
            ...getFileProps('materialfile'),
          }}
        />
        {renderSign({
          name: 'holdrmeet50',
          editable: editableInCode(signMap.holdrmeet50),
          // editable: true,
          leaderapprove: true,
          independentModule: false,
        })}
      </BaseFormCard>

      <BaseFormCard
        title="上传持有人名册"
        name="FJ1GrWdBwgYcDKZs"
        megaLayout={megaProps}
        visible={displayInCode('80')}
        upDown={upInCode('90')}
      >
        <Field
          type="button"
          editable={editableInCode('80')}
          x-component-props={{
            text: '模板下载',
            type: 'primary',
            ghost: true,
            onClick: '{{onTemplateDown}}',
          }}
        />
        <Field
          required
          title="上传权益登记日当天持有人名册"
          name="rightregistdaypresholdrfile"
          type="bpm-upload-list"
          x-mega-props={{ span: 4, labelWidth: 200 }}
          editable={editableInCode('80')}
          x-component-props={{
            ...getFileProps('rightregistdaypresholdrfile'),
          }}
        />
      </BaseFormCard>

      <BaseFormCard
        title="上传持有人大会相关文件"
        name="4XI6qSLatv7"
        megaLayout={megaProps}
        visible={displayInCode('90')}
        upDown={upInCode('110')}
      >
        {/*
            转换结构
            1. 基金份额持有人大会表决结果暨决议生效的公告文件 文件: fundsharereseffectannofile 日期: fundsharereseffectannodate
            2. 计票结果文件 文件: resultfile
            2. 备案报告 文件: regrptfile
        */}
        <Field
          editable
          type="array"
          name="fundsharereseffectannoCard"
          title={null}
          x-component="form-table"
          x-mega-props={{ span: 4 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field
              type="string"
              name="filetype"
              title="文件类型"
              default="default"
              editable={false}
            />
            <Field
              required
              name="filename"
              title="上传文件"
              type="bpm-upload-list"
              editable={editableInCode('90')}
              x-component-props={{
                accept: '.pdf,.docx,.doc,.xls,.xlsx,.png,.jpg',
                multiple: true,
                isFsfund: true,
              }}
            />
            <Field
              required
              type="date"
              name="filedate"
              title="公告日期"
              editable={editableInCode('90')}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
          </Field>
        </Field>
        {renderSign({
          name: 'holdrmeet90',
          editable: editableInCode(signMap.holdrmeet90),
          labelWidth: 100,
          leaderapprove: true,
          independentModule: false,
        })}
      </BaseFormCard>

      <BaseFormCard
        name="JuPkNzkVXvFyXn7Nhxi"
        title="公告发布"
        megaLayout={megaProps}
        visible={displayInCode('110')}
      >
        <Field
          editable
          type="array"
          name="fundsharereseffectannonotices"
          x-component="form-table"
          x-mega-props={{ span: 3 }}
          x-component-props={{
            renderButtons: false,
            rowSelection: null,
            className: 'removeBandedRows',
          }}
        >
          <Field type="object">
            <Field name="title" title="公告文件" type="string" editable={false} />
            <Field
              name="publishdate"
              title="公告日期"
              type="date"
              editable={editableInCode('110')}
              x-component-props={{ format: 'YYYY-MM-DD' }}
            />
            <Field
              name="issync"
              title="发布状态"
              enum={issyncEnum}
              type="string"
              editable={false}
            />
            <Field
              name="action"
              title="操作"
              type="ButtonField"
              visible={false}
              editable
              x-component-props={{ text: '去发布', type: 'primary' }}
            />
          </Field>
        </Field>
      </BaseFormCard>
    </>
  );
}

export default Form;
