import React from 'react';
import Form from './form';
import Effects from './effects';
import BaseForm from '@chinahorm/web-components/es/components/BaseForm';
import NoticeModal from '@/pages/Client/Launch/components/noticeModal';
import ButtonField from '@/pages/Client/Launch/components/buttonField';
import AmountField from '@/pages/Client/Launch/components/amountField';

function Index(props) {
  const formEffects = new Effects(props);
  return (
    <BaseForm
      formEffects={formEffects}
      {...props}
      components={{ NoticeModal, ButtonField, AmountField }}
    >
      <Form audit={formEffects.audit} formEffects={formEffects} {...props} />
    </BaseForm>
  );
}

export default Index;
