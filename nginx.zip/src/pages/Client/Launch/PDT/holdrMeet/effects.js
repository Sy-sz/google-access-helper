import React from 'react';
import { Button } from 'antd';
import moment from 'moment';
import { difference } from 'lodash';
import { FormPath, FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import {
  minifundLiquidFund,
  listNoticeMatch,
  getdesigndate,
  pdtconfigDetail,
} from '@/common/axios';
import { dividendSignPeople } from '@/common/axios/pdtSystem';
import {
  batchToggleSignType,
  batchFormatFile,
  convertFileFlatToArray,
  convertFileArrayToFlat,
  validateSign,
  leaderSeparator,
} from '../../utils';
import { genJumpProcess, downloadFile, getDictionary, D } from '@/utils';

const { onFieldValueChange$, onFieldInit$, onFieldInputChange$ } = FormEffectHooks;
// const { onToggleChange$ } = BpmFormEffectHooks;

/** 这几个文件 数据是平铺的，但展示在表格里，需要来回转化一下 */
const fileFlatToArrayMap = {
  fundshareholdrannoCard: [
    {
      filetype: '基金份额持有人大会的公告',
      filekey: 'fundshareholdrannofile',
      datekey: 'fundshareholdrannodate',
    },
    {
      filetype: '基金份额持有人大会的第一次提示性公告',
      filekey: 'fundsharetipsactannofile',
      datekey: 'fundsharetipsactannodate',
    },
    {
      filetype: '基金份额持有人大会的第二次提示性公告',
      filekey: 'nextfundsharetipsactannofile',
      datekey: 'nextfundsharetipsactannodate',
    },
  ],
  fundsharereseffectannoCard: [
    {
      filetype: '基金份额持有人大会表决结果暨决议生效的公告',
      filekey: 'fundsharereseffectannofile',
      datekey: 'fundsharereseffectannodate',
    },
    {
      filetype: '计票结果文件（包括票（pdf）签名、签章、营业执照、合同扫描件等）',
      filekey: 'resultfile',
    },
    {
      filetype: '备案报告',
      filekey: 'regrptfile',
    },
  ],
};
/** 会签字段名与可编辑节点的映射 */
export const signMap = {
  holdrmeet10: '10',
  holdrmeet50: '50',
  holdrmeet90: '90',
};
// 需要格式化的文件
const fileNames = ['materialfile', 'rightregistdaypresholdrfile'];
// 包含去发布按钮的节点，存在未发布的公告提交时给提示
const publishCode = {
  40: 'fundshareholdrannonotices',
  110: 'fundsharereseffectannonotices',
};

export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    const {
      context: { getProcess },
    } = props;
    const { elementCode, firstTokenFlag, readOnlyFlag } = getProcess() || {};
    this.elementCode = elementCode;
    this.firstTokenFlag = firstTokenFlag;
    this.readOnlyFlag = readOnlyFlag;
    this.leaderMap = {};
    this.countersignusersCache = [];
  }

  createFormEffects() {
    return (
      $,
      { dispatch, setFieldState, setFieldValue, getFieldState, getFieldValue, notify },
    ) => {
      // 把默认会签人缓存下来；
      onFieldInit$('holdrmeet10').subscribe((field) => {
        this.countersignusersCache = field.value.countersignusers || [];
      });

      // 选择基金代码
      onFieldValueChange$('fundcode').subscribe(async (field) => {
        if (this.elementCode !== '10' || !field.value) {
          return;
        }

        // 1. 带出合同规定迷你超60日后方案、基金净资产、户数等
        const managerRes = await dividendSignPeople({ fundcode: field.value });
        const fundManager = managerRes.data?.split(';')?.filter(Boolean);
        if (fundManager?.length) {
          const countersignusers = [...this.countersignusersCache, ...fundManager];
          setFieldValue('holdrmeet10.countersignusers', countersignusers);
        }

        // 2. 查对应的基金经理，加到会签人里
        const [err, res] = await minifundLiquidFund({ fundcode: field.value }); // '009263'
        if (err) {
          return;
        }

        const defaultData = {
          custcnt: null,
          datadate: null,
          haholdasset: null,
          lowenddate: null,
          miniplan: null,
        };
        const extra = ['haholdasset', 'custcnt']; // 要拼上截止日期的字段
        const datadate = res.data?.datadate && moment(res.data.datadate).format('YYYY-MM-DD');

        Object.entries(res.data || defaultData).forEach(([key, value]) => {
          if (extra.includes(key)) {
            const megaProps = datadate ? { addonAfter: `(截止：${datadate})` } : {};
            setFieldState(key, (state) => {
              state.props['x-mega-props'] = megaProps;
            });
          }

          setFieldValue(key, value);
        });
      });

      onFieldValueChange$('holdrmeettype').subscribe((field) => {
        setFieldState('*(lowenddate,miniplan,haholdasset,custcnt)', (state) => {
          state.visible = field.value === '清盘';
        });
      });

      // 查 领导字典； 设置 领导options； 设置 领导审批顺序；
      onFieldInit$('holdrmeet10').subscribe(async () => {
        getDictionary(D.LEADER_LIST).then(([leaderDict]) => {
          const leaderEnum = [];
          this.leaderMap = leaderDict.reduce((acc, { name: label, value }) => {
            leaderEnum.push({ label, value });
            acc[value] = label;
            acc[label] = value;
            return acc;
          }, {});

          ['holdrmeet10', 'holdrmeet50', 'holdrmeet90'].forEach((item) => {
            const { leaderrank } = getFieldValue(item) || {};
            if (leaderrank) {
              const rank = leaderrank
                .split(leaderSeparator)
                .map((e) => this.leaderMap[e])
                .join(leaderSeparator);

              setFieldValue(`${item}.leaderrank`, rank);
            }
          });

          setFieldState('*(holdrmeet10.leader,holdrmeet50.leader,holdrmeet90.leader)', (state) => {
            state.props.enum = leaderEnum;
          });
        });
      });

      // 领导不是同时审批时，显示领导、领导审批顺序，否则隐藏
      onFieldValueChange$(
        '*(holdrmeet10.leaderapprove,holdrmeet50.leaderapprove,holdrmeet90.leaderapprove)',
      ).subscribe((field) => {
        const { segments } = FormPath.parse(field.name);

        setFieldState(`${segments[0]}.leaderrank`, (state) => {
          state.visible = field.value === '0';
        });
      });

      // 会签，点领导审批时，按点击顺序排序
      onFieldInputChange$('*(holdrmeet10.leader,holdrmeet50.leader,holdrmeet90.leader)').subscribe(
        (field) => {
          const { segments } = FormPath.parse(field.name);
          const leaderrank = getFieldValue(`${segments[0]}.leaderrank`) || undefined;
          let leaderOrderArr = leaderrank?.split(leaderSeparator) ?? [];
          leaderOrderArr = leaderOrderArr.map((e) => this.leaderMap[e]);
          const isAdd = field.value.length > leaderOrderArr.length; // 是否为新增
          const active = isAdd
            ? difference(field.value, leaderOrderArr)
            : difference(leaderOrderArr, field.value);

          if (isAdd) {
            leaderOrderArr.push(...active);
          } else {
            leaderOrderArr = leaderOrderArr.filter((e) => e !== active[0]);
          }
          const leaderName = leaderOrderArr.map((e) => this.leaderMap[e]);
          setFieldValue(`${segments[0]}.leaderrank`, leaderName.join(leaderSeparator));
        },
      );

      // 去发布 显隐
      onFieldInit$(
        '*(fundshareholdrannonotices.*.action,fundsharereseffectannonotices.*.action)',
      ).subscribe((field) => {
        const { segments } = FormPath.parse(field.name);
        const [fieldName, idx] = segments;
        const { issync } = getFieldValue(fieldName)[idx] || {};
        if (issync === '0') {
          setFieldState(`${fieldName}.${idx}.action`, (state) => {
            state.visible = true;
          });
        }
      });

      // 去发布 打开弹框
      onFieldValueChange$(
        '*(fundshareholdrannonotices.*.action,fundsharereseffectannonotices.*.action)',
      ).subscribe(async (field) => {
        const { segments } = FormPath.parse(field.name);
        const [fieldName, idx] = segments;
        const { noticeid, publishdate } = getFieldValue(fieldName)[idx] || {};

        const res = await listNoticeMatch({ size: 1000 });
        const noticetypeOptions = res.data?.map(({ noticetypename, noticetypeid, ...rest }) => ({
          ...rest,
          dictLabel: noticetypename,
          dictValue: noticetypeid,
          label: noticetypename,
          value: noticetypeid,
        }));

        setFieldState('formModal', (state) => {
          state.props['x-component-props'] = {
            visible: true,
            noticeid,
            setFieldState,
            noticetypeOptions,
            publishdate: moment(publishdate).format('YYYY-MM-DD'),
          };
        });
      });

      onFieldInit$('fundsharereseffectannoCard.*.filedate').subscribe((field) => {
        if (this.elementCode !== '90' || this.readOnlyFlag) {
          return;
        }

        const { segments } = FormPath.parse(field.name);
        const [fieldName, idx] = segments;
        if (idx >= 1) {
          setFieldState(`${fieldName}.${idx}.filedate`, (state) => {
            state.visible = false;
          });
        }
      });

      // 公告日不能为节假日或节假日前一天, 并带出三个公告日期
      onFieldInputChange$('annodate').subscribe(async (field) => {
        const [[err1, t1], [err2, t2]] = await Promise.all([
          getdesigndate({ date: field.value, workflag: '1', offset: '1' }),
          getdesigndate({ date: field.value, workflag: '1', offset: '2' }),
        ]);
        if (err1 || err2) {
          return '网络错误，请稍后再试';
        }

        setFieldValue('fundshareholdrannoCard.0.filedate', field.value);
        setFieldValue('fundshareholdrannoCard.1.filedate', t1.data);
        setFieldValue('fundshareholdrannoCard.2.filedate', t2.data);
      });
    };
  }

  /** 格式化 传入的数据 */
  formatInitData(values) {
    values.leaderMap = this.leaderMap;
    return {
      ...values,
      ...convertFileFlatToArray(values, fileFlatToArrayMap),
      ...batchToggleSignType(values, Object.keys(signMap)),
    };
  }

  /** 格式化 传出的数据 */
  formatSubmitData(values) {
    values.leaderMap = this.leaderMap;
    return {
      ...values,
      ...convertFileArrayToFlat(values, fileFlatToArrayMap),
      ...batchToggleSignType(values, Object.keys(signMap)),
      ...batchFormatFile(values, fileNames),
    };
  }

  applyFormatData(values) {
    return this.formatInitData(values);
  }

  auditFormatData(values) {
    return this.formatInitData(values);
  }

  applySubmit(values, file) {
    return this.formatSubmitData(values);
  }

  auditSubmit(values, file) {
    return this.formatSubmitData(values);
  }

  daftSubmit(values) {
    return this.formatSubmitData(values);
  }

  async submitConfirm(values, next, { actionName }) {
    // 退回不校验
    if (actionName.includes('退回')) {
      next(true);
      return;
    }

    // 会签人、会签部门必填一项
    const isSignPass = validateSign({
      values,
      signMap,
      elementCode: this.elementCode,
      formActions: this.formActions,
    });
    if (!isSignPass) {
      next(false);
      return;
    }

    // 存在未发布的公告时弹框提示
    const publishField = publishCode[this.elementCode];
    if (publishField) {
      const hasNoPublish = values[publishField]?.some(({ issync }) => issync === '0');
      if (hasNoPublish) {
        this.antModal.confirm({
          title: '提示',
          content: '有未发布的公告，是否继续？',
          onOk: () => next(true),
          onCancel: () => next(false),
        });
        return;
      }
    }

    next(true);
  }

  validatePublishCode() {}

  get expressionScope() {
    return {
      onTemplateDown: () => {
        pdtconfigDetail({ id: 'd3d45dbd4121413491c4bfe476c71149' }).then((res) => {
          const url = res.data.value;
          downloadFile(url, '基金持有人名单-模板.xlsx');
        });
      },
      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
      flowTracking: (name) => {
        if (!this.formData.liquidSubredInfo?.status) {
          return null;
        }

        return (
          <Button type="primary">
            {genJumpProcess({
              code: 'SUBRED_PROJECT',
              title: '流程跟踪',
              tokenId: this.formData.liquidSubredInfo?.tokenId,
              tag: 'trace',
            })}
          </Button>
        );
      },
      initiationProcess: () => {
        window.open('#/app/bpm/process/pdt/subRedProject?&type=1');
      },
    };
  }
}
