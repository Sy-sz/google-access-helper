import React from 'react';
import { FormEffectHooks } from 'formily-antd';
import { FormEffects } from '@chinahorm/web-components/es/components/ProcessLayout/pages/core/FormEffects';
import store from '@/store';
// import { useLinkageUtils } from '@chinahorm/web-components/es/components/ProcessLayout/hooks';
import moment from 'moment';
import uniq from 'lodash/uniq';
import isString from 'lodash/isString';
import cloneDeep from 'lodash/cloneDeep';
import { convert } from '@cerdo/cerdo-utils';
import { defaultNoticeusers } from '@/utils';
import { toggleSignType } from '../../utils';

const larges = ['调整大额', '暂停大额', '恢复大额'];

const { onFieldValueChange$, onFieldInputChange$, onFieldInit$ } = FormEffectHooks;
export default class Effects extends FormEffects {
  constructor(props) {
    super(props);
    this.managerid = null;
    this.dispatcher = store.useModelDispatchers('pdtSystem');
    this.filename = '';
    this.filepath = '';
    this.fileid = '';

    this.dictData = [
      { dictName: '暂停申购', name: 'pausepurdate', title: '暂停申购' },
      { dictName: '暂停赎回', name: 'pausereddate', title: '暂停赎回' },
      { dictName: '暂停定投定额', name: 'pausequantdate', title: '暂停定投定额' },
      { dictName: '暂停大额', name: 'limitsaledate', title: '暂停大额' },
      { dictName: '恢复申购', name: 'recoverpurdate', title: '恢复申购' },
      { dictName: '恢复赎回', name: 'recoverreddate', title: '恢复赎回' },
      { dictName: '恢复定投定额', name: 'recoverquantdate', title: '恢复定投定额' },
      { dictName: '恢复大额', name: 'recoversaledate', title: '恢复大额' },
      { dictName: '调整大额', name: 'changelimitdate', title: '调整大额' },
      { dictName: '其他类型', name: 'elsestartdate', title: '其他类型' },
    ];
  }
  createFormEffects() {
    const { getProcess } = this.props.context;
    // 登录人是当前节点处理人时，currentUserFlag是1，否则是0
    const { firstTokenFlag, currentUserFlag, elementCode, readOnlyFlag } = getProcess() || {};
    return ($, { setFieldState, setFieldValue, getFieldValue }) => {
      // const linkage = useLinkageUtils();
      onFieldInit$('*(fundcode,tradetype)').subscribe(({ value, name }) => {
        setFieldValue(name, value ? value.split(';') : value);
      });

      onFieldValueChange$('*(pausedate,recoverdate)').subscribe(({ value, name }) => {
        this.formData[name] = value;
      });
      // sharecode
      // organinfoid
      // sellers
      // 交易类型判断部分
      if (currentUserFlag === 0 || Number(this.formData.status) === 1) {
        onFieldValueChange$('tradetype').subscribe(({ value }) => {
          this.dictData.forEach((item) => {
            if (value) {
              setFieldState(item.name, (e) => {
                e.visible = value?.findIndex((name) => name === item.dictName) > -1;
              });
            }
          });

          // 大额时的相关逻辑
          const isLarge = value?.some((e) => larges.includes(e));
          setFieldState('funds', (e) => {
            e.props['x-component-props'].visibleColumns = [
              { name: 'largeStatus', visible: !!isLarge },
            ];
          });
          if (elementCode === '10' && !readOnlyFlag) {
            setFieldState('tradetypeMsg', (e) => {
              e.value = isLarge ? '请确认，份额详情中大额类型' : null;
            });
          }

          setFieldState('*(beforelimitamount,afterlimitamount)', (state) => {
            state.visible = value?.some((e) => e === '调整大额');
          });

          setFieldState('limitamount', (state) => {
            state.visible = value?.some((e) => e === '暂停大额');
          });

          setFieldState('elseremark', (state) => {
            state.visible = value?.some((e) => e === '其他类型');
          });
        });
      }

      // 交易类型
      onFieldInit$('tradetype').subscribe(({ value }) => {
        this.tradetype = value && value.split(';');
        if (this.tradetype && Array.isArray(this.tradetype) && this.tradetype.length > 0) {
          this.dictData.forEach((item) => {
            setFieldState(item.name, (s) => {
              s.visible = this.tradetype?.findIndex((name) => name === item.dictName) > -1;
            });
          });

          const isLarge = larges.some((e) => value.includes(e));
          if (isLarge) {
            setFieldState('funds', (e) => {
              e.props['x-component-props'].visibleColumns = [
                { name: 'largeStatus', visible: true },
              ];
            });
          }

          if (value.includes('调整大额')) {
            setFieldState('*(beforelimitamount,afterlimitamount)', (state) => {
              state.visible = true;
            });
          }

          this.isVisible(this.tradetype);
        }
      });

      // 交易所申请函是否申请盖章，如果选是则默认选中三个知会人，如果选否去掉该三个知会人
      if ((firstTokenFlag || elementCode === '30') && !readOnlyFlag) {
        onFieldValueChange$('subred40.isseal').subscribe(({ value }) => {
          const oldNoticeusers = this.formData.subred40.noticeusers;

          const noticeusers =
            value === '1'
              ? uniq([...oldNoticeusers, ...defaultNoticeusers])
              : oldNoticeusers.filter((id) => !defaultNoticeusers.includes(id));
          setFieldValue('subred40.noticeusers', noticeusers);
        });
      }

      // 只在第一步 需要监听 change事件
      // if (currentUserFlag === 0) {
      onFieldInputChange$('fundcode').subscribe((fieldState) => {
        const { value } = fieldState;
        const funds = getFieldValue('funds');
        if (value && Array.isArray(value) && value.length > 0) {
          const fund = value.length > 0 ? value.join(';') : '';
          this.dispatcher.dividendFundday({ fundcode: fund, page: 1, size: 100 }).then((result) => {
            const dataList = result.data;
            if (dataList && Array.isArray(dataList) && dataList.length > 0) {
              const newArrlist = dataList.map((b, i) => {
                const itemCache = funds.find((e) => e.fundcode === b.fundcode);
                if (itemCache) {
                  return itemCache;
                }

                return {
                  fundcode: b.fundcode,
                  fundname: b.fundname,
                  fundstatus: b.subredstatus,
                  limitAmtInfo: b.limitAmtInfo,
                  largeStatus: b.largeStatus?.split(','),
                };
              });
              if (elementCode === '10' && !readOnlyFlag) {
                setFieldValue('funds', newArrlist);
              }
            }
          });
        } else {
          setFieldValue('funds', []);
        }
      });
      // }
      // if (!firstTokenFlag || readOnlyFlag||Number(this.formData.status)===1) {
      //   onFieldInit$('fundcode').subscribe((fieldState) => {
      //     const { value } = fieldState
      //     let funShareList = []
      //     this.dispatcher.dividendFundday({ fundcode: value, page: 1, size: 100 }).then(res => {
      //       if (res) {
      //         res.data.forEach((b, i) => {
      //           funShareList = []
      //           b.fundShares.forEach((item) => {
      //             funShareList.push({ label: `${item.fundshortname}[${item.fundcode}]`, value: item.fundshortname })
      //           })
      //           linkage.enum(`*.${i}.sharecodes`, [...funShareList])
      //         })
      //       }
      //     })
      //     // })
      //   })
      // }
    };
  }
  // 交易类型判断日期是否展示
  isVisible(value) {
    const { setFieldState } = this.formActions;
    if (value.find((b) => b === '暂停大额')) {
      setFieldState('limitsaledate', (state) => {
        state.visible = true;
      });
      setFieldState('limitamount', (state) => {
        state.visible = true;
      });
    }
    if (value.find((b) => b === '其他类型')) {
      setFieldState('elsestartdate', (state) => {
        state.visible = true;
      });
      setFieldState('elseremark', (state) => {
        state.visible = true;
      });
    }
  }
  joinArray(data, chr = ',') {
    if (!data) {
      return '';
    }
    if (data instanceof Array) {
      return data.join(chr);
    }
    return data;
  }
  formatFiles = (filelist) => {
    const formatItem = (file) => {
      if (!file.response || !file.response.fileid) {
        return file;
      }
      return file.response;
    };
    const attachments = (filelist || []).map((item) => {
      return {
        ...formatItem(item),
      };
    });
    return attachments;
  };

  formatData(values) {
    return {
      ...values,
      subred40: toggleSignType(values.subred40),
      annfiles: this.formatFiles(values.annfiles),
      sealfiles: this.formatFiles(values.sealfiles),
      tradetype: this.joinArray(values.tradetype, ';'),
      fundcode: this.joinArray(values.fundcode, ';'),
      organinfoid: this.joinArray(values.organinfoid, ';'),
      funds: values.funds?.map((e) => {
        e.largeStatus = e.largeStatus.join(',');
        return e;
      }),
      limitamount: Number(values.limitamount?.replace(/,/g, '')),
      beforelimitamount: Number(values.beforelimitamount?.replace(/,/g, '')),
      afterlimitamount: Number(values.afterlimitamount?.replace(/,/g, '')),
      // sellers: this.joinArray(values.sellers, ';'),
    };
  }
  applySubmit(values) {
    console.log('提交前的数据', values);
    const result = values;
    let data = this.formatData(result);
    return data;
  }
  auditSubmit(values) {
    console.log('提交前的数据auditSubmit', values);
    const result = values;
    if (this.elementCode === '30') {
      if (
        (result.subred40.countersigndeparts || []).length === 0 &&
        (result.subred40.countersignusers || []).length === 0
      ) {
        this.antMessage.info('会签部门、会签人必须选填其中一项');
        return false;
      }
    }
    let data = this.formatData(result);
    if (this.organinfoids) {
      data.organinfoid = this.organinfoids.join(';');
    }
    console.log('提交后的数据auditSubmit', data);
    return data;
  }
  daftSubmit(values) {
    return this.formatData(values);
  }
  /** 格式化初始数据 */
  initFormatData = (data) => {
    const funds = data.funds?.map((e) => {
      e.largeStatus = (isString(e.largeStatus) && e.largeStatus.split(',')) || [];
      return e;
    });
    ['limitamount', 'beforelimitamount', 'afterlimitamount'].forEach((e) => {
      data[e] = convert.toThousands(data[e]);
    });
    data.subred40 = toggleSignType(data.subred40);
    return { ...data, funds };
  };

  /** 首次提交 初始化数据 */
  applyFormatData(formData) {
    return this.initFormatData(formData);
  }

  /** 非首次(审核提交) 初始化数据 */
  auditFormatData(formData) {
    return this.initFormatData(formData);
  }

  getParameters() {
    const formid = this.formData.id;

    const fieldsValue = { formid };
    // 批量取出字段
    const fields = [
      'fundcode',
      'pausepurdate',
      'pausereddate',
      'pausequantdate',
      'recoverpurdate',
      'recoverreddate',
      'recoverquantdate',
      'limitsaledate',
      'recoversaledate',
      'limitamount',
      'tradereason',
      'tradetype',
      'anndate',
      'funds',
      'changelimitdate',
      'beforelimitamount',
      'afterlimitamount',
    ];
    this.formActions.getFormState((state) => {
      fields.forEach((e) => {
        let v;
        const stateValue = state.values[e];

        switch (e) {
          case 'funds':
            v = cloneDeep(stateValue).map((it) => {
              if (Array.isArray(it.largeStatus)) {
                it.largeStatus = it.largeStatus.join(',');
              }
              return it;
            });
            break;
          case 'fundcode':
            v = stateValue?.join(';');
            break;
          case 'tradetype':
            v = stateValue?.join(',');
            break;
          case 'pausepurdate':
          case 'pausereddate':
          case 'pausequantdate':
          case 'recoverpurdate':
          case 'recoverreddate':
          case 'recoverquantdate':
          case 'limitsaledate':
          case 'recoversaledate':
          case 'anndate':
            v = stateValue ? moment(stateValue).format('YYYY-MM-DD') : '';
            break;
          case 'limitamount':
          case 'beforelimitamount':
          case 'afterlimitamount':
            v = Number(stateValue?.replace(/,/g, ''));
            break;
          default:
            v = stateValue;
        }

        fieldsValue[e] = v;
      });
    });

    return fieldsValue;
  }
  /**
   * 提交前置提示
   * @param values
   * @param next
   * @returns {boolean}
   */
  submitConfirm(values, next) {
    if (this.pageStatus.firstEditable || this.pageStatus.applyEditable) {
      this.antModal.confirm({
        title: '请确认',
        content: (
          <div style={{ color: 'red' }}>
            <div>请仔细确认您所填写的内容是否正确，如果送审，系统将不支持手工撤单；</div>
            <ul style={{ paddingLeft: '25px' }}>
              <li>如果确认送审 ，请点击“是”，</li>
              <li>否则请点击“否”，重新填写相关内容。</li>
            </ul>
          </div>
        ),
        okText: '是',
        cancelText: '否',
        onOk(close) {
          close();
          next(true);
        },
        onCancel(close) {
          close();
          next(false);
        },
      });
    } else {
      if (['60'].includes(this.elementCode)) {
        this.antModal.confirm({
          title: '请确认',
          content: <span style={{ color: 'red' }}>确认公告已发布？</span>,
          okText: '是',
          cancelText: '否',
          onOk(close) {
            close();
            next(true);
          },
          onCancel(close) {
            close();
            next(false);
          },
        });
      } else {
        next(true);
      }
    }
  }
  get expressionScope() {
    const { setFieldValue } = this.formActions;
    return {
      // 公告信息生成公告
      generateNotice: () => {
        const list = this.getParameters();
        this.antMessage.loading('公告文件生成中...');
        this.dispatcher.subRedProjectUpload({ ...list }).then((res) => {
          if (res.data && !res.error) {
            this.filename = res.data.filename;
            this.filepath = res.data.filepaths;
            this.fileid = res.data.fileid;
            this.antMessage.destroy();
            this.antMessage.info('生成公告成功');
            this.formActions.setFieldState('annfiles', (state) => {
              state.description = '';
              state.value = res.data;
            });
          } else {
            this.antMessage.destroy();
            this.antMessage.error(res.message || '公告文件生成失败！');
          }
        });
      },
      // 交易所申请函
      applyBtnNotice: () => {
        const list = this.getParameters();
        this.antMessage.loading('公告文件生成中...');
        this.dispatcher.subredapplyProjectUpload({ ...list }).then((res) => {
          if (res.data && !res.error) {
            this.filename = res.data.filename;
            this.filepath = res.data.filepaths;
            this.fileid = res.data.fileid;
            this.antMessage.destroy();
            this.antMessage.info('生成公告成功');
            this.formActions.setFieldState('sealfiles', (state) => {
              state.description = '';
              state.value = res.data;
            });
          } else {
            this.antMessage.destroy();
            this.antMessage.error(res.message || '公告文件生成失败！');
          }
        });
      },

      fileSuccess: (name) => {
        const { setFieldState } = this.formActions;
        return function ({ file }) {
          if (file && file.status === 'done') {
            setFieldState(name, (state) => {
              const currentFileList = state.value || [];
              let newFileList = [
                { fileId: file.response.fileid || '', ...file },
                ...currentFileList,
              ];
              state.value = newFileList;
              state.description = '';
            });
          }
        };
      },
      fileDel: (name) => {
        const { setFieldState } = this.formActions;
        return function (file) {
          setFieldState(name, (state) => {
            const currentFileList = state.value || [];
            const newFileList = currentFileList.filter((item) => {
              if (item.response) {
                return item.response.fileid !== file.response.fileid;
              }
              return item.id ? item.id !== file.id : item.fileid !== file.fileid;
            });
            state.description = '';
            state.value = [...newFileList];
          });
        };
      },
      // 发布公告
      publishNotice: async () => {
        const { processId } = this.props.context;
        const annfiles = this.formActions.getFieldValue('annfiles') || [];
        const fileid = annfiles[0].fileid;
        const fundcode = this.formActions.getFieldValue('fundcode') || '';
        if (Array.isArray(annfiles) && annfiles.length > 0) {
          this.antMessage.loading('公告文件发布中...', 0);
          const res = await this.dispatcher.pubNotice({
            fileid: fileid,
            mainfundcodes: fundcode,
            processid: processId,
          });
          if (res && res.data) {
            // let url = '';
            // const hostname = window.location.hostname || '';
            // if (hostname.includes('localhost') || hostname.includes('172.30')) {
            //   url = '172.30.81.91/pdt/';
            // }
            // if (hostname.includes('apptest')) {
            //   url = 'apptest.fsfund.com:7172/fsyy/pdt-web/';
            // }
            // if (hostname.includes('fsapi') || hostname.includes('research')) {
            //   url = 'research.fsfund.com/web/pdt/';
            // }
            this.antMessage.success('公告生成成功，即将跳转发布页面', 1.5, () => {
              // window.open(`//${url}#/app/pdt/notice/list?eid=${res.data}`);
              window.open(`#/app/pdt/notice/list?eid=${res.data}`);
            });
            this.antMessage.destroy();
          } else {
            this.antMessage.info(res.msg || '公告文件发布失败');
          }
        }
      },
      onAmountBlur: (name) => (e) => {
        const value = isNaN(Number(e.target.value)) ? null : e.target.value;
        setFieldValue(name, convert.toThousands(value));
      },
      onAmountFocus: (name) => (e) => {
        setFieldValue(name, e.target.value?.replace(/,/g, ''));
      },
    };
  }
}
