import React from 'react';
import { Field } from 'formily-antd';
import BasicFormCard from '@chinahorm/web-components/es/components/BasicFormCard';
import {
  useDictList,
  useFundFullList,
} from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import { isMobile } from '@/utils';
import { renderSign } from '../../utils';

function Form(props) {
  const {
    context: { formData, getProcess },
    formEffects: { dictData },
  } = props;
  const { elementCode, readOnlyFlag, firstTokenFlag, elementId, endElementId } = getProcess() || {};

  const megaProps = {
    labelWidth: 160,
    responsive: { lg: 3, m: 2, s: 1 },
    contextResponsive: { lg: 3, m: 2, s: 1 },
  };
  // const { pageEditable } = usePageStatus(props)
  // const megaProps = {
  //   labelWidth: 140,
  //   responsive: { lg: 4, m: 2, s: 1 },
  //   contextResponsive: { lg: 4, m: 2, s: 1 },
  // };

  // const megaLayoutProps = useMegaLayoutProps(megaProps);
  const endFlag = elementId === endElementId;

  const tradetypeRequest = useDictList({ id: '41e9adb99d934f73b92fc62cd5f25de3' });

  // 会签是否可编辑
  const isEditable =
    (['10'].includes(elementCode) &&
      !readOnlyFlag &&
      formData.applydepartmentid === '53479972-4DC3-461C-A004-45AC49B5AB81') ||
    (['30'].includes(elementCode) && !readOnlyFlag);
  const isVisible =
    formData.applydepartmentid === '53479972-4DC3-461C-A004-45AC49B5AB81' ||
    (!['10', '20'].includes(elementCode) && !firstTokenFlag) ||
    endFlag;
  // 公告原因，事由是否显示
  // const isInformationVisible = formData.applydepartmentid === ('53479972-4DC3-461C-A004-45AC49B5AB81')
  const visible = isMobile();

  return (
    <>
      <BasicFormCard title="基本信息" megaProps={megaProps}>
        <Field
          name="code"
          title="单据编号"
          type="string"
          default="单据提交后自动生成"
          editable={false}
        />
        <Field
          name="applydate"
          title="申请日期"
          type="date"
          x-component-props={{ format: 'YYYY-MM-DD' }}
          editable={false}
        />
        <Field name="applyusername" title="申请人" type="string" editable={false} />
        <Field name="applydepartmentname" title="所属部门" type="string" editable={false} />
      </BasicFormCard>

      <BasicFormCard title="基金信息" megaProps={megaProps}>
        <Field
          name="fundcode"
          title="基金名称"
          type="tree-select"
          required
          display={elementCode === '10' && !readOnlyFlag ? true : false}
          x-mega-props={{ span: 3 }}
          x-component-props={{
            optionFilterProp: 'label',
            placeholder: '请输入基金名称',
            ...useFundFullList({
              fundperiod: '存续期',
              multiple: true,
            }),
            style: { maxWidth: 600 },
            renderLabel: (text, record) =>
              (elementCode === '10' && !readOnlyFlag) ||
              (Number(formData.status) === 1 && !readOnlyFlag) ? (
                text.label
              ) : (
                <>
                  <span>{text.title}</span>
                  <br />
                </>
              ),
          }}
        />
        <Field
          title={visible ? '' : '份额详情'}
          name="funds"
          type="array"
          x-component="form-table"
          // display={visible}
          x-component-props={{
            renderMoveDown: () => null,
            renderMoveUp: () => null,
            renderAddition: () => null,
            renderAdditionCount: () => null,
            renderCopy: () => null,
            renderRemove: () => null,
            rowSelection: null,
            visibleColumns: [
              { name: 'largeStatus', visible: false },
              { name: 'limitAmtInfo', visible: elementCode === '10' && !readOnlyFlag },
            ],
          }}
          x-mega-props={{ span: visible ? 4 : 3 }}
        >
          <Field type="object">
            <Field
              name="fundcode"
              title="基金代码"
              type="string"
              editable={false}
              x-component-props={{ style: { minWidth: 80 } }}
            />
            <Field
              name="fundname"
              title="基金名称"
              type="string"
              editable={false}
              x-component-props={{ style: { minWidth: 200 } }}
            />
            <Field
              name="fundstatus"
              title="当前状态"
              type="string"
              editable={false}
              x-component-props={{ style: { minWidth: 80 } }}
            />
            <Field
              editable={elementCode === '10' && !readOnlyFlag}
              name="largeStatus"
              title="大额类型"
              type="checkbox"
              enum={[
                { label: '申赎', value: '申赎' },
                { label: '定投', value: '定投' },
                { label: '转换', value: '转换' },
              ]}
              x-component-props={{
                style: { minWidth: 200 },
                // checkAll: false,
                // disabled: pageEditable ? false : true,
              }}
            />
            <Field
              name="limitAmtInfo"
              title="限额详情"
              type="string"
              editable={false}
              x-component-props={{ style: { whiteSpace: 'pre-line' } }}
            />
          </Field>
        </Field>
        <Field
          name="tradetype"
          title="交易类型"
          type="tree-select"
          required
          x-component-props={{
            tokenSeparators: [','],
            ...tradetypeRequest,
            style: { maxWidth: 500 },
            multiple: true,
          }}
        />
        <Field
          name="tradetypeMsg"
          type="string"
          editable={false}
          x-mega-props={{
            span: 2,
            labelWidth: 0,
          }}
          x-component-props={{
            style: { color: 'orange' },
          }}
        />
        {dictData.map((item, index) => {
          return (
            <Field
              name={item.name}
              title={`${item.title}起始日期`}
              type="date"
              required
              key={index}
              visible={false}
              x-component-props={{
                format: 'YYYY-MM-DD',
                style: { maxWidth: 500 },
                placeholder: `请选择${item.title}起始日期`,
              }}
              // x-mega-props={{ span: item.span || 4 }}
            />
          );
        })}
        <Field
          name="limitamount"
          title="限售金额"
          type="string"
          required
          visible={false}
          x-component-props={{
            placeholder: '请输入限售金额',
            onBlur: '{{onAmountBlur("limitamount")}}',
            onFocus: '{{onAmountFocus("limitamount")}}',
            style: { maxWidth: 500 },
          }}
        />
        <Field
          name="beforelimitamount"
          title="调整前的限售金额"
          type="string"
          required
          visible={false}
          x-component-props={{
            placeholder: '请输入整前的限售金额',
            onBlur: '{{onAmountBlur("beforelimitamount")}}',
            onFocus: '{{onAmountFocus("beforelimitamount")}}',
            style: { maxWidth: 500 },
          }}
        />
        <Field
          name="afterlimitamount"
          title="调整后的限售金额"
          type="string"
          required
          visible={false}
          x-component-props={{
            placeholder: '请输入整后的限售金额',
            onBlur: '{{onAmountBlur("afterlimitamount")}}',
            onFocus: '{{onAmountFocus("afterlimitamount")}}',
            style: { maxWidth: 500 },
          }}
        />
        <Field
          name="anndate"
          title="公告日期"
          type="date"
          required
          x-mega-props={{
            span: 4,
          }}
          x-component-props={{
            placeholder: '请选择公告日期',
            format: 'YYYY-MM-DD',
            style: { maxWidth: 500 },
          }}
        />
        <Field
          name="elseremark"
          title="其他交易类型说明"
          type="textarea"
          visible={false}
          x-component-props={{
            placeholder: `请输入其他交易类型`,
            previewPlaceholder: '-',
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="eventreason"
          title="事由"
          type="textarea"
          x-component-props={{
            placeholder: `请输入事由`,
            previewPlaceholder: '-',
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="tradereason"
          title="公告原因"
          type="textarea"
          // visible={isInformationVisible}
          visible={isVisible}
          editable={isEditable}
          x-component-props={{
            placeholder: `请输入公告原因`,
            previewPlaceholder: '-',
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="relatesaler"
          title="涉及销售商"
          type="textarea"
          x-component-props={{
            placeholder: `请填写涉及的销售商`,
            previewPlaceholder: '-',
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="note"
          title="备注"
          type="textarea"
          x-component-props={{
            placeholder: `请输入备注信息`,
            previewPlaceholder: '-',
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />

        <Field
          name="organinfoid"
          title="选择销售商"
          type="tree-select"
          visible={false}
          x-component-props={{
            placeholder: `请填写涉及的销售商`,
            previewPlaceholder: '-',
            autoSize: { minRows: 3, maxRows: 20 },
          }}
          x-mega-props={{ span: 4 }}
        />
      </BasicFormCard>

      {renderSign({
        name: 'subred40',
        title: '会签信息',
        display: isVisible,
        editable: isEditable,
        isseal: {
          show: true,
          title: '交易所申请函',
        },
      })}

      <BasicFormCard title="公告信息" megaLayout={megaProps} visible={isVisible}>
        <Field
          title="公告文件"
          name="annfiles"
          type="bpm-upload-list"
          editable={isEditable}
          x-component-props={{
            onSuccess: '{{fileSuccess("annfiles")}}',
            onDel: '{{fileDel("annfiles")}}',
            accept: '.doc,.docx',
            multiple: true,
            isFsfund: true,
            // maxLength: 4,
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          name="generatebtn"
          type="button"
          editable={isEditable}
          x-component-props={{
            text: '生成公告',
            onClick: '{{generateNotice}}',
          }}
        />
      </BasicFormCard>
      <BasicFormCard
        title="发布公告"
        megaLayout={megaProps}
        visible={(['60', '70'].includes(elementCode) && !firstTokenFlag) || endFlag}
      >
        <Field
          title="发布公告"
          name="publishnotice"
          type="button"
          editable={['60'].includes(elementCode) && !readOnlyFlag}
          x-component-props={{
            text: '点击跳转发布',
            onClick: '{{publishNotice}}',
          }}
          x-mega-props={{ span: 4 }}
        />
        <Field
          name="isxrbl"
          title="是否公告XBRL"
          type="radio"
          default="0"
          enum={[
            { label: '是', value: '1' },
            { label: '否', value: '0' },
          ]}
          x-component-props={{ size: 'middle' }}
          editable={['60'].includes(elementCode) && !readOnlyFlag}
        />
        <Field
          title=""
          name="makingnotice"
          type="button"
          visible={false}
          editable
          x-component-props={{
            text: '制作',
          }}
        />
      </BasicFormCard>

      <BasicFormCard title="交易所申请函" megaLayout={megaProps} visible={isVisible}>
        <Field
          title="申请函文件"
          name="sealfiles"
          type="bpm-upload-list"
          editable={isEditable}
          x-component-props={{
            onSuccess: '{{fileSuccess("sealfiles")}}',
            onDel: '{{fileDel("sealfiles")}}',
            accept: '.doc,.docx',
            multiple: true,
            isFsfund: true,
            // maxLength: 4,
          }}
          x-mega-props={{ span: 2 }}
        />
        <Field
          name="applyBtn"
          type="button"
          editable={isEditable}
          x-component-props={{
            text: '生成文件',
            onClick: '{{applyBtnNotice}}',
          }}
        />
      </BasicFormCard>
    </>
  );
}

export default Form;
