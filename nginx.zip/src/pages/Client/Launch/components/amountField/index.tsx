import React from 'react';
import { InputNumber } from 'antd';
import { useFieldState } from 'formily-antd';
import { convert } from '@cerdo/cerdo-utils';

/** 千分位符 */
const AmountField = (props) => {
  const [field] = useFieldState(null);

  if (field.editable) {
    return (
      <InputNumber
        formatter={(value) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
        parser={(value) => value!.replace(/\$\s?|(,*)/g, '')}
        {...props}
      />
    );
  }

  return <span>{convert.renderThousands(props.value)}</span>;
};

export default AmountField;
