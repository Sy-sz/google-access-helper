import React from 'react';
import FormModal from '@/pages/notice/noticeMg/com/formModal';
import { message } from 'antd';

const NoticeModal = (props) => {
  const {
    visible,
    noticeid,
    publishdate,
    urlNoticeId = null,
    noticetypeOptions = [],
    setFieldState,
    fundcode,
    noticetypeid,
  } = props;

  const closeModal = () => {
    setFieldState('formModal', (state) => {
      state.props['x-component-props'] = { ...state.props['x-component-props'], visible: false };
    });
  };

  return (
    <FormModal
      modalFrom="liquidation"
      title="修改公告"
      id={noticeid}
      publishdate={publishdate}
      visible={visible}
      urlNoticeId={urlNoticeId}
      noticetypeid={noticetypeid}
      noticetypeOptions={noticetypeOptions}
      fundcode={fundcode}
      onCancel={closeModal}
      onOk={() => {
        closeModal();
        message.success('操作成功');
        window.location.reload();
      }}
    />
  );
};

export default NoticeModal;
