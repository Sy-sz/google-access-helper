import React from 'react';
import { Button } from 'antd';

const ButtonField = (props) => {
  const { text, onChange } = props;

  return (
    <Button onClick={() => onChange(Math.random())} {...props}>
      {text}
    </Button>
  );
};

export default ButtonField;
