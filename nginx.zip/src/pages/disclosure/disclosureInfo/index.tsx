// 合规驾驶舱 信息披露
import React, { useRef, useMemo } from 'react';
import { Button, Popconfirm, message } from 'antd';
import { SearchAgGridTable } from '@cerdo/cerdo-design';
import { disclosureRuleList } from '@/common/axios/config';
import { columnDefs } from './components/data';
import { IColumnDefs } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import AddOrEditModal from './components/AddOrEditModal';
import { cloneDeep } from 'lodash';
import { disclosureRuleEnable, disclosureRuleDisable, disclosureRuleDelete } from '@/common/axios';

const Index = () => {
  const searchAgTableRef = useRef(null);
  const addOrEditModalRef = useRef(null);

  const onOpen = (rows) => {
    addOrEditModalRef.current?.toOpenModal(cloneDeep(rows));
  };

  // 提交form并刷新表格
  const refreshTable = () => {
    searchAgTableRef.current.onSearch();
  };

  const onDelete: Function = async (id) => {
    const [err] = await disclosureRuleDelete({ id });
    if (err) {
      return;
    }
    message.success('删除成功');
    refreshTable();
  };

  const onEnable: Function = async (id) => {
    const [err] = await disclosureRuleEnable({ id });
    if (err) {
      return;
    }
    message.success('启用成功');
    refreshTable();
  };

  const ondisable: Function = async (id) => {
    const [err] = await disclosureRuleDisable({ id });
    if (err) {
      return;
    }
    message.success('禁用成功');
    refreshTable();
  };

  const columns: IColumnDefs = useMemo(
    () => [
      ...columnDefs,
      {
        headerName: '操作',
        width: 120,
        headerAlign: 'center',
        cellRenderer: (rows) => {
          return (
            <>
              <Button
                type="link"
                size="small"
                style={{ padding: '5px 5px' }}
                onClick={() => onOpen(rows.data)}
              >
                编辑
              </Button>
              {rows.data.isEnabled === '1' ? (
                <Button
                  type="link"
                  size="small"
                  style={{ padding: '5px 5px' }}
                  onClick={() => ondisable(rows.data.id)}
                >
                  禁用
                </Button>
              ) : (
                <Button
                  type="link"
                  size="small"
                  style={{ padding: '5px 5px' }}
                  onClick={() => onEnable(rows.data.id)}
                >
                  启用
                </Button>
              )}
              <Popconfirm
                title="确认删除？"
                placement="topRight"
                onConfirm={() => onDelete(rows.data.id)}
              >
                <Button type="link" size="small" style={{ padding: '5px 5px' }}>
                  删除
                </Button>
              </Popconfirm>
            </>
          );
        },
        hideInSearch: true,
      },
    ],
    [],
  );

  return (
    <>
      <SearchAgGridTable
        method="get"
        url={disclosureRuleList}
        ref={searchAgTableRef}
        actionBtns={[
          <Button
            key="add"
            type="primary"
            onClick={() => {
              onOpen(null);
            }}
          >
            新增
          </Button>,
        ]}
        tableConfig={{
          autoHeight: true,
          columnDefs: columns,
        }}
      />
      <AddOrEditModal
        ref={addOrEditModalRef}
        onSave={() => {
          refreshTable();
        }}
      />
    </>
  );
};

export default Index;
