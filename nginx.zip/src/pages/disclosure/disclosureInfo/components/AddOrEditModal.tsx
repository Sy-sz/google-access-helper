import React, { useState, useImperativeHandle } from 'react';
import { Form, Input, message, Button, Table } from 'antd';
import { cloneDeep } from 'lodash';
import { convert } from '@cerdo/cerdo-utils';
import { DragModal, DictSelectPlus, UploadFile } from '@cerdo/cerdo-design';
import { disclosureRuleSave, commonApi, ossBaseFileInfoList } from '@/common/axios';
import DateForm from './DateForm';
import { uploadFileApi, downloadFileApi } from 'common/axios/config';
import styles from './index.scss';

interface IEditorModalProps {
  onSave?: () => void;
  [key: string]: any;
}

const AddOrEditModal: React.FC<IEditorModalProps> = React.forwardRef((props, ref) => {
  const { onSave } = props;
  const formRef = React.useRef(null);
  const dateFormRef = React.useRef(null);
  const [visible, setVisible] = useState(false);
  const [rows, setRows] = useState<any>({});
  const [title, setTitle] = useState('');
  const [tableData, setTableData] = useState([]);
  const [loading, setLoading] = useState(false);

  const setStatePromise = () => {
    return new Promise((resolve) => {
      resolve(true);
    });
  };

  // 加载oss文件列表
  const loadOssFileList = async (fileIdList) => {
    const [err, result] = await ossBaseFileInfoList({ fileIdList });
    if (err) {
      return;
    }
    const fileList = result?.data?.map((item) => {
      return {
        fileid: item.fileId,
        filename: item.fileName,
        filesize: item.size,
        filepath: item.filePath,
      };
    });
    setTableData(fileList);
  };

  // 打开模态框
  const toOpenModal = (rows?: any) => {
    setVisible(true);
    if (rows) {
      setTitle('修改配置');
      rows.cooperateObj = rows.cooperateObj ? rows.cooperateObj.split(',') : [];
      rows.chargeObj = rows.chargeObj ? rows.chargeObj.split(',') : [];
      rows.focusObj = rows.focusObj ? rows.focusObj.split(',') : [];
      rows.day = rows.day ? rows.day.split(',') : [];
      rows.month = rows.month ? rows.month.split(',') : [];
      rows.quarter = rows.quarter ? rows.quarter.split(',') : [];
      rows.week = rows.week ? rows.week.split(',') : [];
      rows.noticeDay = rows.noticeDay ? rows.noticeDay.split(';') : [];
      if (rows.attachment) {
        loadOssFileList(rows.attachment.split(','));
      }
      setRows(rows);
    } else {
      setTitle('新增配置');
      setRows(null);
      setTableData([]);
    }
    setStatePromise().then(() => {
      const formData = rows ? cloneDeep(rows) : {};
      formRef.current?.setFieldsValue(formData);
      dateFormRef.current?.initData(rows ? formData : null);
      console.log('formdata', formData);
    });
  };

  // 暴露给父组件的方法
  useImperativeHandle(ref, () => ({ toOpenModal }));

  // 关闭模态框
  const toCloseModal = () => {
    formRef.current?.resetFields();
    setVisible(false);
  };

  // 新增、编辑配置
  const handleOkClick = () => {
    formRef.current?.validateFields().then(
      (values) => {
        dateFormRef.current?.getData().then(async (dateValues) => {
          setLoading(true);
          const params = {
            ...values,
            ...dateValues,
            attachment: tableData?.map((item) => item.fileid)?.join(','),
            id: rows?.id,
            focusObj: values.focusObj?.join(','),
            cooperateObj: values.cooperateObj?.join(','),
            chargeObj: values.chargeObj?.join(','),
          };
          const [err] = await disclosureRuleSave(params);
          if (err) {
            setLoading(false);
            return;
          }
          setLoading(false);
          message.success(`${title}成功`);
          onSave?.();
          toCloseModal();
        });
      },
      (err) => {
        if (err?.errorFields?.length) {
          message.warning(err.errorFields[0]['errors']);
        }
      },
    );
  };

  const handleBeforeUpload = (file) => {
    if (file) {
      const fileArr = (file.name || '').split('.');
      if (
        !['ZIP', 'RAR', 'PDF', 'DOC', 'DOCX', 'XLS', 'XLSX'].includes(
          fileArr[fileArr.length - 1].toUpperCase(),
        )
      ) {
        message.warning(`【${file.name}】文件格式不支持`);
        return Promise.reject();
      }
      if (tableData.find((a) => a.filename === file.name)) {
        message.warning(`【${file.name}】文件已存在`);
        return Promise.reject();
      }
      return Promise.resolve();
    }
    return Promise.reject();
  };

  const handleUploadChange = (file: any) => {
    const fileList = [...(tableData || []), file];
    setTableData(fileList);
  };

  const getColumns = () => {
    return [
      {
        title: '文件名',
        dataIndex: 'filename',
        key: 'filename',
        width: 400,
        render(text, record) {
          return (
            <Button
              type="link"
              onClick={() =>
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi)
              }
            >
              {text}
            </Button>
          );
        },
      },
      {
        title: '文件大小',
        dataIndex: 'filesize',
        key: 'filesize',
        width: 80,
        render(text) {
          if (text === 0) {
            return text;
          }

          return convert.toFileSize(text) || 0;
        },
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 40,
        render: (text, record) => {
          return (
            <Button
              type="link"
              danger
              onClick={() => {
                setTableData(tableData.filter((a) => a.fileid !== record.fileid));
              }}
            >
              删除
            </Button>
          );
        },
      },
    ];
  };

  return (
    <DragModal
      visible={visible}
      title={title}
      width={1000}
      maskClosable={false}
      onOk={handleOkClick}
      onCancel={toCloseModal}
      okText="确认"
      cancelText="取消"
      confirmLoading={loading}
      style={{ top: 50 }}
    >
      <h3 className={styles['title-h3']}>基本信息</h3>
      <Form
        ref={formRef}
        autoComplete="off"
        labelCol={{ span: 3 }}
        labelAlign="right"
        wrapperCol={{ span: 21 }}
      >
        <Form.Item
          label="披露事项"
          name="name"
          rules={[{ required: true, message: '披露事项不能为空' }]}
        >
          <Input placeholder="请输入披露事项" />
        </Form.Item>
        <Form.Item label="法律依据" name="legalBasis">
          <Input.TextArea placeholder="请输入法律依据" />
        </Form.Item>
        <Form.Item label="报送对象" name="submitObj">
          <Input placeholder="请输入报送对象" />
        </Form.Item>
        <Form.Item label="归属部门" name="chargeObj">
          <DictSelectPlus
            placeholder="请输入归属部门"
            style={{ width: '100%' }}
            dictId="22ee5a77-f7ca-47b8-9c83-c91514d5ed62"
            mode="multiple"
          />
        </Form.Item>
        <Form.Item label="协同部门" name="cooperateObj">
          <DictSelectPlus
            placeholder="请输入协同部门"
            style={{ width: '100%' }}
            dictId="22ee5a77-f7ca-47b8-9c83-c91514d5ed62"
            mode="multiple"
          />
        </Form.Item>
        <Form.Item label="传阅对象" name="focusObj">
          <DictSelectPlus
            placeholder="请输入传阅对象"
            style={{ width: '100%' }}
            dictId="22ee5a77-f7ca-47b8-9c83-c91514d5ed62"
            mode="multiple"
          />
        </Form.Item>
        <Form.Item label="发送方式" name="sendType">
          <DictSelectPlus
            placeholder="请输入发送方式"
            style={{ width: '100%' }}
            dictId="f47a033e-b0f5-4c74-8f9c-78660879c235"
          />
        </Form.Item>
      </Form>
      <h3 className={styles['title-h3']}>日期设置</h3>
      <DateForm ref={dateFormRef} />
      <h3 className={styles['title-h3']}>附件</h3>
      <div>
        <UploadFile
          uploadUrl={uploadFileApi}
          downloadUrl={downloadFileApi}
          accept=".pdf,.PDF,.doc,.docx,.xls,.xlsx,.zip,.rar"
          multiple
          showUploadList={false}
          beforeUpload={handleBeforeUpload}
          onChange={handleUploadChange}
        >
          <Button type="primary">上传附件</Button>
        </UploadFile>
        <Table
          pagination={false}
          rowKey="fileid"
          size="small"
          scroll={{ y: 200 }}
          columns={getColumns()}
          dataSource={tableData}
        />
      </div>
    </DragModal>
  );
});

export default AddOrEditModal;
