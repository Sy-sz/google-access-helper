function convertToChinaNum(num) {
  const arr1 = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
  const arr2 = ['', '十']; // 可继续追加更高位转换值
  if (!num || isNaN(num)) {
    return '零';
  }
  const english = num.toString().split('');
  let result = '';
  for (let i = 0; i < english.length; i += 1) {
    const des_i = english.length - 1 - i; // 倒序排列设值
    result = arr2[i] + result;
    const arr1_index = english[des_i];
    result = arr1[arr1_index] + result;
  }
  return result;
}

function generate(startNum: number, endNum: number, isCn: boolean, prefix: string, suffix: string) {
  let array = [];
  for (let i = 1; i <= endNum; i += 1) {
    array.push({
      key: `${i}`,
      label: `${prefix}${isCn ? convertToChinaNum(i) : i}${suffix}`,
      value: `${i}`,
    });
  }
  for (let i = -1; i >= startNum; i -= 1) {
    array.push({
      key: `${i}`,
      label: `倒数${prefix}${isCn ? convertToChinaNum(-i) : -i}${suffix}`,
      value: `${i}`,
    });
  }
  return array;
}

const frequencyType = {
  Year: 'year',
  Quarter: 'quarter',
  Month: 'month',
  Week: 'week',
  Day: 'day',
};

const frequencyValueList = ['year', 'quarter', 'month', 'week', 'day'];

const frequencyList = [
  {
    key: '1',
    label: '年',
    value: 'year',
  },
  {
    key: '2',
    label: '季度',
    value: 'quarter',
  },
  {
    key: '3',
    label: '月',
    value: 'month',
  },
  {
    key: '4',
    label: '周',
    value: 'week',
  },
  {
    key: '5',
    label: '日',
    value: 'day',
  },
];

const type = {
  Quarter: 'quarter',
  Month: 'month',
  Week: 'week',
  Day: 'day',
};

const ofType = {
  MonthByYear: 'monthByYear',
  MonthByQuarter: 'monthByQuarter',
  DayByMonth: 'dayByMonth',
  DayByWeek: 'dayByWeek',
};

const pointType = {
  Quarter: 'quarter',
  Month: 'month',
  Week: 'week',
  DayByMonth: 'dayByMonth',
  DayByWeek: 'dayByWeek',
};

const dayType = [
  {
    key: '1',
    label: '自然日',
    value: 'natureDay',
  },
  {
    key: '2',
    label: '工作日',
    value: 'tradeDay',
  },
];

const radioType = {
  Per: 'per',
  Appoint: 'appoint',
  NoAppoint: 'noAppoint',
};

const postponeType = {
  Front: 'front',
  Behind: 'behind',
};
const radioList = [
  {
    label: '每',
    value: 'per',
  },
  {
    label: '指定',
    value: 'appoint',
  },
  {
    label: '不指定',
    value: 'noAppoint',
  },
];

const radioListSimple = [
  {
    label: '每',
    value: 'per',
  },
  {
    label: '指定',
    value: 'appoint',
  },
];

const quarterList = generate(1, 4, true, '第', '季度');

const monthByYearList = generate(1, 12, false, '', '月');

const monthByQuarterList = generate(1, 3, false, '第', '个月');

const weekByMonthList = generate(1, 4, false, '', '');

const dayByMonthList = generate(1, 31, false, '', '');

const dayByWeekList = [
  ...generate(1, 7, true, '周', '').slice(0, 6),
  {
    key: '7',
    label: '周日',
    value: '7',
  },
];

export default {
  type,
  ofType,
  quarterList,
  monthByYearList,
  monthByQuarterList,
  weekByMonthList,
  dayByMonthList,
  dayByWeekList,
  dayType,
  convertToChinaNum,
  pointType,
  frequencyType,
  frequencyList,
  frequencyValueList,
  radioType,
  postponeType,
  radioList,
  radioListSimple,
};
