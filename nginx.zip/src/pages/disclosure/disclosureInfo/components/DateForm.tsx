import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { Checkbox, Radio, Space, message, Form, InputNumber, Button, TimePicker } from 'antd';
import dateEnum from './dateEnum';
import styles from './index.scss';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import moment from 'moment';

const formItemLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 3 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 21 },
  },
};
const formItemLayoutWithOutLabel = {
  wrapperCol: {
    xs: { span: 24, offset: 0 },
    sm: { span: 21, offset: 3 },
  },
};

const formItemLayoutWithOutLabelSmall = {
  wrapperCol: {
    xs: { span: 24, offset: 0 },
    sm: { span: 9, offset: 3 },
  },
};

const DateForm: React.FC<any> = forwardRef((props, ref) => {
  const {
    frequencyType,
    frequencyList,
    quarterList,
    monthByYearList,
    monthByQuarterList,
    dayByMonthList,
    dayByWeekList,
    frequencyValueList,
    dayType: dayTypeList,
    radioType,
    postponeType,
    radioList,
    radioListSimple,
  } = dateEnum;

  const formRef = useRef(null);

  const [radioDay, setRadioDay] = useState<string>(radioType.Per);
  const [radioMonth, setRadioMonth] = useState<string>(radioType.NoAppoint);
  const [radioQuarter, setRadioQuarter] = useState<string>(radioType.NoAppoint);
  const [dayType, setDayType] = useState<string>('natureDay');
  const [day, setDay] = useState<string[]>([]);
  const [quarter, setQuarter] = useState<string[]>([]);
  const [month, setMonth] = useState<string[]>([]);
  const [frequency, setFrequency] = useState<string>(frequencyType.Year);
  const [nonTradeDayPostpone, setNonTradeDayPostpone] = useState<boolean>(false);
  const [description, setDescription] = useState<string>();
  const [appointMonthOrWeek, setAppointMonthOrWeek] = useState<string>(radioType.NoAppoint);
  const [noticePostpone, setNoticePostpone] = useState<string>();
  const [noticeDayType, setNoticeDayType] = useState<string>('natureDay');

  const sort = (arr: string[]): string[] => {
    arr.sort((a: string, b: string) =>
      parseInt(a, 10) > parseInt(b, 10) ? 1 : parseInt(b, 10) > parseInt(a, 10) ? -1 : 0,
    );
    return arr;
  };

  useEffect(() => {
    let yearDesc = frequency === 'year' ? '每年，' : '';
    let quaterDesc =
      radioQuarter === radioType.Per
        ? '每季度，'
        : radioQuarter === radioType.Appoint
          ? quarter?.length > 0
            ? `第${sort(quarter).join(',')}季度，`
            : '***，'
          : '';
    let monthDesc =
      radioMonth === radioType.Per
        ? '每月，'
        : radioMonth === radioType.Appoint
          ? month?.length > 0
            ? `第${sort(month).join(',')}个月，`
            : '***，'
          : '';
    let weekDesc =
      appointMonthOrWeek === frequencyType.Week || frequency === frequencyType.Week ? '每周，' : '';
    let dayTypeDesc = dayType === 'natureDay' ? '自然日' : '工作日';
    let dayDesc =
      weekDesc.length > 0
        ? day.length > 0
          ? dayByWeekList
              .filter((item) => day.includes(item.value))
              .map((item2) => item2.label)
              .join(',')
          : radioDay === radioType.Per
            ? '每天'
            : '***'
        : radioDay === radioType.Per
          ? `每个${dayTypeDesc}`
          : radioDay === radioType.Appoint
            ? day.length > 0
              ? `第${sort(day).join(',')}个${dayTypeDesc}`
              : '***'
            : '';
    let nonTradeDayPostponeDesc = nonTradeDayPostpone === true ? '，非工作日顺延' : '';
    setDescription(
      yearDesc + quaterDesc + monthDesc + weekDesc + dayDesc + nonTradeDayPostponeDesc,
    );
  }, [radioDay, radioMonth, radioQuarter, dayType, day, quarter, month, nonTradeDayPostpone]);

  const initData = (data: any): void => {
    if (!data) {
      setFrequency(frequencyType.Year);
      setRadioDay(radioType.Per);
      setRadioQuarter(radioType.NoAppoint);
      setRadioMonth(radioType.NoAppoint);
      setAppointMonthOrWeek(radioType.NoAppoint);
      setDayType('natureDay');
      setNonTradeDayPostpone(false);
      setDay([]);
      setQuarter([]);
      setMonth([]);
      setDescription('');
      setNoticeDayType('natureDay');
      setNoticePostpone('');
      formRef?.current?.setFieldsValue({
        noticeList: [
          {
            noticeDay: 0,
            noticeTime: moment('09:00', 'HH:mm'),
          },
        ],
      });
      return;
    }
    const {
      day,
      month,
      quarter,
      week,
      dayType,
      nonTradeDayPostpone,
      frequency,
      noticeDay,
      noticeDayType,
      noticePostpone,
    } = data;
    setFrequency(frequency);
    if (quarter?.length) {
      if (quarter[0] === radioType.Per) {
        setRadioQuarter(radioType.Per);
      } else {
        setRadioQuarter(radioType.Appoint);
        setDay(quarter);
      }
    } else {
      setRadioQuarter(radioType.NoAppoint);
      setDay([]);
    }
    if (month?.length) {
      if (month[0] === radioType.Per) {
        setRadioMonth(radioType.Per);
      } else {
        setRadioMonth(radioType.Appoint);
        setMonth(month);
      }
      if (frequency !== frequencyType.Month) {
        setAppointMonthOrWeek(frequencyType.Month);
      }
    } else {
      setRadioMonth(radioType.NoAppoint);
      setMonth([]);
    }
    if (week?.length) {
      if (week[0] === radioType.Per && frequency !== frequencyType.Week) {
        setAppointMonthOrWeek(frequencyType.Week);
      }
    }
    setDayType(dayType);
    if (day?.length) {
      if (day[0] === radioType.Per) {
        setRadioDay(radioType.Per);
      } else {
        setRadioDay(radioType.Appoint);
        console.log(day);
        setDay(day);
      }
    } else {
      setRadioDay(radioType.NoAppoint);
      setDay([]);
    }
    setNonTradeDayPostpone(nonTradeDayPostpone === '1' ? true : false);
    setNoticeDayType(noticeDayType);
    setNoticePostpone(noticePostpone);
    const noticeData = noticeDay.map((item) => {
      const temp = item.split(',');
      return {
        noticeDay: parseInt(temp[0], 10),
        noticeTime: moment(temp[1], 'HH:mm'),
      };
    });
    formRef?.current?.setFieldsValue({ noticeList: noticeData || [] });
  };

  const resetDateSelect = (): void => {
    setRadioDay(radioType.Per);
    setRadioQuarter(radioType.NoAppoint);
    setRadioMonth(radioType.NoAppoint);
    setAppointMonthOrWeek(radioType.NoAppoint);
    setDayType('natureDay');
    setNonTradeDayPostpone(false);
    setDay([]);
    setQuarter([]);
    setMonth([]);
  };

  const getData = (): Promise<any> => {
    return new Promise((resolve, reject) => {
      if (radioQuarter === radioType.Appoint && quarter?.length === 0) {
        message.warning('指定了季度，但并未选择');
        reject();
      }
      if (radioMonth === radioType.Appoint && month?.length === 0) {
        message.warning('指定了月，但并未选择');
        reject();
      }
      if (radioDay === radioType.Appoint && day?.length === 0) {
        message.warning('指定了日，但并未选择');
        reject();
      }
      let dayData = radioDay === radioType.Per ? radioType.Per : day?.length ? day.join(',') : null;
      let weekData =
        frequency === frequencyType.Week || appointMonthOrWeek === frequencyType.Week
          ? radioType.Per
          : null;
      let monthData =
        radioMonth === radioType.Per ? radioType.Per : month?.length ? month.join(',') : null;
      let quarterData =
        radioQuarter === radioType.Per ? radioType.Per : quarter?.length ? quarter.join(',') : null;
      let nonTradeDayPostponeData = nonTradeDayPostpone ? '1' : '0';
      const noticeFormData = formRef?.current?.getFieldValue('noticeList') || [];
      console.log('noticeFormData', noticeFormData);
      const noticeData = noticeFormData.map(
        (item) => `${item.noticeDay},${item.noticeTime?.format('HH:mm')}`,
      );
      console.log('noticeData', noticeData);
      resolve({
        day: dayData,
        week: weekData,
        month: monthData,
        quarter: quarterData,
        nonTradeDayPostpone: nonTradeDayPostponeData,
        dayType,
        description,
        frequency,
        noticeDay: noticeData?.length ? noticeData.join(';') : null,
        noticeDayType,
        noticePostpone,
      });
    });
  };

  useImperativeHandle(ref, () => {
    return {
      initData,
      resetDateSelect,
      getData,
    };
  });

  const handleFrequencyRadio = (e) => {
    const value = e.target.value;
    setFrequency(value);
    resetDateSelect();
    switch (value) {
      case frequencyType.Quarter: {
        setRadioQuarter(radioType.Per);
        break;
      }
      case frequencyType.Month: {
        setRadioMonth(radioType.Per);
        break;
      }
      case frequencyType.Day: {
        setNonTradeDayPostpone(false);
        break;
      }
      default:
        break;
    }
  };

  const getShowRadios = (type: string) => {
    if (frequency !== type) {
      return radioList;
    }
    return radioListSimple;
  };

  const handleAppointRadio = (value: string, type: 'day' | 'week' | 'month' | 'quarter'): void => {
    switch (type) {
      case frequencyType.Day: {
        if (radioDay === radioType.Appoint || value === radioType.Appoint) {
          setDay([]);
        }
        setRadioDay(value);
        break;
      }
      case frequencyType.Month: {
        if (radioMonth === radioType.Appoint || value === radioType.Appoint) {
          setMonth([]);
        }
        if (radioMonth === radioType.NoAppoint || value === radioType.NoAppoint) {
          setDay([]);
        }
        setRadioMonth(value);
        break;
      }
      case frequencyType.Quarter: {
        if (radioQuarter === radioType.Appoint || value === radioType.Appoint) {
          setQuarter([]);
        }
        if (radioQuarter === radioType.NoAppoint || value === radioType.NoAppoint) {
          setMonth([]);
          setDay([]);
        }
        setRadioQuarter(value);
        break;
      }
      default:
        break;
    }
  };

  const handleAppointMonthOrWeek = (value: string): void => {
    setAppointMonthOrWeek(value);
    setDayType('natureDay');
    setMonth([]);
    setDay([]);
  };

  const show = (type: 'year' | 'quarter' | 'month' | 'week' | 'day'): boolean => {
    return frequencyValueList.indexOf(frequency || 'year') <= frequencyValueList.indexOf(type);
  };

  const handleNoticePostpone = (list: string[]) => {
    setNoticePostpone(list?.length ? list[list.length - 1] : null);
  };

  return (
    <Form ref={formRef} {...formItemLayout} labelAlign="right">
      <Form.Item label="频率" className={styles['form-item-frequency']}>
        <Radio.Group options={frequencyList} onChange={handleFrequencyRadio} value={frequency} />
      </Form.Item>
      {show('year') && (
        <Form.Item label="指定年" className={styles['form-item-frequency']}>
          每年
        </Form.Item>
      )}
      {show('quarter') && (
        <>
          <Form.Item label="指定季度" className={styles['form-item-frequency']}>
            <Radio.Group
              options={getShowRadios('quarter')}
              value={radioQuarter}
              onChange={(e) => handleAppointRadio(e.target.value, 'quarter')}
            />
          </Form.Item>
          {radioQuarter === 'appoint' && (
            <Form.Item {...formItemLayoutWithOutLabel}>
              <Checkbox.Group
                options={quarterList}
                value={quarter}
                onChange={(val) => setQuarter(val as string[])}
              />
            </Form.Item>
          )}
        </>
      )}
      {(show('year') || show('quarter')) && (
        <Form.Item label="按月/周" className={styles['form-item-frequency']}>
          <Radio.Group
            options={[
              {
                label: '月',
                value: frequencyType.Month,
              },
              {
                label: '周',
                value: frequencyType.Week,
              },
              {
                label: '不指定',
                value: radioType.NoAppoint,
              },
            ]}
            value={appointMonthOrWeek}
            onChange={(e) => handleAppointMonthOrWeek(e.target.value)}
          />
        </Form.Item>
      )}
      {(frequency === frequencyType.Month || appointMonthOrWeek === frequencyType.Month) && (
        <>
          <Form.Item label="指定月" className={styles['form-item-frequency']}>
            <Radio.Group
              options={radioListSimple}
              value={radioMonth}
              onChange={(e) => handleAppointRadio(e.target.value, 'month')}
            />
          </Form.Item>
          {radioMonth === 'appoint' && (
            <Form.Item {...formItemLayoutWithOutLabel}>
              <Checkbox.Group
                options={
                  radioQuarter && radioQuarter !== radioType.NoAppoint
                    ? monthByQuarterList
                    : monthByYearList
                }
                value={month}
                onChange={(val) => setMonth(val as string[])}
              />
            </Form.Item>
          )}
        </>
      )}
      {(frequency === frequencyType.Week || appointMonthOrWeek === frequencyType.Week) && (
        <Form.Item label="指定周" className={styles['form-item-frequency']}>
          每周
        </Form.Item>
      )}
      <Form.Item label="指定日" className={styles['form-item-frequency']}>
        {frequency === frequencyType.Day ? (
          <span>每天</span>
        ) : (
          <Radio.Group
            options={[
              {
                label: '每',
                value: 'per',
              },
              {
                label: '指定',
                value: 'appoint',
              },
            ]}
            value={radioDay}
            onChange={(e) => handleAppointRadio(e.target.value, 'day')}
          />
        )}
      </Form.Item>
      {frequency !== frequencyType.Week && appointMonthOrWeek !== frequencyType.Week && (
        <Form.Item {...formItemLayoutWithOutLabel}>
          <Radio.Group
            options={dayTypeList}
            value={dayType}
            onChange={(e) => {
              setDayType(e.target.value);
              setNonTradeDayPostpone(false);
            }}
          />
        </Form.Item>
      )}
      {radioDay === 'appoint' && (
        <Form.Item {...formItemLayoutWithOutLabel}>
          <Checkbox.Group
            options={
              frequency === frequencyType.Week || appointMonthOrWeek === frequencyType.Week
                ? dayByWeekList
                : dayByMonthList
            }
            value={day}
            onChange={(val) => setDay(val as string[])}
          />
        </Form.Item>
      )}
      <Form.Item label="描述" className={styles['form-item-frequency']}>
        {description}
      </Form.Item>
      <Form.Item label="提醒时间" className={styles['form-item-frequency']}>
        <span className={styles['notice-description']}>提前多少天进行提醒，0代表当天</span>
      </Form.Item>
      <Form.List name="noticeList">
        {(fields, { add, remove }) => (
          <>
            {fields.map(({ key, name, ...restField }) => (
              <Form.Item {...formItemLayoutWithOutLabel} key={key}>
                <Space align="baseline">
                  <Form.Item>截止日前/天</Form.Item>
                  <Form.Item {...restField} name={[name, 'noticeDay']} initialValue={0}>
                    <InputNumber min={0} max={999} step={1} />
                  </Form.Item>
                  <Form.Item
                    {...restField}
                    name={[name, 'noticeTime']}
                    initialValue={moment('09:00', 'HH:mm')}
                  >
                    <TimePicker format="HH:mm" allowClear={false} />
                  </Form.Item>
                  {fields.length > 1 ? <MinusCircleOutlined onClick={() => remove(name)} /> : null}
                </Space>
              </Form.Item>
            ))}
            <Form.Item {...formItemLayoutWithOutLabelSmall}>
              <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>
                添加
              </Button>
            </Form.Item>
          </>
        )}
      </Form.List>
      <Form.Item {...formItemLayoutWithOutLabel}>
        <Radio.Group
          options={dayTypeList}
          value={noticeDayType}
          onChange={(e) => {
            setNoticeDayType(e.target.value);
            setNoticePostpone('');
          }}
        />
      </Form.Item>
      {noticeDayType === 'natureDay' && (
        <Form.Item {...formItemLayoutWithOutLabel}>
          <Checkbox.Group value={[noticePostpone]} onChange={handleNoticePostpone}>
            <Checkbox value={postponeType.Front}>非工作日前移</Checkbox>
            <Checkbox value={postponeType.Behind}>非工作日后移</Checkbox>
          </Checkbox.Group>
        </Form.Item>
      )}
    </Form>
  );
});

export default DateForm;
