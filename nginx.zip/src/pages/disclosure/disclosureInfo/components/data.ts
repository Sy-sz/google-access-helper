import { IColumnDefs } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';
import { Input } from 'antd';

const statusEnum = [
  { dictLabel: '启用', dictValue: '1' },
  { dictLabel: '禁用', dictValue: '0' },
];

export const columnDefs: IColumnDefs = [
  {
    headerName: '披露事项',
    field: 'name',
    flex: 1,
    minWidth: 80,
    component: Input,
    componentProps: {
      placeholder: '请输入披露事项',
      allowClear: true,
    },
  },
  {
    headerName: '法律依据',
    field: 'legalBasis',
    flex: 1,
    hideInSearch: true,
  },
  {
    headerName: '报送对象',
    field: 'submitObj',
    flex: 1,
    separator: ',',
    hideInSearch: true,
  },
  {
    headerName: '归属部门',
    field: 'chargeObj',
    flex: 1,
    separator: ',',
    dictId: '22ee5a77-f7ca-47b8-9c83-c91514d5ed62',
    component: 'DictSelectPlus',
    componentProps: { placeholder: '请选择归属部门', mode: 'multiple', maxTagCount: 1 },
    transform: (value) => value?.join(),
  },
  {
    headerName: '协同部门',
    field: 'cooperateObj',
    flex: 1,
    separator: ',',
    dictId: '22ee5a77-f7ca-47b8-9c83-c91514d5ed62',
    hideInSearch: true,
  },
  {
    headerName: '传阅对象',
    field: 'focusObj',
    separator: ',',
    flex: 1,
    dictId: '22ee5a77-f7ca-47b8-9c83-c91514d5ed62',
    hideInSearch: true,
  },
  {
    headerName: '发送方式',
    field: 'sendType',
    flex: 1,
    dictId: 'f47a033e-b0f5-4c74-8f9c-78660879c235',
    hideInSearch: true,
  },
  {
    headerName: '频率',
    field: 'frequency',
    width: 100,
    minWidth: 100,
    dictId: 'c06eb24a-f8c3-4599-a8c4-f209c2dc339e',
    hideInSearch: true,
  },
  {
    headerName: '状态',
    field: 'isEnabled',
    width: 100,
    minWidth: 100,
    component: 'DictSelectPlus',
    componentProps: { placeholder: '请选择状态' },
    valueEnum: statusEnum,
  },
];
