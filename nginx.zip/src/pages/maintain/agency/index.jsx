import React, { Component } from 'react';
import {
  Button,
  Col,
  Divider,
  Form,
  Input,
  message,
  Popconfirm,
  Select,
  Space,
  Typography,
} from 'antd';
import { delAgency, listAgency } from 'common/axios';
import { DictSelect, FetchTable } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { fn } from '@cerdo/cerdo-utils';
import FormModal from './com/formModal';
import SearchCard from '@/common/component/SearchCard';

const FormItem = Form.Item;
const Option = Select.Option;

class Index extends Component {
  constructor() {
    super();
    this.state = {
      modalId: '',
      modalTitle: '',
      modalVisible: false,
      businesstype: '',
    };
    this.params = {};
    this.formRef = React.createRef();
  }

  getList = () => {
    return new Promise((resolve, reject) => {
      this.table.getFormParams(this.formRef.current).then((values) => {
        listAgency({
          ...values,
        })
          .then((result) => {
            if (fn.checkResponse(result)) {
              resolve(result);
            }
            reject(null);
          })
          .finally(() => {});
      });
    });
  };

  handleSearchClick = () => {
    this.table.reloadAndReset();
  };

  handleRemoveClick = (id) => {
    delAgency({ organinfoid: id }).then((result) => {
      if (fn.checkResponse(result)) {
        message.success('删除成功', 1.5, () => {
          this.table.reload();
        });
      }
    });
  };

  handleModalClick = (type, record, id) => {
    this.setState({
      modalId: id,
      modalTitle: type === 1 ? '修改信息' : '添加信息',
      modalVisible: true,
      businesstype: record && record.businesstype,
    });
  };

  getColumns = (type) => {
    return [
      {
        title: '机构名称',
        dataIndex: 'companyname',
        key: 'companyname',
        width: 300,
        fixed: 'left',
      },
      {
        title: '机构简称',
        dataIndex: 'partysimname',
        key: 'partysimname',
        width: 300,
        fixed: 'left',
      },
      { title: '机构类型', dataIndex: 'businesstype', key: 'businesstype', width: 150 },
      {
        title: '最近更新人/时间',
        dataIndex: 'updateuser',
        key: 'updateuser',
        width: 150,
        render: (_, record) => {
          return (
            <Space size={0} direction="vertical">
              <span>{record.updateuser}</span>
              <span>{record.updatetime}</span>
            </Space>
          );
        },
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 120,
        fixed: 'right',
        render: (text, record) => {
          return (
            <Space size={0} split={<Divider type="vertical" />}>
              <Typography.Link onClick={() => this.handleModalClick(1, record, record.organinfoid)}>
                编辑
              </Typography.Link>
              <Popconfirm
                title="确定删除？"
                onConfirm={() => this.handleRemoveClick(record.organinfoid)}
              >
                <Typography.Link type="danger">删除</Typography.Link>
              </Popconfirm>
            </Space>
          );
        },
      },
    ];
  };

  render() {
    const { modalId, modalTitle, modalVisible, businesstype } = this.state;
    return (
      <div>
        <SearchCard
          bordered={false}
          ref={this.formRef}
          style={{ marginTop: 0 }}
          onSearch={this.handleSearchClick}
        >
          <Col span={8}>
            <FormItem label="关键词" name="keyword">
              <Input allowClear placeholder="请输入机构名称、简称搜索" />
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem label="机构类型" name="businesstype">
              <DictSelect
                style={{ width: '100%' }}
                allowClear
                placeholder="请选择机构类型"
                dictid="b016c891911145418762dc8f5834ccb6"
              >
                {(item) =>
                  item.name !== '代销机构' && (
                    <Option key={item.id} value={item.value}>
                      {item.name}
                    </Option>
                  )
                }
              </DictSelect>
            </FormItem>
          </Col>
        </SearchCard>
        <ListCard
          title="机构信息列表"
          bordered={false}
          extra={
            <Button type="primary" onClick={() => this.handleModalClick(0, null)}>
              添加
            </Button>
          }
        >
          <FetchTable
            size="small"
            showTools={false}
            rowKey="organinfoid"
            ref={(ref) => {
              this.table = ref;
            }}
            getList={this.getList}
            columns={this.getColumns()}
            scroll={{ y: 'calc(100vh - 320px)' }}
            autoHeight={{ blankHeight: 230 }}
          />
        </ListCard>
        <FormModal
          title={modalTitle}
          visible={modalVisible}
          id={modalId}
          businesstype={businesstype}
          onOk={() =>
            this.setState({ modalVisible: false }, () => {
              this.table.reload();
            })
          }
          onCancel={() => this.setState({ modalVisible: false })}
        />
      </div>
    );
  }
}

export default Index;
