import React from 'react';
// 机构信息表单分类
export const formList = [
  {
    name: '托管人',
    list: [
      {
        name: 'postcode',
        label: '邮政编码',
        type: 'input',
        required: false,
      },
      {
        name: 'officeaddress',
        label: '公司住所及办公地址',
        type: 'input',
        required: false,
      },
      {
        name: 'infocontacts',
        label: '托管部门信息披露联系人',
        type: 'input',
        required: false,
      },
    ],
  },
  {
    name: '会计事务所',
    list: [
      {
        name: 'officeaddress',
        label: '办公地址',
        type: 'input',
        required: false,
      },
      {
        name: 'exepartner',
        label: '执行事务合伙人',
        type: 'input',
        required: false,
      },
    ],
  },
  {
    name: '托管人-基本信息',
    list: [
      {
        name: 'regcapitalzh',
        label: '注册资本(大写)',
        type: 'input',
        required: false,
      },
      {
        name: 'firregdate',
        label: '首次注册登记日期',
        type: 'date',
        required: false,
      },
      {
        name: 'approvalnum',
        label: '基金托管业务批准文号',
        type: 'input',
        required: false,
      },
      {
        name: 'socialcreditcode',
        label: '托管人统一社会信用编码',
        type: 'input',
        required: true,
      },
      {
        name: 'abroadfundcustodianid',
        label: '人行-境内托管机构代码',
        tooltip: '使用于【人行新发基金需报送境内托管机构的金融机构法人标准代码】',
        type: 'input',
        required: false,
      },
      {
        name: 'parentid',
        label: '父级机构',
        type: 'select',
        required: false,
      },
      {
        name: 'approvesetupnum',
        label: '批准设立机关和批准设立文号',
        type: 'input',
        required: false,
      },
      {
        name: 'businessscope',
        label: '经营范围',
        type: 'textArea',
        required: false,
      },
      {
        name: 'organizeway',
        label: '组织形式',
        type: 'textArea',
        required: false,
      },
      {
        name: 'duration',
        label: '存续期间',
        type: 'textArea',
        required: false,
      },
      {
        name: 'development',
        label: '发展状况',
        type: 'textArea',
        required: false,
      },
    ],
  },
];

// 招募书补充信息
export const formTextAreaList = [
  {
    name: '招募书补充信息-托管人',
    list: [
      {
        name: 'recruitment',
        label: '招募说明',
        type: 'textArea',
        required: false,
        placeholder: '招募说明',
      },
    ],
  },
  {
    name: '招募书补充信息-会计师事务所',
    list: [
      {
        name: 'accountant',
        label: '经办会计师',
        type: 'input',
        required: false,
      },
    ],
  },
];
