import { Col, DatePicker, Form, Input, InputNumber, message, Row, Divider, Select } from 'antd';
import momnet from 'moment';
import { saveAgency, detailAgency, listAgency } from 'common/axios';
import { formList, formTextAreaList } from './index.data';
import React, { Component } from 'react';
import { CONST, fn } from '@cerdo/cerdo-utils';
import { DictSelect, DragModal, FetchSelect } from '@cerdo/cerdo-design';

const FormItem = Form.Item;
const Option = Select.Option;

class FormModal extends Component {
  constructor() {
    super();
    this.state = {
      confirmLoading: false,
      isbusinessType: '',
    };
  }

  shouldComponentUpdate(nextProps) {
    if (nextProps.visible && this.props.visible !== nextProps.visible) {
      this.data = {};
      nextProps.id && this.listAgencyDetailData(nextProps.id);
      nextProps.title === '添加信息' && this.handelBusinesstypeChange(undefined);
    }
    return true;
  }

  listAgencyDetailData = (id) => {
    detailAgency({ organinfoid: id }).then((result) => {
      if (fn.checkResponse(result)) {
        this.data = result.data;
        this.form.setFieldsValue({
          companyname: this.data.companyname,
          businesstype: this.data.businesstype,
          contactor: this.data.contactor,
          address: this.data.address,
          duty: this.data.duty,
          email: this.data.email,
          englishname: this.data.englishname,
          fax: this.data.fax,
          foundtime: this.data.foundtime && momnet(this.data.foundtime),
          hotline: this.data.hotline,
          lawman: this.data.lawman,
          mobileno: this.data.mobileno,
          othercontactway: this.data.othercontactway,
          partysimname: this.data.partysimname,
          phone: this.data.phone,
          regaddress: this.data.regaddress,
          regcapital: this.data.regcapital,
          remark: this.data.remark,
          website: this.data.website,
          parentid: this.data.parentid,
          officeaddress: this.data.officeaddress,
          firregdate: this.data.firregdate && momnet(this.data.firregdate),
          regcapitalzh: this.data.regcapitalzh,
          approvalnum: this.data.approvalnum,
          infocontacts: this.data.infocontacts,
          socialcreditcode: this.data.socialcreditcode,
          abroadfundcustodianid: this.data.abroadfundcustodianid,
          exepartner: this.data.exepartner,
          organizeway: this.data.organizeway,
          duration: this.data.duration,
          approvesetupnum: this.data.approvesetupnum,
          postcode: this.data.postcode,
          development: this.data.development,
          businessscope: this.data.businessscope,
          accountant: this.data.accountant,
          recruitment: this.data.recruitment,
        });
      }
    });
  };

  saveAgencyData = (data) => {
    this.setState({ confirmLoading: true });
    saveAgency(data).then((result) => {
      this.setState({ confirmLoading: false });
      if (fn.checkResponse(result)) {
        message.success(`${this.props.title}成功`, 0.5, () => {
          this.props.onOk();
        });
      }
    });
  };

  handleSubmit = () => {
    this.form.validateFields().then((values) => {
      const parentid = this.form.getFieldValue('parentid');
      this.saveAgencyData({
        ...this.data,
        ...values,
        ...{
          parentid: parentid ? parentid : '',
          foundtime: values.foundtime && values.foundtime.format('YYYY-MM-DD'),
          firregdate: values.firregdate && values.firregdate.format('YYYY-MM-DD'),
        },
      });
    });
  };

  // 机构类型切换托管人信息是否展示
  handelBusinesstypeChange = (val) => {
    this.setState({
      isbusinessType: val,
    });
  };

  // eslint-disable-next-line complexity
  render() {
    const { confirmLoading, isbusinessType } = this.state;
    const { visible, title, onCancel, businesstype } = this.props;
    return (
      <DragModal
        title={title}
        visible={visible}
        width="calc(80%)"
        maskClosable={false}
        destroyOnClose
        closable={false}
        onCancel={onCancel}
        onOk={this.handleSubmit}
        confirmLoading={confirmLoading}
      >
        <Form
          scrollToFirstError
          {...CONST.formModalLayout}
          ref={(ref) => {
            this.form = ref;
          }}
        >
          <Row>
            <Divider orientation="left">基本情况</Divider>
            <Col span={12}>
              <FormItem
                label="机构名称"
                name="companyname"
                hasFeedback
                rules={[{ required: true, message: '请输入机构名称' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入机构名称" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="机构简称"
                name="partysimname"
                hasFeedback
                rules={[{ required: true, message: '请输入机构简称' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入机构简称" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="英文名称"
                name="englishname"
                hasFeedback
                rules={[{ required: false, message: '请输入英文名称' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入英文名称" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="机构类型"
                name="businesstype"
                hasFeedback
                rules={[{ required: true, message: '请选择机构类型' }]}
              >
                <DictSelect
                  style={{ width: '100%' }}
                  allowClear
                  placeholder="请选择机构类型"
                  dictid="b016c891911145418762dc8f5834ccb6"
                  onChange={(val) => this.handelBusinesstypeChange(val)}
                >
                  {(item) =>
                    item.name !== '代销机构' && (
                      <DictSelect.Option key={item.id} value={item.value}>
                        {item.name}
                      </DictSelect.Option>
                    )
                  }
                </DictSelect>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="法人代表"
                name="lawman"
                hasFeedback
                rules={[{ required: false, message: '请输入法人代表' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入法人代表" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="注册地址"
                name="regaddress"
                hasFeedback
                rules={[{ required: false, message: '请输入注册地址' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入注册地址" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="注册资本"
                name="regcapital"
                hasFeedback
                rules={[{ required: false, message: '请输入注册金额' }]}
              >
                <InputNumber style={{ width: '100%' }} placeholder="请输入注册资本" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="成立时间"
                name="foundtime"
                hasFeedback
                rules={[{ required: false, message: '请选择成立时间' }]}
              >
                <DatePicker style={{ width: '100%' }} placeholder="请选择成立时间" />
              </FormItem>
            </Col>
            {(businesstype && businesstype === '托管人' && !isbusinessType) ||
              (isbusinessType && isbusinessType === '托管人')
              ? formList[2].list.map((item, index) => {
                if (item.type === 'input') {
                  return (
                    <Col span={12} key={index}>
                      <FormItem
                        label={item.label}
                        name={item.name}
                        tooltip={item.tooltip}
                        hasFeedback
                        rules={[{ required: item.required, message: `请输入${item.label}` }]}
                      >
                        <Input style={{ width: '100%' }} placeholder={`请输入${item.label}`} />
                      </FormItem>
                    </Col>
                  );
                }
                if (item.type === 'date') {
                  return (
                    <Col span={12} key={index}>
                      <FormItem
                        label={item.label}
                        name={item.name}
                        tooltip={item.tooltip}
                        hasFeedback
                        rules={[{ required: item.required, message: `请选择${item.label}` }]}
                      >
                        <DatePicker
                          style={{ width: '100%' }}
                          plsaceholder={`请选择${item.label}`}
                        />
                      </FormItem>
                    </Col>
                  );
                }
                if (item.type === 'select') {
                  return (
                    <Col span={12} key={index}>
                      <FormItem
                        label={item.label}
                        name={item.name}
                        tooltip={item.tooltip}
                        hasFeedback
                        rules={[{ required: item.required, message: `请选择${item.label}` }]}
                      >
                        <FetchSelect
                          style={{ width: '100%' }}
                          placeholder={`请选择${item.label}`}
                          firstInit
                          getData={listAgency}
                          getParams={(value) => ({
                            keyword: value,
                            businesstype: '托管人',
                            page: 1,
                            size: 100,
                            ishead: 1,
                          })}
                        >
                          {(item) => (
                            <Option key={item.organinfoid} value={item.organinfoid}>
                              {item.companyname}
                            </Option>
                          )}
                        </FetchSelect>
                      </FormItem>
                    </Col>
                  );
                }
                if (item.type === 'textArea') {
                  return (
                    <Col span={24} key={index}>
                      <FormItem
                        {...CONST.formModalFullLayout}
                        label={item.label}
                        name={item.name}
                        tooltip={item.tooltip}
                        hasFeedback
                        rules={[{ required: item.required, message: `请输入${item.label}` }]}
                      >
                        <Input.TextArea
                          autoSize={{ minRows: 3, maxRows: 20 }}
                          placeholder={`请输入${item.label}`}
                        />
                      </FormItem>
                    </Col>
                  );
                }
                return null;
              })
              : null}
            <Divider orientation="left">联系信息</Divider>
            <Col span={12}>
              <FormItem
                label="联系人"
                name="contactor"
                hasFeedback
                rules={[{ required: false, message: '请输入联系人' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入联系人" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="联系电话"
                name="phone"
                hasFeedback
                rules={[{ required: false, message: '请输入联系电话' }]}
              >
                <Input type="tel" style={{ width: '100%' }} placeholder="请输入联系电话" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="职务"
                name="duty"
                hasFeedback
                rules={[{ required: false, message: '请输入职务' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入职务" />
              </FormItem>
            </Col>

            <Col span={12}>
              <FormItem
                label="手机号码"
                name="mobileno"
                hasFeedback
                rules={[{ required: false, message: '请输入手机号码' }]}
              >
                <Input type="tel" style={{ width: '100%' }} placeholder="请输入手机号码" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="联系地址"
                name="address"
                hasFeedback
                rules={[{ required: false, message: '请输入联系地址' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入联系地址" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="邮箱地址"
                name="email"
                hasFeedback
                rules={[{ required: false, message: '请输入邮箱地址' }]}
              >
                <Input type="email" style={{ width: '100%' }} placeholder="请输入邮箱地址" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="传真"
                name="fax"
                hasFeedback
                rules={[{ required: false, message: '请输入传真' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入传真" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="客服热线"
                name="hotline"
                hasFeedback
                rules={[{ required: false, message: '请输入客服热线' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入客服热线" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="公司网址"
                name="website"
                hasFeedback
                rules={[{ required: false, message: '请输入公司网址' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入公司网址" />
              </FormItem>
            </Col>

            {(businesstype && businesstype === '会计事务所' && !isbusinessType) ||
              (isbusinessType && isbusinessType === '会计事务所')
              ? formList[1].list.map((item, index) => {
                if (item.type === 'input') {
                  return (
                    <Col span={12} key={index}>
                      <FormItem
                        label={item.label}
                        name={item.name}
                        hasFeedback
                        rules={[{ required: item.required, message: `请输入${item.label}` }]}
                      >
                        <Input style={{ width: '100%' }} placeholder={`请输入${item.label}`} />
                      </FormItem>
                    </Col>
                  );
                }
                return null;
              })
              : null}

            {(businesstype && businesstype === '托管人' && !isbusinessType) ||
              (isbusinessType && isbusinessType === '托管人')
              ? formList[0].list.map((item, index) => {
                if (item.type === 'input') {
                  return (
                    <Col span={12} key={index}>
                      <FormItem
                        label={item.label}
                        name={item.name}
                        tooltip={item.tooltip}
                        hasFeedback
                        rules={[{ required: item.required, message: `请输入${item.label}` }]}
                      >
                        <Input style={{ width: '100%' }} placeholder={`请输入${item.label}`} />
                      </FormItem>
                    </Col>
                  );
                }
                return null;
              })
              : null}
            <Col span={24}>
              <FormItem
                {...CONST.formModalFullLayout}
                label="备注"
                name="remark"
                hasFeedback
                rules={[{ required: false, message: '请输入备注' }]}
              >
                <Input.TextArea autoSize={{ minRows: 3, maxRows: 20 }} placeholder="请输入备注" />
              </FormItem>
            </Col>
            {(businesstype &&
              (businesstype === '托管人' || businesstype === '会计事务所') &&
              !isbusinessType) ||
              (isbusinessType && (isbusinessType === '托管人' || isbusinessType === '会计事务所')) ? (
              <Divider orientation="left">其他补充信息</Divider>
            ) : null}

            {(businesstype && businesstype === '托管人' && !isbusinessType) ||
              (isbusinessType && isbusinessType === '托管人')
              ? formTextAreaList[0].list.map((item, index) => {
                if (item.type === 'textArea') {
                  return (
                    <Col span={24} key={index}>
                      <FormItem
                        {...CONST.formModalFullLayout}
                        label={item.label}
                        name={item.name}
                        tooltip={item.tooltip}
                        hasFeedback
                        rules={[{ required: item.required, message: `请输入${item.label}` }]}
                      >
                        <Input.TextArea
                          autoSize={{ minRows: 3, maxRows: 20 }}
                          placeholder={`请输入${item.placeholder}`}
                        />
                      </FormItem>
                    </Col>
                  );
                }
                return null;
              })
              : null}

            {(businesstype && businesstype === '会计事务所' && !isbusinessType) ||
              (isbusinessType && isbusinessType === '会计事务所')
              ? formTextAreaList[1].list.map((item, index) => {
                if (item.type === 'input') {
                  return (
                    <Col span={12} key={index}>
                      <FormItem
                        label={item.label}
                        name={item.name}
                        hasFeedback
                        rules={[{ required: item.required, message: `请输入${item.label}` }]}
                      >
                        <Input style={{ width: '100%' }} placeholder={`请输入${item.label}`} />
                      </FormItem>
                    </Col>
                  );
                }
                return null;
              })
              : null}
          </Row>
        </Form>
      </DragModal>
    );
  }
}

export default FormModal;
