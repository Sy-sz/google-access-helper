import { message, Table } from 'antd';
import { saveAgencyFunds } from 'common/axios';
import React, { Component } from 'react';
import { DragModal } from '@cerdo/cerdo-design';
import { fn } from '@cerdo/cerdo-utils';
import moment from 'moment';

class FormModal extends Component {
  constructor() {
    super();
    this.state = {
      confirmLoading: false,
      changeFileList: [],
    };
  }
  handleSubmit = () => {
    const { changeFileList } = this.state;
    if (changeFileList) {
      saveAgencyFunds(changeFileList).then((result) => {
        if (fn.checkResponse(result)) {
          this.props.onCancel();
          message.success('导入成功');
        }
      });
    }
  };
  getColumns = () => {
    return [
      { title: '基金代码', dataIndex: 'fundcode', key: 'fundcode', width: 50 },
      { title: '基金名称', dataIndex: 'fundname', key: 'fundname', width: 50 },
      { title: '机构代码', dataIndex: 'companycode', key: 'companycode', width: 50 },
      {
        title: '机构名称',
        dataIndex: 'originalcompanyname',
        key: 'originalcompanyname',
        width: 50,
        render(text, record) {
          return record.flag && Number(record.flag) === 1 ? (
            record.originalcompanyname
          ) : (
            <span style={{ color: 'red' }}>{record.originalcompanyname}</span>
          );
        },
      },
      { title: '代销机构', dataIndex: 'companyname', key: 'companyname', width: 50 },
      {
        title: '代销上线日期',
        dataIndex: 'onlinedate',
        key: 'onlinedate',
        width: 50,
        render(text) {
          return text && moment(text).format('YYYY-MM-DD');
        },
      },
      { title: '代销属性', dataIndex: 'agencyattr', key: 'agencyattr', width: 50 },
      { title: '错误信息提示', dataIndex: 'msg', key: 'msg', width: 50 },
    ];
  };

  render() {
    const { confirmLoading } = this.state;
    const { visible, title, onCancel } = this.props;
    const rowSelection = {
      columnWidth: 20,
      onChange: (selectedRowKeys, selectedRows) => {
        this.setState({
          changeFileList: selectedRows,
        });
      },
    };

    return (
      <DragModal
        title={title}
        visible={visible}
        width={1000}
        maskClosable={false}
        destroyOnClose
        closable={false}
        onCancel={onCancel}
        onOk={this.handleSubmit}
        confirmLoading={confirmLoading}
        bodyStyle={{ padding: 0 }}
      >
        <Table
          columns={this.getColumns()}
          dataSource={
            this.props.fileList && Array.isArray(this.props.fileList) ? this.props.fileList : []
          }
          scroll={{ y: 'calc(100vh - 300px)' }}
          autoHeight={{ blankHeight: 150 }}
          rowSelection={rowSelection}
          rowKey="keyId"
          size="small"
          pagination={{
            defaultPageSize: 100,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total, range) => `${range[0]}-${range[1]} 共 ${total} 条`,
          }}
        />
      </DragModal>
    );
  }
}

export default FormModal;
