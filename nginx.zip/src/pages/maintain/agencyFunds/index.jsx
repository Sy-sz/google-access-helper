import { Button, Col, Form, message, Space, Select, Popover, Tag } from 'antd';
import React, { Component } from 'react';
import { FetchTable, FetchSelect, RangeDate, DictSelect } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { fn } from '@cerdo/cerdo-utils';
import {
  commonApi,
  listAgencyFunds,
  listFundShare,
  exportAgencyFunds,
  importAgencyFunds,
  listAgency,
} from 'common/axios';
import Upload, { MessageShowType } from '@chinahorm/web-components/es/components/Upload';
import moment from 'moment';
import { uuid } from '@/utils';
import FormModal from './com/formModal';
import SearchCard from '@/common/component/SearchCard';

const FormItem = Form.Item;

class AgencyFunds extends Component {
  constructor(props) {
    super(props);
    this.state = {
      exportLoading: false,
      permissions: {
        exportControl: false,
        importControl: false,
      },
      modalId: '',
      modalTitle: '',
      modalVisible: false,
      importFileList: [],
    };

    this.formRef = React.createRef();
  }
  componentDidMount() {
    this.verifyUserPermission();
  }

  getData = () => {
    return new Promise((resolve, reject) => {
      this.table.getFormParams(this.formRef.current, 'YYYY-MM-DD').then((values) => {
        const data = {
          ...values,
          organtype: values.organtype ? values.organtype.join() : '',
          fundids: values.fundids ? values.fundids.join() : '',
          organids: values.organids ? values.organids.join() : null,
          startdate: values.startdate ? moment(values.startdate).format('YYYY-MM-DD') : null,
          enddate: values.enddate ? moment(values.enddate).format('YYYY-MM-DD') : null,
        };
        listAgencyFunds(data)
          .then((result) => {
            if (fn.checkResponse(result)) {
              resolve(result);
            }
            reject(null);
          })
          .finally(() => {});
      });
    });
  };

  getColumns = () => {
    return [
      { title: '基金代码', dataIndex: 'fundcode', key: 'fundcode', fixed: 'left', width: 80 },
      { title: '基金名称', dataIndex: 'fundname', key: 'fundname', fixed: 'left', width: 300 },
      { title: '机构代码', dataIndex: 'companycode', key: 'companycode', width: 50 },
      { title: '机构名称', dataIndex: 'companyname', key: 'companyname', width: 220 },
      { title: '机构类型', dataIndex: 'companytype', key: 'companytype', width: 100 },
      { title: '代销属性', dataIndex: 'agencyattr', key: 'agencyattr', width: 150 },
      {
        title: '代销上线日期',
        dataIndex: 'onlinedate',
        key: 'onlinedate',
        width: 100,
        render(text) {
          return text && moment(text).format('YYYY-MM-DD');
        },
      },
    ];
  };
  handleSearchClick = () => {
    this.table.reloadAndReset();
  };
  // 导出文件权限控制
  // permissionids: 'e6301d75-d69f-465e-aa31-7606dd2fc970'
  verifyUserPermission = () => {
    commonApi
      .userPermission({
        permissionids: [
          'e6301d75-d69f-465e-aa31-7606dd2fc970',
          '001f9d18-10f4-40b5-b599-773d4c2d35f0',
        ].join(),
      })
      .then((result) => {
        if (fn.checkResponse(result)) {
          this.setState({
            permissions: {
              exportControl: result.data[0].haspermission === 1,
              importControl: result.data[1].haspermission === 1,
            },
          });
        }
      });
  };

  // 导出文件
  handleExportClick = () => {
    this.setState({
      exportLoading: true,
    });
    this.table.getFormParams(this.formRef.current, 'YYYY-MM-DD').then((values) => {
      exportAgencyFunds({
        fundids: values.fundids ? values.fundids.join() : '',
        organids: values.organids ? values.organids.join() : null,
        organtype: values.organtype ? values.organtype.join() : '',
        startdate: values.startdate ? moment(values.startdate).format('YYYY-MM-DD') : null,
        enddate: values.enddate ? moment(values.enddate).format('YYYY-MM-DD') : null,
        filename: '代销机构信息(基金).xls',
      }).then(() => {
        message.success('导出成功');
        this.setState({
          exportLoading: false,
        });
      });
    });
  };

  // 导入文件
  handleImportClick = ({ file }) => {
    if (file && file.status === 'done') {
      this.setState({
        // modalId: id,
        modalTitle: '导入文件信息列表',
        modalVisible: true,
        importFileList: file.response.map((item) => {
          return {
            ...item,
            keyId: uuid(),
          };
        }),
      });
    }
  };

  render() {
    const {
      exportLoading,
      permissions: { exportControl, importControl },
      modalVisible,
      modalTitle,
      importFileList,
    } = this.state;
    return (
      <>
        <SearchCard
          bordered={false}
          ref={this.formRef}
          onSearch={this.handleSearchClick}
          onExpand={(expand) => this.table?.setScrollY(expand ? 360 : 320)}
        >
          <Col span={8}>
            <FormItem label="基金" name="fundids">
              <FetchSelect
                getData={listFundShare}
                style={{ width: '100%' }}
                dropdownMatchSelectWidth={false}
                placeholder="请选择基金"
                mode="multiple"
                showArrow
                optionFilterProp="name"
                maxTagCount={1}
                maxTagPlaceholder={(values) => {
                  return (
                    <Popover
                      content={values.map((a) => (
                        <Tag style={{ display: 'block', margin: '4px 0' }} key={a.key}>
                          {a.label}
                        </Tag>
                      ))}
                    >
                      +{values.length} ...
                    </Popover>
                  );
                }}
              >
                {(item) => (
                  <Select.Option
                    key={item.id}
                    value={item.id}
                    name={`${item.fundname || ''}[${item.fundcode || ''}]`}
                  >
                    {item.fundname || ''}[{item.fundcode || ''}]
                  </Select.Option>
                )}
              </FetchSelect>
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem label="机构" name="organids">
              <FetchSelect
                getData={listAgency}
                getParams={(value) => ({
                  keyword: value,
                  businesstype: '代销机构',
                  page: 1,
                  size: 30,
                })}
                style={{ width: '100%' }}
                dropdownMatchSelectWidth={false}
                placeholder="请选择机构"
                mode="multiple"
                showArrow
                optionFilterProp="name"
                maxTagCount={1}
                maxTagPlaceholder={(values) => {
                  return (
                    <Popover
                      content={values.map((a) => (
                        <Tag style={{ display: 'block', margin: '4px 0' }} key={a.key}>
                          {a.label}
                        </Tag>
                      ))}
                    >
                      +{values.length} ...
                    </Popover>
                  );
                }}
              >
                {(item) => (
                  <Select.Option
                    key={item.organinfoid}
                    value={item.organinfoid}
                    name={`${item.companyname || ''}[${item.companycode || ''}]`}
                  >
                    {item.companyname || ''}[{item.companycode || ''}]
                  </Select.Option>
                )}
              </FetchSelect>
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem label="机构类型" name="organtype">
              <DictSelect
                style={{ width: '100%' }}
                allowClear
                placeholder="请选择机构类型"
                dictid="f993cf7a384343f281e6cb6ad9ed6173"
                mode="multiple"
              />
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem label="代销属性" name="agencyattr">
              <DictSelect
                style={{ width: '100%' }}
                allowClear
                placeholder="请选择代销属性"
                dictid="4767de5ffc244840971c6403a14e85d0"
              />
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem label="上线时间" name="daterange">
              <RangeDate style={{ width: '100%' }} />
            </FormItem>
          </Col>
        </SearchCard>
        <ListCard
          title="基金代销信息列表"
          extra={
            <Space>
              {exportControl && (
                <Button
                  key="export"
                  type="primary"
                  loading={exportLoading}
                  onClick={() => this.handleExportClick()}
                >
                  {exportLoading ? '导出中...' : '导出Excel'}
                </Button>
              )}
              {importControl && (
                <Upload
                  accept=".xls,.xlsx"
                  multiple={true}
                  key="up"
                  messageShowType={MessageShowType.None}
                  uploadFunc={importAgencyFunds}
                  onSuccess={this.handleImportClick}
                  showUploadList={false}
                  isFsfund={true}
                >
                  <Button type="primary">导入代销关系</Button>
                </Upload>
              )}
            </Space>
          }
        >
          <FetchTable
            size="small"
            showTools={false}
            ref={(ref) => {
              this.table = ref;
            }}
            // rowKey={"organinfoid"}
            pagination={{ pageSize: 10 }}
            columns={this.getColumns()}
            getList={this.getData}
            scroll={{ y: 'calc(100vh - 320px)' }}
            autoHeight={{ blankHeight: 220 }}
          />
          <FormModal
            title={modalTitle}
            visible={modalVisible}
            // id={modalId}
            fileList={importFileList}
            onCancel={() =>
              this.setState({ modalVisible: false }, () => {
                this.table.reload();
              })
            }
          />
        </ListCard>
      </>
    );
  }
}

export default AgencyFunds;
