import React, { useState } from 'react';
import { DragModal } from '@cerdo/cerdo-design';
import { CONST } from '@cerdo/cerdo-utils';
import { Form, Select } from 'antd';
import { perfoperatorAdd, perfoperatorBatchupdate } from '@/common/axios';

const FormItem = Form.Item;

const Edit = (props) => {
  const { open, title, onCancel, onOk, editType, productList, operatorList, ...otherProps } = props;
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const initialValues = {
    ...otherProps,
    fundcode: otherProps.fundcode ? [otherProps.fundcode] : [],
  };

  const handleOk = async () => {
    setLoading(true);
    form
      .validateFields()
      .then((values) => {
        values.fundcode = values.fundcode.join(',');

        let api = perfoperatorAdd;
        if (editType === 'edit') {
          api = perfoperatorBatchupdate;
          values.ids = otherProps.id;
          delete values.fundcode;
        }

        api({ ...values })
          .then(() => onOk())
          .finally(() => setLoading(false));
      })
      .catch(() => setLoading(false));
  };

  const handleCancel = () => {
    onCancel();
    form.resetFields();
  };

  return (
    <DragModal
      title={title ?? editType === 'edit' ? '编辑' : '新增'}
      visible={open}
      width="calc(520px)"
      maskClosable={false}
      destroyOnClose
      closable={false}
      onCancel={handleCancel}
      onOk={handleOk}
      okText="保存"
      confirmLoading={loading}
    >
      <Form form={form} {...CONST.formModalLayout} initialValues={initialValues}>
        <FormItem
          label="产品名称"
          name="fundcode"
          rules={[{ required: true, message: '不能为空' }]}
        >
          <Select
            allowClear
            disabled={editType === 'edit'}
            mode="multiple"
            maxTagCount={1}
            maxTagTextLength={10}
            options={productList}
            dropdownMatchSelectWidth={false}
            optionFilterProp="filterword"
            placeholder="请选择产品名称"
          />
        </FormItem>
        <FormItem
          label="清算会计人员"
          name="operator"
          rules={[{ required: true, message: '不能为空' }]}
        >
          <Select
            allowClear
            options={operatorList}
            optionFilterProp="filterword"
            placeholder="请选择清算会计人员"
          />
        </FormItem>
      </Form>
    </DragModal>
  );
};

export default Edit;
