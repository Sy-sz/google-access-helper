import React, { useEffect, useRef, useState } from 'react';
import { unstable_batchedUpdates } from 'react-dom';
import { Form, Col, Button, Select, Space, Popconfirm, message } from 'antd';
import { FetchTable } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { fn } from '@cerdo/cerdo-utils';
import { useUserList } from '@chinahorm/web-components/es/components/ProcessLayout/pages/shared/hooks';
import SearchCard from 'common/component/SearchCard';
import { perfoperatorList, perfoperatorDel, bpmFundlist } from 'common/axios';
import { openModal, getDictionary } from '@/utils';
import Edit from './edit';

const FormItem = Form.Item;

const Index = () => {
  const formRef = useRef(null);
  const tableRef = useRef(null);
  const userList = useUserList({ departmentid: '979E99E7-9E37-4429-928B-62AA2BB91C7F' });
  // 选择产品
  const [productList, setProductList] = useState([]);
  // 会计人员
  const [operatorList, setOperator] = useState([]);
  // 产品状态
  const [productStatusList, setProductStatusList] = useState([]);

  const reloadData = () => {
    tableRef.current.reloadAndReset();
  };

  const commonProps = {
    onOk: reloadData,
    productList,
    operatorList,
  };

  // const deleteItem = ({ id }) => {
  //   pdtconfigDel({ id }).then(() => {
  //     reloadData();
  //   });
  // };

  const handleAdd = () => {
    openModal(Edit, { ...commonProps });
  };

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams(formRef.current).then((values) => {
        perfoperatorList({ ...values }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
        });
      });
    });
  };

  const onReset = () => {
    reloadData();
  };

  const fetchOptions = () => {
    Promise.all([
      bpmFundlist({ all: '0', keyword: '', page: 1, size: 1000 }),
      userList.request({})(),
      getDictionary('74fc592542d94bff8660eb2854c47092'),
    ]).then(([{ data }, operator, productStatus]) => {
      const productList = data?.map((e) => ({
        ...e,
        label: `${e.fundname}[${e.fundcode}]`,
        value: e.fundcode,
        filterword: `${e.fundname},${e.fundcode}`,
      }));
      const operatorList = operator?.map((e) => ({
        ...e,
        filterword: `${e.account},${e.label}`,
      }));
      const productStatusList = productStatus?.[0]?.map((e) => ({
        label: e.value,
        value: e.value,
      }));

      unstable_batchedUpdates(() => {
        setProductList(productList);
        setOperator(operatorList);
        setProductStatusList(productStatusList);
      });
    });
  };

  const onDelete = ({ id }) => {
    perfoperatorDel({ id }).then(() => {
      message.success('删除成功');
      reloadData();
    });
  };

  const columns = [
    { title: '产品代码', dataIndex: 'fundcode', width: 120, fixed: 'left' },
    { title: '产品名称', dataIndex: 'fundname', width: 300, fixed: 'left' },
    {
      title: '负责会计',
      dataIndex: 'operator',
      width: 120,
      render: (id) => operatorList.find((e) => e.value === id)?.label,
    },
    { title: '产品状态', dataIndex: 'fundperiod', width: 120 },
    {
      title: '操作',
      width: 120,
      render: (t, record) => (
        <Space>
          <Button
            type="link"
            onClick={() => openModal(Edit, { ...record, ...commonProps, editType: 'edit' })}
          >
            编辑
          </Button>
          <Popconfirm title="确认删除？" onConfirm={() => onDelete(record)}>
            <Button type="link">删除</Button>
          </Popconfirm>
        </Space>
      ),
      fixed: 'right',
    },
  ];

  useEffect(() => {
    fetchOptions();
  }, []);

  return (
    <>
      <SearchCard ref={formRef} onSearch={reloadData} onReset={onReset}>
        <Col span={8}>
          <FormItem label="选择产品" name="fundcode">
            <Select
              allowClear
              showSearch
              options={productList}
              optionFilterProp="filterword"
              placeholder="请选择产品"
            />
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="负责会计人员" name="operator">
            <Select
              allowClear
              showSearch
              options={operatorList}
              optionFilterProp="filterword"
              placeholder="请选择负责会计人员"
            />
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="产品状态" name="fundPeriod">
            <Select options={productStatusList} allowClear placeholder="请选择负责会计人员" />
          </FormItem>
        </Col>
      </SearchCard>

      <ListCard
        title={null}
        bordered={false}
        extra={
          <Button type="primary" onClick={handleAdd}>
            新增
          </Button>
        }
      >
        <FetchTable
          size="small"
          showTools={false}
          rowKey="id"
          ref={tableRef}
          getList={getList}
          columns={columns}
          scroll={{ y: 'calc(100vh - 320px)' }}
          autoHeight={{ blankHeight: 230 }}
        />
      </ListCard>
    </>
  );
};

export default Index;
