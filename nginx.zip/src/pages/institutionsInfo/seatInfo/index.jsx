import React, { useRef } from 'react';
import { Col, Form, Input, Button, Space, Tag, Select } from 'antd';
import { SearchCard, ListCard } from '@/common/component';
import { tradeseatList } from '@/common/axios';
import { FetchTable } from '@cerdo/cerdo-design';
import { fn } from '@cerdo/cerdo-utils';
import { processJump, ProcessCode } from '@/utils';

const FormItem = Form.Item;
const processStatus = [
  { label: '全部', value: '' },
  { label: '审批中', value: 2, renderTag: () => <Tag color="processing">审批中</Tag> },
  { label: '审批结束', value: 3, renderTag: () => <Tag>审批结束</Tag> },
  { label: '已退回', value: 1, renderTag: () => <Tag color="red">已退回</Tag> },
];
const columns = [
  {
    title: '席位号',
    width: 100,
    dataIndex: 'newSeatno',
    render: (val, { applyChgProdSeatno }) => val || applyChgProdSeatno,
  },
  {
    title: '席位单位',
    dataIndex: 'newSeatOutUnit',
    width: 120,
    render: (val, { rentSeatBizName }) => val || rentSeatBizName,
  },
  {
    title: '产品代码',
    dataIndex: 'prodCode',
    width: 120,
  },
  {
    title: '产品名称',
    dataIndex: 'prodName',
    width: 300,
  },
  {
    title: '类型',
    width: 100,
    render: () => '新增席位',
  },
  {
    title: '流程状态',
    dataIndex: 'status',
    width: 100,
    render: (text) => {
      const item = processStatus.find((e) => e.value === text);
      if (item?.renderTag) {
        return item.renderTag();
      }
      return null;
    },
  },
  {
    title: '申请日期',
    dataIndex: 'applydateTerm',
    width: 120,
  },
  {
    title: '申请人',
    dataIndex: 'applyUserName',
    width: 120,
  },
];

const SeatInfo = () => {
  const formRef = useRef(null);
  const tableRef = useRef(null);

  const reloadData = () => {
    tableRef.current.reloadAndReset();
  };

  const onReset = () => {
    reloadData();
  };

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams(formRef.current).then((values) => {
        tradeseatList({ ...values }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
        });
      });
    });
  };

  const linkSeatProcess = () => {
    processJump({
      code: ProcessCode.PDT.TradeSeat,
    });
  };

  return (
    <>
      <SearchCard ref={formRef} onSearch={reloadData} onReset={onReset}>
        <Col span={8}>
          <FormItem label="关键词" name="keyword">
            <Input placeholder="请输入产品，席位单位查询" autoComplete="off" allowClear />
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="流程状态" name="status" initialValue={3}>
            <Select options={processStatus} />
          </FormItem>
        </Col>
      </SearchCard>

      <ListCard
        title="席位信息"
        extra={
          <Space>
            <Button type="primary" onClick={linkSeatProcess}>
              席位申请流程
            </Button>
          </Space>
        }
      >
        <FetchTable
          rowKey="id"
          size="small"
          ref={tableRef}
          showTools={false}
          getList={getList}
          columns={columns}
          scroll={{ y: 'calc(100vh - 320px)' }}
          autoHeight={{ blankHeight: 230 }}
        />
      </ListCard>
    </>
  );
};

export default SeatInfo;
