import React from 'react';
import moment from 'moment';
import { Popover, Space, Tag, Typography } from 'antd';
import {
  CheckSquareOutlined,
  CloseSquareOutlined,
  MinusSquareOutlined,
  InfoCircleOutlined,
} from '@ant-design/icons';
// import { genJumpProcess } from '@/utils';

// 往前推四个季度(不含当前季度)
export const latestQuarter = [1, 2, 3, 4]
  .map((n) => moment().endOf('Q').subtract(n, 'Q').endOf('M').format('YYYY-MM-DD'))
  .map((e) => ({ label: e, value: e }));

const iconStyle = {
  fontSize: 18,
};

const colorMap = {
  success: 'var(--tag-success-color)',
  fail: 'var(--tag-error-color)',
  undone: 'var(--tag-color)',
};

export const renderCardTitle = () => {
  return (
    <Popover
      placement="right"
      content={
        <Space direction="vertical" size={0}>
          <Typography.Text>
            <MinusSquareOutlined style={{ color: colorMap.undone }} /> 业绩数据未复核
          </Typography.Text>
          <Typography.Text>
            <CheckSquareOutlined style={{ color: colorMap.success }} /> 业绩数据已复核
          </Typography.Text>
          <Typography.Text>
            <CloseSquareOutlined style={{ color: colorMap.fail }} /> 业绩数据复核失败
          </Typography.Text>
        </Space>
      }
    >
      基金业绩列表 <InfoCircleOutlined />
    </Popover>
  );
};

const renderIcon = (isReview) => {
  if (isReview === '0') {
    return <MinusSquareOutlined style={{ ...iconStyle, color: colorMap.undone }} />;
  }
  if (isReview === '1') {
    return <CheckSquareOutlined style={{ ...iconStyle, color: colorMap.success }} />;
  }
  if (isReview === '2') {
    return <CloseSquareOutlined style={{ ...iconStyle, color: colorMap.fail }} />;
  }
  return null;
};

const renderContent = (name) => (txt, record) =>
  (
    <span style={{ display: 'flex', alignItems: 'center' }}>
      <span style={{ flex: 1, textAlign: 'right', marginRight: 4 }}>{txt?.replace(/,/, '\n')}</span>
      {txt && renderIcon(record[`${name}Flag`])}
    </span>
  );

export const apprStatus = [
  { label: '全部', value: '' },
  { label: '已复核', value: '1', tag: 'success' },
  { label: '复核失败', value: '2', tag: 'error' },
  { label: '未复核', value: '0', tag: 'default' },
];

export const columns = [
  { title: '产品代码', dataIndex: 'prodCode', width: 100, fixed: 'left' },
  { title: '产品名称', dataIndex: 'prodName', width: 300, fixed: 'left' },
  { title: '最新净值', dataIndex: 'nav', width: 100 },
  {
    title: '近1个月收益率',
    dataIndex: 'recentOneMonthYield',
    width: 100,
    render: renderContent('recentOneMonthYield'),
  },
  {
    title: '近3个月收益率',
    dataIndex: 'recentThreeMonthYield',
    width: 100,
    render: renderContent('recentThreeMonthYield'),
  },
  {
    title: '近6个月收益率',
    dataIndex: 'recentSixMonthYield',
    width: 100,
    render: renderContent('recentSixMonthYield'),
  },
  {
    title: '今年以来收益率',
    dataIndex: 'yieldYtd',
    width: 100,
    render: renderContent('yieldYtd'),
  },
  {
    title: '近1年来收益率',
    dataIndex: 'nearOneYYield',
    width: 100,
    render: renderContent('nearOneYYield'),
  },
  {
    title: '近3年来收益率',
    dataIndex: 'nearThreeYYield',
    width: 100,
    render: renderContent('nearThreeYYield'),
  },
  {
    title: '近5年来收益率',
    dataIndex: 'nearFiveYYield',
    width: 100,
    render: renderContent('nearFiveYYield'),
  },
  {
    title: '成立以来收益率',
    dataIndex: 'yieldSetup',
    width: 100,
    render: renderContent('yieldSetup'),
  },
  { title: '其他情况', dataIndex: 'otherInfo', width: 220, render: renderContent('otherInfo') },
  {
    title: '数据截止日期',
    dataIndex: 'dataEndDate',
    width: 100,
    render: (txt) => txt?.split(' ')?.[0],
  },
  {
    title: '数据状态',
    dataIndex: 'apprStatus',
    width: 100,
    fixed: 'right',
    render: (txt) => {
      const { tag, label } = apprStatus.find((e) => e.value === txt) || {};
      return <Tag color={tag}>{label}</Tag>;
    },
  },
  // {
  //   title: '操作',
  //   width: 80,
  //   fixed: 'right',
  //   render(text, record) {
  //     return genJumpProcess({
  //       code: 'PERF_APPR',
  //       title: '查看流程',
  //       tokenId: record.tokenId,
  //       tag: 'trace',
  //     });
  //   },
  // },
];
