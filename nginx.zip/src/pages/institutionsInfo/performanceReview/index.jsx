import React, { useRef } from 'react';
import { Col, Form, Button, Space, Select } from 'antd';
import { SearchCard, ListCard } from '@/common/component';
import { listFundShare, appritemList } from 'common/axios';
import { FetchSelect, FetchTable } from '@cerdo/cerdo-design';
import { fn } from '@cerdo/cerdo-utils';
import { processJump, ProcessCode } from '@/utils';
import { latestQuarter, columns, apprStatus, renderCardTitle } from './data';

const FormItem = Form.Item;

const SeatInfo = () => {
  const formRef = useRef(null);
  const tableRef = useRef(null);
  // 选择产品
  // const [productList, setProductList] = useState([]);

  const reloadData = () => {
    tableRef.current.reloadAndReset();
  };

  const onReset = () => {
    reloadData();
  };

  const getList = () => {
    return new Promise((resolve) => {
      tableRef.current.getFormParams(formRef.current).then((values) => {
        appritemList({ ...values }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
        });
      });
    });
  };

  const linkSeatProcess = () => {
    processJump({
      code: ProcessCode.PDT.PerformanceReview,
    });
  };

  // const fetchOptions = () => {
  //   listFundShare({ page: 1, size: 999 }).then((res) => {
  //     const productList = res.data?.map((e) => ({
  //       ...e,
  //       label: `${e.fundshortname}[${e.fundcode}]`,
  //       value: e.fundcode,
  //       filterword: `${e.fundshortname},${e.fundcode}`,
  //     }));

  //     setProductList(productList);
  //   });
  // };

  // useEffect(() => {
  //   fetchOptions();
  // }, []);

  return (
    <>
      <SearchCard ref={formRef} onSearch={reloadData} onReset={onReset} expand>
        <Col span={8}>
          <FormItem label="数据日期" name="dataEndDate" initialValue={latestQuarter[0].value}>
            <Select options={latestQuarter} />
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="产品名称" name="fundcode">
            <FetchSelect
              getData={listFundShare}
              style={{ width: '100%' }}
              placeholder="请输入基金代码或名称搜索"
            >
              {(item) => (
                <FetchSelect.Option
                  key={item.fundode}
                  value={item.fundcode}
                >{`${item.fundshortname}[${item.fundcode}]`}</FetchSelect.Option>
              )}
            </FetchSelect>
          </FormItem>
        </Col>
        <Col span={8}>
          <FormItem label="复核状态" name="apprStatus" initialValue="1">
            <Select options={apprStatus} />
          </FormItem>
        </Col>
      </SearchCard>

      <ListCard
        title={renderCardTitle()}
        extra={
          <Space>
            <Button type="primary" onClick={linkSeatProcess}>
              基金业绩复核流程
            </Button>
          </Space>
        }
      >
        <FetchTable
          rowKey="id"
          size="small"
          ref={tableRef}
          showTools={false}
          getList={getList}
          columns={columns}
          scroll={{ y: 'calc(100vh - 320px)' }}
          autoHeight={{ blankHeight: 230 }}
        />
      </ListCard>
    </>
  );
};

export default SeatInfo;
