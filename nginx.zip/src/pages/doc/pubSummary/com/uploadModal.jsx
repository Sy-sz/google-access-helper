import React, { createRef, useState } from 'react';
import { DragModal, UploadFile, LocalTable } from '@cerdo/cerdo-design';
import { convert, fn } from '@cerdo/cerdo-utils';
import { message, Card, Button } from 'antd';
import { saveSummaryFile, commonApi } from 'common/axios';
import { uploadFileApi, downloadFileApi } from 'common/axios/config';

const UploadModal = (props) => {
  const { visible, onCancel, onOk } = props;
  const [loading, setLoading] = useState(false);

  let tableRef = createRef();

  let tableData = [];

  const handleSubmit = () => {
    let data = [];
    data = tableData.filter((a) => a.tips === '');
    if (data.length < 1) {
      message.warning('没有可上报的文件');
      return;
    }
    setLoading(true);
    saveSummaryFile(data)
      .then((result) => {
        if (fn.checkResponse(result)) {
          message.success('提交成功', 1.5, () => {
            onOk();
          });
        }
      })
      .finally(() => setLoading(false));
  };

  const handleBeforeUpload = (file, fileList) => {
    if (file) {
      const fileArr = (file.name || '').split('.');
      if (!['ZIP', 'PDF'].includes(fileArr[1].toUpperCase()) || fileArr.length > 2) {
        message.warning(`【${file.name}】文件格式不支持`);
        return Promise.reject();
      }
      if (!/^CN_50220000_\d{6}_FA0100[7|8]0_\d{8}_\d{6}_\d{8}_\d{6}_\d{2}$/.test(fileArr[0])) {
        message.warning(`【${file.name}】文件名编号错误`);
        return Promise.reject();
      }
      if (tableData.find((a) => a.filename === file.name)) {
        message.warning(`【${file.name}】文件已存在`);
        return Promise.reject();
      }
      return Promise.resolve();
    }
  };

  const verifyTableData = () => {
    tableData.forEach((item) => {
      const fileArr = (item.filename || '').split('.');
      const temp = tableData.filter((a) => (a.filename || '').includes(fileArr[0]));
      item.tips =
        temp.length > 1 ? (
          ''
        ) : (
          <span className="red">
            缺失{['ZIP'].includes(fileArr[1].toUpperCase()) ? 'pdf' : 'zip'}文件
          </span>
        );
    });
  };

  const handleUploadChange = (file, fileList) => {
    tableData.push(file);
    verifyTableData();
    tableRef.dataSourceChange({ data: tableData });
  };

  const getColumns = () => {
    return [
      {
        title: '文件名',
        dataIndex: 'filename',
        key: 'filename',
        width: 400,
        render(text, record) {
          return (
            <Button
              type="link"
              onClick={() =>
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi)
              }
            >
              {text}
            </Button>
          );
        },
      },
      {
        title: '文件大小',
        dataIndex: 'filesize',
        key: 'filesize',
        width: 80,
        render(text) {
          if (text === 0) {
            return text;
          }

          return convert.toFileSize(text) || 0;
        },
      },
      { title: '提示', dataIndex: 'tips', key: 'tips', width: 100 },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 40,
        render: (text, record) => {
          return (
            <Button
              type="link"
              danger
              onClick={() => {
                tableData = tableData.filter((a) => a.fileid !== record.fileid);
                verifyTableData();
                tableRef.dataSourceChange({ data: tableData });
              }}
            >
              删除
            </Button>
          );
        },
      },
    ];
  };

  return (
    <DragModal
      visible={visible}
      onCancel={() => {
        onCancel();
      }}
      okText="确认提交"
      onOk={handleSubmit}
      title="上传概要文件"
      destroyOnClose
      width={1000}
      confirmLoading={loading}
      bodyStyle={{ padding: 0 }}
    >
      <Card
        bordered={false}
        extra={
          <>
            <span style={{ paddingRight: 12 }} className="red">
              仅支持上传已编号pdf和zip文件{' '}
            </span>
            <UploadFile
              uploadUrl={uploadFileApi}
              downloadUrl={downloadFileApi}
              accept=".pdf,.PDF,.zip,.ZIP"
              multiple
              showUploadList={false}
              showProcess
              beforeUpload={handleBeforeUpload}
              onChange={handleUploadChange}
            >
              <Button type="primary">上传概要文件</Button>
            </UploadFile>
          </>
        }
      >
        <LocalTable
          size="small"
          showTools={false}
          rowKey="fileid"
          ref={(ref) => {
            tableRef = ref;
          }}
          toolStyleTop={0}
          columns={getColumns()}
          scroll={{ y: 300 }}
        />
      </Card>
    </DragModal>
  );
};

export default UploadModal;
