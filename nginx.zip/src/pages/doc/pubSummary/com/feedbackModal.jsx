import React, { useEffect, createRef, useState, useRef } from 'react';
import { DragModal, FetchSelect, FetchTable } from '@cerdo/cerdo-design';
import { DatePicker, Tabs, Form, Popover, Tag, Space } from 'antd';
import {
  listSummaryFeedbackAgency,
  listSummaryFeedbackFund,
  listFundShare,
  listAgency,
  listSummaryAgency,
} from 'common/axios';
import { fn } from '@cerdo/cerdo-utils';
import moment from 'moment';

const formRef = createRef();
let tableRef_1 = createRef();
let tableRef_2 = createRef();

const FeedbackModal = (props) => {
  const { onCancel, visible } = props;
  const [activeKey, setActiveKey] = useState(2);

  let tableParams = useRef({
    filedate: moment().format('YYYYMMDD'),
  });

  useEffect(() => {
    visible && (tableParams.current.filedate = moment().format('YYYYMMDD'));
  }, [visible]);

  const getData_1 = () => {
    return new Promise((resolve, reject) => {
      tableRef_1.current.getFormParams(formRef.current).then((values) => {
        listSummaryFeedbackAgency({
          ...tableParams.current,
          ...values,
        })
          .then((result) => {
            if (fn.checkResponse(result)) {
              resolve(result);
            }
            resolve(null);
          })
          .catch(() => {
            reject();
          });
      });
    });
  };

  const getData_2 = () => {
    return new Promise((resolve, reject) => {
      tableRef_2.current.getFormParams(formRef.current).then((values) => {
        listSummaryFeedbackFund({
          ...tableParams.current,
          ...values,
        })
          .then((result) => {
            if (fn.checkResponse(result)) {
              resolve(result);
            }
            resolve(null);
          })
          .catch(() => {
            reject();
          });
      });
    });
  };

  const handleSearchClick = (activeKey) => {
    Number(activeKey) === 1
      ? tableRef_1?.current?.reloadAndReset()
      : tableRef_2?.current?.reloadAndReset();
  };

  const renderTabBarExtraContent = () => {
    return (
      <Space>
        {Number(activeKey) === 2 && (
          <FetchSelect
            getData={listFundShare}
            style={{ width: 200 }}
            dropdownMatchSelectWidth={false}
            placeholder="搜索基金"
            mode="multiple"
            showArrow
            optionFilterProp="name"
            maxTagCount={1}
            maxTagPlaceholder={(values) => {
              return (
                <Popover
                  content={values.map((a) => (
                    <Tag style={{ display: 'block', margin: '4px 0' }} key={a.key}>
                      {a.label}
                    </Tag>
                  ))}
                >
                  +{values.length} ...
                </Popover>
              );
            }}
            onChange={(value) => {
              tableParams.current.fundcodes = (value || []).join();
              handleSearchClick(activeKey);
            }}
          >
            {(item) => (
              <FetchSelect.Option
                key={item.id}
                value={item.fundcode}
                name={`${item.fundname || ''}[${item.fundcode || ''}]`}
              >
                {item.fundname || ''}[{item.fundcode || ''}]
              </FetchSelect.Option>
            )}
          </FetchSelect>
        )}
        {Number(activeKey) === 2 && (
          <FetchSelect
            getData={listAgency}
            getParams={(value) => ({
              keyword: value,
              businesstype: '代销机构',
              page: 1,
              size: 30,
            })}
            style={{ width: 200 }}
            dropdownMatchSelectWidth={false}
            placeholder="搜索机构"
            mode="multiple"
            showArrow
            optionFilterProp="name"
            maxTagCount={1}
            maxTagPlaceholder={(values) => {
              return (
                <Popover
                  content={values.map((a) => (
                    <Tag style={{ display: 'block', margin: '4px 0' }} key={a.key}>
                      {a.label}
                    </Tag>
                  ))}
                >
                  +{values.length} ...
                </Popover>
              );
            }}
            onChange={(value) => {
              tableParams.current.salecodes = (value || []).join();
              handleSearchClick(activeKey);
            }}
          >
            {(item) => (
              <FetchSelect.Option
                key={item.organinfoid}
                value={item.companycode}
                name={`${item.companyname || ''}[${item.companycode || ''}]`}
              >
                {item.companyname || ''}[{item.companycode || ''}]
              </FetchSelect.Option>
            )}
          </FetchSelect>
        )}
        {Number(activeKey) === 1 && (
          <FetchSelect
            getData={listSummaryAgency}
            getParams={(value) => ({
              keyword: value,
              page: 1,
              size: 30,
            })}
            style={{ width: 200 }}
            dropdownMatchSelectWidth={false}
            placeholder="搜索参与人"
            mode="multiple"
            showArrow
            optionFilterProp="name"
            maxTagCount={1}
            maxTagPlaceholder={(values) => {
              return (
                <Popover
                  content={values.map((a) => (
                    <Tag style={{ display: 'block', margin: '4px 0' }} key={a.key}>
                      {a.label}
                    </Tag>
                  ))}
                >
                  +{values.length} ...
                </Popover>
              );
            }}
            onChange={(value) => {
              tableParams.current.salecodes = (value || []).join();
              handleSearchClick(activeKey);
            }}
          >
            {(item) => (
              <FetchSelect.Option
                key={item.code}
                value={item.code}
                name={`${item.name || ''}[${item.code || ''}]`}
              >
                {item.name || ''}[{item.code || ''}]
              </FetchSelect.Option>
            )}
          </FetchSelect>
        )}
        <DatePicker
          defaultValue={moment()}
          onChange={(date, dateString) => {
            tableParams.current.filedate = date?.format('YYYYMMDD');
            handleSearchClick(activeKey);
          }}
        />
      </Space>
    );
  };

  const getColumns = (type) => {
    const statusObj = {
      0: ['gray', '未发送'],
      1: ['orange', '发送中'],
      2: ['green', '发送成功'],
      3: ['red', '发送失败'],
      4: ['red', '销售端未开机'],
    };
    const typeObj = {
      0: '管理人',
      1: '代理人',
    };
    if (type === 1) {
      return [
        { title: '序号', dataIndex: 'sort', key: 'sort', valueType: 'number', width: 40 },
        {
          title: '参与人类型',
          dataIndex: 'type',
          key: 'type',
          width: 80,
          render(text) {
            return <span className={typeObj[Number(text)]}>{typeObj[Number(text)]}</span>;
          },
        },
        { title: '机构名称', dataIndex: 'name', key: 'name', width: 200 },
        { title: '机构代码', dataIndex: 'code', key: 'code', width: 80 },
        {
          title: '日期',
          dataIndex: 'filedate',
          key: 'filedate',
          width: 80,
          render: (text) => (text ? moment(text).format('YYYY-MM-DD') : '-'),
        },
      ];
    }
    return [
      {
        title: '序号',
        dataIndex: 'sort',
        key: 'sort',
        valueType: 'number',
        width: 40,
        render(_, __, index) {
          return index + 1;
        },
      },
      { title: '管理人代码', dataIndex: 'mancode', key: 'mancode', width: 80 },
      { title: '基金代码', dataIndex: 'fundcode', key: 'fundcode', width: 70 },
      { title: '基金名称', dataIndex: 'fundname', key: 'fundname', width: 100 },
      { title: '机构代码', dataIndex: 'salecode', key: 'salecode', width: 70 },
      { title: '机构名称', dataIndex: 'name', key: 'name', width: 120 },
      { title: '文件名称', dataIndex: 'filename', key: 'filename', width: 300 },
      {
        title: '任务状态',
        dataIndex: 'status',
        key: 'status',
        width: 60,
        render(text, record) {
          const status = statusObj[Number(text || '')];
          return <span className={status ? status[0] : ''}>{status ? status[1] : text}</span>;
        },
      },
      { title: '发送时间', dataIndex: 'sendtime', key: 'sendtime', width: 120 },
    ];
  };

  return (
    <DragModal
      visible={visible}
      closable
      onCancel={onCancel}
      title="查看发送反馈"
      destroyOnClose
      width="90%"
      bodyStyle={{ padding: 0 }}
      footer={<span className="red">注意：反馈信息到达时间为每个业务日6:00。</span>}
    >
      <Form ref={formRef} />
      <Tabs
        defaultActiveKey={activeKey}
        tabBarStyle={{ padding: '0 16px', marginBottom: 0 }}
        tabBarGutter={16}
        style={{ padding: 0 }}
        onChange={(activeKey) => {
          setActiveKey(activeKey);
          tableParams?.current?.fundcodes && (tableParams.current.fundcodes = '');
          tableParams?.current?.salecodes && (tableParams.current.salecodes = '');
          handleSearchClick(activeKey);
        }}
        tabBarExtraContent={renderTabBarExtraContent()}
      >
        <Tabs.TabPane tab="概要文件汇总列表" key={2} style={{ padding: '8px 12px ' }}>
          <FetchTable
            size="small"
            showTools={false}
            ref={tableRef_2}
            getList={getData_2}
            columns={getColumns(2)}
            scroll={{ y: `calc(100vh - 360px)` }}
          />
        </Tabs.TabPane>
        <Tabs.TabPane tab="参与人列表" key={1} style={{ padding: '8px 12px ' }}>
          <FetchTable
            size="small"
            showTools={false}
            ref={tableRef_1}
            getList={getData_1}
            columns={getColumns(1)}
            scroll={{ y: `calc(100vh - 360px)` }}
          />
        </Tabs.TabPane>
      </Tabs>
    </DragModal>
  );
};

export default FeedbackModal;
