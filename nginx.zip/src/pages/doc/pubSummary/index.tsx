/**
 * 见证监会公告 列表页
 * 单秀雨 2022-03-24
 */

import React, { useRef, useState } from 'react';
import { message, Button, Spin } from 'antd';
import { reportSummaryFile } from 'common/axios';
import { listSummaryFileApi } from '@/common/axios/config';
import { fn } from '@cerdo/cerdo-utils';
import { type DetailGridInfo } from 'ag-grid-community';
import { PDTSearchAgGridTable } from '@/common/component';
import UploadModal from './com/uploadModal';
import FeedbackModal from './com/feedbackModal';
import { getColumns } from './data';

interface SearchParams {
  keyword?: string;
}

const Index = () => {
  const agGridRef = useRef<DetailGridInfo>(null);
  const searchAgTableRef = useRef(null);
  const searchParams = useRef<SearchParams>({});
  const [loading, setLoading] = useState(false);
  const [selectAll, setSelectAll] = useState(false); // 是否全选
  const [selectedRows, setSelectedRows] = useState([]); // 选中行
  const [modalVisible, setModalVisible] = useState(false);
  const [feedbackModalVisible, setFeedbackModalVisible] = useState(false);

  const onGridReady = (grid) => {
    agGridRef.current = grid;
  };

  const onSelectionChanged = (e, { selectAll, selectedRows }) => {
    setSelectAll(selectAll);
    setSelectedRows(selectedRows);
  };

  const onFormatRowData = (data) => {
    data.forEach((a) => {
      a.status = '3';
      a.filereportlist?.forEach((b) => {
        a.status = Number(a.status) < Number(b.status) ? a.status : b.status;
      });
    });
    return data;
  };

  // 上报、批量上报
  const handlePubClick = (rows) => {
    let fileids = null;
    if (Array.isArray(rows)) {
      fileids = rows.flatMap((a) => (a.filereportlist || []).map((b) => b.fileid)).join();
    } else {
      fileids = (rows.filereportlist || []).map((a) => a.fileid).join();
    }

    setLoading(true);
    reportSummaryFile({ fileids: fileids, selectAll, keyword: searchParams.current.keyword })
      .then((result) => {
        if (fn.checkResponse(result)) {
          message.success('上报成功', 2, () => {
            agGridRef.current.api.deselectAll();
            searchAgTableRef.current.onSearch();
          });
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };

  const onFormatParams = (params) => {
    searchParams.current = params;
    return params;
  };

  console.log('selectedRows', selectedRows);

  return (
    <Spin spinning={loading}>
      <PDTSearchAgGridTable
        url={listSummaryFileApi}
        ref={searchAgTableRef}
        actionBtns={[
          <Button
            key="1"
            type="primary"
            disabled={!selectedRows.length && !selectAll}
            onClick={() => handlePubClick(selectedRows)}
          >
            批量上报
          </Button>,
          <Button key="2" type="primary" onClick={() => setModalVisible(true)}>
            上传文件
          </Button>,
          <Button key="3" type="primary" onClick={() => setFeedbackModalVisible(true)}>
            查看发送反馈
          </Button>,
        ]}
        rowId="id"
        tableConfig={{
          columnDefs: getColumns({ handlePubClick }),
          rowModelType: 'serverSide',
          onGridReady,
          onSelectionChanged,
        }}
        onFormatParams={onFormatParams}
        onFormatRowData={onFormatRowData}
      />

      <UploadModal
        visible={modalVisible}
        onOk={() => {
          setModalVisible(false);
          searchAgTableRef.current.onSearch();
        }}
        onCancel={() => setModalVisible(false)}
      />

      <FeedbackModal
        visible={feedbackModalVisible}
        onOk={() => setFeedbackModalVisible(false)}
        onCancel={() => setFeedbackModalVisible(false)}
      />
    </Spin>
  );
};

export default Index;
