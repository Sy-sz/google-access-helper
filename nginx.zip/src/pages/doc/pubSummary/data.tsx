import React from 'react';
import { Tooltip, Button } from 'antd';
import { commonApi } from 'common/axios';
import { downloadFileApi } from 'common/axios/config';
import { InfoCircleOutlined } from '@ant-design/icons';
import { type ITableConfig } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';

const statusObj = {
  undefined: ['', ''],
  0: ['gray', '未上报'],
  1: ['orange', '处理中'],
  2: ['green', '处理成功'],
  '-1': ['red', '处理失败'],
};
export const getColumns = ({ handlePubClick }) =>
  [
    {
      headerName: '关键词',
      field: 'keyword',
      hideInTable: true,
      componentProps: { placeholder: '请输入产品代码或名称搜索', allowClear: true },
    },
    {
      headerName: '基金',
      field: 'fundcode',
      flex: 1,
      pinned: 'left',
      width: 300,
      minWidth: 300,
      hideInSearch: true,
      valueGetter: ({ data }) => `${data.fundname || ''}[${data.fundcode}]`,
    },
    {
      headerName: '概要文件',
      field: 'filename',
      // width: 560,
      // minWidth: 560,
      flex: 1,
      autoHeight: true,
      sortable: false,
      hideInSearch: true,
      cellRenderer: ({ data }) => {
        return data.filereportlist?.map((a) => (
          <Button
            size="small"
            key={a.fileid}
            type="link"
            style={{ display: 'block' }}
            onClick={() => commonApi.downloadFile(a.fileid, a.filename, downloadFileApi)}
          >
            <Tooltip
              placement="right"
              title={
                <small className={statusObj[`${a.status}`][0]}>
                  {statusObj[`${a.status}`][1]}
                  {Number(a.status) === -1 ? `：${a.msg}` : ''}
                </small>
              }
            >
              {a.filename || ''}&nbsp;&nbsp;
              {Number(a.status) === -1 && a.msg && <InfoCircleOutlined className="red" />}
            </Tooltip>
          </Button>
        ));
      },
    },
    {
      headerName: '状态',
      field: 'status',
      hideInSearch: true,
      sortable: false,
      width: 100,
      minWidth: 100,
      headerComponentParams: {
        tooltip:
          '未上报：概要文件已经上传，但未上报 <br/>  处理中：文件已上报，系统处理中 <br/>处理成功：文件上报中数平台成功 <br/> 处理失败：文件上报中数平台失败 <br/>',
      },
      cellRenderer: ({ value }) => {
        return <span className={statusObj[`${value}`][0]}>{statusObj[`${value}`][1]}</span>;
      },
    },
    {
      headerName: '上传人',
      field: 'createuser',
      hideInSearch: true,
      width: 100,
      minWidth: 100,
    },
    {
      headerName: '上传时间',
      field: 'createtime',
      hideInSearch: true,
      width: 160,
      minWidth: 160,
    },
    {
      headerName: '操作',
      field: 'action',
      hideInSearch: true,
      sortable: false,
      filter: false,
      width: 100,
      minWidth: 100,
      cellRenderer: ({ data }) => {
        return (
          data.status === '0' && (
            <Button type="link" onClick={() => handlePubClick(data)}>
              上报
            </Button>
          )
        );
      },
    },
  ] as ITableConfig['columnDefs'];
