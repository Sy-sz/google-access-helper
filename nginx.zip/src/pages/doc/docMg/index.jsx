import React, { Component } from 'react';
import {
  Card,
  Menu,
  Button,
  message,
  Input,
  Popconfirm,
  Form,
  Row,
  Col,
  Divider,
  Dropdown,
  Space,
} from 'antd';
import { DownOutlined } from '@ant-design/icons';
import {
  listDocTree,
  listDocFileList,
  listDocHistory,
  saveFile,
  removeFile,
  batchReadAutoNumberFile,
  commonApi,
} from 'common/axios';
import { uploadFileApi, downloadFileApi } from 'common/axios/config';
import HistoryModal from './com/HistoryModal';
import { AUTH_DIR, AUTH_EDIT, AUTH_VIEW, methods } from './com/methods';
import {
  RangeDate,
  UploadFile,
  UserDeptSelect,
  EditTree,
  FetchTable,
  DictSelect,
} from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { array, routeUtils, fn } from '@cerdo/cerdo-utils';
import UploadModal from './com/UploadModal';
import { downloadBatchFile, getProcessDocFileList } from '@/common/axios';
import { getColumns, typeData } from './index.data';
import moment from 'moment';
import SearchCard from '@/common/component/SearchCard';

const FormItem = Form.Item;

class Index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      treeLoading: false,
      treeData: [],
      expandedKeys: [],
      selectedTreeNode: {},
      selectUserKeys: [],
      selectDeptKeys: [],
      selectRoleKeys: [],
      selectPositionKeys: [],
      selectedRows: '',
      authVisible: false,

      historyVisible: false,
      historyList: [],
      uploadVisible: false,

      permissions: { isProductManager: false },

      curDocType: {},

      batchDownloadLoading: false,
    };
    this.formRef = React.createRef();
    methods(this);
  }

  componentDidMount() {
    this.getConfigListData();
  }

  getConfigListData = () => {
    this.setState({ treeLoading: true });
    const pathname = this.props.location.pathname;
    const arr = (pathname || '').split('/');
    let curDocType = typeData.find((a) => a.typecode === arr[arr.length - 1]);
    // 如果是新增的文档类型，则使用 文档管理员 权限 作为管理权限
    if (!curDocType) {
      curDocType = {
        systemid: `fsyy-pdt-backend-${arr[arr.length - 1]}`,
        permissionid: 'eeb55d52-8b67-4d84-9a7e-4f4ff7749f45',
      };
    }
    this.setState({ curDocType });

    this.getPdtDocTree(curDocType.systemid);
    this.verifyUserPermission(curDocType.permissionid);
  };

  // 验证用户权限
  verifyUserPermission(permissionids) {
    commonApi.userPermission({ permissionids }).then((result) => {
      if (fn.checkResponse(result)) {
        this.setState({
          permissions: {
            isProductManager: result.data[0].haspermission === 1,
          },
        });
      }
    });
  }

  getPdtDocTree = (systemid) => {
    this.setState({ treeLoading: true });
    listDocTree({ systemid })
      .then((res) => {
        if (res && res.data.length > 0) {
          // 默认展开 全部
          let expandedKeys = [res.data[0].id];
          if (res.data[0].children && res.data[0].children.length > 0) {
            expandedKeys.push(res.data[0].children[0].id);
          }
          this.setState(
            {
              treeData: array.toOptionsArray(res.data, 'id', 'nodeName'),
              expandedKeys: expandedKeys,
              selectedTreeNode: res.data[0],
            },
            () => {
              this.table.reload();
            },
          );
        }
      })
      .catch(() => {})
      .finally(() => this.setState({ treeLoading: false }));
  };

  reloadPdtDocTree = () => {
    listDocTree({ systemid: this.state.curDocType.systemid }).then((res) => {
      if (res && res.data.length > 0) {
        this.setState(
          {
            treeData: array.toOptionsArray(res.data, 'id', 'nodeName'),
          },
          () => {
            this.tree.reload(this.state.treeData);
          },
        );
      }
    });
  };

  getDocList = () => {
    const { selectedTreeNode, curDocType } = this.state;
    if (!(selectedTreeNode && selectedTreeNode.id)) {
      return Promise.resolve(null);
    }
    return new Promise((resolve, reject) => {
      this.table.getFormParams(this.formRef.current, 'YYYY-MM-DD').then((values) => {
        let func = listDocFileList;
        if (curDocType.typecode === 'process') {
          func = getProcessDocFileList;
        }

        func({
          ...values,
          catalogid: selectedTreeNode.id,
          key: values.value ? values.key : null, // 未填 value的时候 key置空
          systemid: curDocType.systemid,
        })
          .then((result) => {
            if (fn.checkResponse(result)) {
              resolve(result);
            }
            resolve(null);
          })
          .catch(() => {
            reject();
          });
      });
    });
  };

  getHistoryList = (record) => {
    this.setState({ historyVisible: true });
    listDocHistory({
      docfileid: record.docfileid,
    })
      .then((res) => {
        if (res && res.data && Array.isArray(res.data) && res.data.length > 0) {
          this.setState({
            historyList: res.data.map((item, index) => {
              item.id = index;
              return item;
            }),
          });
        }
      })
      .catch(() => {});
  };

  /** 删除文档中的文件 */
  handleDeleteFileClick = (item) => {
    removeFile({
      fileid: item.fileid,
    })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('删除成功', 0.5, () => {
            this.table.reload();
          });
        }
      })
      .catch(() => {});
  };

  /** 替换新文件 */
  handleReplaceFileClick = (file, record) => {
    const { selectedTreeNode, curDocType } = this.state;
    saveFile({
      ...file,
      catalogid: selectedTreeNode.id,
      lastfileid: record.fileid,
      isProcess: curDocType.typecode === 'process' ? 1 : 0,
    }).then((res) => {
      if (fn.checkResponse(res)) {
        message.success('替换成功', 0.5, () => {
          this.table.reload();
        });
      }
      if (res.code === 'C201') {
        message.error(res.msg);
      }
    });
  };

  getOperationBtn = (record) => {
    const { curDocType } = this.state;
    return Number(record.authtype) === 1 ? (
      <>
        <Button
          type="link"
          onClick={() => {
            this.handleDownloadClick(record.fileid, record.filename);
          }}
        >
          下载
        </Button>
        <Divider type="vertical" />
        <UploadFile
          uploadUrl={uploadFileApi}
          downloadUrl={downloadFileApi}
          accept=".xls,.xlsx,.doc,.docx,.zip,.rar"
          showUploadList={false}
          disabled={record.status && record.status === 3 ? true : false}
          onChange={(file, fileList) => this.handleReplaceFileClick(file, record)}
        >
          <Button disabled={record.status && record.status === 3 ? true : false} type="link">
            替换
          </Button>
        </UploadFile>
        <Divider type="vertical" />
        <Button
          type="link"
          size="small"
          onClick={() => {
            this.getHistoryList(record);
          }}
        >
          历史
        </Button>
        {curDocType.typecode !== 'process' && (
          <>
            <Divider type="vertical" />
            <Popconfirm
              title="确定删除?"
              onConfirm={() => {
                this.handleDeleteFileClick(record);
              }}
            >
              <Button type="link" danger size="small">
                删除
              </Button>
            </Popconfirm>
          </>
        )}

        {/* {isProductManager && <Divider type="vertical" />}
                {isProductManager && this.getAuthBtn({ type: 'link', filetype: AUTH_FILE, fileid: record.fileid, name: record.filename })} */}
      </>
    ) : (
      <>
        <Button
          type="link"
          onClick={() => {
            this.handleDownloadClick(record.fileid, record.filename);
          }}
        >
          下载
        </Button>
        <Divider type="vertical" />
        <Button
          type="link"
          size="small"
          onClick={() => {
            this.getHistoryList(record);
          }}
        >
          历史文档
        </Button>
      </>
    );
  };

  getAuthBtn = (config = {}) => {
    const { selectedTreeNode } = this.state;
    if (!selectedTreeNode.fileid && !selectedTreeNode.id) {
      return null;
    }
    return (
      <Dropdown
        overlay={
          <Menu
            onClick={({ key }) => {
              this.getPermissionView({
                title: `${config.name} - ${
                  config.filetype === '0' ? '文件' : '文件目录'
                } - 编辑 - 权限设置`,
                fileid: config.fileid,
                filetype: config.filetype,
                authtype: key,
              });
            }}
          >
            <Menu.Item key={AUTH_EDIT}>编辑权限</Menu.Item>
            <Menu.Item key={AUTH_VIEW}>查看权限</Menu.Item>
          </Menu>
        }
      >
        <Button type={config.type || 'primary'} disabled>
          授权 <DownOutlined />
        </Button>
      </Dropdown>
    );
  };

  clickJump = () => {
    const { selectedRows } = this.state;
    if (selectedRows.some((a) => !['docx', 'doc', 'pdf'].includes(a.filename.split('.')[1]))) {
      message.warning('仅支持word、pdf文档编号');
      return;
    }

    batchReadAutoNumberFile(selectedRows).then((res) => {
      if (fn.checkResponse(res)) {
        routeUtils.pushObjNew.call(this, {
          pathname: `/app/pdt/doc/autonumber`,
          state: { tableList: res.data },
        });
      }
    });
  };

  hanldDownloadClick = () => {
    const { selectedRows, curDocType } = this.state;
    if (selectedRows.length === 0) {
      message.warning('请先选择要导出的文件');
      return;
    }
    this.setState({ batchDownloadLoading: true });
    downloadBatchFile({
      filelist: selectedRows,
      filename: `${curDocType.typename}_${moment().format('YYYY-MM-DD')}.zip`,
    }).then(() => {
      this.setState({ batchDownloadLoading: false });
    });
  };

  onDrag = (ev, ui) => {
    console.log(ev, ui);
    // const { initialLeftBoxWidth } = this.state;
    // const newLeftBoxWidth = ui.x + initialLeftBoxWidth;
    // this.setState({
    //     leftBoxWidth: newLeftBoxWidth,
    //     dragBoxBackground: '#FFB6C1'
    // });
  };

  render() {
    const {
      treeData,
      treeLoading,
      expandedKeys,
      selectedTreeNode,
      historyVisible,
      historyList,
      authVisible,
      authTitle,
      uploadVisible,
      selectUserKeys,
      selectDeptKeys,
      selectRoleKeys,
      selectPositionKeys,
      selectedRows,
      curDocType,
      permissions: { isProductManager },
      batchDownloadLoading,
      uploadTreeLoading,
    } = this.state;

    const rowSelection = isProductManager
      ? {
          onChange: (selectedRowKeys, selectedRows) => {
            const newSelectedRows = selectedRows.map((item) => {
              return { filename: item.filename, fileid: item.fileid };
            });
            this.setState({ selectedRows: newSelectedRows });
          },
        }
      : null;

    return (
      <div>
        <Row gutter={[8, 16]}>
          <Col span={6}>
            <Card bodyStyle={{ overflowX: 'auto' }} bordered={false}>
              <EditTree
                ref={(ref) => {
                  this.tree = ref;
                }}
                style={{ height: 'calc(100vh - 160px)', overflow: 'auto' }}
                draggable
                expandedKeys={expandedKeys}
                gData={treeData}
                loading={treeLoading}
                onSelect={(value, { selected, node }) => {
                  if (selected) {
                    this.setState({ selectedTreeNode: node }, () => {
                      this.table.reloadAndReset();
                    });
                  }
                }}
                onItemDrop={(info) => this.handleDropNode(info)}
                onItemDelete={(item) => this.handleDeleteNode(item)}
                onItemEdit={(item) => this.handleEditNode(item)}
                onItemAdd={(item) => this.handleAddNode(item)}
                allowEdit={isProductManager}
              />
            </Card>
          </Col>
          <Col span={18}>
            <SearchCard
              bordered={false}
              showNum={2}
              ref={this.formRef}
              onSearch={() => this.table.reloadAndReset()}
              onExpand={(expand) => this.table.setScrollY(expand ? 365 : 325)}
            >
              <Col span={12}>
                <FormItem label="文件名" name="filename">
                  <Input allowClear style={{ width: '100%' }} placeholder="请输入文件名" />
                </FormItem>
              </Col>
              <Col span={12}>
                <Form.Item label="创建时间" name="daterange">
                  <RangeDate />
                </Form.Item>
              </Col>
              <Col span={12}>
                <FormItem label="标签搜索" name="value">
                  <Input
                    addonBefore={
                      <Form.Item name="key" noStyle>
                        <DictSelect
                          style={{ width: 100 }}
                          dictid="8bbf6eb1-95a3-494c-b709-02f16d81c266"
                        >
                          {(item) => (
                            <DictSelect.Option key={item.id} value={item.value}>
                              {item.name}
                            </DictSelect.Option>
                          )}
                        </DictSelect>
                      </Form.Item>
                    }
                    style={{ width: '100%' }}
                    placeholder="请输入标签值"
                    allowClear
                  />
                </FormItem>
              </Col>
            </SearchCard>
            <ListCard
              title="文件列表"
              extra={
                Number(selectedTreeNode.authtype) === 1 ? (
                  <Space>
                    {curDocType.typecode === 'agency' && isProductManager && (
                      <Button
                        type="primary"
                        loading={uploadTreeLoading}
                        onClick={this.handleUpdateAgencyClick}
                      >
                        刷新树
                      </Button>
                    )}
                    {curDocType.typecode === 'notice' && (
                      <Button
                        type="primary"
                        disabled={!selectedRows || selectedRows.length === 0}
                        onClick={() => {
                          this.clickJump();
                        }}
                      >
                        自动编号
                      </Button>
                    )}
                    {isProductManager &&
                      curDocType.typecode === 'notice' &&
                      this.getAuthBtn({
                        filetype: AUTH_DIR,
                        fileid: selectedTreeNode.id,
                        name: selectedTreeNode.nodeName,
                      })}
                    {/* <UploadFile
                                        disabled={!(selectedTreeNode !== null && selectedTreeNode.id !== null)}
                                        showUploadList={false}
                                        showProcess
                                        accept=".xls,.xlsx,.doc,.docx,.zip,.rar"
                                        onChange={(file, fileList) => this.handleAddFileClick(file, fileList)}
                                        /> */}
                    {((curDocType.typecode === 'agency' &&
                      (!selectedTreeNode.children ||
                        (Array.isArray(selectedTreeNode.children) &&
                          selectedTreeNode.children.length === 0))) ||
                      (selectedTreeNode.id && curDocType.typecode !== 'agency')) && (
                      <Button
                        type="primary"
                        disabled={!(selectedTreeNode !== null && selectedTreeNode.id !== null)}
                        onClick={() => this.setState({ uploadVisible: true })}
                      >
                        上传文件
                      </Button>
                    )}
                    <Button
                      type="primary"
                      disabled={!(selectedTreeNode !== null && selectedTreeNode.id !== null)}
                      onClick={this.hanldDownloadClick}
                      loading={batchDownloadLoading}
                    >
                      批量下载
                    </Button>
                  </Space>
                ) : (
                  <Space>
                    {curDocType.typecode === 'agency' && (
                      <Button type="primary" onClick={this.handleUpdateAgencyClick}>
                        刷新树
                      </Button>
                    )}
                    <Button
                      type="primary"
                      disabled={!(selectedTreeNode !== null && selectedTreeNode.id !== null)}
                      onClick={this.hanldDownloadClick}
                      loading={batchDownloadLoading}
                    >
                      批量下载
                    </Button>
                  </Space>
                )
              }
            >
              <FetchTable
                size="small"
                showTools={false}
                ref={(ref) => {
                  this.table = ref;
                }}
                rowKey="fileid"
                columns={getColumns(curDocType.typecode, isProductManager, this.getOperationBtn)}
                rowSelection={rowSelection}
                getList={this.getDocList}
                scroll={{ y: `calc(100vh - 325px)`, x: 2000 }}
                autoHeight={{
                  blankHeight: 350,
                }}
              />
            </ListCard>
          </Col>
        </Row>

        <HistoryModal
          visible={historyVisible}
          list={historyList}
          onCancel={() => {
            this.setState({ historyVisible: false, historyList: [] });
          }}
        />

        <UploadModal
          data={{
            id: selectedTreeNode.id,
            curDocType,
          }}
          visible={uploadVisible}
          onOk={() => {
            this.setState({ uploadVisible: false });
            this.table.reload();
          }}
          onCancel={() => {
            this.setState({ uploadVisible: false });
          }}
        />

        <UserDeptSelect
          title={authTitle}
          visible={authVisible}
          onSave={this.authSave}
          onCancel={this.authCancel}
          selectUserKeys={selectUserKeys}
          selectDeptKeys={selectDeptKeys}
          selectRoleKeys={selectRoleKeys}
          selectPositionKeys={selectPositionKeys}
          singleMode={false}
          deptable
          userable
          roleable
          positionable
        />
      </div>
    );
  }
}

export default Index;
