import { DragModal, UploadFile, FetchSelect, DictSelect } from '@cerdo/cerdo-design';
import { CONST, fn } from '@cerdo/cerdo-utils';
import { Form, Row, Col, message, Radio } from 'antd';
import React, { Component } from 'react';
import { saveFile, listFundShare } from 'common/axios';
import { uploadFileApi, downloadFileApi } from 'common/axios/config';
import { listDictionary } from '@cerdo/cerdo-utils/lib/api';

const FormItem = Form.Item;

class UploadModal extends Component {
  constructor() {
    super();
    this.state = {
      tagsData: [],
      confirmLoading: false,
    };
    this.data = {};
  }

  componentDidMount() {
    listDictionary({ dictids: '50f50b7a-62da-4a01-86aa-4181871d96a8' }).then((result) => {
      if (fn.checkResponse(result)) {
        this.setState({
          tagsData: result.data[0].children,
        });
      }
    });
  }

  handleSubmit = () => {
    this.form.validateFields().then((values) => {
      this.setState({ confirmLoading: true });
      saveFile({
        fundlist: this.data.fundlist,
        tags: this.data.tags,
        ...values.file[0],
        catalogid: this.props.data.id,
      }).then((res) => {
        if (fn.checkResponse(res)) {
          message.success('保存成功', 0.2, () => {
            this.props.onOk();
          });
        }
        if (res.code === 'C201') {
          message.error(res.msg);
        }
        this.setState({ confirmLoading: false });
      });
    });
  };

  render() {
    const {
      visible,
      onCancel,
      data: { curDocType },
    } = this.props;
    const { tagsData, confirmLoading } = this.state;
    return (
      <DragModal
        visible={visible}
        onCancel={() => {
          this.form.resetFields();
          onCancel();
        }}
        onOk={this.handleSubmit}
        maskClosable={false}
        destroyOnClose
        title="上传文件"
        width={800}
        confirmLoading={confirmLoading}
      >
        <Form
          {...CONST.layout}
          ref={(ref) => {
            this.form = ref;
          }}
        >
          <Row>
            <Col span={24}>
              <FormItem
                label="文件"
                name="file"
                getValueFromEvent={(file, fileList) => fileList}
                rules={[{ required: true, message: '请上传文件' }]}
              >
                <UploadFile
                  uploadUrl={uploadFileApi}
                  downloadUrl={downloadFileApi}
                  showProcess={false}
                  // accept=".xls,.xlsx,.doc,.docx,.zip,.rar"
                />
              </FormItem>
            </Col>
            {curDocType.typecode !== 'agency' && (
              <Col span={24}>
                <FormItem
                  label="关联基金"
                  name="fund"
                  hasFeedback
                  rules={[{ required: false, message: '请选择基金' }]}
                >
                  <FetchSelect
                    getData={listFundShare}
                    mode="multiple"
                    style={{ width: '100%' }}
                    dropdownMatchSelectWidth={false}
                    placeholder="请输入基金代码或名称搜索"
                    onChange={(value, option) => {
                      this.data.fundlist =
                        option && Array.isArray(option)
                          ? option.map((a) => ({
                              fundcode: a.key,
                              fundname: a.name,
                              fundid: a.id,
                              fund: `${a.name}[${a.key}]`,
                            }))
                          : null;
                    }}
                  >
                    {(item) => (
                      <FetchSelect.Option
                        key={item.fundcode}
                        id={item.fundid}
                        value={`${item.fundname}[${item.fundcode}]`}
                        name={item.fundname}
                      >
                        {item.fundname}[{item.fundcode}]
                      </FetchSelect.Option>
                    )}
                  </FetchSelect>
                </FormItem>
              </Col>
            )}
            {curDocType.typecode === 'agency' ? (
              <Col span={24}>
                <FormItem
                  label="标签"
                  name="tags"
                  hasFeedback
                  rules={[{ required: true, message: '请选择标签' }]}
                  onChange={(e) => {
                    this.data.tags = e.target.value;
                  }}
                >
                  <Radio.Group buttonStyle="solid" size="small">
                    {tagsData.map((item) => (
                      <Radio.Button
                        style={{ display: 'inline-block', margin: '3px 2px' }}
                        key={item.name}
                        value={item.name}
                      >
                        {item.name}
                      </Radio.Button>
                    ))}
                  </Radio.Group>
                </FormItem>
              </Col>
            ) : (
              <Col span={24}>
                <FormItem
                  label="标签"
                  name="tags"
                  hasFeedback
                  rules={[{ required: false, message: '请选择标签' }]}
                >
                  <DictSelect
                    mode="tags"
                    dictid="50f50b7a-62da-4a01-86aa-4181871d96a8"
                    style={{ width: '100%' }}
                    placeholder="请选择标签"
                    onChange={(value, option) => {
                      this.data.tags = value && Array.isArray(value) ? value.join(',') : value;
                    }}
                  />
                </FormItem>
              </Col>
            )}
          </Row>
        </Form>
      </DragModal>
    );
  }
}

export default UploadModal;
