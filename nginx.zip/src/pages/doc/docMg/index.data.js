import React from 'react';
import { convert } from '@cerdo/cerdo-utils/lib';
import { Popover, Space, Tag, Typography } from 'antd';
import {
  FileWordOutlined,
  FilePdfOutlined,
  FileImageOutlined,
  FileTextOutlined,
  FileOutlined,
  FileExcelOutlined,
  FileZipOutlined,
} from '@ant-design/icons';
import { downloadFileApi } from '@/common/axios/config';
import { commonApi } from '@/common/axios';

export const getFileIcon = (fileName, fileExt) => {
  let newFileExt = fileExt;
  if (!fileExt && fileName) {
    // 正则获取文件扩展名
    const matchArr = fileName.match(/\.(\w+)$/);
    newFileExt = Array.isArray(matchArr) && matchArr.length > 0 ? matchArr[1] : null;
  }
  switch ((newFileExt || '').toLocaleLowerCase()) {
    case 'doc':
    case 'docx':
      return <FileWordOutlined style={{ color: '#2b569a', fontSize: 16 }} />;
    case 'pdf':
      return <FilePdfOutlined style={{ color: 'red', fontSize: 16 }} />;
    case 'jpg':
    case 'png':
    case 'gif':
    case 'jpeg':
      return <FileImageOutlined style={{ color: '#28afe9', fontSize: 16 }} />;
    case 'txt':
    case 'log':
      return <FileTextOutlined style={{ color: 'gray', fontSize: 16 }} />;
    case 'xls':
    case 'xlsx':
      return <FileExcelOutlined style={{ color: '#207146', fontSize: 16 }} />;
    case 'zip':
    case 'rar':
      return <FileZipOutlined style={{ fontSize: 16 }} />;
    default:
      return <FileOutlined style={{ color: 'gray', fontSize: 16 }} />;
  }
};

export const typeData = [
  {
    typecode: 'notice',
    typename: '公告文档',
    catalogid: '',
    systemid: 'fsyy-pdt-backend',
    permissionid: 'cd1eb03215fb4f3ba6952f59fbd745fb',
  }, // 公告文档 doc-notice
  {
    typecode: 'process',
    typename: '流程文档',
    catalogid: '',
    systemid: 'fsyy-pdt-backend-process',
    permissionid: 'be7e6673-f8e9-4e99-bef1-a65798ec9bbe',
  }, // 流程文档
  {
    typecode: 'agency',
    typename: '代销机构文档',
    catalogid: '',
    systemid: 'fsyy-pdt-backend-agency',
    permissionid: '5110f9dd-6b45-41a9-a236-f7de9b8c91d2',
  }, // 代销机构文档
  {
    typecode: 'special',
    typename: '专户文档',
    catalogid: '',
    systemid: 'fsyy-pdt-backend-special',
    permissionid: 'bb0e2fd6-70b7-46bf-b70b-b4a7732a385c',
  }, // 专户文档
  {
    typecode: 'clear',
    typename: '清算文档',
    catalogid: '',
    systemid: 'fsyy-pdt-backend-clear',
    permissionid: '6795ed99-0d10-4c94-a8af-12f18bbb408d',
  }, // 专户文档
  {
    typecode: 'data',
    typename: '资料库',
    catalogid: '',
    systemid: 'fsyy-pdt-backend-data',
    permissionid: '1dbd285b-6d63-4abf-b59c-7c62a6002214',
  }, // 资料库
];

export const getColumns = (type, isProductManager, getOperationBtn) => {
  let columns = [];
  switch (type) {
    case 'notice':
      columns = [
        {
          title: '文件名',
          dataIndex: 'filename',
          key: 'filename',
          width: 350,
          fixed: 'left',
          render: (text, record) => (
            <a
              onClick={() =>
                Number(record.authtype) === 1 &&
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi)
              }
            >
              {getFileIcon(text)} {text}
            </a>
          ),
        },
        { title: '分类', dataIndex: 'docname', key: 'docname', width: 120 },
        {
          title: '文件大小',
          dataIndex: 'filesize',
          key: 'filesize',
          width: 100,
          render: (text) => (text ? convert.toFileSize(text) : '0KB'),
        },
        {
          title: '关联产品',
          dataIndex: 'fund',
          key: 'fund',
          width: 200,
          render: (text, record) => {
            const funds = (record.mappinglist || []).filter((a) => a.key === 'fund');
            return (
              <Popover
                placement="bottomLeft"
                content={
                  <Space
                    direction="vertical"
                    size={0}
                    style={{
                      maxHeight: 400,
                      overflowY: 'auto',
                      marginRight: '-16px',
                      paddingRight: '16px',
                    }}
                  >
                    {funds.map((a, i) => (
                      <span key={i}>{a.value}</span>
                    ))}
                  </Space>
                }
              >
                <Typography.Paragraph ellipsis>
                  {funds.map((a) => a.value).join(' ')}
                </Typography.Paragraph>
              </Popover>
            );
          },
        },
        {
          title: '标签',
          dataIndex: 'tag',
          key: 'tag',
          render: (text, record) => {
            const tags = (record.mappinglist || []).filter((a) => a.key === 'tag');
            return (
              <Popover
                placement="bottomLeft"
                content={
                  <Space
                    direction="vertical"
                    size={0}
                    style={{
                      maxHeight: 400,
                      overflowY: 'auto',
                      marginRight: '-16px',
                      paddingRight: '16px',
                    }}
                  >
                    {tags.map((a, i) => (
                      <span key={i}>{a.value}</span>
                    ))}
                  </Space>
                }
              >
                <Typography.Paragraph ellipsis>
                  {tags.map((a) => (
                    <Tag key={a.value}>{a.value}</Tag>
                  ))}
                </Typography.Paragraph>
              </Popover>
            );
          },
        },
        {
          title: '最近更新人/时间',
          dataIndex: 'updateuser',
          width: 150,
          fixed: 'right',
          render: (_, record) => {
            return (
              <Space size={0} direction="vertical">
                <span>{record.updateuser || record.createuser}</span>
                <span>{record.updatetime || record.createtime}</span>
              </Space>
            );
          },
        },
        {
          title: '操作',
          dataIndex: 'operation',
          key: 'operation',
          width: isProductManager ? 200 : 120,
          fixed: 'right',
          render: (text, record) => getOperationBtn(record),
        },
      ];
      break;
    case 'agency':
      columns = [
        {
          title: '文件名',
          dataIndex: 'filename',
          key: 'filename',
          width: 350,
          fixed: 'left',
          render: (text, record) => (
            <a
              onClick={() =>
                Number(record.authtype) === 1 &&
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi)
              }
            >
              {getFileIcon(text)} {text}
            </a>
          ),
        },
        { title: '代销机构', dataIndex: 'docname', key: 'docname', width: 120 },
        {
          title: '文件大小',
          dataIndex: 'filesize',
          key: 'filesize',
          width: 100,
          render: (text) => (text ? convert.toFileSize(text) : '0KB'),
        },
        {
          title: '标签',
          dataIndex: 'tag',
          key: 'tag',
          render: (text, record) => {
            const tags = (record.mappinglist || []).filter((a) => a.key === 'tag');
            return (
              <Popover
                placement="bottomLeft"
                content={
                  <Space
                    direction="vertical"
                    size={0}
                    style={{
                      maxHeight: 400,
                      overflowY: 'auto',
                      marginRight: '-16px',
                      paddingRight: '16px',
                    }}
                  >
                    {tags.map((a, i) => (
                      <span key={i}>{a.value}</span>
                    ))}
                  </Space>
                }
              >
                <Typography.Paragraph ellipsis>
                  {tags.map((a) => (
                    <Tag key={a.value}>{a.value}</Tag>
                  ))}
                </Typography.Paragraph>
              </Popover>
            );
          },
        },
        {
          title: '最近更新人/时间',
          dataIndex: 'updateuser',
          width: 150,
          fixed: 'right',
          render: (_, record) => {
            return (
              <Space size={0} direction="vertical">
                <span>{record.updateuser || record.createuser}</span>
                <span>{record.updatetime || record.createtime}</span>
              </Space>
            );
          },
        },
        {
          title: '操作',
          dataIndex: 'operation',
          key: 'operation',
          fixed: 'right',
          width: isProductManager ? 200 : 120,
          render: (text, record) => getOperationBtn(record),
        },
      ];
      break;
    case 'special':
      columns = [
        {
          title: '文件名',
          dataIndex: 'filename',
          key: 'filename',
          width: 350,
          fixed: 'left',
          render: (text, record) => (
            <a
              onClick={() =>
                Number(record.authtype) === 1 &&
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi)
              }
            >
              {getFileIcon(text)} {text}
            </a>
          ),
        },
        { title: '分类', dataIndex: 'docname', key: 'docname', width: 120 },
        {
          title: '文件大小',
          dataIndex: 'filesize',
          key: 'filesize',
          width: 100,
          render: (text) => (text ? convert.toFileSize(text) : '0KB'),
        },
        {
          title: '标签',
          dataIndex: 'tag',
          key: 'tag',
          render: (text, record) => {
            const tags = (record.mappinglist || []).filter((a) => a.key === 'tag');
            return (
              <Popover
                placement="bottomLeft"
                content={
                  <Space
                    direction="vertical"
                    size={0}
                    style={{
                      maxHeight: 400,
                      overflowY: 'auto',
                      marginRight: '-16px',
                      paddingRight: '16px',
                    }}
                  >
                    {tags.map((a, i) => (
                      <span key={i}>{a.value}</span>
                    ))}
                  </Space>
                }
              >
                <Typography.Paragraph ellipsis>
                  {tags.map((a) => (
                    <Tag key={a.value}>{a.value}</Tag>
                  ))}
                </Typography.Paragraph>
              </Popover>
            );
          },
        },
        {
          title: '最近更新人/时间',
          dataIndex: 'updateuser',
          width: 150,
          fixed: 'right',
          render: (_, record) => {
            return (
              <Space size={0} direction="vertical">
                <span>{record.updateuser || record.createuser}</span>
                <span>{record.updatetime || record.createtime}</span>
              </Space>
            );
          },
        },
        {
          title: '操作',
          dataIndex: 'operation',
          key: 'operation',
          width: isProductManager ? 200 : 120,
          fixed: 'right',
          render: (text, record) => getOperationBtn(record),
        },
      ];
      break;
    case 'process':
      columns = [
        {
          title: '文件名',
          dataIndex: 'filename',
          key: 'filename',
          width: 350,
          fixed: 'left',
          render: (text, record) => (
            <a
              onClick={() =>
                Number(record.authtype) === 1 &&
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi)
              }
            >
              {getFileIcon(text)} {text}
            </a>
          ),
        },
        { title: '分类', dataIndex: 'docname', key: 'docname' },
        {
          title: '文件大小',
          dataIndex: 'filesize',
          key: 'filesize',
          render: (text) => (text ? convert.toFileSize(text) : '0KB'),
        },
        { title: '流程编号', dataIndex: 'code', key: 'code' },
        {
          title: '关联产品',
          dataIndex: 'fundname',
          key: 'fundname',
          width: 200,
          render: (text) => (
            <Popover
              placement="bottomLeft"
              content={
                <Space
                  direction="vertical"
                  size={0}
                  style={{
                    maxHeight: 400,
                    overflowY: 'auto',
                    marginRight: '-16px',
                    paddingRight: '16px',
                  }}
                >
                  {(text || '')
                    .split('】')
                    .filter((txt) => !!txt)
                    .map((txt, i) => (
                      <span key={i}>{txt}】</span>
                    ))}
                </Space>
              }
            >
              <Typography.Paragraph ellipsis>{text}</Typography.Paragraph>
            </Popover>
          ),
        },
        { title: '上传步骤', dataIndex: 'elementname', key: 'elementname' },
        {
          title: '流程状态',
          dataIndex: 'status',
          render: (text) => {
            switch (text) {
              case 1:
                return <Tag color="red">已退回</Tag>;
              case 2:
                return <Tag color="processing">审批中</Tag>;
              case 3:
                return <Tag color="#ccc">审批结束</Tag>;
              default:
                break;
            }
          },
        },
        { title: '申请人', dataIndex: 'applyusername', key: 'applyusername' },
        { title: '申请日期', dataIndex: 'applydate', key: 'applydate' },
        {
          title: '操作',
          dataIndex: 'operation',
          key: 'operation',
          width: isProductManager ? 180 : 120,
          fixed: 'right',
          render: (text, record) => getOperationBtn(record),
        },
      ];
      break;
    default:
      columns = [
        {
          title: '文件名',
          dataIndex: 'filename',
          key: 'filename',
          width: 350,
          fixed: 'left',
          render: (text, record) => (
            <a
              onClick={() =>
                Number(record.authtype) === 1 &&
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi)
              }
            >
              {getFileIcon(text)} {text}
            </a>
          ),
        },
        { title: '分类', dataIndex: 'docname', key: 'docname', width: 120 },
        {
          title: '文件大小',
          dataIndex: 'filesize',
          key: 'filesize',
          width: 100,
          render: (text) => (text ? convert.toFileSize(text) : '0KB'),
        },
        {
          title: '关联产品',
          dataIndex: 'fund',
          key: 'fund',
          width: 200,
          render: (text, record) => {
            const funds = (record.mappinglist || []).filter((a) => a.key === 'fund');
            return (
              <Popover
                placement="bottomLeft"
                content={
                  <Space
                    direction="vertical"
                    size={0}
                    style={{
                      maxHeight: 400,
                      overflowY: 'auto',
                      marginRight: '-16px',
                      paddingRight: '16px',
                    }}
                  >
                    {funds.map((a, i) => (
                      <span key={i}>{a.value}</span>
                    ))}
                  </Space>
                }
              >
                <Typography.Paragraph ellipsis>
                  {funds.map((a) => a.value).join(' ')}
                </Typography.Paragraph>
              </Popover>
            );
          },
        },
        {
          title: '标签',
          dataIndex: 'tag',
          key: 'tag',
          render: (text, record) => {
            const tags = (record.mappinglist || []).filter((a) => a.key === 'tag');
            return (
              <Popover
                placement="bottomLeft"
                content={
                  <Space
                    direction="vertical"
                    size={0}
                    style={{
                      maxHeight: 400,
                      overflowY: 'auto',
                      marginRight: '-16px',
                      paddingRight: '16px',
                    }}
                  >
                    {tags.map((a, i) => (
                      <span key={i}>{a.value}</span>
                    ))}
                  </Space>
                }
              >
                <Typography.Paragraph ellipsis>
                  {tags.map((a) => (
                    <Tag key={a.value}>{a.value}</Tag>
                  ))}
                </Typography.Paragraph>
              </Popover>
            );
          },
        },
        {
          title: '最近更新人/时间',
          dataIndex: 'updateuser',
          width: 150,
          fixed: 'right',
          render: (_, record) => {
            return (
              <Space size={0} direction="vertical">
                <span>{record.updateuser || record.createuser}</span>
                <span>{record.updatetime || record.createtime}</span>
              </Space>
            );
          },
        },
        {
          title: '操作',
          dataIndex: 'operation',
          key: 'operation',
          width: isProductManager ? 200 : 120,
          fixed: 'right',
          render: (text, record) => getOperationBtn(record),
        },
      ];
      break;
  }

  return columns;
};
