import { message, Modal } from 'antd';
import {
  commonApi,
  addCatalog,
  editCatalog,
  moveCatalog,
  delCatalog,
  authPermission,
  detailPermission,
} from 'common/axios';
import { downloadFileApi } from 'common/axios/config';
import { fn } from '@cerdo/cerdo-utils';

// 授权枚举
export const AUTH_VIEW = 0;
export const AUTH_EDIT = 1;
export const AUTH_FILE = 0;
export const AUTH_DIR = 1;

export const OBJ_PERSON = '1';
export const OBJ_DEPT = '2';
export const OBJ_POSITION = '3';
export const OBJ_ROLE = '4';

export function methods(context) {
  /** 编辑节点 */
  context.handleEditNode = (item) => {
    return editCatalog({
      catalogid: item.id,
      docname: item.value,
      sort: 0,
    })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('修改成功');
          return true;
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  /** 添加节点 */
  context.handleAddNode = (item) => {
    return addCatalog({
      docname: item.value,
      sort: 0,
      parentid: item.parentid,
    })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('添加成功');
          return { id: res.data };
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  /** 删除文档节点 */
  context.handleDeleteNode = (item) => {
    return new Promise((resolve, reject) => {
      const { treeData } = context.state;
      if (treeData.length === 1 && treeData[0].id === item.id) {
        message.error('一级节点不可删除');
        resolve(null);
      }
      delCatalog({
        catalogid: item.id,
      })
        .then((res) => {
          if (fn.checkResponse(res)) {
            message.success('删除成功');
            resolve(true);
          }
        })
        .catch(() => {
          resolve(false);
        });
    });
  };

  /** 移动节点 */
  context.handleDropNode = (info) => {
    return new Promise((resolve, reject) => {
      const fromNode = info.dragNode.props.eventKey;
      const toNode = info.node.props.eventKey;

      Modal.confirm({
        title: '确定移动节点吗？',
        onOk: () => {
          moveCatalog({
            from: fromNode,
            to: toNode,
          })
            .then((res) => {
              if (fn.checkResponse(res)) {
                message.success('移动成功');
                context.reloadPdtDocTree();
                resolve(true);
              }
              resolve(false);
            })
            .catch(() => {
              resolve(false);
            });
        },
        onCancel: () => {
          resolve(null);
        },
      });
    });
  };

  /** 获取权限信息 */
  context.getPermissionView = (config) => {
    const { fileid, filetype, authtype } = config;
    detailPermission({
      docid: config.fileid,
      authtype,
    })
      .then((res) => {
        if (fn.checkResponse(res)) {
          let data = res.data;
          let userKeys = [];
          data
            .filter((x) => x.objtype === OBJ_PERSON)
            .map((item) => {
              return userKeys.push(item.objid);
            });
          let deptKeys = [];
          data
            .filter((x) => x.objtype === OBJ_DEPT)
            .map((item) => {
              return deptKeys.push(item.objid);
            });

          let roleKeys = [];
          data
            .filter((x) => x.objtype === OBJ_ROLE)
            .map((item) => {
              return roleKeys.push(item.objid);
            });
          let positionKeys = [];
          data
            .filter((x) => x.objtype === OBJ_POSITION)
            .map((item) => {
              return positionKeys.push(item.objid);
            });

          context.setState({
            selectUserKeys: userKeys,
            selectDeptKeys: deptKeys,
            selectRoleKeys: roleKeys,
            selectPositionKeys: positionKeys,
            authVisible: true,
            fileid: fileid,
            filetype: filetype,
            authtype: authtype,
            authTitle: config.title,
          });
        }
      })
      .catch(() => {});
  };

  /** 下载文档 */
  context.downloadDoc = (fileid, filename) => {
    commonApi.downloadFile(fileid, filename, downloadFileApi).then((res) => {
      // console.log('res ==>', res);
    });
  };

  /** 保存授权信息 */
  context.authSave = (
    userKeys,
    users,
    deptKeys,
    depts,
    positionKeys,
    positions,
    roleKey,
    roles,
  ) => {
    const { fileid, filetype, authtype } = context.state;
    let permissions = [...users, ...depts, ...roles, ...positions].map((item) => {
      return {
        objid: item.id || item.objid,
        objname: item.name || item.objname,
        objtype: item.type || item.objtype,
        fileid,
        filetype,
        authtype,
      };
    });

    if (permissions.length === 0) {
      permissions = [{ fileid, filetype, authtype }];
    }

    authPermission({
      permissions,
    }).then((res) => {
      if (fn.checkResponse(res)) {
        message.success('保存成功');
        setTimeout(() => {
          context.setState({
            authVisible: false,
          });
        }, 500);
      }
    });
  };

  /** 取消保存授权信息 */
  context.authCancel = () => {
    context.setState({
      authVisible: false,
    });
  };
}
