import React, { Component } from 'react';
import { DragModal } from '@cerdo/cerdo-design';
import { Table, Button } from 'antd';
import { convert } from '@cerdo/cerdo-utils';
import { commonApi } from 'common/axios';
import { downloadFileApi } from 'common/axios/config';

class HistoryModal extends Component {
  getColumns = () => {
    return [
      {
        title: '文件名称',
        key: 'filename',
        dataIndex: 'filename',
        render: (text, record) => {
          return (
            <Button
              type="link"
              onClick={() => {
                commonApi
                  .downloadFile(record.fileid, record.filename, downloadFileApi)
                  .then((res) => {
                    // console.log('res ==>', res);
                  });
              }}
            >
              {text}
            </Button>
          );
        },
      },
      {
        title: '文件大小',
        key: 'filesize',
        dataIndex: 'filesize',
        render(text) {
          return text ? convert.toFileSize(text) : '';
        },
      },
      {
        title: '上传人',
        key: 'createuser',
        dataIndex: 'createuser',
      },
      {
        title: '上传时间',
        key: 'createtime',
        dataIndex: 'createtime',
      },
    ];
  };

  render() {
    const { onCancel, visible, list } = this.props;
    return (
      <DragModal footer={null} visible={visible} onCancel={onCancel} title="历史文档" width={980}>
        <Table rowKey="historyid" dataSource={list} size="small" columns={this.getColumns()} />
      </DragModal>
    );
  }
}

export default HistoryModal;
