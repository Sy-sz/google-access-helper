import React, { Component } from 'react';
import {
  Card,
  Button,
  message,
  Input,
  Form,
  Row,
  Col,
  Divider,
  Tag,
  Typography,
  Popover,
  Space,
} from 'antd';
import {
  listDocTree,
  getProcessDocFileList,
  listDocHistory,
  saveFile,
  commonApi,
} from 'common/axios';
import { uploadFileApi, downloadFileApi } from 'common/axios/config';
import { methods } from './com/methods';
import {
  RangeDate,
  UploadFile,
  EditTree,
  FetchTable,
  SearchSelect,
  DictSelect,
} from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { array, convert, fn } from '@cerdo/cerdo-utils';
import HistoryModal from './com/HistoryModal';
import SearchCard from '@/common/component/SearchCard';
import { getFileIcon } from '../docMg/index.data';

const FormItem = Form.Item;

class Index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      treeLoading: false,
      treeData: [],
      expandedKeys: [],
      selectedTreeNode: {},
      selectUserKeys: [],
      selectDeptKeys: [],
      selectRoleKeys: [],
      selectPositionKeys: [],
      selectedRows: '',
      authVisible: false,
      fileid: null,
      filetype: null,
      authtype: null,
      authTitle: null,
      historyVisible: false,
      historyList: [],
      uploadVisible: false,

      permissions: { isProductManager: false },
    };
    this.formRef = React.createRef();
    methods(this);
  }

  componentDidMount() {
    this.getPdtDocTree();
    this.verifyUserPermission();
  }

  // 验证用户权限
  verifyUserPermission() {
    commonApi
      .userPermission({ permissionids: 'cd1eb03215fb4f3ba6952f59fbd745fb' })
      .then((result) => {
        if (fn.checkResponse(result)) {
          this.setState({
            permissions: {
              isProductManager: result.data[0].haspermission === 1,
            },
          });
        }
      });
  }

  getPdtDocTree = () => {
    this.setState({ treeLoading: true });
    listDocTree({ systemid: 'fsyy-pdt-backend-process' })
      .then((res) => {
        if (res && res.data.length > 0) {
          // 默认展开 全部
          let expandedKeys = [res.data[0].id];
          if (res.data[0].children && res.data[0].children.length > 0) {
            expandedKeys.push(res.data[0].children[0].id);
          }
          this.setState(
            {
              treeData: array.toOptionsArray(res.data, 'id', 'nodeName'),
              expandedKeys: expandedKeys,
              selectedTreeNode: res.data[0],
            },
            () => {
              this.table.reload();
            },
          );
        }
      })
      .catch(() => {})
      .finally(() => this.setState({ treeLoading: false }));
  };

  reloadPdtDocTree = () => {
    listDocTree({ systemid: 'fsyy-pdt-backend-process' }).then((res) => {
      if (res && res.data.length > 0) {
        this.setState(
          {
            treeData: array.toOptionsArray(res.data, 'id', 'nodeName'),
          },
          () => {
            this.tree.reload(this.state.treeData);
          },
        );
      }
    });
  };

  getDocList = () => {
    const { selectedTreeNode } = this.state;
    if (!(selectedTreeNode && selectedTreeNode.id)) {
      return Promise.resolve(null);
    }
    return new Promise((resolve, reject) => {
      this.table.getFormParams(this.formRef.current, 'YYYY-MM-DD').then((values) => {
        getProcessDocFileList({
          ...values,
          catalogid: selectedTreeNode.id,
          systemid: 'fsyy-pdt-backend-process',
          key: values.value ? values.key : null, // 未填 value的时候 key置空
        })
          .then((result) => {
            if (fn.checkResponse(result)) {
              resolve(result);
            }
            resolve(null);
          })
          .catch(() => {
            reject();
          });
      });
    });
  };
  getHistoryList = (record) => {
    this.setState({ historyVisible: true });
    listDocHistory({
      docfileid: record.docfileid,
    })
      .then((res) => {
        if (res && res.data && Array.isArray(res.data) && res.data.length > 0) {
          this.setState({
            historyList: res.data.map((item, index) => {
              item.id = index;
              return item;
            }),
          });
        }
      })
      .catch(() => {});
  };

  /** 替换新文件 */
  handleReplaceFileClick = (file, record) => {
    saveFile({
      ...file,
      catalogid: record.catalogid,
      lastfileid: record.fileid,
      isProcess: 1,
    }).then((res) => {
      if (fn.checkResponse(res)) {
        message.success('替换成功', 0.5, () => {
          this.table.reload();
        });
      }
      if (res.code === 'C201') {
        message.error(res.msg);
      }
    });
  };

  getColumns = () => {
    return [
      {
        title: '文件名',
        dataIndex: 'filename',
        key: 'filename',
        width: 350,
        fixed: 'left',
        render: (text, record) => (
          <a
            onClick={() =>
              Number(record.authtype) === 1 &&
              commonApi.downloadFile(record.fileid, record.filename, downloadFileApi)
            }
          >
            {getFileIcon(text)} {text}
          </a>
        ),
      },
      {
        title: '分类',
        key: 'docname',
        dataIndex: 'docname',
        width: 120,
      },
      {
        title: '流程编号',
        dataIndex: 'code',
        width: 100,
      },
      {
        title: '关联产品',
        dataIndex: 'fundname',
        width: 200,
        render: (text) => (
          <Popover
            placement="bottomLeft"
            content={
              <Space
                direction="vertical"
                size={0}
                style={{
                  maxHeight: 400,
                  overflowY: 'auto',
                  marginRight: '-16px',
                  paddingRight: '16px',
                }}
              >
                {(text || '')
                  .split('】')
                  .filter((txt) => !!txt)
                  .map((txt, i) => (
                    <span key={i}>{txt}】</span>
                  ))}
              </Space>
            }
          >
            <Typography.Paragraph ellipsis>{text}</Typography.Paragraph>
          </Popover>
        ),
      },
      {
        title: '上传人',
        dataIndex: 'createuser',
        width: 100,
      },
      {
        title: '上传节点',
        dataIndex: 'elementname',
        width: 120,
      },
      {
        title: '文件大小',
        key: 'filesize',
        dataIndex: 'filesize',
        width: 80,
        render(text) {
          return text ? convert.toFileSize(text) : '';
        },
      },
      {
        title: '流程申请日期',
        dataIndex: 'applydate',
        width: 100,
      },
      {
        title: '申请人',
        dataIndex: 'applyusername',
        width: 60,
      },
      {
        title: '流程状态',
        dataIndex: 'status',
        width: 80,
        fixed: 'right',
        render: (text) => {
          switch (text) {
            case 1:
              return <Tag color="red">已退回</Tag>;
            case 2:
              return <Tag color="processing">审批中</Tag>;
            case 3:
              return <Tag>审批结束</Tag>;
            default:
              break;
          }
        },
      },
      {
        title: '操作',
        dataIndex: 'operate',
        key: 'operate',
        fixed: 'right',
        width: 200,
        render: (text, record) => this.getOperationBtn(record),
      },
    ];
  };

  getOperationBtn = (record) => {
    return (
      <>
        <Button
          type="link"
          onClick={() => {
            this.downloadDoc(record.fileid, record.filename);
          }}
        >
          下载
        </Button>
        <Divider type="vertical" />
        <UploadFile
          uploadUrl={uploadFileApi}
          downloadUrl={downloadFileApi}
          accept=".xls,.xlsx,.doc,.docx,.zip,.rar"
          showUploadList={false}
          disabled={record.status === 3 ? true : false}
          onChange={(file, fileList) => this.handleReplaceFileClick(file, record)}
        >
          <Button disabled={record.status === 3} type="link">
            替换
          </Button>
        </UploadFile>
        <Divider type="vertical" />
        <Button
          type="link"
          size="small"
          onClick={() => {
            this.getHistoryList(record);
          }}
        >
          历史文档
        </Button>
      </>
    );
  };

  render() {
    const {
      treeData,
      treeLoading,
      expandedKeys,
      historyVisible,
      historyList,
      permissions: { isProductManager },
    } = this.state;
    return (
      <div>
        <Row gutter={[8, 16]}>
          <Col span={6}>
            <Card bodyStyle={{ overflowX: 'auto' }} bordered={false}>
              <EditTree
                ref={(ref) => {
                  this.tree = ref;
                }}
                style={{ height: 'calc(100vh - 165px)', overflow: 'auto' }}
                draggable
                expandedKeys={expandedKeys}
                gData={treeData}
                loading={treeLoading}
                onSelect={(value, { selected, node }) => {
                  if (selected) {
                    this.setState({ selectedTreeNode: node }, () => {
                      this.table.reloadAndReset();
                    });
                  }
                }}
                onItemDrop={(info) => this.handleDropNode(info)}
                onItemDelete={(item) => this.handleDeleteNode(item)}
                onItemEdit={(item) => this.handleEditNode(item)}
                onItemAdd={(item) => this.handleAddNode(item)}
                allowEdit={isProductManager}
              />
            </Card>
          </Col>
          <Col span={18}>
            <SearchCard
              bordered={false}
              ref={this.formRef}
              showNum={2}
              onSearch={() => this.table.reloadAndReset()}
              onExpand={(expand) => this.table.setScrollY(expand ? 365 : 325)}
            >
              <Col span={12}>
                <FormItem label="流程编号" name="code">
                  <Input allowClear placeholder="请输入流程编号" />
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem label="标签搜索" name="value">
                  <Input
                    addonBefore={
                      <Form.Item name="key" noStyle>
                        <DictSelect
                          style={{ width: 100 }}
                          dictid="8bbf6eb1-95a3-494c-b709-02f16d81c266"
                        >
                          {(item) => (
                            <DictSelect.Option key={item.id} value={item.value}>
                              {item.name}
                            </DictSelect.Option>
                          )}
                        </DictSelect>
                      </Form.Item>
                    }
                    style={{ width: '100%' }}
                    allowClear
                  />
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem label="流程申请日期" name="daterange">
                  <RangeDate />
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem label="流程状态" name="status" initialValue={3}>
                  <SearchSelect
                    style={{ width: '100%' }}
                    placeholder="全部"
                    defaultOptions={[
                      { text: '已退回', value: 1 },
                      { text: '审批中', value: 2 },
                      { text: '审批结束', value: 3 },
                    ]}
                  />
                </FormItem>
              </Col>
            </SearchCard>
            <ListCard title="流程文件列表">
              <FetchTable
                size="small"
                showTools={false}
                ref={(ref) => {
                  this.table = ref;
                }}
                rowKey="fileid"
                columns={this.getColumns()}
                getList={this.getDocList}
                scroll={{ y: `calc(100vh - 325px)` }}
                autoHeight={{
                  blankHeight: 350,
                }}
              />
            </ListCard>
          </Col>
        </Row>

        <HistoryModal
          visible={historyVisible}
          list={historyList}
          onCancel={() => {
            this.setState({ historyVisible: false, historyList: [] });
          }}
        />
      </div>
    );
  }
}

export default Index;
