import { Col, Divider, Form, Button, message, Space } from 'antd';
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { fn } from '@cerdo/cerdo-utils';
import { FetchTable, RangeDate } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { listMiniFund, downloadMiniFundFile, commonApi, updateList } from 'common/axios';
import moment from 'moment';
import FormModal from '../com/formModal';
import SearchCard from '@/common/component/SearchCard';

const FormItem = Form.Item;

class Index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      detailSendEmail: {},
      exportLoadingId: null,
      updateLoading: false,
      permissions: {
        isDownload: false,
        isEdit: false,
      },
    };
    this.params = {};
    this.formRef = React.createRef();
  }
  componentDidMount() {
    this.verifyUserPermission();
  }

  verifyUserPermission = () => {
    commonApi
      .userPermission({
        permissionids: [
          'ceccda50-d326-4205-91ef-dda3a10e2e40',
          'b57633fc-9d1b-4bf6-8ba5-9523181f11ad',
        ].join(),
      })
      .then((result) => {
        if (fn.checkResponse(result)) {
          this.setState({
            permissions: {
              isDownload: result.data[0].haspermission === 1,
              isEdit: result.data[1].haspermission === 1,
            },
          });
        }
      });
  };

  getList = () => {
    return new Promise((resolve, reject) => {
      this.table.getFormParams(this.formRef.current, 'YYYY-MM-DD').then((values) => {
        listMiniFund({
          ...values,
        })
          .then((result) => {
            if (fn.checkResponse(result)) {
              resolve(result);
            }
            reject(null);
          })
          .finally(() => {});
      });
    });
  };
  handleSearchClick = () => {
    this.table.reloadAndReset();
  };

  // 导出文件
  handleExportClick = (record) => {
    this.setState({
      exportLoadingId: record.id,
    });
    downloadMiniFundFile({
      rptdate: record.rptdate,
      filename: `迷你基金检测周报-报表日期(${moment(record.rptdate).format('YYYY-MM-DD')}).doc`,
    }).then((res) => {
      if (res) {
        message.success('下载文件成功');
      }
      this.setState({
        exportLoadingId: null,
      });
    });
  };

  // 设置邮件发送
  handleSendEmailClick = () => {
    this.setState({
      modalVisible: true,
    });
  };
  // 更新
  handleUpdateClick = () => {
    const date = this.params.updateDate;
    if (!date) {
      message.warning('请选择更新日期');
      return;
    }

    const currentDate = moment().format('YYYY-MM-DD');
    const isNullDate = date && date[0] && date[1];
    const isOverFlowDate =
      isNullDate &&
      moment(date[0]).isBefore(moment(currentDate)) &&
      moment(date[1]).isBefore(moment(currentDate));

    if (!isNullDate) {
      message.warning('起始日期为必填项');
    } else if (!isOverFlowDate) {
      message.warning(`选择日期不得超过${currentDate}`);
    } else {
      this.setState({ updateLoading: true });
      updateList({
        startdate: date[0] ? moment(date[0]).format('YYYY-MM-DD') : null,
        enddate: date[1] ? moment(date[1]).format('YYYY-MM-DD') : null,
      })
        .then((result) => {
          if (result.code === '0000') {
            this.setState({ updateLoading: false });
            this.table.reloadAndReset();
            message.success('更新成功');
          } else {
            this.setState({ updateLoading: false });
          }
        })
        .catch(() => {
          this.setState({ updateLoading: false });
        });
    }
  };

  getColumns = () => {
    const {
      permissions: { isDownload, isEdit },
      exportLoadingId,
    } = this.state;
    return [
      {
        title: '报表日期',
        dataIndex: 'rptdate',
        key: 'rptdate',
        render: (text) => text && moment(text).format('YYYY-MM-DD'),
      },
      {
        title: '红灯提醒基金个数',
        dataIndex: 'redcount',
        key: 'redcount',
        render: (text, record) => (
          <Link to={`/app/pdt/doc/minfund/form?rptdate=${record.rptdate}&datatype=1`}>{text}</Link>
        ),
      },
      {
        title: '黄灯提醒基金个数',
        dataIndex: 'yelcount',
        key: 'yelcount',
        render: (text, record) => (
          <Link to={`/app/pdt/doc/minfund/form?rptdate=${record.rptdate}&datatype=2`}>{text}</Link>
        ),
      },
      {
        title: '已迷你基金个数',
        dataIndex: 'mincount',
        key: 'mincount',
        render: (text, record) => (
          <Link to={`/app/pdt/doc/minfund/form?rptdate=${record.rptdate}&datatype=0`}>{text}</Link>
        ),
      },
      // { title: '邮件发送状态', dataIndex: 'status', key: 'status' },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 160,
        render: (text, record) => {
          return (
            <Space size={0} split={<Divider type="vertical" />}>
              <Link to={`/app/pdt/doc/minfund/form?rptdate=${record.rptdate}&datatype=1`}>
                查看
              </Link>
              {isEdit && (
                <Link
                  to={`/app/pdt/doc/minfund/form?isedit=1&rptdate=${record.rptdate}&datatype=1`}
                >
                  编辑
                </Link>
              )}
              {isDownload && (
                <a
                  // type="link"
                  loading={exportLoadingId === record.id}
                  onClick={() => this.handleExportClick(record)}
                >
                  {/* 下载文件 */}
                  {exportLoadingId === record.id ? '下载中...' : '下载文件'}
                </a>
              )}
            </Space>
          );
        },
      },
    ];
  };

  render() {
    const { modalVisible, updateLoading } = this.state;

    return (
      <div>
        <SearchCard ref={this.formRef} bordered={false} onSearch={this.handleSearchClick}>
          <Col span={8}>
            <FormItem label="报表日期" name="daterange">
              <RangeDate style={{ width: '100%' }} />
            </FormItem>
          </Col>
        </SearchCard>
        <ListCard
          title="迷你基金列表"
          bordered={false}
          extra={
            <Space>
              <RangeDate
                style={{ width: '120px' }}
                onChange={(value) => {
                  this.params.updateDate = value;
                }}
              />
              <Button
                type="primary"
                onClick={() => this.handleUpdateClick()}
                loading={updateLoading}
              >
                {updateLoading ? '更新中...' : '更新'}
              </Button>
              <Button type="primary" onClick={this.handleSendEmailClick}>
                设置邮件发送
              </Button>
            </Space>
          }
        >
          <FetchTable
            size="small"
            showTools={false}
            rowKey="id"
            ref={(ref) => {
              this.table = ref;
            }}
            columns={this.getColumns()}
            getList={this.getList}
            autoHeight={{ blankHeight: 200 }}
            scroll={{ y: `calc(100vh - 320px)` }}
          />
        </ListCard>
        <FormModal
          title="设置发送时间"
          visible={modalVisible}
          onCancel={() =>
            this.setState({ modalVisible: false }, () => {
              this.table.reload();
            })
          }
        />
      </div>
    );
  }
}

export default Index;
