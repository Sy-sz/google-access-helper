import moment from 'moment';
import React from 'react';
import { convert, fn } from '@cerdo/cerdo-utils';
import { Input, Select, message, Row, Col, Tooltip, Button, Divider, Popover } from 'antd';
import { DataField } from '@/common/component';
import { saveIspubweek, saveRemark } from 'common/axios';
import { CheckOutlined, CloseOutlined, EditOutlined } from '@ant-design/icons';
import { isFunction } from 'lodash';

const Option = Select.Option;

// 保存
const handleSaveIspubweekClick = (record, that) => {
  saveIspubweek({
    id: record.id,
    ispubweek: record.ispubweek || '0',
  }).then((result) => {
    if (fn.checkResponse(result)) {
      message.success('保存成功', 0.5, () => {
        that(record, 'optype', '');
        if (!record.ispubweek) {
          that(record, 'ispubweek', '0');
        }
      });
    }
  });
};

/** 保存 措施 */
const handleSaveMeasure = (params, callback) => {
  saveIspubweek(params).then((result) => {
    if (fn.checkResponse(result)) {
      message.success('保存成功');
      isFunction(callback) && callback();
    }
  });
};

// 红灯部分
// 1.合同中约定自动清盘
const getLiquidationColumns = (data, params, that) => {
  console.log('重新加载');
  return [
    { title: '所属投资部门', dataIndex: 'belgdept', key: 'belgdept' },
    { title: '基金名称', dataIndex: 'portfname', key: 'portfname' },
    { title: '基金代码', dataIndex: 'portfcode', key: 'portfcode' },
    {
      title: '数据日期',
      dataIndex: 'datadate',
      key: 'datadate',
      render: (text) => text && moment(text).format('YYYY-MM-DD'),
    },
    { title: '户数', dataIndex: 'custcnt', key: 'custcnt', align: 'right' },
    {
      title: '市值',
      dataIndex: 'haholdasset',
      key: 'haholdasset',
      align: 'right',
      render: (text) => text && convert.toThousands(text),
    },
    { title: '规模连续过低工作日天数', dataIndex: 'lowday', key: 'lowday', align: 'right' },
    {
      title: '连续60个工作日低于5000万或200人的截止时间',
      dataIndex: 'lowenddate',
      key: 'lowenddate',
      width: 170,
    },
    {
      title: '是否要求发布迷你提示性公告',
      dataIndex: 'isminipub',
      key: 'isminipub',
      render: (text) =>
        text && Number(text) === 1 ? '是' : text && Number(text) === 0 ? '否' : undefined,
    },
    {
      title: '本周内是否发布迷你提示性公告',
      dataIndex: 'ispubweek',
      key: 'ispubweek',
      align: 'center',
      render: (text, record) => {
        const newText = record.new_ispubweek || text;
        return (
          <DataField
            value={
              <Row wrap={false} justify="center">
                <Col>{!newText ? '' : Number(newText) === 1 ? '是' : '否'}</Col>
                {params.isedit && (
                  <Col flex="20px">
                    <EditOutlined
                      style={{ cursor: 'pointer', marginLeft: 5 }}
                      onClick={() => that.handleDoAction(record, 'optype', 'edit')}
                    />
                  </Col>
                )}
              </Row>
            }
            editable={record.optype === 'edit' && params.isedit}
          >
            <Row wrap={false}>
              <Col flex={1}>
                <Select
                  allowClear
                  style={{ width: '100%', textAlign: 'left' }}
                  defaultValue={Number(newText) === 1 ? '是' : '否'}
                  onChange={(value) => that.handleDoAction(record, 'ispubweek', value)}
                >
                  <Option value="0">否</Option>
                  <Option value="1">是</Option>
                </Select>
              </Col>
              <Col
                flex="42px"
                style={{ display: 'inline-flex', alignItems: 'center', cursor: 'pointer' }}
              >
                <CheckOutlined
                  style={{ flex: 1 }}
                  onClick={() => handleSaveIspubweekClick(record, that.handleDoAction)}
                />
                <CloseOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    that.handleDoAction(record, 'optype', '');
                    that.handleDoAction(record, 'ispubweek', 'reset');
                  }}
                />
              </Col>
            </Row>
          </DataField>
        );
      },
    },
    {
      title: '产品负责人',
      dataIndex: 'managername',
      key: 'managername',
      width: 100,
    },
    {
      title: '措施',
      dataIndex: 'measure',
      key: 'measure',
      align: 'center',
      width: 200,
      render: (text, record) => {
        return (
          <DataField
            value={
              <Row wrap={false} justify="center">
                <Popover
                  content={text}
                  overlayInnerStyle={{ maxWidth: 300, wordBreak: 'break-all' }}
                >
                  <div
                    style={{
                      width: '100%',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {text}
                  </div>
                </Popover>
                {params.isedit && (
                  <Col flex="20px">
                    <EditOutlined
                      style={{ cursor: 'pointer', marginLeft: 5 }}
                      onClick={() => that.handleDoAction(record, 'measuresEditable', true)}
                    />
                  </Col>
                )}
              </Row>
            }
            editable={!!record.measuresEditable && params.isedit}
          >
            <Row wrap={false}>
              <Col flex={1}>
                <Input
                  placeholder="请输入措施"
                  defaultValue={text}
                  onChange={(e) => that.handleDoAction(record, 'measure', e.target.value)}
                />
              </Col>
              <Col
                flex="42px"
                style={{ display: 'inline-flex', alignItems: 'center', cursor: 'pointer' }}
              >
                <CheckOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    handleSaveMeasure({ id: record.id, measure: record.measure }, () => {
                      that.handleDoAction(record, 'measuresEditable', false);
                    });
                  }}
                />
                <CloseOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    that.handleDoAction(record, 'measuresEditable', false);
                    that.handleDoAction(record, 'measure', 'reset');
                  }}
                />
              </Col>
            </Row>
          </DataField>
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      width: 160,
      render: (text, record) => {
        return (
          <div>
            <Button type="link" onClick={() => that.handleDetailClick(record)}>
              查看详情
            </Button>
            <Divider type="vertical" />
            <Button
              type="link"
              loading={that.state.docLoadingId === record.id}
              onClick={() => that.handleDownloadDocClick(record)}
            >
              生成文档
            </Button>
          </div>
        );
      },
    },
  ];
};

// 2.合同约定上报方案，并6个月内召开持有人大会
const getConferenceColumns = (data, params, that) => {
  return [
    { title: '所属投资部门', dataIndex: 'belgdept', key: 'belgdept' },
    { title: '基金名称', dataIndex: 'portfname', key: 'portfname' },
    { title: '基金代码', dataIndex: 'portfcode', key: 'portfcode' },
    {
      title: '数据日期',
      dataIndex: 'datadate',
      key: 'datadate',
      render: (text) => text && moment(text).format('YYYY-MM-DD'),
    },
    { title: '户数', dataIndex: 'custcnt', key: 'custcnt', align: 'right' },
    {
      title: '市值',
      dataIndex: 'haholdasset',
      key: 'haholdasset',
      align: 'right',
      render: (text) => text && convert.toThousands(text),
    },
    { title: '规模连续过低工作日天数', dataIndex: 'lowday', key: 'lowday', align: 'right' },
    {
      title: '连续60个工作日低于5000万或200人的截止时间',
      dataIndex: 'lowenddate',
      key: 'lowenddate',
      width: 170,
    },
    {
      title: '产品负责人',
      dataIndex: 'managername',
      key: 'managername',
      width: 100,
    },
    {
      title: '措施',
      dataIndex: 'measure',
      key: 'measure',
      align: 'center',
      width: 200,
      render: (text, record) => {
        return (
          <DataField
            value={
              <Row wrap={false} justify="center">
                <Popover
                  content={text}
                  overlayInnerStyle={{ maxWidth: 300, wordBreak: 'break-all' }}
                >
                  <div
                    style={{
                      width: '100%',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {text}
                  </div>
                </Popover>
                {params.isedit && (
                  <Col flex="20px">
                    <EditOutlined
                      style={{ cursor: 'pointer', marginLeft: 5 }}
                      onClick={() => that.handleDoAction(record, 'measuresEditable', true)}
                    />
                  </Col>
                )}
              </Row>
            }
            editable={!!record.measuresEditable && params.isedit}
          >
            <Row wrap={false}>
              <Col flex={1}>
                <Input
                  placeholder="请输入措施"
                  defaultValue={text}
                  onChange={(e) => that.handleDoAction(record, 'measure', e.target.value)}
                />
              </Col>
              <Col
                flex="42px"
                style={{ display: 'inline-flex', alignItems: 'center', cursor: 'pointer' }}
              >
                <CheckOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    handleSaveMeasure({ id: record.id, measure: record.measure }, () => {
                      that.handleDoAction(record, 'measuresEditable', false);
                    });
                  }}
                />
                <CloseOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    that.handleDoAction(record, 'measuresEditable', false);
                    that.handleDoAction(record, 'measure', 'reset');
                  }}
                />
              </Col>
            </Row>
          </DataField>
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      width: 160,
      render: (text, record) => {
        return (
          <div>
            <Button type="link" onClick={() => that.handleDetailClick(record)}>
              查看详情
            </Button>
            <Divider type="vertical" />
            <Button
              type="link"
              loading={that.state.docLoadingId === record.id}
              onClick={() => that.handleDownloadDocClick(record)}
            >
              生成文档
            </Button>
          </div>
        );
      },
    },
  ];
};

// 3.发起式基金成立后第三年至三年对日前三个月，基金规模低于1亿元；或发起式基金成立后三年对日前三个月内，基金规模低于2亿元
const getFundSizeColumns = (data, params, that) => {
  return [
    { title: '所属投资部门', dataIndex: 'belgdept', key: 'belgdept' },
    { title: '基金名称', dataIndex: 'portfname', key: 'portfname' },
    { title: '基金代码', dataIndex: 'portfcode', key: 'portfcode' },
    {
      title: '合同生效日',
      dataIndex: 'contrstdate',
      key: 'contrstdate',
      render: (text) => text && moment(text).format('YYYY-MM-DD'),
    },
    {
      title: '合同生效三年对日',
      dataIndex: 'contrthreedate',
      key: 'contrthreedate',
      render: (text) => text && moment(text).format('YYYY-MM-DD'),
    },
    {
      title: '最新市值',
      dataIndex: 'haholdasset',
      key: 'haholdasset',
      align: 'right',
      render: (text) => text && convert.toThousands(text),
    },
    {
      title: '产品负责人',
      dataIndex: 'managername',
      key: 'managername',
      width: 100,
    },
    {
      title: '措施',
      dataIndex: 'measure',
      key: 'measure',
      align: 'center',
      width: 200,
      render: (text, record) => {
        return (
          <DataField
            value={
              <Row wrap={false} justify="center">
                <Popover
                  content={text}
                  overlayInnerStyle={{ maxWidth: 300, wordBreak: 'break-all' }}
                >
                  <div
                    style={{
                      width: '100%',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {text}
                  </div>
                </Popover>
                {params.isedit && (
                  <Col flex="20px">
                    <EditOutlined
                      style={{ cursor: 'pointer', marginLeft: 5 }}
                      onClick={() => that.handleDoAction(record, 'measuresEditable', true)}
                    />
                  </Col>
                )}
              </Row>
            }
            editable={!!record.measuresEditable && params.isedit}
          >
            <Row wrap={false}>
              <Col flex={1}>
                <Input
                  placeholder="请输入措施"
                  defaultValue={text}
                  onChange={(e) => that.handleDoAction(record, 'measure', e.target.value)}
                />
              </Col>
              <Col
                flex="42px"
                style={{ display: 'inline-flex', alignItems: 'center', cursor: 'pointer' }}
              >
                <CheckOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    handleSaveMeasure({ id: record.id, measure: record.measure }, () => {
                      that.handleDoAction(record, 'measuresEditable', false);
                    });
                  }}
                />
                <CloseOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    that.handleDoAction(record, 'measuresEditable', false);
                    that.handleDoAction(record, 'measure', 'reset');
                  }}
                />
              </Col>
            </Row>
          </DataField>
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      width: 160,
      render: (text, record) => {
        return (
          <div>
            <Button type="link" onClick={() => that.handleDetailClick(record)}>
              查看详情
            </Button>
            <Divider type="vertical" />
            <Button
              type="link"
              loading={that.state.docLoadingId === record.id}
              onClick={() => that.handleDownloadDocClick(record)}
            >
              生成文档
            </Button>
          </div>
        );
      },
    },
  ];
};

const getFixedOpenColumns = (data, params, that) => {
  return [
    { title: '所属投资部门', dataIndex: 'belgdept', key: 'belgdept' },
    { title: '基金名称', dataIndex: 'portfname', key: 'portfname' },
    { title: '基金代码', dataIndex: 'portfcode', key: 'portfcode' },
    {
      title: '下一开放日',
      dataIndex: 'nextopendate',
      key: 'nextopendate',
      render: (text) => (text ? moment(text).format('YYYY-MM-DD') : '开放中'),
    },
    { title: '户数', dataIndex: 'custcnt', key: 'custcnt', align: 'right' },
    {
      title: '最新市值',
      dataIndex: 'haholdasset',
      key: 'haholdasset',
      align: 'right',
      render: (text) => text && convert.toThousands(text),
    },
    {
      title: '产品负责人',
      dataIndex: 'managername',
      key: 'managername',
      width: 100,
    },
    {
      title: '措施',
      dataIndex: 'measure',
      key: 'measure',
      align: 'center',
      width: 200,
      render: (text, record) => {
        return (
          <DataField
            value={
              <Row wrap={false} justify="center">
                <Popover
                  content={text}
                  overlayInnerStyle={{ maxWidth: 300, wordBreak: 'break-all' }}
                >
                  <div
                    style={{
                      width: '100%',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {text}
                  </div>
                </Popover>
                {params.isedit && (
                  <Col flex="20px">
                    <EditOutlined
                      style={{ cursor: 'pointer', marginLeft: 5 }}
                      onClick={() => that.handleDoAction(record, 'measuresEditable', true)}
                    />
                  </Col>
                )}
              </Row>
            }
            editable={!!record.measuresEditable && params.isedit}
          >
            <Row wrap={false}>
              <Col flex={1}>
                <Input
                  placeholder="请输入措施"
                  defaultValue={text}
                  onChange={(e) => that.handleDoAction(record, 'measure', e.target.value)}
                />
              </Col>
              <Col
                flex="42px"
                style={{ display: 'inline-flex', alignItems: 'center', cursor: 'pointer' }}
              >
                <CheckOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    handleSaveMeasure({ id: record.id, measure: record.measure }, () => {
                      that.handleDoAction(record, 'measuresEditable', false);
                    });
                  }}
                />
                <CloseOutlined
                  style={{ flex: 1 }}
                  onClick={() => {
                    that.handleDoAction(record, 'measuresEditable', false);
                    that.handleDoAction(record, 'measure', 'reset');
                  }}
                />
              </Col>
            </Row>
          </DataField>
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      width: 160,
      render: (text, record) => {
        return (
          <div>
            <Button type="link" onClick={() => that.handleDetailClick(record)}>
              查看详情
            </Button>
            <Divider type="vertical" />
            <Button
              type="link"
              loading={that.state.docLoadingId === record.id}
              onClick={() => that.handleDownloadDocClick(record)}
            >
              生成文档
            </Button>
          </div>
        );
      },
    },
  ];
};

// 黄灯部分
// 1.基金规模已连续10个工作日低于1亿元 2.基金户数已连续10个工作日低于250户
const getYellowLightColumns = (data, params, that) => {
  return [
    { title: '所属投资部门', dataIndex: 'belgdept', key: 'belgdept' },
    { title: '基金名称', dataIndex: 'portfname', key: 'portfname' },
    { title: '基金代码', dataIndex: 'portfcode', key: 'portfcode' },
    {
      title: '数据日期',
      dataIndex: 'datadate',
      key: 'datadate',
      render: (text) => text && moment(text).format('YYYY-MM-DD'),
    },
    { title: '户数', dataIndex: 'custcnt', key: 'custcnt', align: 'right' },
    {
      title: '市值',
      dataIndex: 'haholdasset',
      key: 'haholdasset',
      align: 'right',
      render: (text) => text && convert.toThousands(text),
    },
    {
      title: '机构客户市值占比',
      dataIndex: 'orgcustratio',
      key: 'orgcustratio',
      align: 'right',
      // render: (text) => text && text.toFixed(4),
      render: (text) => text && convert.toNumber(text * 100, 2, 1),
    },
    {
      title: '合同规定迷你超过60日后方案',
      dataIndex: 'contractplansixty',
      key: 'contractplansixty',
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      width: 160,
      render: (text, record) => {
        return (
          <div>
            <Button type="link" onClick={() => that.handleDetailClick(record)}>
              查看详情
            </Button>
            <Divider type="vertical" />
            <Button
              type="link"
              loading={that.state.docLoadingId === record.id}
              onClick={() => that.handleDownloadDocClick(record)}
            >
              生成文档
            </Button>
          </div>
        );
      },
    },
  ];
};

// 3.发起式基金成立后第二年，基金规模低于1亿元；或发起式基金成立后第三年开始至三年对日前三个月，基金规模高于1亿元但低于2亿元
const getBothColumns = (data, params, that) => {
  return [
    { title: '所属投资部门', dataIndex: 'belgdept', key: 'belgdept' },
    { title: '基金名称', dataIndex: 'portfname', key: 'portfname' },
    { title: '基金代码', dataIndex: 'portfcode', key: 'portfcode' },
    {
      title: '数据日期',
      dataIndex: 'datadate',
      key: 'datadate',
      render: (text) => text && moment(text).format('YYYY-MM-DD'),
    },
    {
      title: '合同生效日',
      dataIndex: 'contrstdate',
      key: 'contrstdate',
      align: 'right',
      render: (text) => text && moment(text).format('YYYY-MM-DD'),
    },
    { title: '户数', dataIndex: 'custcnt', key: 'custcnt', align: 'right' },
    {
      title: '市值',
      dataIndex: 'haholdasset',
      key: 'haholdasset',
      align: 'right',
      render: (text) => text && convert.toThousands(text),
    },
    {
      title: '合同规定迷你超过60日后方案',
      dataIndex: 'contractplansixty',
      key: 'contractplansixty',
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      width: 160,
      render: (text, record) => {
        return (
          <div>
            <Button type="link" onClick={() => that.handleDetailClick(record)}>
              查看详情
            </Button>
            <Divider type="vertical" />
            <Button
              type="link"
              loading={that.state.docLoadingId === record.id}
              onClick={() => that.handleDownloadDocClick(record)}
            >
              生成文档
            </Button>
          </div>
        );
      },
    },
  ];
};

// 基金备注 保存
const handleSaveRemarkClick = (record, callback) => {
  saveRemark({
    id: record.id,
    remark: record.remark,
  }).then((result) => {
    if (fn.checkResponse(result)) {
      message.success('保存成功', 0.5, () => {
        callback(record, 'optype', '');
      });
    }
  });
};
// 已迷你基金
const getMiniFundsColumns = (data, params, that) => {
  return [
    { title: '所属投资部门', dataIndex: 'belgdept', key: 'belgdept' },
    { title: '基金名称', dataIndex: 'portfname', key: 'portfname' },
    { title: '基金代码', dataIndex: 'portfcode', key: 'portfcode' },
    {
      title: '数据日期',
      dataIndex: 'datadate',
      key: 'datadate',
      render: (text) => text && moment(text).format('YYYY-MM-DD'),
    },
    { title: '户数', dataIndex: 'custcnt', key: 'custcnt', align: 'right' },
    {
      title: '市值',
      dataIndex: 'haholdasset',
      key: 'haholdasset',
      align: 'right',
      render: (text) => text && convert.toThousands(text),
    },
    { title: '规模连续过低工作日天数', dataIndex: 'lowday', key: 'lowday', align: 'right' },
    {
      title: '备注',
      dataIndex: 'remark',
      key: 'remark',
      align: 'center',
      width: 400,
      render: (text, record) => {
        return (
          <DataField
            value={
              <Row wrap={false} justify="center">
                <Col className="one-ellipsis" style={{ maxWidth: 350 }}>
                  <Tooltip placement="bottomLeft" title={text}>
                    {text}
                  </Tooltip>
                </Col>
                {params.isedit && (
                  <Col flex="20px">
                    <EditOutlined
                      style={{ cursor: 'pointer', marginLeft: 5 }}
                      onClick={() => that.handleDoAction(record, 'optype', 'edit')}
                    />
                  </Col>
                )}
              </Row>
            }
            editable={record.optype === 'edit' && params.isedit}
          >
            <Row wrap={false}>
              <Col flex={1}>
                <Input
                  style={{ width: '100%' }}
                  allowClear
                  placeholder="请输入备注"
                  defaultValue={text || undefined}
                  onChange={({ target: { value } }) => that.handleDoAction(record, 'remark', value)}
                />
              </Col>
              <Col
                flex="42px"
                style={{ display: 'inline-flex', alignItems: 'center', cursor: 'pointer' }}
              >
                <CheckOutlined
                  style={{ flex: 1 }}
                  onClick={() => handleSaveRemarkClick(record, that.handleDoAction)}
                />
                <CloseOutlined
                  style={{ flex: 1 }}
                  onClick={() => that.handleDoAction(record, 'optype', '')}
                />
              </Col>
            </Row>
          </DataField>
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      width: 160,
      render: (text, record) => {
        return (
          <div>
            <Button type="link" onClick={() => that.handleDetailClick(record)}>
              查看详情
            </Button>
            <Divider type="vertical" />
            <Button
              type="link"
              loading={that.state.docLoadingId === record.id}
              onClick={() => that.handleDownloadDocClick(record)}
            >
              生成文档
            </Button>
          </div>
        );
      },
    },
  ];
};

// 处理红灯表头部分
const redLightTitle = (data, params, that) => {
  // 清盘
  const liquidation = getLiquidationColumns(data, params, that);
  // 召开大会
  const conference = getConferenceColumns(data, params, that);
  // 红灯基金规模
  const findSize = getFundSizeColumns(data, params, that);
  // 定开
  const fixedOpen = getFixedOpenColumns(data, params, that);

  const firstsubtitle = <strong>合同中约定自动清盘</strong>;
  const secondsubtitle = <strong>合同约定上报方案，并6个月内召开持有人大会</strong>;
  const thirdsubtitle = <strong>合同约定上报方案</strong>;
  const redLightTitle = [
    {
      bigTitle: '1、基金规模已低于5000万元',
      tableTitle: [
        {
          title: () => firstsubtitle,
          columns: liquidation,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) &&
            data.length > 0 &&
            data.filter((a) => a.datatype === '1.1' && a.contractplansixty === '自动清盘'),
        },
        {
          title: () => secondsubtitle,
          columns: conference,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) &&
            data.length > 0 &&
            data.filter((a) => a.datatype === '1.1' && a.contractplansixty === '召开持有人大会'),
        },
        {
          title: () => thirdsubtitle,
          columns: conference,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) &&
            data.length > 0 &&
            data.filter((a) => a.datatype === '1.1' && a.contractplansixty === '上报方案'),
        },
      ],
    },
    {
      bigTitle: '2、基金规模已低于200户',
      tableTitle: [
        {
          title: () => firstsubtitle,
          columns: liquidation,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) &&
            data.length > 0 &&
            data.filter((a) => a.datatype === '1.2' && a.contractplansixty === '自动清盘'),
        },
        {
          title: () => secondsubtitle,
          columns: conference,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) &&
            data.length > 0 &&
            data.filter((a) => a.datatype === '1.2' && a.contractplansixty === '召开持有人大会'),
        },
        {
          title: () => thirdsubtitle,
          columns: conference,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) &&
            data.length > 0 &&
            data.filter((a) => a.datatype === '1.2' && a.contractplansixty === '上报方案'),
        },
      ],
    },
    {
      bigTitle:
        '3、发起式基金成立后第三年至三年对日前三个月，基金规模低于1亿元；或发起式基金成立后三年对日前三个月内，基金规模低于2亿元',
      tableTitle: [
        {
          title: () => '',
          columns: findSize,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) && data.length > 0 && data.filter((a) => a.datatype === '1.3'),
        },
      ],
    },
    {
      bigTitle: '4、定期开放基金临近下一次开放期的2个月，基金规模低于1亿元',
      tableTitle: [
        {
          title: () => '',
          columns: fixedOpen,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) && data.length > 0 && data.filter((a) => a.datatype === '1.4'),
        },
      ],
    },
  ];
  return redLightTitle;
};

// 处理黄灯表头部分
const yellowLightTitle = (data, params, that) => {
  const yellowLight = getYellowLightColumns(data, params, that);
  const bothTitle = getBothColumns(data, params, that);
  const yellowLightTitle = [
    {
      bigTitle: '1、基金规模已连续10个工作日低于1亿元',
      tableTitle: [
        {
          title: () => '',
          columns: yellowLight,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) && data.length > 0 && data.filter((a) => a.datatype === '2.1'),
        },
      ],
    },
    {
      bigTitle: '2、基金户数已连续10个工作日低于250户',
      tableTitle: [
        {
          title: () => '',
          columns: yellowLight,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) && data.length > 0 && data.filter((a) => a.datatype === '2.2'),
        },
      ],
    },
    {
      bigTitle:
        '3、发起式基金成立后第二年，基金规模低于1亿元；或发起式基金成立后第三年开始至三年对日前三个月，基金规模高于1亿元但低于2亿元',
      tableTitle: [
        {
          title: () => '',
          columns: bothTitle,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) && data.length > 0 && data.filter((a) => a.datatype === '2.3'),
        },
      ],
    },
  ];
  return yellowLightTitle;
};

// 处理迷你基金表头部分
const miniFundTitle = (data, params, that) => {
  const miniFunds = getMiniFundsColumns(data, params, that);
  const miniFundsTitle = [
    {
      bigTitle: '',
      tableTitle: [
        {
          title: () => '',
          columns: miniFunds,
          pagination: false,
          size: 'small',
          dataSource:
            Array.isArray(data) && data.length > 0 && data.filter((a) => a.datatype.includes('0.')),
        },
      ],
    },
  ];
  return miniFundsTitle;
};

export default function initConfig(params, that) {
  console.log(params);
  return {
    redLightTitle: (data) => redLightTitle(data, params, that),
    yellowLightTitle: (data) => yellowLightTitle(data, params, that),
    miniFundTitle: (data) => miniFundTitle(data, params, that),
    // handleDetailClick:(data)=>handleDetailClick(data)
  };
}
