export const weekData = [
    {
      quarter: 1,
      value: '周一',
      text: '周一',
    }, {
      quarter: 2,
      value: '周二',
      text: '周二',
    }, {
      quarter: 3,
      value: '周三',
      text: '周三',
    }, {
      quarter: 4,
      value: '周四',
      text: '周四',
    }, {
        quarter: 5,
        value: '周五',
        text: '周五',
      },
  ]