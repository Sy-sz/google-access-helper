import React, { Component } from 'react';
import { Card, Tabs, Table, DatePicker, Spin, Space } from 'antd';
import { cloneDeep } from 'lodash';
import initConfig from './config';
import { commonApi, detailMiniFund, downloadMiniFundDoc } from '@/common/axios';
import { url } from '@cerdo/cerdo-utils';
import DetailModal from '../com/detailModal';
import styles from './index.less';
import moment from 'moment';

const { TabPane } = Tabs;

class Index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      redLightTableTitle: [],
      yellowLightTableTitle: [],
      miniFundsTitle: [],
      activeKey: '1',
      initLoading: false,
      isDetailVisible: false,
      detailLiquidationList: {},
      detailRecord: {},

      fileLoading: false,
      // docLoadingId:null,

      permissions: { isEdit: false },
    };
    this.data = [];
    this.dataBak = [];
    this.params = url.getAllQueryString();

    // props.cacheLifecycles.didCache(this.componentDidCache)
    // props.cacheLifecycles.didRecover(this.componentDidRecover);
  }

  componentDidMount = async () => {
    this.init();
  };

  componentDidRecover = () => {
    this.init();
  };

  init = async () => {
    this.setState({ activeKey: this.params.datatype || '1' });
    const res = await commonApi.userPermission({
      permissionids: ['b57633fc-9d1b-4bf6-8ba5-9523181f11ad'].join(),
    });
    this.params.isedit =
      res &&
      Array.isArray(res.data) &&
      res.data.length > 0 &&
      Number(res.data[0].haspermission) === 1 &&
      Number(this.params.isedit) === 1;
    this.initConfig = initConfig(this.params, this);
    this.initData(this.params.datatype);
  };

  handleDoAction = (record, key, value) => {
    let temp = this.data.find((a) => a.id === record.id);
    if (temp) {
      temp[key] = value === 'reset' ? this.dataBak.find((a) => a.id === record.id)[key] : value;
    }
    if (record.datatype.includes('1.')) {
      const redTitle = this.initConfig.redLightTitle(this.data);
      this.setState({
        redLightTableTitle: redTitle,
      });
    }
    if (record.datatype.includes('0.')) {
      const miniTitle = this.initConfig.miniFundTitle(this.data);
      this.setState({
        miniFundsTitle: miniTitle,
      });
    }
  };

  handleDetailClick = (record) => {
    this.setState({
      isDetailVisible: true,
      detailRecord: record,
    });
  };

  handleDownloadDocClick = (record) => {
    this.setState({ docLoadingId: record.id });
    downloadMiniFundDoc({
      portfcode: record.portfcode,
      datatype: record.datatype,
      rptdate: record.rptdate,
      filename: `${record.portfname}_迷你详情说明_截至日期(${record.rptdate}).doc`,
    }).then((result) => {
      this.setState({ docLoadingId: null });
    });
  };

  initData = (datatype) => {
    this.setState({ initLoading: true });
    detailMiniFund({
      rptdate: this.params.rptdate,
      datatype: datatype,
    }).then((res) => {
      if (res) {
        this.data = res.data;
        this.dataBak = cloneDeep(res.data);
        switch (datatype) {
          case '1':
            this.setState({
              redLightTableTitle: this.initConfig.redLightTitle(this.data),
            });
            break;
          case '2':
            this.setState({
              yellowLightTableTitle: this.initConfig.yellowLightTitle(this.data),
            });
            break;
          case '0':
            this.setState({
              miniFundsTitle: this.initConfig.miniFundTitle(this.data),
            });
            break;
          default:
        }
      }
      this.setState({ initLoading: false });
    });
  };

  handleChangeClick = (key) => {
    this.initData(key);
  };

  render() {
    const {
      activeKey,
      redLightTableTitle,
      yellowLightTableTitle,
      // miniFundsTitle,
      initLoading,
      isDetailVisible,
      detailRecord,
    } = this.state;
    return (
      <div className={styles['pdt-product']}>
        <Spin spinning={initLoading}>
          <Card bodyStyle={{ padding: 0 }} bordered={false}>
            <Tabs
              tabBarStyle={{ padding: '0 16px' }}
              tabBarGutter={16}
              activeKey={activeKey}
              onTabClick={(key) => this.setState({ activeKey: key })}
              animated={{ inkBar: true, tabPane: false }}
              onChange={(key) => this.handleChangeClick(key)}
              tabBarExtraContent={
                <Space size={0}>
                  <label>报表日期：</label>
                  <DatePicker
                    allowClear={false}
                    defaultValue={moment(this.params?.rptdate)}
                    onChange={(date, dateString) => {
                      this.params.rptdate = dateString.replace(/-/g, '');
                      this.initData(activeKey);
                    }}
                  />
                </Space>
              }
            >
              <TabPane tab="红灯" key="1">
                <div className="pdt-product-tab">
                  {redLightTableTitle &&
                    redLightTableTitle.map((item, index) => (
                      <Card key={index} bordered={false} title={<b>{item.bigTitle}</b>}>
                        {item.tableTitle.map((information, indexs) => (
                          <Table
                            key={indexs}
                            rowKey="fundcode"
                            style={{ marginTop: 12 }}
                            {...information}
                            scroll={{ y: 400 }}
                          />
                        ))}
                      </Card>
                    ))}
                </div>
              </TabPane>
              <TabPane tab="黄灯" key="2">
                <div className="pdt-product-tab">
                  {yellowLightTableTitle &&
                    yellowLightTableTitle.map((item, index) => (
                      <Card key={index} title={<b>{item.bigTitle}</b>} bordered={false}>
                        {item.tableTitle.map((information, indexs) => (
                          <Table
                            key={indexs}
                            rowKey="fundcode"
                            {...information}
                            scroll={{ y: 400 }}
                          />
                        ))}
                      </Card>
                    ))}
                </div>
              </TabPane>

              {/* <TabPane tab="已迷你基金" key="0">
                <div className="pdt-product-tab">
                  {miniFundsTitle &&
                    miniFundsTitle.map((item, index) => (
                      <Card key={index} title={item.bigTitle} bordered={false}>
                        {item.tableTitle.map((information, indexs) => (
                          <Table
                            key={indexs}
                            rowKey="fundcode"
                            {...information}
                            // scroll={{ y: 400 }}
                          />
                        ))}
                      </Card>
                    ))}
                </div>
              </TabPane> */}
            </Tabs>
          </Card>
        </Spin>
        <DetailModal
          title="查看详情"
          visible={isDetailVisible}
          detailRecord={detailRecord}
          onCancel={() => this.setState({ isDetailVisible: false })}
        />
      </div>
    );
  }
}

export default Index;
