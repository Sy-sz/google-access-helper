/**
 * 迷你基金设置邮件发送时间 弹窗
 * 单秀雨 2022-03-15
 */
import { Col, Form, message, Row, Button, Select, Spin } from 'antd';
import { saveEmailConfig, detailEamilConfig } from 'common/axios';
import React, { Component } from 'react';
import { CONST, fn } from '@cerdo/cerdo-utils';
import { DragModal, SearchSelect } from '@cerdo/cerdo-design';
import { weekData } from '../detail/index.data';
import Input from 'antd/lib/input/Input';
const FormItem = Form.Item;

class FormModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true
    };
  }

  shouldComponentUpdate(nextProps) {
    if (nextProps.visible && nextProps.visible !== this.props.visible) {
      this.loadData();
    }
    return true;
  }

  loadData = () => {
    this.setState({ loading: true })
    detailEamilConfig().then(res => {
      if (fn.checkResponse(res)) {
        this.form && this.form.setFieldsValue({
          // frequency: res.data.frequency,
          id: res.data.id,
          tdate: res.data.tdate,
          receiver: (res.data.receiver || '').split(',').filter(a => a),
        })
        this.setState({ loading: false })
      }
    })
  }


  // 保存
  handleSave = () => {
    this.form.validateFields().then(values => {
      saveEmailConfig({
        frequency: '每周',
        id: values.id,
        tdate: values.tdate ? values.tdate : '',
        receiver: values.receiver ? values.receiver.join() : '',
      }).then((res) => {
        if (fn.checkResponse(res)) {
          message.success('保存成功');
          this.props.onCancel();
        }
      });
    });
  };

  // 取消
  handleCancel = () => {
    this.props.onCancel();
  }


  render() {
    const { visible, title } = this.props;
    const { loading } = this.state;

    return (
      <DragModal
        title={title}
        visible={visible}
        width={600}
        maskClosable={false}
        destroyOnClose
        closable={false}
        footer={[
          <Button key="save" type="primary" onClick={this.handleSave}>
            保存
          </Button>,
          <Button key="cancel" onClick={this.handleCancel}>
            取消
          </Button>,
        ]}
      >
        <Spin spinning={loading}>
          <Form
            scrollToFirstError
            {...CONST.formModalLayout}
            ref={(ref) => {
              this.form = ref;
            }}
          >
            <Row>
              <Col span={24}>
                <FormItem
                  label="发送频率"
                  name="frequency"
                  initialValue="每周"
                  rules={[{ required: false, message: '请输入发送频率' }]}
                >
                  每周
                </FormItem>
                <FormItem name="id" style={{ display: 'none' }}>
                  <Input />
                </FormItem>
              </Col>
              <Col span={24}>
                <FormItem label="具体时间" name="tdate" rules={[{ required: true, message: '请输入具体时间' }]}>
                  <SearchSelect allowClear style={{ width: '100%' }} placeholder="请输入具体时间" defaultOptions={weekData} />
                </FormItem>
              </Col>
              <Col span={24}>
                <FormItem label="输入邮箱" name="receiver" rules={[{ required: true, message: '请输入邮箱' }]}>
                  <Select mode="tags" style={{ width: '100%' }} placeholder="请输入接收人邮箱" />
                </FormItem>
              </Col>
            </Row>
          </Form>
        </Spin>
      </DragModal>
    );
  }
}

export default FormModal;
