/* eslint-disable no-irregular-whitespace */
/**
 * 迷你基金基金和户数详情
 * 单秀雨 2022-05-10
 */
import { Col, Form, Input, Row, DatePicker, InputNumber, Table, Empty, Spin, Divider } from 'antd';
import React, { Component } from 'react';
import { DragModal } from '@cerdo/cerdo-design';
import { DataField } from '@/common/component';
import { CONST, convert } from '@cerdo/cerdo-utils';
import { detailLiquidation } from '@/common/axios';
import moment from 'moment';
import store from '@/store';
import * as echarts from 'echarts';

const FormItem = Form.Item;
const { withModel } = store;
const echartsTheme = {
  light: {
    title: 'rgba(0, 0, 0, 0.85)',
    legend: 'rgba(0, 0, 0, 0.85)',
  },
  dark: {
    title: 'rgba(255, 255, 255, 0.85)',
    legend: 'rgba(255, 255, 255, 0.85)',
  },
};

const customeTableMap = {
  个人户: 'indvcust',
  产品户: 'prodcust',
  机构户: 'orgcust',
};

@withModel('pdtSystem')
class FormModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      Eloading: false,
      myChart: null,
      dataList: {},
      custConstruct: [],
      xAxisList: [],
      newDatadate: null,
    };
  }
  shouldComponentUpdate(nextProps) {
    if (nextProps.visible && this.props.visible !== nextProps.visible) {
      this.initData(nextProps.detailRecord);
    }
    return true;
  }

  initData = (record) => {
    this.setState({ Eloading: true });
    detailLiquidation({
      portfcode: record.portfcode,
      datatype: record.datatype,
      // datadate: record.datadate,
      rptdate: record.rptdate,
    })
      .then((result) => {
        if (result.data) {
          // 基本信息
          let baseInfo = result.data.baseInfo;
          this.setState({
            dataList: {
              portfname: baseInfo.portfname,
              setupdate: moment(baseInfo.setupdate).format('YYYY-MM-DD') || undefined,
              trustbank: baseInfo.trustbank,
              fundmanagerlist: baseInfo.fundmanagerlist,
              commonfundlist: baseInfo.commonfundlist,
              belgdept: baseInfo.belgdept,
              haholdasset: convert.toThousands(baseInfo.haholdasset),
              custcnt: baseInfo.custcnt,
              custonstruct: baseInfo.custonstruct && baseInfo.custonstruct.split(';'),
              lowday: baseInfo.lowday,
              contractplansixty: baseInfo.contractplansixty,
              lowenddate: moment(baseInfo.lowenddate).format('YYYY-MM-DD') || undefined,
            },
            xAxisList: result.data.assetCustcntList,
            newDatadate: moment(record.datadate).format('YYYY-MM-DD'),
          });

          // 客户结构
          const custDataSource = result.data.custConstruct;
          const customeTable = [];
          Object.keys(customeTableMap).forEach((item) => {
            let prefix = customeTableMap[item];
            let record = {
              title: item,
              cnt: custDataSource[`${prefix}cnt`],
              asset: convert.toThousands(custDataSource[`${prefix}asset`]),
              share: convert.toThousands(custDataSource[`${prefix}share`]),
              ratio: custDataSource[`${prefix}ratio`],
            };
            customeTable.push(record);
          });
          this.setState({
            custConstruct: customeTable,
          });
          this.initChart(result);
        }
        this.setState({ Eloading: false });
      })
      .catch(() => {
        this.setState({ Eloading: false });
      });
  };
  initChart = (result) => {
    const { theme } = this.props.pdtSystem[0];
    window.addEventListener('resize', this.resizeChart);
    // 基金名称
    const portfname = result.data.baseInfo.portfname || '——';
    const myChart = echarts.init(this.myCharts);
    this.setState({ myChart });
    // 日期
    let date = result.data.assetCustcntList
      .map((item) => {
        return item.datadate;
      })
      .sort((a, b) => {
        return new Date(b).getTime() - new Date(a).getTime();
      });
    // 规模
    let haholdasset = result.data.assetCustcntList.map((item) => {
      return item.haholdasset;
    });
    // 户数
    let custcnt = result.data.assetCustcntList.map((item) => {
      return item.custcnt;
    });

    const { dataList, newDatadate } = this.state;
    const titleColor = echartsTheme[theme].title;
    const option = {
      legend: {
        data: ['基金规模', '户数'],
        // right: '15%',
        top: 30,
        textStyle: {
          fontSize: 12,
          color: echartsTheme[theme].legend,
        },
      },
      title: {
        left: 'center',
        // text: `${portfname}规模和户数`,
        text: `【${portfname}】截止${newDatadate}，基金规模${dataList.haholdasset}元，迷你天数${dataList.lowday}工作日，客户数${dataList.custcnt}户`,
        textStyle: {
          color: titleColor,
          fontSize: 13,
          fontWeight: 'normal',
        },
      },
      xAxis: {
        type: 'category',
        data: date,
        axisLabel: {
          // rotate: 20,
          interval: 'auto',
          showMinLabel: true, // 显示最小值
          showMaxLabel: true, // 显示最大值
        },
      },
      axisLabel: {
        color: titleColor,
      },
      yAxis: [
        {
          name: '基金规模',
          data: haholdasset,
          type: 'value',
          splitLine: {
            show: true,
          },
          nameTextStyle: {
            color: titleColor,
          },
        },
        {
          name: '户数',
          data: custcnt,
          type: 'value',
          splitLine: {
            show: false,
          },
          nameTextStyle: {
            color: titleColor,
          },
        },
      ],
      series: [
        {
          name: '基金规模',
          data: haholdasset,
          type: 'line',
          color: '#ff6633',
          yAxisIndex: 0,
          showSymbol: false,
        },
        {
          name: '户数',
          data: custcnt,
          color: '#00BFFF',
          type: 'line',
          yAxisIndex: 1,
          showSymbol: false,
        },
      ],
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'line',
        },
        formatter: function (params) {
          let html = '';
          params.forEach((item, index) => {
            html += `<div style='display:flex;align-items:center;justify-content:space-between;margin:2px 0;'>
                    <span style='display:flex;align-items:center;'>
                        <span style='width:8px;height:8px;background:${item.color};'></span>
                        <span style='margin:0 4px 0 4px;'>${item.seriesName}</span>
                    </span>
                    <span style='font-weight:700;color:#fff;'>${convert.toThousands(
                      item.value,
                    )}</span>
                    </div>`;
          });
          html = `<div style="height:auto;box-sizing:border-box;padding:5px;border-radius:6px;box-shadow: 0px 0px 6px rgba(153, 153, 153, 0.25);">
                    <div>日期：${moment(params[0].name).format('YYYY-MM-DD')}</div>
                    ${html}
                    </div>`;
          return html;
        },
      },
    };

    option && myChart.setOption(option);
  };
  resizeChart = () => {
    const { myChart } = this.state;
    myChart && myChart.resize();
  };
  // 取消
  handleCancel = () => {
    this.props.onCancel();
  };

  handleSearchClick = () => {
    this.table.reloadAndReset();
  };

  getColumns = () => {
    return [
      { title: '', dataIndex: 'title', key: 'title' },
      { title: '户数', dataIndex: 'cnt', key: 'cnt' },
      { title: '市值 (元)', dataIndex: 'asset', key: 'asset' },
      { title: '份额 (份)', dataIndex: 'share', key: 'share' },
      { title: '占比', dataIndex: 'ratio', key: 'ratio' },
    ];
  };

  render() {
    const { visible, title } = this.props;
    const { dataList, custConstruct, xAxisList, Eloading } = this.state;

    return (
      <DragModal
        title={title}
        visible={visible}
        width={1250}
        destroyOnClose
        closable
        onCancel={this.handleCancel}
        bodyStyle={{ maxHeight: 'calc(100vh - 300px)', overflowY: 'auto' }}
        footer={null}
      >
        <Divider orientation="left">基本信息</Divider>
        <Form
          scrollToFirstError
          {...CONST.formModalLayout}
          labelAlign="right"
          ref={(ref) => {
            this.form = ref;
          }}
        >
          <Row>
            <Col span={8}>
              <FormItem label="基金名称" noStyle={false}>
                <DataField editable={false} value={dataList.portfname}>
                  <FormItem label="基金名称" name="portfname">
                    <Input allowClear style={{ width: '100%' }} placeholder="请输入基金名称" />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="成立日期" noStyle={false}>
                <DataField editable={false} value={dataList.setupdate}>
                  <FormItem label="成立日期" name="setupdate">
                    <DatePicker allowClear style={{ width: '100%' }} placeholder="请输入成立日期" />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="托管行" noStyle={false}>
                <DataField editable={false} value={dataList.trustbank}>
                  <FormItem
                    label="托管行"
                    name="trustbank"
                    rules={[{ required: true, message: '请输入托管行' }]}
                  >
                    <Input allowClear style={{ width: '100%' }} placeholder="请输入托管行" />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="基金经理" noStyle={false}>
                <DataField editable={false} value={dataList.fundmanagerlist}>
                  <FormItem
                    label="基金经理"
                    name="fundmanagerlist"
                    rules={[{ required: true, message: '请输入基金经理' }]}
                  >
                    <Input allowClear style={{ width: '100%' }} placeholder="请输入基金经理" />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="归属投资部" noStyle={false}>
                <DataField editable={false} value={dataList.belgdept}>
                  <FormItem
                    label="归属投资部"
                    name="belgdept"
                    rules={[{ required: true, message: '请输入归属投资部' }]}
                  >
                    <Input allowClear style={{ width: '100%' }} placeholder="请输入归属投资部" />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="基金规模(元)" noStyle={false}>
                <DataField editable={false} value={dataList.haholdasset}>
                  <FormItem
                    label="基金规模（万）"
                    name="haholdasset"
                    rules={[{ required: true, message: '请输入基金规模' }]}
                  >
                    <InputNumber
                      allowClear
                      style={{ width: '100%' }}
                      placeholder="请输入基金规模"
                    />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="户数" noStyle={false}>
                <DataField editable={false} value={dataList.custcnt}>
                  <FormItem
                    label="户数"
                    name="custcnt"
                    rules={[{ required: true, message: '请输入户数' }]}
                  >
                    <InputNumber allowClear style={{ width: '100%' }} placeholder="请输入户数" />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>

            <Col span={8}>
              <FormItem label="迷你持续工作日(天)" noStyle={false}>
                <DataField editable={false} value={dataList.lowday}>
                  <FormItem
                    label="迷你持续工作日(天)"
                    name="lowday"
                    rules={[{ required: true, message: '请选择迷你持续工作日' }]}
                  >
                    <InputNumber
                      allowClear
                      style={{ width: '100%' }}
                      placeholder="请选择迷你持续工作日"
                    />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="迷你条款" noStyle={false}>
                <DataField editable={false} value={dataList.contractplansixty}>
                  <FormItem
                    label="迷你条款"
                    name="contractplansixty"
                    rules={[{ required: true, message: '请输入迷你条款' }]}
                  >
                    <Input allowClear style={{ width: '100%' }} placeholder="请输入迷你条款" />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
            <Col span={8}>
              <FormItem label="达到60天工作日" noStyle={false}>
                <DataField editable={false} value={dataList.lowenddate}>
                  <FormItem
                    label="达到60天工作日"
                    name="lowenddate"
                    rules={[{ required: true, message: '请选择达到60天工作日' }]}
                  >
                    <DatePicker
                      allowClear
                      style={{ width: '100%' }}
                      placeholder="请选择达到60天工作日"
                    />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>

            <Col span={16}>
              <FormItem label="机构占比" noStyle={false} {...CONST.formFullLayout}>
                <DataField
                  editable={false}
                  value={
                    dataList &&
                    Array.isArray(dataList.custonstruct) &&
                    dataList.custonstruct.map((item, index) => (
                      <span key={index} style={{ marginRight: '10px' }}>
                        {item}
                      </span>
                    ))
                  }
                >
                  <FormItem
                    label="机构占比"
                    name="custonstruct"
                    rules={[{ required: true, message: '请输入机构占比' }]}
                    {...CONST.formFullLayout}
                  >
                    <Input.TextArea
                      autoSize={{ minRows: 6, maxRows: 40 }}
                      placeholder="请输入机构占比"
                    />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>

            <Col span={24}>
              <FormItem
                label={
                  <span style={{ lineHeight: '18px' }}>
                    基金经理共
                    <br />
                    同管理产品
                  </span>
                }
                noStyle={false}
                {...CONST.formFullLayout}
              >
                <DataField
                  editable={false}
                  value={
                    dataList &&
                    Array.isArray(dataList.commonfundlist) &&
                    dataList.commonfundlist.map((item, index) => (
                      <span key={index} style={{ marginRight: '10px' }}>
                        {item} ,
                      </span>
                    ))
                  }
                >
                  <FormItem
                    label={
                      <span style={{ lineHeight: '18px' }}>
                        基金经理共
                        <br />
                        同管理产品
                      </span>
                    }
                    name="commonfundlist"
                    rules={[{ required: true, message: '请输入基金经理共同管理产品' }]}
                    {...CONST.formFullLayout}
                  >
                    <Input.TextArea
                      autoSize={{ minRows: 6, maxRows: 40 }}
                      placeholder="请输入基金经理共同管理产品"
                    />
                  </FormItem>
                </DataField>
              </FormItem>
            </Col>
          </Row>
        </Form>
        <Divider orientation="left">规模变化和客户数变化</Divider>
        <div className="EchartBox" style={{ position: 'relative', width: '100%', height: 400 }}>
          {Eloading ? (
            <div
              style={{
                width: '100%',
                height: '100%',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                position: 'absolute',
                left: '0',
                top: '0',
              }}
            >
              <Spin />
            </div>
          ) : null}
          {xAxisList.length > 0 ? (
            <div
              id="myCharts"
              ref={(ref) => {
                this.myCharts = ref;
              }}
              style={{ width: '100%', height: 400 }}
            ></div>
          ) : (
            <div
              style={{
                width: '100%',
                height: '100%',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              {' '}
              <Empty />
            </div>
          )}
        </div>
        {/* <p style={{ fontSize: '10px', textAlign: 'center', fontWeight: 'bold' }}>
          
        </p> */}
        <Divider orientation="left">客户结构</Divider>
        <Table
          rowKey="title"
          size="small"
          loading={false}
          bordered={false}
          dataSource={custConstruct}
          columns={this.getColumns()}
          pagination={false}
        />
      </DragModal>
    );
  }
}

export default FormModal;
