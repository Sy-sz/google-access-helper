import React, { useRef, useState } from 'react';
import { Button, Col, Row, Tag, Progress, Space } from 'antd';
import { unstable_batchedUpdates } from 'react-dom';
import QueueAnim from 'rc-queue-anim';
import { fn } from '@cerdo/cerdo-utils';
import { exportSummary, viewSummary, exportRisk } from 'common/axios';
import { PDTSearchAgGridTable, ListCard, CreatePortal } from '@/common/component';
import { listSummaryApi } from '@/common/axios/config';
import { getColumns } from './data';
import styles from './index.less';

const Summary = () => {
  const searchAgTableRef = useRef(null);
  const agGridRef = useRef(null);
  const [selectedRows, setSelectedRows] = useState([]); // 选中行
  const [currentShareId, setCurrentShareId] = useState('');
  const [exportLoading, setExportLoading] = useState<boolean | '70' | '80'>(false);
  const [progressObj, setProgressObj] = useState({ total: 0, current: 0, precent: 0 });

  /** 选中行 */
  const onSelectionChanged = (e) => {
    const selectedRows = e.api.getSelectedRows();
    unstable_batchedUpdates(() => {
      setSelectedRows(selectedRows);
      setProgressObj({ total: selectedRows.length, current: 0, precent: 0 });
    });
  };

  const handleExportSummary = (type, item) => {
    return exportSummary({
      shareids: item.id,
      exporttype: type,
      filename: `${item.fundname}_${item.fundcode}.zip`,
    }).then(() => {
      exportRisk({
        templateid: 'fdfd248f88f24099b64065a12656ef78', // 风险揭示书模板
        shareid: item.id,
        fundid: item.fundid,
        fundcode: item.fundcode,
      }); // 导出风险揭示书
    });
  };

  const handleModalClick = async (type: '70' | '80') => {
    setExportLoading(type);
    for (let index = 0; index < selectedRows.length; index = index + 1) {
      setProgressObj({
        current: index + 1,
        total: selectedRows.length,
        precent: ((index + 1) / selectedRows.length) * 100,
      });
      await handleExportSummary(type, selectedRows[index]);
      if (index === selectedRows.length - 1) {
        setExportLoading(false);
      }
    }
  };

  /** 查看PDF */
  const handleViewPDFClick = (shareid) => {
    setCurrentShareId(shareid);
    viewSummary({ shareid })
      .then((res) => {
        if (fn.checkResponse(res)) {
          window.open(res.data);
        }
      })
      .finally(() => setCurrentShareId(''));
  };

  const onGridReady = (grid) => {
    agGridRef.current = grid;
  };

  return (
    <div className={styles.summary}>
      <CreatePortal container=".search-ag-grid-table">
        <ListCard>
          <Row>
            <Col flex="1" style={{ alignSelf: 'center' }}>
              <QueueAnim
                type={['right', 'left']}
                duration={100}
                onEnd={() => {
                  if (!selectedRows.length) {
                    searchAgTableRef.current?.onSearch();
                  }
                }}
              >
                {selectedRows && selectedRows.length ? (
                  selectedRows.map((item) => (
                    <Tag
                      key={item.id}
                      closable
                      onClose={() => {
                        const selectIds = selectedRows.reduce((acc, curr) => {
                          if (curr.id !== item.id) {
                            acc.push(curr.id);
                          }
                          return acc;
                        }, []);

                        setProgressObj({
                          current: 0,
                          total: selectIds.length,
                          precent: 0,
                        });
                        agGridRef.current.api.forEachNode((node) => {
                          const hasIncludes = selectIds.includes(node.data.id);
                          node.setSelected(hasIncludes);
                        });
                      }}
                      style={{ margin: '3px 5px' }}
                    >
                      {item.fundshortname}[{item.fundcode}]
                    </Tag>
                  ))
                ) : (
                  <div className="gray">请先选择要导出的基金</div>
                )}
              </QueueAnim>
            </Col>
            <Col flex="70px" style={{ alignSelf: 'center' }}>
              {!!progressObj.total && (
                <Progress
                  format={() => `${progressObj.current}/${progressObj.total}`}
                  percent={progressObj.precent}
                  size="small"
                  type="circle"
                  width={60}
                />
              )}
            </Col>
            <Col flex="100px" style={{ alignSelf: 'center' }}>
              <Space direction="vertical">
                <Button
                  type="primary"
                  size="small"
                  onClick={() => handleModalClick('70')}
                  disabled={!selectedRows.length}
                  loading={exportLoading === '70'}
                >
                  导出70文件
                </Button>
                <Button
                  type="primary"
                  size="small"
                  onClick={() => handleModalClick('80')}
                  disabled={!selectedRows.length}
                  loading={exportLoading === '80'}
                >
                  导出80文件
                </Button>
              </Space>
            </Col>
          </Row>
        </ListCard>
      </CreatePortal>

      <PDTSearchAgGridTable
        url={listSummaryApi}
        ref={searchAgTableRef}
        actionBtns={[
          <span className="red" key="tip" style={{ lineHeight: 1 }}>
            提示：一次导出多个文件，可能会被浏览器拦截。如发现被拦截，请在浏览器地址栏添加信任。
          </span>,
        ]}
        onFormatParams={(params: any) => {
          params.pageSize = 1000;
          return params;
        }}
        tableConfig={{
          columnDefs: getColumns({ currentShareId, handleViewPDFClick }),
          pagination: false,
          onGridReady,
          onSelectionChanged,
        }}
      />
    </div>
  );
};

export default Summary;
