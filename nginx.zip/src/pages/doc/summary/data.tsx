import React from 'react';
import { Button } from 'antd';
import type { ITableConfig } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';

export const getColumns = ({ currentShareId, handleViewPDFClick }) =>
  [
    // {
    //   headerName: '序号',
    //   hideInSearch: true,
    //   width: 75,
    //   minWidth: 75,
    //   sortable: false,
    //   pinned: 'left',
    //   valueGetter: 'node.rowIndex + 1',
    //   checkboxSelection: true,
    //   showDisabledCheckboxes: true,
    // },
    {
      headerName: '关键词',
      field: 'keyword',
      hideInTable: true,
      componentProps: { placeholder: '请输入产品代码或名称搜索', allowClear: true },
    },
    {
      headerName: '产品代码',
      field: 'fundcode',
      hideInSearch: true,
      flex: 1,
    },
    {
      headerName: '产品简称',
      field: 'fundshortname',
      hideInSearch: true,
      flex: 1,
    },
    {
      headerName: '最近更新人',
      field: 'updateuser',
      hideInSearch: true,
      flex: 1,
    },
    {
      headerName: '最近更新时间',
      field: 'updatetime',
      hideInSearch: true,
      flex: 1,
    },
    {
      headerName: '操作',
      field: 'operation',
      hideInSearch: true,
      sortable: false,
      width: 150,
      minWidth: 150,
      cellRenderer: ({ data }) => {
        return (
          <div>
            <Button
              type="link"
              size="small"
              loading={currentShareId === data.id}
              onClick={() => {
                handleViewPDFClick(data.id);
              }}
            >
              查看PDF
            </Button>
            <Button
              type="link"
              size="small"
              onClick={() => {
                window.openTab({
                  path: `/app/pdt/doc/summary/edit?fundid=${data.fundid}&shareid=${data.id}&fundcode=${data.fundcode}`,
                });
              }}
            >
              查看
            </Button>
          </div>
        );
      },
    },
  ] as ITableConfig['columnDefs'];
