import React from 'react';
import { Card, Input } from 'antd';
import { WangEditor } from '@cerdo/cerdo-design';

const { TextArea } = Input;

class RichText extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      content: this.props.data.content,
      isHtml: true,
    };
  }
  componentDidMount() {
    // 初始化文本域和富文本
    const { data } = this.props;
    const isHtml = this.checkHtml(data.content);
    // if (isHtml) {
    // 	this.editor = new wangeditor(`#richtext_${data.key}`)
    // 	this.editor.create()
    // 	this.editor.txt.html(data.content)
    // }

    this.setState({ isHtml: isHtml });
  }

  changeType = (value) => {
    console.log(value);
  };

  // 保存内容
  saveContent = (e, data) => {
    if (this.state.isHtml) {
      let content = this.editor.txt.html();
      this.props.onSonChange(content, data.key);
    } else {
      let content = this.state.content;
      this.props.onSonChange(content, data.key);
    }
    // this.setState({
    //   content: this.state.content
    // })
  };
  // 点击取消
  backContent = () => {
    this.setState({ content: this.props.data.content });
    if (this.state.isHtml) {
      if (!this.props.data.content) {
        // 起始没内容 清空填写内容
        this.editor.txt.clear();
      } else {
        this.editor.txt.html(this.props.data.content);
      }
    }
  };
  // 修改文本域的内容
  changeContent = (e) => {
    this.setState({ content: e.target.value });
    // this.props.onSonChange(e.target.value, key)
  };

  // 生成单一内容
  generateContent = () => {
    this.editor.txt.html();
    // console.log(this.editor.txt.html())
  };

  // 富文本和文本域判断
  showRichText = (data) => {
    if (this.state.isHtml) {
      return <WangEditor disabled id={`richtext_${data.key}`} value={this.state.content} />;
    }
    return (
      <TextArea
        disabled
        placeholder="请输入正文"
        rows={10}
        value={this.state.content}
        onChange={(e) => this.changeContent(e, data.key)}
      />
    );
  };

  // 切换富文本和文本域
  // switchText = (e, data) => {
  // 	this.setState({
  // 		isHtml: !this.state.isHtml
  // 	}, () => {
  // 		setTimeout(() => {
  // 			this.editor = new wangeditor(`#richtext_${data.key}`)
  // 			this.editor.create()
  // 			this.editor.txt.html(data.content)
  // 		})
  // 	})
  // 	// console.log(data.key)
  // 	// this.setState({
  // 	//   isHtml: !this.state.isHtml
  // 	// })

  // }

  // 判断是否含有html标签
  checkHtml = (html) => {
    let reg = /<[^>]+>/g;
    return reg.test(html);
  };

  render() {
    const { data } = this.props;
    // const { isHtml } = this.state;
    return (
      <div className="content" id={`content_${data.key}`}>
        <strong>{data.value}</strong>
        <Card
          bordered={false}
        // extra={
        //   <SpaceHB>
        //     {/* <Button size="small" onClick={(e) => this.switchText(e, data)}>{isHtml ? '文本' : '图文'}</Button>
        // 	<Button size="small">美化</Button>
        // 	<Select
        // 		style={{ width: 200, marginLeft: '8px' }}
        // 		size="small"
        // 		placeholder="请选择"
        // 		onChange={this.changeType}
        // 	>
        // 		{
        // 			typeList.map(item => {
        // 				return <Option key={item.noticetypeid} value={item.noticetypeid}>{item.noticetype}</Option>
        // 			})
        // 		}
        // 	</Select>
        // 	<Button size="small" type="primary" onClick={(e) => this.generateContent(e, data)}>生成</Button> */}
        //   </SpaceHB>
        // }
        >
          {this.showRichText(data)}
          {/* <div id={`richtext_${data.key}`}></div> */}
          {/* <SpaceHB style={{ float: 'right', marginTop: 8 }}>
             <Button size="small" type="primary" onClick={(e) => this.saveContent(e, data)}>保存</Button>
						<Button size="small" type="danger" onClick={(e) => this.backContent(e, data)}>取消</Button>
          </SpaceHB> */}
        </Card>
      </div>
    );
  }
}

export default RichText;
