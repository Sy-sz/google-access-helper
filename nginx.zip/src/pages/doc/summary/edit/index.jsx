import React, { Component } from 'react';
import { Card, Col, Row, message, Button, Skeleton } from 'antd';
import {
  listDirectory,
  addDirectory,
  updateDirectory,
  delDirectory,
  viewSummary,
} from 'common/axios';
import RichText from './com/richText';
import { url, fn } from '@cerdo/cerdo-utils';
import { EditTree } from '@cerdo/cerdo-design';
import QueueAnim from 'rc-queue-anim';
import styles from '../index.less';

class Edit extends Component {
  constructor(props) {
    super(props);
    this.state = {
      treeLoading: false,
      treeData: [],
      dataList: [],
      previewLoading: false,
    };
  }

  componentDidMount() {
    const params = url.getAllQueryString();
    if (params.fundid) {
      this.params = params;
      this.getListDirectory();
    }
  }

  getDataList = (treeData) => {
    let dataList = [];
    const generateList = (data) => {
      (data || []).forEach(node => {
        node.key = node.id; // 生成key 树里面做唯一标识
        dataList.push(node);
        if (node.children.length > 0) {
          generateList(node.children);
        }
      });
    }
    generateList(treeData);
    return dataList;
  };

  getListDirectory = () => {
    this.setState({ treeLoading: true });
    listDirectory({ type: 'pdi', ...this.params }).then((res) => {
      if (fn.checkResponse(res)) {
        const data = res.data.children || [];
        this.setState({
          treeData: data,
          dataList: this.getDataList(data),
        });
      }
      this.setState({ treeLoading: false })
    });
  };

  handleNodeSelect = (selectedKeys, e) => {
    // 判断key值是否存在数据中，否则定位id时报错
    const { dataList } = this.state;
    selectedKeys.length === 1 &&
      dataList.map((item) => item.id === selectedKeys[0]).some((a) => !!a) &&
      document
        .getElementById(`content_${selectedKeys[0]}`)
        .scrollIntoView({ behavior: 'smooth' });
  };

  // 预览
  handlePreviewClick = () => {
    this.setState({ previewLoading: true });
    viewSummary({ shareid: this.params.shareid }).then((res) => {
      if (fn.checkResponse(res)) {
        window.open(res.data);
      }
      this.setState({ previewLoading: false });
    });
  };

  handleAddNode = (node) => {
    return addDirectory({ id: node.parentid, name: node.value, fundcode: this.params.fundcode })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('添加成功');
          this.getListDirectory();
          return true;
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  handleDeleteNode = (item) => {
    console.log(item);
    return delDirectory({ id: item.id, fundcode: this.params.fundcode })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('删除成功');
          return true;
        }
        return false;
      })
      .catch((_) => false);
  };

  handleEditNode = (item) => {
    return updateDirectory({ id: item.id, name: item.value, fundcode: this.params.fundcode })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('保存成功');
          return true;
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  handleDropNode = (info) => {
    console.log(info);
  };

  render() {
    const { typeList, treeLoading, treeData, dataList, previewLoading } = this.state;

    return (
      <div className={styles['gutter-example']}>
        <div className={styles['gutter-example-box']}>
          <Row gutter={[8, 8]}>
            <Col span={6}>
              <Card bodyStyle={{ height: `calc(100vh - 120px)` }} bordered={false}>
                <EditTree
                  // draggable
                  allowEdit={false}
                  loading={treeLoading}
                  gData={treeData}
                  expandedKeys={[]}
                  onSelect={this.handleNodeSelect}
                  onItemAdd={(item) => this.handleAddNode(item)}
                  onItemEdit={(item) => this.handleEditNode(item)}
                  onItemDelete={(item) => this.handleDeleteNode(item)}
                  onItemDrop={this.handleDropNode}
                />
              </Card>
            </Col>
            <Col span={18}>
              <Card
                bordered={false}
                bodyStyle={{ height: `calc(100vh - 170px)`, overflowY: 'auto' }}
                extra={
                  <Button
                    type="primary"
                    size="small"
                    loading={previewLoading}
                    onClick={() => this.handlePreviewClick()}
                  >
                    预览
                  </Button>
                }
              >
                {
                  treeLoading
                    ? <Skeleton active />
                    : <QueueAnim type="bottom">
                      {
                        dataList.map((item) => {
                          return (
                            <RichText
                              key={item.key}
                              data={item}
                              typeList={typeList}
                              onSonChange={this.getOnSonChange}
                            />
                          );
                        })
                      }
                    </QueueAnim>
                }
              </Card>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default Edit;
