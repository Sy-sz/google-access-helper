import React from 'react';
import { Link } from 'react-router-dom';
import { PDTSelect, PDTSearchAgGridTable } from '@/common/component';
import { comEleReviewProxyApi } from '@/common/axios/config';
import { storage } from '@cerdo/cerdo-utils';
import { D } from '@/utils';
import type { ITableConfig } from '@cerdo/cerdo-design/lib/SearchAgGridTable/type';

const columns: ITableConfig['columnDefs'] = [
  {
    headerName: '产品代码',
    field: 'fundcode',
    flex: 1,
    componentProps: { placeholder: '请输入产品名称或代码' },
  },
  {
    headerName: '产品名称',
    field: 'fundname',
    flex: 1,
    hideInSearch: true,
  },
  {
    headerName: '状态',
    field: 'status',
    flex: 1,
    dictId: D.APPROVE_TYPE_LIST,
    component: PDTSelect,
    // transform: (value) => value?.join(),
    // componentProps: { mode: 'multiple', maxTagCount: 3 },
  },
  {
    headerName: '数据更新时间',
    field: 'updatetime',
    flex: 1,
    hideInSearch: true,
  },
  {
    headerName: '核对人',
    field: 'checkuser',
    flex: 1,
    hideInSearch: true,
  },
  {
    headerName: '核对时间',
    field: 'checktime',
    flex: 1,
    hideInSearch: true,
  },
];
const ParamsCheck = () => {
  const { account } = storage.getUserInfo() || {};

  const columnDefs = columns.concat([
    {
      headerName: '操作',
      field: 'action',
      sortable: false,
      hideInSearch: true,
      cellRenderer: ({ data }) => {
        let text;
        const { reviewid, dataid, funcid, status, reviewer, alreviewer, createuser } = data || {};
        const url = `/app/com/form?layout=sub&reviewid=${reviewid}&dataid=${dataid}&funcid=${funcid}`;
        if (status === '0' && createuser === account) {
          text = '编辑';
        }

        if (status === '10') {
          if (reviewer?.includes(account)) {
            text = '核对';
          }
          if (alreviewer?.includes(account)) {
            text = '查看';
          }
        }

        if (status === '99') {
          text = '查看';
        }

        if (!text) {
          return null;
        }

        return (
          <Link to={url} target="_blank">
            {text}
          </Link>
        );
      },
    },
  ]);

  return (
    <PDTSearchAgGridTable
      url={comEleReviewProxyApi}
      // rowId="reviewid"
      showSerialColumn={false}
      tableConfig={{
        columnDefs,
        defaultColDef: { sortable: false },
        // rowModelType: 'serverSide',
      }}
    />
  );
};

export default ParamsCheck;
