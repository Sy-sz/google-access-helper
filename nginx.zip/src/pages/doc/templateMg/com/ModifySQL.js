import React, { Component } from 'react';
import { Form, Card, Input, Select, message, Modal } from 'antd';
import { saveTemplateSqlContent } from 'common/axios';
import { CodeMirror } from '@cerdo/cerdo-design';
import { eventCenter, fn, storage } from '@cerdo/cerdo-utils';

const Option = Select.Option;

class ModifySQL extends Component {
  constructor(props) {
    super(props);
    this.state = {
      saveLoading: false,
      theme: '',
    };
  }

  componentDidMount = () => {
    const { data } = this.props;
    this.timer = setTimeout(() => {
      if (data.sqlid) {
        this.editor.setValue(data.content);
        this.form.setFieldsValue({
          resulttype: data.resulttype,
          name: data.name,
          type: data.type,
          params: data.params || [],
        });
      } else {
        this.form.resetFields();
        this.editor.setValue('');
      }
      clearTimeout(this.timer);
    }, 200);
    this.setState({ theme: storage.getItem('theme') });
    this.themeEventId = eventCenter.subscribe('changeTheme', (eventName, valueObj) => {
      this.setState({ theme: valueObj.theme });
    });
  };

  componentWillUnmount() {
    eventCenter.unsubscribe(this.themeEventId);
  }

  onSave = () => {
    const { data, onOk, title } = this.props;
    this.form.validateFields().then((values) => {
      const content = this.editor.getValue();
      if (!content || content === '') {
        message.warning('请输入SQL内容');
        return;
      }
      // 新增
      this.setState({ saveLoading: true });
      saveTemplateSqlContent({
        content: content,
        templateid: data.templateid,
        sqlid: data.sqlid,
        ...values,
      }).then((res) => {
        if (fn.checkResponse(res)) {
          message.success(`${title}成功`, 1, () => {
            onOk(res.data);
          });
          this.setState({ saveLoading: false });
        }
      });
    });
  };

  render() {
    const { saveLoading, theme } = this.state;
    const { onCancel, visible, title } = this.props;
    return (
      <Modal
        // destroyOnClose
        onCancel={onCancel}
        width={1000}
        visible={visible}
        title={title}
        okText="提交"
        onOk={this.onSave}
        okButtonProps={{ loading: saveLoading }}
        bodyStyle={{ padding: 0 }}
      >
        <Card
          bordered={false}
          title={
            <Form
              layout="inline"
              ref={(ref) => {
                this.form = ref;
              }}
            >
              <Form.Item
                label="名称"
                name="name"
                rules={[{ required: true, message: '请填写名称' }]}
              >
                <Input placeholder="请输入SQL名称" />
              </Form.Item>
              <Form.Item
                label="类型"
                name="resulttype"
                initialValue="MAP"
                rules={[{ required: true, message: '请选择类型' }]}
              >
                <Select placeholder="请选择类型">
                  <Select.Option value="MAP">MAP</Select.Option>
                  <Select.Option value="JSON">JSON</Select.Option>
                  <Select.Option value="IMG">IMG</Select.Option>
                </Select>
              </Form.Item>
              <Form.Item
                label="参数"
                name="params"
                rules={[{ required: false, message: '请输入参数' }]}
              >
                <Select mode="tags" style={{ width: 400 }} placeholder="请输入参数">
                  <Option value="shareid">shareid</Option>
                  <Option value="fundid">fundid</Option>
                  <Option value="fundcode">fundcode</Option>
                </Select>
              </Form.Item>

              <Form.Item
                label="数据读取方式"
                name="type"
                initialValue="SQL"
                rules={[{ required: true, message: '请选择数据读取方式' }]}
              >
                <Select style={{ width: 100 }} placeholder="请选择类型">
                  <Select.Option value="SQL">SQL</Select.Option>
                  <Select.Option value="dataservice">数据服务</Select.Option>
                  <Select.Option value="api">API</Select.Option>
                </Select>
              </Form.Item>
            </Form>
          }
        >
          <CodeMirror
            ref={(ref) => {
              this.editor = ref;
            }}
            theme={theme === 'light' ? 'idea' : 'ayu-mirage'}
            mode="text/x-sql"
          />
        </Card>
        <style>{`.CodeMirror-hints{z-index:1001}.CodeMirror-fullscreen{z-index:1001}`}</style>
      </Modal>
    );
  }
}

export default ModifySQL;
