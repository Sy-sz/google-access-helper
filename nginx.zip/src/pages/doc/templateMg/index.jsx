import React, { Component } from 'react';
import { Card, Row, Col, Button, message } from 'antd';
import {
  detailTemplateMg,
  listTemplateMg,
  delTemplateMg,
  saveTemplateMg,
  updateTemplateMg,
  delTemplateSqlContent,
} from 'common/axios';
import ModifySQL from './com/ModifySQL';
import { CodeMirror, OperateButton, LocalTable, EditTree } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { array, eventCenter, fn, storage } from '@cerdo/cerdo-utils';
import { observer } from 'mobx-react';

@observer
class Index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modifyTitle: '',
      modifyVisible: false,
      modifyData: null,

      currentTemplate: null,
      treeData: [],
      treeLoading: false,
      expandedKeys: [],
      theme: '',
    };
  }

  componentDidMount() {
    this.getTreeData();
    this.setState({ theme: storage.getItem('theme') });
    this.themeEventId = eventCenter.subscribe('changeTheme', (eventName, valueObj) => {
      this.setState({ theme: valueObj.theme });
    });
  }

  componentWillUnmount() {
    eventCenter.unsubscribe(this.themeEventId);
  }

  // 获取模板列表
  getTreeData = () => {
    this.setState({ treeLoading: true });
    listTemplateMg().then((res) => {
      if (res) {
        const treeData = array.toOptionsArray([res.data], 'templateid', 'label');
        this.setState({
          treeData: treeData,
          expandedKeys: [treeData[0].key],
          treeLoading: false,
        });
      }
    });
  };

  // 添加模板
  handleAddNode = (item) => {
    return saveTemplateMg({
      label: item.value,
      templateid: item.parentid,
    })
      .then((res) => {
        if (res) {
          message.success('新增成功');
          return { templateid: res.data };
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  // 删除模板
  handleDeleteNode = (item) => {
    return delTemplateMg({
      templateid: item.templateid,
    })
      .then((res) => {
        if (res.code) {
          message.success('删除成功');
          return true;
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  handleEditNode = (item) => {
    return updateTemplateMg({
      templateid: item.templateid,
      label: item.value,
    })
      .then((res) => {
        if (res.code) {
          message.success('修改成功');
          return true;
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  // 删除sql
  handleDeleteSqlClick = (record) => {
    const { currentTemplate } = this.state;
    delTemplateSqlContent({
      sqlid: record.sqlid,
    }).then((res) => {
      if (fn.checkResponse(res)) {
        message.success('删除成功', 1.5, () => {
          this.handleTreeSelect([currentTemplate.templateid], {
            selected: true,
            node: { templateid: currentTemplate.templateid },
          });
        });
      }
    });
  };

  // 保存html
  handleSaveHtmlClick = () => {
    const { currentTemplate } = this.state;
    if (!currentTemplate) {
      message.error('请选择模板');
      return;
    }
    updateTemplateMg({
      templateid: currentTemplate.templateid,
      html: this.editor.getValue(),
    }).then((res) => {
      if (res) {
        message.success('保存成功');
      }
    });
  };

  // 编辑SQL
  handleEditSqlClick = (text, record) => {
    this.setState({
      modifyData: record,
      modifyTitle: '编辑SQL',
      modifyVisible: true,
    });
  };

  // 添加SQL
  handleAddSqlClick = () => {
    this.setState({
      modifyData: { templateid: this.state.currentTemplate.templateid },
      modifyTitle: '添加SQL',
      modifyVisible: true,
    });
  };

  // html 预览
  // sourcePreview = () => {
  //     viewTemplateMg({
  //         fundid: 'B88FB862F8C960AAE0530B141EACEA0D',
  //         templateid: '941740bc49e344469466215f3c163f82'
  //     }).then((res) => {
  //         if (res.code !== 'C200') return;
  //         Modal.confirm({
  //             icon: null,
  //             title: '模板预览',
  //             content: (
  //                 <div id="htmlPreview" />
  //             ),
  //         })
  //         setTimeout(() => { $('#htmlPreview').html(res.data) }, 200)
  //     }).catch(() => {

  //     }).finally(() => {

  //     })
  // }

  getColumns = () => {
    return [
      {
        title: '名称',
        dataIndex: 'name',
        key: 'name',
        width: 80,
        fixed: 'left',
      },
      {
        title: '查询sql/数据服务ID',
        dataIndex: 'content',
        key: 'content',
        width: 800,
        render: (text) => {
          return <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit' }}>{text}</pre>;
        },
      },
      {
        title: '类型',
        dataIndex: 'resulttype',
        key: 'resulttype',
        width: 80,
        fixed: 'right',
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 100,
        fixed: 'right',
        render: (text, record, index) => {
          return (
            <OperateButton
              type="edit | delete"
              onEdit={() => {
                this.handleEditSqlClick(text, record, index);
              }}
              onDelete={() => {
                this.handleDeleteSqlClick(record);
              }}
            />
          );
        },
      },
    ];
  };

  // 选中模板
  handleTreeSelect = (value, { selected, node }) => {
    if (!selected) {
      return;
    }

    detailTemplateMg({
      templateid: node.templateid,
    })
      .then((res) => {
        if (res) {
          this.setState(
            {
              currentTemplate: res.data,
            },
            () => {
              this.editor.setValue(res.data.html);
              this.table.dataSourceChange({ data: res.data.sqlcontents || [] }, true);
            },
          );
        }
      })
      .catch(() => {});
  };

  render() {
    const {
      treeData,
      treeLoading,
      modifyData,
      modifyTitle,
      modifyVisible,
      currentTemplate,
      expandedKeys,
      theme,
    } = this.state;

    return (
      <div>
        <Row gutter={[8, 16]}>
          <Col span={6}>
            <Card bordered={false} bodyStyle={{ overflowX: 'auto' }}>
              <EditTree
                ref={(ref) => {
                  this.tree = ref;
                }}
                style={{ height: 'calc(100vh - 165px)', overflow: 'auto' }}
                draggable
                expandedKeys={expandedKeys}
                gData={treeData}
                loading={treeLoading}
                onSelect={this.handleTreeSelect}
                // onItemDrop={(info) => this.handleDropNode(info)}
                onItemDelete={(item) => this.handleDeleteNode(item)}
                onItemEdit={(item) => this.handleEditNode(item)}
                onItemAdd={(item) => this.handleAddNode(item)}
              />
            </Card>
          </Col>
          <Col span={18}>
            <Card
              title={currentTemplate ? currentTemplate.label : '请选择模板'}
              extra={
                <Button
                  disabled={!currentTemplate}
                  size="small"
                  type="primary"
                  onClick={this.handleSaveHtmlClick}
                >
                  保存
                </Button>
              }
              bordered={false}
            >
              <CodeMirror
                ref={(ref) => {
                  this.editor = ref;
                }}
                theme={theme === 'light' ? 'idea' : 'ayu-mirage'}
                id={theme}
                // onChange={(value) => {  }}
              />
            </Card>
            <ListCard
              title="数据源列表"
              extra={
                <div>
                  <Button
                    disabled={!currentTemplate}
                    size="small"
                    type="primary"
                    onClick={() => this.handleAddSqlClick()}
                  >
                    添加SQL
                  </Button>
                </div>
              }
            >
              <LocalTable
                size="small"
                showTools={false}
                ref={(ref) => {
                  this.table = ref;
                }}
                rowKey="sqlid"
                columns={this.getColumns()}
                toolStyleTop={0}
                scroll={{ y: 1200 }}
              />
            </ListCard>
          </Col>
        </Row>

        {modifyVisible && (
          <ModifySQL
            title={modifyTitle}
            visible={modifyVisible}
            data={modifyData}
            onCancel={() => {
              this.setState({ modifyVisible: false });
            }}
            onOk={() => {
              this.setState(
                {
                  modifyVisible: false,
                },
                () => {
                  this.handleTreeSelect([currentTemplate.templateid], {
                    selected: true,
                    node: { templateid: currentTemplate.templateid },
                  });
                },
              );
            }}
          />
        )}
      </div>
    );
  }
}

export default Index;
