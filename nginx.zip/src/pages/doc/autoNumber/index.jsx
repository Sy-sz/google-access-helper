import React, { Component } from 'react';
import { Button, message, Space, Card } from 'antd';
import {
  listNoticeType,
  genAutoNumberFile,
  downloadAutoNumberPdf,
  listFundShare,
} from 'common/axios';
import { readAutoNumberFileApi } from 'common/axios/config';
import { UploadFile, SearchSelect, OperateButton, LocalTable } from '@cerdo/cerdo-design';
import moment from 'moment';

class AutoNumber extends Component {
  constructor() {
    super();
    this.state = {
      loading: false,
      tableData: [],
    };
  }

  componentDidMount() {
    const params = this.props.location.state;
    if (params && params.tableList) {
      this.setState(
        {
          tableData: params.tableList,
        },
        () => {
          this.table.dataSourceChange(params.tableList);
        },
      );
    }
  }

  // 读取文件
  handleFileChange = (file, fileList) => {
    const { tableData } = this.state;
    tableData.push(file);
    this.setState({ tableData }, () => {
      this.table.dataSourceChange({ data: tableData });
    });
  };

  // 点击生成按钮
  handleGenerateClick = () => {
    const { tableData } = this.state;
    const submitData = tableData.filter((a) => a.fundcode && a.noticetypeid);
    if (submitData.length < 1) {
      message.warning('没有符合编号的文件');
      return;
    }

    this.setState({ loading: true });
    // 请求生成pdf文件接口
    genAutoNumberFile(submitData).then((res) => {
      if (res && res.data) {
        const downloadId = res.data.pdfid;
        const data = res.data.list;
        const fileName =
          submitData.length > 1
            ? `编号文件_${moment().format('YYYYMMDDHHMMSS')}.zip`
            : `${res.data.list[0].pdffilename}`;

        downloadAutoNumberPdf({
          filename: fileName,
          id: downloadId,
        });

        this.table.dataSourceChange({
          data: tableData.map((item) => {
            const temp = data.find((a) => a.batchid === item.id);
            if (temp) {
              item.pdffilename = temp.pdffilename;
            } else {
              item.pdffilename = '未编号，请确认公告类型、基金已选择';
            }
            return item;
          }),
        });
      } else {
        message.warning(res.msg || '生成失败');
      }
      this.setState({ loading: false });
    });
  };
  // 删除
  handleDeleteClick = (id) => {
    let { tableData } = this.state;
    tableData = tableData.filter((a) => a.id !== id);
    this.setState({ tableData }, () => {
      this.table.dataSourceChange({ data: tableData });
    });
  };
  getColumns = () => {
    return [
      {
        title: '原文件',
        dataIndex: 'originfilename',
        key: 'originfilename',
        // align: 'center',
        width: '24%',
      },
      {
        title: '公告类别',
        dataIndex: 'noticetype',
        key: 'noticetype',
        width: '20%',
        // align: 'center',
        render: (text, record, index) => this.selectnoticeDom(record),
      },
      {
        title: '基金',
        dataIndex: 'fund',
        key: 'fund',
        width: '30%',
        // align: 'center',
        render: (text, record, index) => {
          return <span>{this.selectDom(record)}</span>;
        },
      },
      {
        title: '文件编号',
        dataIndex: 'pdffilename',
        key: 'pdffilename',
        align: 'center',
        width: '20%',
      },
      {
        title: '操作',
        dataIndex: 'delete',
        key: 'delete',
        align: 'center',
        width: '6%',
        render: (_, record) => (
          <OperateButton type="delete" onDelete={() => this.handleDeleteClick(record.id)} />
        ),
      },
    ];
  };
  // 基金编码部分
  selectDom = (record) => {
    return (
      <SearchSelect
        getData={() =>
          listFundShare({
            keyword: 'all',
          })
        }
        style={{ width: '100%' }}
        allowClear={false}
        defaultValue={record.fundcode ? `${record.fundname}[${record.fundcode}]` : undefined}
        // dropdownMatchSelectWidth={false}
        placeholder="请选择基金"
        optionFilterProp="children"
        onChange={(_, option) => this.changeFund(record.id, option)}
      >
        {(item) => (
          <SearchSelect.Option
            key={item.id}
            value={item.fundcode}
            name={item.fundname}
            style={{ width: 300 }}
          >{`${item.fundname}[${item.fundcode}]`}</SearchSelect.Option>
        )}
      </SearchSelect>
    );
  };

  changeFund = (id, option) => {
    const { tableData } = this.state;
    const item = tableData.find((a) => a.id === id);
    item.fundcode = option.value;
    item.fundname = option.name;
  };

  // 公告类别
  selectnoticeDom = (record) => {
    return (
      <SearchSelect
        getData={listNoticeType}
        style={{ width: '100%' }}
        allowClear={false}
        defaultValue={record.noticetype}
        // dropdownMatchSelectWidth={false}
        placeholder="请选择公告类别"
        optionFilterProp="name"
        onChange={(_, option) => this.changenoticeFund(record.id, option)}
      >
        {(item) => (
          <SearchSelect.Option
            key={item.noticetypeid}
            value={item.noticetypeid}
            name={item.noticetype}
          >
            {item.noticetype}
          </SearchSelect.Option>
        )}
      </SearchSelect>
    );
  };

  changenoticeFund = (id, option) => {
    const { tableData } = this.state;
    const item = tableData.find((a) => a.id === id);
    item.noticetypeid = option.value;
    item.noticetype = option.name;
  };

  render() {
    const { loading, tableData } = this.state;
    return (
      <Card
        bordered={false}
        extra={
          <Space>
            <UploadFile
              uploadUrl={readAutoNumberFileApi}
              // downloadUrl={downloadFileApi}
              multiple
              onChange={this.handleFileChange}
              accept=".doc, .docx,.pdf"
              showUploadList={false}
              showProcess
            >
              <Button type="primary">批量上传</Button>
            </UploadFile>
            <Button
              type="primary"
              loading={loading}
              onClick={this.handleGenerateClick}
              disabled={tableData.length === 0}
            >
              {loading ? '生成中...' : '生成'}
            </Button>
          </Space>
        }
      >
        <LocalTable
          size="small"
          showTools={false}
          ref={(ref) => {
            this.table = ref;
          }}
          rowKey="id"
          pagination={false}
          columns={this.getColumns()}
          scroll={{ y: `calc(100vh - 160px)` }}
        />
      </Card>
    );
  }
}

export default AutoNumber;
