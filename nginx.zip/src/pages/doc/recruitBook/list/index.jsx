import { FetchTable } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { routeUtils, fn } from '@cerdo/cerdo-utils';
import { Button, Col, Form, Input, Space } from 'antd';
import React, { Component } from 'react';
import { listRecruit } from '@/common/axios';
import SearchCard from '@/common/component/SearchCard';

const FormItem = Form.Item;

class List extends Component {
  constructor() {
    super();
    this.state = {};
    this.formRef = React.createRef();
  }

  componentDidMount() {}

  getList = () => {
    return new Promise((resolve, reject) => {
      this.table.getFormParams(this.formRef.current).then((values) => {
        listRecruit({
          ...values,
        }).then((result) => {
          if (fn.checkResponse(result)) {
            resolve(result);
          }
          reject(null);
        });
      });
    });
  };

  getColumns = () => {
    return [
      { title: '产品代码', dataIndex: 'fundcode', key: 'fundcode', width: 150, fixed: 'left' },
      { title: '产品简称', dataIndex: 'fundname', key: 'fundname', width: 300, fixed: 'left' },
      {
        title: '最近更新人/时间',
        dataIndex: 'updateuser',
        key: 'updateuser',
        width: 150,
        render: (_, record) => {
          return (
            <Space size={0} direction="vertical">
              <span>{record.updateuser}</span>
              <span>{record.updatetime}</span>
            </Space>
          );
        },
      },
      {
        title: '操作',
        width: 100,
        dataIndex: 'operation',
        key: 'operation',
        fixed: 'right',
        render: (text, record) => {
          return (
            <Button
              type="link"
              onClick={() => {
                routeUtils.pushNew.call(
                  this,
                  `/app/pdt/doc/recruitBook/edit?fundid=${record.fundid}&fundcode=${record.fundcode}&fundname=${record.fundname}`,
                );
              }}
            >
              编辑
            </Button>
          );
        },
      },
    ];
  };

  handleSearchClick = () => {
    this.table.reloadAndReset();
  };

  render() {
    return (
      <div>
        <SearchCard ref={this.formRef} bordered={false} onSearch={this.handleSearchClick}>
          <Col span={8}>
            <FormItem label="关键词" name="keyword">
              <Input style={{ width: '100%' }} allowClear placeholder="请输入产品代码或名称搜索" />
            </FormItem>
          </Col>
        </SearchCard>
        <ListCard title="招募产品列表" bordered={false} size="small">
          <FetchTable
            size="small"
            showTools={false}
            rowKey="fundid"
            ref={(ref) => {
              this.table = ref;
            }}
            getList={this.getList}
            columns={this.getColumns()}
            autoHeight={{ blankHeight: 160 }}
            scroll={{ y: 'calc(100vh - 320px)' }}
          />
        </ListCard>
      </div>
    );
  }
}

export default List;
