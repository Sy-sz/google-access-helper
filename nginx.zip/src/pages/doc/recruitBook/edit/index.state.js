import { fn } from '@cerdo/cerdo-utils';
import { getAllUsers } from '@cerdo/cerdo-utils/lib/api';
import { observable, action, makeObservable } from 'mobx';

class RecruitState {
    constructor() {
        makeObservable(this);
    }

    @observable userData = null;
    @action setUserData = () => {
        if (this.userData && Array.isArray(this.userData)) { return; }
        getAllUsers().then(result => {
            if (fn.checkResponse(result)) {
                this.userData = result.data;
            }
        })
    };
}

export default new RecruitState();
