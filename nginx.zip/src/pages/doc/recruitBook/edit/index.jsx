import { EditTree, FetchSelect, UploadFile } from '@cerdo/cerdo-design';
import { url, fn, guid } from '@cerdo/cerdo-utils';
import { Button, Card, Col, message, Modal, Result, Row, Skeleton, Tooltip, Space } from 'antd';
import React, { Component } from 'react';
import {
  addDirectory,
  listRecruitDirectory,
  delDirectory,
  updateDirectory,
  listRecruit,
  listTemplateMg,
  saveRecruitTree,
  commonApi,
  saveNewRecruitDirectory,
  sendEmailRecruit,
  genAllRecruitContent,
  viewRecruit,
  exportRecruit,
  dargDirectory,
  updateTitleNum,
  importRecruit,
  saveRecruitAllContent,
} from '@/common/axios';
import RichText from '../com/richText';
import styles from './index.less';
import RecruitState from './index.state';
import { SyncOutlined, FileDoneOutlined, ExportOutlined, SaveOutlined } from '@ant-design/icons';
import { uploadFileApi, downloadFileApi } from 'common/axios/config';

class Edit extends Component {
  constructor(props) {
    super(props);
    this.state = {
      treeKey: guid(),
      treeLoading: false,
      treeData: [],
      expandedKeys: [],

      dataList: [],
      templateList: [],

      copyLoading: false,
      genAllLoading: false,
      newTermLoading: false,
      previewLoading: false,
      exportLoading: false,
      updateNumLoading: false,
      saveAllLoading: false,

      permissions: {},

      guid: '',
      importLoading: false,
    };
    this.data = {};
  }

  componentDidMount() {
    const params = url.getAllQueryString();
    if (params.fundid) {
      this.params = params;
      this.getListDirectory();
      this.getTemplateList();
    }
    this.verifyUserPermission();
    RecruitState.setUserData();
  }

  verifyUserPermission = () => {
    commonApi
      .userPermission({
        permissionids: [
          '70f692d8-20c9-4bea-9800-4efcde81df21',
          'f7a357de-071d-4b21-884f-faa46e67530c',
        ].join(),
      })
      .then((result) => {
        if (fn.checkResponse(result)) {
          this.setState({
            permissions: {
              isEditTree: result.data[0].haspermission === 1,
              isAdmin: result.data[1].haspermission === 1,
            },
          });
        }
      });
  };

  getDataList = (treeData) => {
    let dataList = [];
    const generateList = (data) => {
      (data || []).forEach((node) => {
        node.key = node.id; // 生成key 树里面做唯一标识
        dataList.push(node);
        if (node.children.length > 0) {
          generateList(node.children);
        }
      });
    };
    generateList(treeData);
    return dataList;
  };

  getTemplateList = () => {
    listTemplateMg({ templateid: 'D9B0328ECD7C6612E055000000000001' }).then((res) => {
      if (res && res.data) {
        this.setState({ templateList: res.data.children || [] });
      }
    });
  };

  getListDirectory = (loading = true) => {
    loading && this.setState({ treeLoading: true });
    listRecruitDirectory({
      type: 'pdmp',
      ...this.params,
    }).then((res) => {
      loading && this.setState({ treeLoading: false });
      if (fn.checkResponse(res)) {
        const data = res.data.children || [];
        this.setState({
          rootid: res.data.id,
          treeData: data,
          treeKey: loading ? this.state.treeKey : guid(),
          dataList: this.getDataList(data),
          guid: guid(),
        });
        this.tree &&
          this.tree.setState({
            expandedKeys: this.state.expandedKeys,
          });
      }
    });
  };

  refreshRightContet = () => {
    this.setState({ dataList: this.getDataList(this.tree.state.treeData) });
  };

  handleNewClick = () => {
    Modal.confirm({
      title: '确认开始新一期？',
      content: <small>新一期内容将自动复制本期内容，并将本期内容备份。</small>,
      okText: '是',
      cancelText: '否',
      onOk: () => {
        this.setState({ newTermLoading: true });
        saveNewRecruitDirectory({
          fundcode: this.params.fundcode,
        }).then((result) => {
          if (fn.checkResponse(result)) {
            message.success('已初始化新一期', 0.5, () => {
              this.getListDirectory();
            });
          }
          this.setState({ newTermLoading: false });
        });
      },
    });
  };

  handleUpdateTitleNumClick = () => {
    this.setState({ updateNumLoading: true });
    updateTitleNum({
      fundcode: this.params.fundcode,
    }).then((result) => {
      this.setState({ updateNumLoading: false });
      if (fn.checkResponse(result)) {
        message.success('刷新序号成功', 0.5, () => {
          this.getListDirectory(false);
        });
      }
    });
  };

  handleSendEmailClick = () => {
    sendEmailRecruit({
      fundcode: this.params.fundcode,
    }).then((result) => {
      if (fn.checkResponse(result)) {
        message.success('催办邮件发送成功，请注意查收邮箱！');
      }
    });
  };

  handleGenAllClick = () => {
    Modal.confirm({
      title: '生成全部将会覆盖现有内容，确认操作？',
      onOk: () => {
        this.setState({ genAllLoading: true });
        genAllRecruitContent({
          fundcode: this.params.fundcode,
        }).then((result) => {
          if (fn.checkResponse(result)) {
            message.success('生成成功', 0.5, () => {
              this.getListDirectory();
            });
          }
          this.setState({ genAllLoading: false });
        });
      },
    });
  };

  handlePreviewClick = () => {
    this.setState({ previewLoading: true });
    viewRecruit({
      fundcode: this.params.fundcode,
    }).then((result) => {
      if (fn.checkResponse(result)) {
        window.open(result.data);
      }
      this.setState({ previewLoading: false });
    });
  };

  handleExportClick = () => {
    if (this.state.dataList.some((a) => a.status !== '99')) {
      Modal.confirm({
        title: '提示',
        // content: '检测到存在未审核通过章节，是否继续导出？',
        content: '确认导出WORD文件？',
        okText: '是',
        cancelText: '否',
        onOk: () => {
          this.exportDocFile();
        },
      });
    } else {
      this.exportDocFile();
    }
  };

  handleDataChange = (id, key, value) => {
    const { dataList } = this.state;
    let node = dataList.find((a) => a.id === id);
    node[key] = value;
    this.setState({ dataList });
  };

  handleSaveAllClick = () => {
    Modal.confirm({
      title: '提示',
      // content: '检测到存在未审核通过章节，是否继续导出？',
      content: '确认保存全部章节？',
      okText: '是',
      cancelText: '否',
      onOk: () => {
        const { dataList } = this.state;
        this.setState({ saveAllLoading: true });
        const data = dataList.map((a) => {
          return {
            id: a.id,
            content: a.content,
            templateid: a.templateid,
          };
        });
        saveRecruitAllContent(data).then((result) => {
          this.setState({ saveAllLoading: false });
          if (fn.checkResponse(result)) {
            message.success('全部章节保存成功');
          }
        });
      },
    });
  };

  exportDocFile = () => {
    this.setState({ exportLoading: true });
    exportRecruit({
      fundcode: this.params.fundcode,
    }).then((result) => {
      if (fn.checkResponse(result)) {
        const { fileId, fileName } = result.data;
        commonApi.downloadFile(fileId, fileName, downloadFileApi);
      }
      this.setState({ exportLoading: false });
    });
  };

  handleFundChange = (value) => {
    this.data.copyFundCode = value;
  };

  handleCopyTreeClick = () => {
    if (!this.data.copyFundCode) {
      return message.warning('请选择要复制的基金');
    }
    this.setState({ copyLoading: true });
    saveRecruitTree({
      sourcefundcode: this.data.copyFundCode,
      targetfundcode: this.params.fundcode,
    }).then((result) => {
      if (fn.checkResponse(result)) {
        message.success('复制成功', 0.5, () => {
          this.getListDirectory();
          this.data.copyFundCode = null;
        });
      }
      this.setState({ copyLoading: false });
    });
  };

  handleUploadChange = (file, fileList) => {
    if (file) {
      Modal.confirm({
        title: '确认导入解析？',
        onOk: () => {
          this.setState({ importLoading: true });
          importRecruit({
            fundcode: this.params.fundcode,
            fileid: file.fileid,
          }).then((result) => {
            this.setState({ importLoading: false });
            if (fn.checkResponse(result)) {
              message.success('解析成功', 1.5, () => {
                this.getListDirectory();
              });
            }
          });
        },
      });
    }
  };

  getDrapPosition = (node) => {
    const { dragOver, dragOverGapBottom, dragOverGapTop } = node;
    if (dragOver) {
      return 'sub';
    }
    if (dragOverGapBottom) {
      return 'bottom';
    }
    if (dragOverGapTop) {
      return 'top';
    }
  };

  handleDropNode = (info) => {
    return dargDirectory({
      sourceid: info.dragNode.id,
      targetid: info.node.id,
      position: this.getDrapPosition(info.node),
    })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('拖动成功', 0.1, async () => {
            this.getListDirectory(false);
            this.setState({
              expandedKeys: [info.dragNode.id, info.node.id],
            });
          });
          return true;
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  handleAddNode = (item) => {
    return addDirectory({
      id: item.parentid,
      name: item.value,
      fundcode: this.params.fundcode,
      type: 'pdmp',
    })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('添加成功', 0.5, () => {
            this.refreshRightContet();
          });
          return { id: res.data, key: res.data, isedit: 1, status: 0 };
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  handleDeleteNode = (item) => {
    // TODO 删除点击 未阻止事件冒泡
    return delDirectory({ id: item.id, fundcode: this.params.fundcode })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('删除成功', 0.5, () => {
            this.refreshRightContet();
          });
          return true;
        }
        return false;
      })
      .catch((_) => false);
  };

  handleEditNode = (item) => {
    return updateDirectory({ id: item.id, name: item.value, fundcode: this.params.fundcode })
      .then((res) => {
        if (fn.checkResponse(res)) {
          message.success('保存成功', 0.5, () => {
            this.refreshRightContet();
          });
          return true;
        }
        return false;
      })
      .catch(() => {
        return false;
      });
  };

  handleNodeSelect = (selectedKeys) => {
    const { dataList } = this.state;
    selectedKeys.length === 1 &&
      dataList.map((item) => item.id === selectedKeys[0]).some((a) => !!a) &&
      document.getElementById(`content_${selectedKeys[0]}`).scrollIntoView({ behavior: 'smooth' });
  };

  render() {
    const {
      treeLoading,
      rootid,
      treeKey,
      treeData,
      dataList,
      templateList,
      expandedKeys,
      newTermLoading,
      genAllLoading,
      saveAllLoading,
      updateNumLoading,
      exportLoading,
      permissions: { isEditTree, isAdmin },
      guid,
      importLoading,
      copyLoading,
    } = this.state;

    if (!treeLoading && treeData.length === 0) {
      return (
        <Result
          title="抱歉，该基金暂未配置过招募书目录结构！"
          subTitle="可复制类似基金进行初始化操作"
          extra={
            <div>
              {isAdmin && (
                <p>
                  <UploadFile
                    uploadUrl={uploadFileApi}
                    downloadUrl={downloadFileApi}
                    accept=".doc,.docx"
                    showProcess
                    showUploadList={false}
                    onChange={this.handleUploadChange}
                  >
                    <Button type="primary" loading={importLoading}>
                      上传招募文档解析
                    </Button>
                  </UploadFile>
                </p>
              )}

              <FetchSelect
                style={{ width: 300, textAlign: 'left' }}
                getData={listRecruit}
                getParams={() => ({ iscopy: '1' })}
                allowClear={false}
                placeholder="请选择要复制的基金"
                onChange={(value) => this.handleFundChange(value)}
              >
                {(item) => (
                  <FetchSelect.Option key={item.fundid} value={item.fundcode}>
                    {item.fundname}[{item.fundcode}]
                  </FetchSelect.Option>
                )}
              </FetchSelect>
              <Button
                type="primary"
                style={{ marginLeft: -60, border: 0 }}
                onClick={this.handleCopyTreeClick}
                loading={copyLoading}
              >
                复制
              </Button>
            </div>
          }
        />
      );
    }
    return (
      <Row gutter={[8, 8]} className={styles['pdt_recruit_book_edit']}>
        <Col span={6}>
          <Card bodyStyle={{ height: `calc(100vh - 115px)`, overflow: 'auto' }} bordered={false}>
            <EditTree
              ref={(ref) => {
                this.tree = ref;
              }}
              style={{ height: 'calc(100vh - 180px)', overflowX: 'auto' }}
              expandedKeys={expandedKeys}
              key={treeKey}
              gData={treeData}
              loading={treeLoading}
              onItemDrop={(info) => this.handleDropNode(info)}
              onItemDelete={(item) => this.handleDeleteNode(item)}
              onItemEdit={(item) => this.handleEditNode(item)}
              onItemAdd={(item) => this.handleAddNode(item)}
              onSelect={this.handleNodeSelect}
              allowEdit={isEditTree}
              rootid={rootid}
              draggable={isEditTree}
            />
          </Card>
        </Col>
        <Col span={18}>
          <Card
            bordered={false}
            title={
              <Tooltip title={`${this.params.fundname}招募说明书`}>
                <strong>{this.params.fundname}招募说明书</strong>
              </Tooltip>
            }
            bodyStyle={{ height: `calc(100vh - 165px)`, overflowY: 'auto', marginTop: 2 }}
            extra={
              <Space>
                {isEditTree && (
                  <Button
                    type="primary"
                    size="small"
                    loading={saveAllLoading}
                    icon={<SaveOutlined />}
                    onClick={this.handleSaveAllClick}
                  >
                    保存全部
                  </Button>
                )}
                {isEditTree && (
                  <Button
                    type="primary"
                    size="small"
                    loading={updateNumLoading}
                    icon={<SyncOutlined />}
                    onClick={this.handleUpdateTitleNumClick}
                  >
                    刷新序号
                  </Button>
                )}
                {isEditTree && (
                  <Button
                    type="primary"
                    size="small"
                    loading={newTermLoading}
                    icon={<FileDoneOutlined />}
                    onClick={this.handleNewClick}
                  >
                    开始新一期
                  </Button>
                )}

                {/* <Button
                  type="primary"
                  size="small"
                  icon={<FileDoneOutlined />}
                  onClick={this.handleSendEmailClick}
                >
                  催办
                </Button> */}
                {isEditTree && (
                  <Button
                    type="primary"
                    size="small"
                    loading={genAllLoading}
                    icon={<FileDoneOutlined />}
                    onClick={this.handleGenAllClick}
                  >
                    生成全部
                  </Button>
                )}
                {/* <Button
                  type="primary"
                  size="small"
                  loading={previewLoading}
                  icon={<FolderViewOutlined />}
                  onClick={this.handlePreviewClick}
                >
                  预览
                </Button> */}
                <Button
                  type="primary"
                  size="small"
                  loading={exportLoading}
                  icon={<ExportOutlined />}
                  onClick={this.handleExportClick}
                >
                  导出
                </Button>
              </Space>
            }
          >
            {/* <QueueAnim type="bottom"> 性能差 */}
            {treeLoading ? (
              <Skeleton active />
            ) : (
              Array.isArray(dataList) &&
              dataList.map((item) => {
                return (
                  <RichText
                    key={item.id + guid}
                    data={{ ...item, ...this.params, isop: isEditTree }}
                    templateList={templateList}
                    onValueChange={this.handleDataChange}
                  />
                );
              })
            )}
            {/* </QueueAnim> */}
          </Card>
        </Col>
      </Row>
    );
  }
}

export default Edit;
