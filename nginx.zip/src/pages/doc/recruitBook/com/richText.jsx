import React, { Component } from 'react';
import {
  Button,
  Card,
  Empty,
  message,
  Popover,
  Select,
  Spin,
  Timeline,
  Tooltip,
  Tag,
  Space,
} from 'antd';
import { WangEditor } from '@cerdo/cerdo-design';
import {
  MoreOutlined,
  FileDoneOutlined,
  BorderOutlined,
  CheckSquareOutlined,
  KeyOutlined,
  LoadingOutlined,
} from '@ant-design/icons';
import {
  genRecruitContent,
  listRecruitApprove,
  saveRecruitContent,
  saveRecruitExt,
  submitRecruitContent,
} from '@/common/axios';
import { fn } from '@cerdo/cerdo-utils';
import { debounce, isEqual } from 'lodash';
import moment from 'moment';
import AuthModal from './authModal';

const statusArr = [
  { status: '0', text: '编辑中', sText: '', color: '#d9d9d9' },
  { status: '10', text: '已退回', sText: '退回', color: '#ff4d4f' },
  { status: '20', text: '审核中', sText: '提交', color: '#1890ff' },
  { status: '99', text: '已通过', sText: '通过', color: '#389e0d' },
];
const getIsReadOnly = (data) => {
  const { status = '0', isedit } = data;
  // 审批通过 || !((退回||编辑中)&&有编辑权限) || !(审批中&&有审批权限)
  if (Number(status) === 99) {
    return true;
  }

  if (Number(status) === 0 || Number(status) === 10) {
    return !(Number(isedit) === 1);
  }

  if (Number(status) === 20) {
    return true;
  }
  return false;
};

class RichText extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        ...props.data,
        isReadOnly: getIsReadOnly(props.data),
        isHtml: /<[^>]+>/g.test(props.data.content),
        oldContent: props.data.content,
      },

      trackLoading: true,
      trackData: [],

      authModalVisible: false,

      genLoading: false, // 内容生成中
    };
    this.getTrackDataDebounce = debounce(this.getTrackData, 1000);
  }

  componentDidMount() {
    if (this.editor) {
      this.editor.editor.config.pasteTextHandle = this.handlePasteText;
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return !isEqual(nextProps, this.props) || !isEqual(nextState, this.state);
  }

  initData = (data) => {
    /** data 字段说明
     * iskeepstatus:是否保留审批状态
     * isedit:是否有编辑权限
     * isapprove:是否有审批权限
     * status:当前状态
     *  |--0   初始化状态 【编辑中】
     *  |--10  审批退回  【已退回】
     *  |--20  提交     【审核中】
     *  |--99  审批通过 【已通过】
     */
    const { content } = data;
    const isReadOnly = getIsReadOnly(data);
    this.setState({
      data: {
        ...data,
        isHtml: /<[^>]+>/g.test(content),
        oldContent: content, // 记录初始值，取消按钮用
        isReadOnly: isReadOnly,
      },
    });
  };

  handlePasteText = (pasteStr) => {
    let contentList = [];
    let pList = (pasteStr || '')
      .replace(/[\n\r]/g, '')
      .replace(/(<\/?(div|span|font|strong|a).*?>)/g, '')
      .split('</p>');
    pList.forEach((pStr) => {
      if (pStr) {
        let content = (pStr || '').replace(/^(<p.*?>)/g, '');
        if (content.includes('<br/>')) {
          let brList = content.split('<br/>');
          contentList.push(
            brList
              .map((txt) => {
                return /[<\/?[tr|td|table|tbody|th|thead].*?>]/.test(txt)
                  ? `${content}<br/>`
                  : `<p style="text-indent: 21pt;">${txt.replace(
                      /^([/\s|&nbsp;])*|([/\s|&nbsp;])*$/g,
                      '',
                    )}</p>`;
              })
              .join(''),
          );
        } else {
          contentList.push(
            /[<\/?[tr|td|table|tbody|th|thead].*?>]/.test(content)
              ? `<p>${content}</p>`
              : `<p style="text-indent: 21pt;">${content.replace(
                  /^([/\s|&nbsp;])*|([/\s|&nbsp;])*$/g,
                  '',
                )}</p>`,
          );
        }
      }
    });
    return contentList.join('');
  };

  // #region 内容保存、审批按钮

  // 提交审核
  handleSubmitClick = (status) => {
    const {
      data: { id, templateid, content },
    } = this.state;
    submitRecruitContent({
      id,
      templateid,
      content,
      status: status,
    }).then((result) => {
      if (fn.checkResponse(result)) {
        message.success('提交成功', 0.5, () => {
          this.initData({ ...this.state.data, ...result.data });
          this.props.onValueChange && this.props.onValueChange(id, 'status', status);
        });
      }
    });
  };

  // 保存内容
  handleSaveClick = () => {
    const {
      data: { id, templateid, content },
    } = this.state;
    saveRecruitContent({
      id,
      templateid,
      content,
    }).then((result) => {
      if (fn.checkResponse(result)) {
        message.success('保存成功');
      }
    });
  };

  // 点击取消
  handleCancelClick = () => {
    const {
      data: { oldContent },
    } = this.state;
    if (!oldContent) {
      message.warning('原始值为空，无法取消');
      return;
    }
    this.handleDataChange('content', oldContent);
  };

  handleIsKeepStatusClick = () => {
    const {
      data: { iskeepstatus, id },
    } = this.state;
    const newIskeepStatus = Number(iskeepstatus) === 1 ? '0' : '1';
    saveRecruitExt({
      nodeid: id,
      iskeepstatus: newIskeepStatus,
    }).then((result) => {
      if (fn.checkResponse(result)) {
        message.success(`${Number(iskeepstatus) === 1 ? '取消' : '设置'}成功`, 0.5, () => {
          this.handleDataChange('iskeepstatus', newIskeepStatus);
        });
      }
    });
  };

  handleHeaderClick = () => {
    const {
      data: { isnoheader, id },
    } = this.state;
    const newIsNoHeader = Number(isnoheader) === 1 ? '0' : '1';
    saveRecruitExt({
      nodeid: id,
      isnoheader: newIsNoHeader,
    }).then((result) => {
      if (fn.checkResponse(result)) {
        message.success(`${Number(newIsNoHeader) === 1 ? '取消标题' : '恢复标题'}成功`, 0.5, () => {
          this.handleDataChange('isnoheader', newIsNoHeader);
        });
      }
    });
  };

  // #endregion

  handleDataChange = (key, value) => {
    // console.log(key, value);
    const equal = `${value}\n` === this.state.data.content;
    if (key === 'content' && equal) {
      return;
    }

    this.setState({
      data: {
        ...this.state.data,
        [key]: value,
      },
    });
    if (['templateid', 'content'].includes(key)) {
      const {
        data: { id },
      } = this.state;
      this.props.onValueChange && this.props.onValueChange(id, key, value);
    }
  };

  handleGenClick = () => {
    const {
      data: { fundid, templateid, fundcode },
    } = this.state;
    if (!templateid || this.state.genLoading) {
      return;
    }
    this.setState({ genLoading: true });
    genRecruitContent({
      fundid,
      fundcode,
      templateid,
    }).then((result) => {
      this.setState({ genLoading: false });
      if (fn.checkResponse(result) && result.data) {
        this.handleDataChange('isHtml', /<[^>]+>/g.test(result.data));
        this.handleDataChange('content', result.data);
        message.success('生成成功');
      }
    });
  };

  renderContent = () => {
    const {
      data: { id, isHtml, content, isReadOnly },
    } = this.state;
    return isHtml ? (
      <WangEditor
        ref={(ref) => {
          this.editor = ref;
        }}
        disabled={isReadOnly}
        id={`richtext_${id}`}
        value={content}
        height={298}
        zIndex={101}
        onChange={(value) => this.handleDataChange('content', value)}
      />
    ) : (
      <WangEditor
        ref={(ref) => {
          this.editor = ref;
        }}
        disabled={isReadOnly}
        id={`richtext_${id}`}
        value={content}
        height={298}
        zIndex={101}
        onChange={(value) => this.handleDataChange('content', value)}
      />
      // <TextArea
      //   disabled={isReadOnly}
      //   placeholder="请输入正文"
      //   rows={15}
      //   value={content}
      //   onChange={({ target: { value } }) => this.handleDataChange('content', value)}
      // />
    );
  };

  getTrackData = () => {
    const {
      data: { id },
    } = this.state;
    this.setState({ trackLoading: true });
    listRecruitApprove({ id }).then((result) => {
      if (fn.checkResponse(result)) {
        this.setState({ trackData: result.data });
      }
      this.setState({ trackLoading: false });
    });
  };

  renderTrack = () => {
    const { trackLoading, trackData } = this.state;
    return (
      <Spin spinning={trackLoading}>
        {!trackLoading &&
          (trackData.length > 0 ? (
            <Timeline>
              {trackData.map((item) => {
                const statusObj = statusArr.find((a) => a.status === item.status) || {};
                return (
                  <Timeline.Item key={item.id} color={statusObj.color}>
                    [{statusObj.sText}] {item.createuser} <br />
                    <small>
                      {item.createtime && moment(item.createtime).format('YYYY-MM-DD HH:mm:ss')}
                    </small>
                  </Timeline.Item>
                );
              })}
            </Timeline>
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          ))}
      </Spin>
    );
  };

  renderHeader = () => {
    const {
      data: { isnoheader, value, isop },
    } = this.state;
    return isop ? (
      <Tooltip title="显示/隐藏标题">
        <strong
          onClick={this.handleHeaderClick}
          className={Number(isnoheader) === 1 ? 'noheader' : ''}
        >
          {value}
        </strong>
      </Tooltip>
    ) : (
      <strong>{value}</strong>
    );
  };

  renderTitle = () => {
    const {
      data: { status, id, value },
    } = this.state;
    const statusObj = statusArr.find((a) => a.status === (status || '0'));
    return (
      <Space>
        <Popover
          title="日志跟踪"
          getPopupContainer={() => document.getElementById(`content_${id}`)}
          content={this.renderTrack()}
          placement="bottomLeft"
        >
          {statusObj && (
            <Tag
              onMouseEnter={this.getTrackDataDebounce}
              icon={<MoreOutlined />}
              color={statusObj.color}
            >
              {statusObj.text}
            </Tag>
          )}
        </Popover>
        {(value || '').includes('投资组合报告') && (
          <small className="red">提示：请注意检查内容中索引是否正确</small>
        )}
      </Space>
    );
  };

  renderExtra = () => {
    const { templateList } = this.props;
    const { data, genLoading } = this.state;

    return (
      <Space>
        <div className="content-gen-btn">
          <Select
            disabled={data.isReadOnly}
            style={{ width: 200 }}
            showArrow={false}
            showSearch
            size="small"
            placeholder="请选择模板"
            optionFilterProp="name"
            defaultValue={data.templateid || ''}
            onChange={(value) => this.handleDataChange('templateid', value)}
            dropdownStyle={{ zIndex: 10001 }}
          >
            <Select.Option key="" value="">
              无模板
            </Select.Option>
            {(templateList || []).map((item) => (
              <Select.Option key={item.templateid} value={item.templateid} name={item.label}>
                {item.label}
              </Select.Option>
            ))}
          </Select>
          <Tooltip title="生成内容">
            <Button
              disabled={data.isReadOnly}
              size="small"
              type="primary"
              onClick={this.handleGenClick}
              icon={
                genLoading ? (
                  <LoadingOutlined style={{ fontSize: 18 }} />
                ) : (
                  <FileDoneOutlined style={{ fontSize: 18 }} />
                )
              }
            />
          </Tooltip>
        </div>
        {data.isop && (
          <Tooltip title="保留审核状态">
            <Button
              size="small"
              type="primary"
              onClick={() => this.handleIsKeepStatusClick(!data.iskeepstatus)}
              icon={
                Number(data.iskeepstatus) === 1 ? (
                  <CheckSquareOutlined style={{ fontSize: 18 }} />
                ) : (
                  <BorderOutlined style={{ fontSize: 18 }} />
                )
              }
            />
          </Tooltip>
        )}
        {/* <Tooltip title='文本框/富文本框切换'>
          <Button
            disabled={data.isReadOnly}
            size="small"
            type="primary"
            onClick={() => this.handleDataChange('isHtml', !data.isHtml)}
            icon={
              data.isHtml
                ? <FileTextOutlined style={{ fontSize: 18 }} />
                : <FileImageOutlined style={{ fontSize: 18 }} />
            }
          />
        </Tooltip> */}
        {/* <Tooltip title='内容格式美化'>
          <Button
            disabled={data.isReadOnly}
            size="small"
            type="primary"
            icon={<MonitorOutlined style={{ fontSize: 18 }} />}
          />
        </Tooltip> */}
        {data.isop && (
          <Tooltip title="设置审核权限">
            <Button
              size="small"
              type="primary"
              onClick={() => this.setState({ authModalVisible: true })}
              icon={<KeyOutlined />}
            />
          </Tooltip>
        )}
      </Space>
    );
  };

  renderBtn = () => {
    const {
      data: { isedit, isapprove, status },
    } = this.state;
    // 有编辑权限 & 当前状态是初始化或退回状态
    if (Number(isedit) === 1 && (Number(status) === 0 || Number(status) === 10)) {
      return (
        <Space style={{ float: 'right', marginTop: 8 }}>
          <Button size="small" type="primary" danger onClick={() => this.handleSubmitClick('20')}>
            提交
          </Button>
          <Button size="small" type="primary" onClick={this.handleSaveClick}>
            保存
          </Button>
          <Button size="small" onClick={this.handleCancelClick}>
            取消
          </Button>
        </Space>
      );
    }

    // 有操作审批权限 & 当前状态是审核中
    if (Number(isapprove) === 1 && Number(status) === 20) {
      return (
        <Space style={{ float: 'right', marginTop: 8 }}>
          <Button
            size="small"
            type="primary"
            style={{ background: '#389e0d', borderColor: '#389e0d' }}
            onClick={() => this.handleSubmitClick('99')}
          >
            同意
          </Button>
          <Button size="small" type="primary" danger onClick={() => this.handleSubmitClick('10')}>
            退回
          </Button>
        </Space>
      );
    }

    // 有操作权限 & 当前状态是审核通过
    if (Number(isapprove) === 1 && Number(status) === 99) {
      return (
        <Space style={{ float: 'right', marginTop: 8 }}>
          <Button size="small" type="primary" danger onClick={() => this.handleSubmitClick('10')}>
            退回
          </Button>
        </Space>
      );
    }

    return null;
  };

  render() {
    const { authModalVisible } = this.state;
    const { data } = this.props;

    return (
      <div className="content" id={`content_${data.id}`}>
        {this.renderHeader()}
        <Card title={this.renderTitle()} extra={this.renderExtra()} bordered={false}>
          {this.renderContent()}
          {this.renderBtn()}
        </Card>
        {authModalVisible && (
          <AuthModal
            id={data.id}
            visible={authModalVisible}
            onCancel={() => this.setState({ authModalVisible: false })}
            onOk={() => this.setState({ authModalVisible: false })}
          />
        )}
      </div>
    );
  }
}

export default RichText;
