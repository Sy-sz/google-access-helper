import React, { Component } from 'react';
import { message, Radio, Spin, Transfer } from 'antd';
import { DragModal } from '@cerdo/cerdo-design';
import RecruitState from '../edit/index.state';
import { listRecruitPermission, saveRecruitPermission } from '@/common/axios';
import { fn } from '@cerdo/cerdo-utils/lib';
import { getQueryString } from '@cerdo/cerdo-utils/lib/url';

class AuthModal extends Component {
    constructor(props) {
        super();
        this.state = {
            data: [],
            loading: true,
            targetKeys: [],

            authType: 0,

        }

        this.data = {
            editKeys: [],
            approveKeys: [],
            authData: [],
        };
    }

    componentDidMount() {
        this.listRecruitPermissionData();
    }

    listRecruitPermissionData = () => {
        this.setState({ loading: true })
        listRecruitPermission({ id: this.props.id }).then(result => {
            if (fn.checkResponse(result)) {
                this.data.authData = result.data;
                const targetKeys = this.data.authData.filter(a => Number(a.type) === 0).map(a => a.objid);
                this.setState({ targetKeys });
            }
            this.setState({ loading: false })
        })
    }

    saveRecruitPermissionData = (data) => {
        saveRecruitPermission(data).then(result => {
            if (fn.checkResponse(result)) {
                message.success('保存成功', .5, () => {
                    this.props.onOk();
                })
            }
        })
    }


    getOpData = (keys, authType) => {
        const delData = this.data.authData.filter(a => !keys.includes(a.objid) && Number(a.type) === Number(authType));
        const addData = RecruitState.userData
            .filter(a => keys.includes(a.id))
            .filter(a => !this.data.authData.find(b => b.objid === a.id && Number(b.type) === Number(authType)));
        return [
            ...delData.map(a => ({ ...a, optype: 'delete' })),
            ...addData.map(a => ({
                nodeid: this.props.id,
                type: authType,
                objtype: '0',
                objid: a.id,
                fundcode: getQueryString('fundcode'),
                optype: 'add',
            }))
        ];
    }

    handleSubmit = () => {
        const { targetKeys, authType } = this.state;

        // 保存前先赋值，以防没有切换状态下为赋值
        this.data[Number(authType) === 1 ? 'approveKeys' : 'editKeys'] = targetKeys;

        this.saveRecruitPermissionData([
            ... this.getOpData(this.data.editKeys, '0'),
            ... this.getOpData(this.data.approveKeys, '1'),
        ])
    }

    handleAuthTypeChange = ({ target: { value } }) => {
        // 切换前先保存 当前的操作数据
        this.data[Number(this.state.authType) === 1 ? 'approveKeys' : 'editKeys'] = this.state.targetKeys;

        const targetKeys = [
            ...this.data[Number(this.state.authType) === 1 ? 'editKeys' : 'approveKeys'],
            ...this.data.authData
                .filter(a => Number(a.type) === Number(value))
                .map(a => a.objid)
        ];

        this.setState({ authType: value, targetKeys });
    }

    handleChange = (targetKeys) => {
        this.setState({ targetKeys });
    }

    render() {
        const { loading, targetKeys } = this.state;
        const { visible, onCancel } = this.props;

        return (
            <DragModal
                visible={visible}
                onCancel={onCancel}
                okText="保存"
                onOk={this.handleSubmit}
                title="权限设置"
                destroyOnClose
                width={600}
                bodyStyle={{ padding: 0 }}
                maskClosable={false}
            >
                <Spin spinning={loading}>
                    <Transfer
                        rowKey={record => record.id}
                        dataSource={RecruitState.userData}
                        titles={[
                            '全部人员',
                            <Radio.Group
                                key="auth"
                                size='small'
                                defaultValue="0"
                                buttonStyle="solid"
                                onChange={this.handleAuthTypeChange}
                            >
                                <Radio.Button key={0} value="0">编辑权限</Radio.Button>
                                <Radio.Button key={1} value="1">审核权限</Radio.Button>
                            </Radio.Group>
                        ]}
                        showSearch
                        targetKeys={targetKeys}
                        onChange={this.handleChange}
                        pagination
                        render={item => `${item.name}[${item.account}]`}
                        listStyle={(obj) => {
                            if (obj.direction === 'left') {
                                return {
                                    height: 450,
                                    width: 300,
                                    borderTop: 'none',
                                    borderBottom: 'none',
                                    borderLeft: 'none',
                                    borderRightWidth: 1,
                                }
                            }
                            return {
                                height: 450,
                                width: 300,
                                borderTop: 'none',
                                borderBottom: 'none',
                                borderRight: 'none',
                                borderLeftWidth: 1,
                            }

                        }}
                    />
                </Spin>
            </DragModal>
        );
    }

}

export default AuthModal;
