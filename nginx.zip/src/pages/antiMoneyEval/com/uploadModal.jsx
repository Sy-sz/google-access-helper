import { Button, Card, message, Space } from 'antd';
import { commonApi } from 'common/axios';
import { UploadFile, DragModal, LocalTable } from '@cerdo/cerdo-design';
import { uploadFileApi, downloadFileApi } from 'common/axios/config';
import React, { Component } from 'react';
import { convert, fn } from '@cerdo/cerdo-utils';
import { cloneDeep } from 'lodash';
import { analyseAntiMoneyEval } from '../../../common/axios';

class UploadModal extends Component {
  constructor() {
    super();
    this.state = {
      tableData: [],
      selectedRowKeys: [],
    };
    this.data = {};
  }

  shouldComponentUpdate(nextProps) {
    if (nextProps.visible && this.props.visible !== nextProps.visible) {
      this.setState({ tableData: [] });
    }
    return true;
  }

  onCancel = () => {
    this.props.onCancel && this.props.onCancel();
  };

  handleSubmit = () => {
    const { data } = this.props;
    const { tableData } = this.state;
    if (tableData.length === 0) {
      message.warning('请先上传文件');
      return;
    }

    const newTableData = cloneDeep(tableData);

    this.setState({ submitLoading: true });
    analyseAntiMoneyEval({
      filelist: newTableData,
      filetype: data.filetype,
    }).then((result) => {
      this.setState({ submitLoading: false });
      if (fn.checkResponse(result)) {
        message.success('上传解析成功', 0.5, () => {
          this.props.onOk && this.props.onOk();
        });
      }
    });
  };

  handleDeleteClick = () => {
    const { selectedRowKeys, tableData } = this.state;
    if (selectedRowKeys.length === 0) {
      message.warning('未选中任何项');
      return;
    }
    const newTableData = tableData.filter((a) => !selectedRowKeys.includes(a.fileid));
    this.setState(
      {
        tableData: newTableData,
        selectedRowKeys: [],
      },
      () => {
        this.table.dataSourceChange({ data: newTableData });
      },
    );
  };

  handleUploadChange = (file, fileList) => {
    let { tableData } = this.state;

    file.index = tableData.length + 1;
    const newtableData = [...tableData, file];

    this.setState(
      {
        tableData: newtableData,
      },
      () => {
        this.table.dataSourceChange({ data: newtableData });
      },
    );
  };

  handleBeforeUpload = (file) => {
    // const isExcel = /\.xls(x)?/.test(file.name);
    const isExcel = /产品业务洗钱风险评估表_(.*)?\(\d{4}-\d{2}-\d{2}\)\.xls(x)?/.test(file.name);
    if (!isExcel) {
      message.error(`【${file.name}】文件命名或格式错误，已剔除`);
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('文件大小不可超过2M');
    }
    return isExcel && isLt2M;
  };

  getColumns = () => {
    return [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        align: 'center',
        sorter: true,
        render: (text, record, index) => {
          return record.index;
        },
      },
      { title: '文件名', dataIndex: 'filename', key: 'filename', sorter: true },
      {
        title: '文件大小',
        dataIndex: 'filesize',
        key: 'filesize',
        width: 100,
        sorter: true,
        render: (text) => (text ? convert.toFileSize(text) : '0KB'),
      },
      {
        title: '操作',
        dataIndex: 'filename',
        key: 'filename',
        width: 100,
        render: (text, record) => {
          return (
            <Button
              type="link"
              onClick={() => {
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi);
              }}
            >
              下载
            </Button>
          );
        },
      },
    ];
  };

  render() {
    const { visible, title } = this.props;
    const { selectedRowKeys, submitLoading } = this.state;
    const rowSelection = {
      columnWidth: 40,
      selectedRowKeys: selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        this.setState({
          selectedRowKeys: selectedRowKeys,
        });
      },
    };

    return (
      <DragModal
        title={title}
        visible={visible}
        width="60%"
        maskClosable={false}
        destroyOnClose
        closable={false}
        bodyStyle={{ padding: 0 }}
        footer={[
          <Button key="save" type="primary" onClick={this.handleSubmit} loading={submitLoading}>
            {submitLoading ? '提交中...' : '提交'}
          </Button>,
          <Button key="cancel" onClick={this.onCancel}>
            取消
          </Button>,
        ]}
      >
        <Card
          title={
            <small className="red">
              注意: 文件命名格式必须满足【产品业务洗钱风险评估表_产品名称(评测日期).xlsx】
            </small>
          }
          bordered={false}
          extra={
            <Space>
              <Button
                type="primary"
                danger
                onClick={this.handleDeleteClick}
                disabled={selectedRowKeys.length === 0}
              >
                批量删除
              </Button>
              <UploadFile
                uploadUrl={uploadFileApi}
                downloadUrl={downloadFileApi}
                accept=".xls,.xlsx"
                multiple
                showUploadList={false}
                onChange={this.handleUploadChange}
                beforeUpload={this.handleBeforeUpload}
              >
                <Button type="primary">批量上传</Button>
              </UploadFile>
            </Space>
          }
        >
          <LocalTable
            size="small"
            showTools={false}
            rowKey="fileid"
            rowSelection={rowSelection}
            ref={(ref) => {
              this.table = ref;
            }}
            toolStyleTop={0}
            columns={this.getColumns()}
            scroll={{ y: `calc(100vh - 380px)` }}
          />
        </Card>
      </DragModal>
    );
  }
}

export default UploadModal;
