import { Col, DatePicker, Form, message, Row } from 'antd';
import React, { Component } from 'react';
import { CONST, fn } from '@cerdo/cerdo-utils';
import { DragModal, FetchSelect } from '@cerdo/cerdo-design';
import { genAntiMoneyEval, getAllFunds } from '../../../common/axios';

const FormItem = Form.Item;

class GenModal extends Component {
  constructor() {
    super();
    this.state = {
      genLoading: false,
    };
  }

  handleSubmit = () => {
    this.form.validateFields().then((values) => {
      this.setState({ genLoading: true });
      genAntiMoneyEval({
        fundids: (values.fundid || []).join(),
        evaluateperiod: values.evaluateperiod.format('YYYY-MM-DD'),
      }).then((result) => {
        if (fn.checkResponse(result)) {
          message.success('生成成功', 0.5, () => {
            this.props.onOk();
          });
        }
        this.setState({ genLoading: false });
      });
    });
  };

  render() {
    const { genLoading } = this.state;
    const { visible, title, onCancel } = this.props;
    return (
      <DragModal
        title={title}
        visible={visible}
        width={600}
        maskClosable={false}
        destroyOnClose
        closable={false}
        onCancel={onCancel}
        onOk={this.handleSubmit}
        confirmLoading={genLoading}
      >
        <Form
          scrollToFirstError
          {...CONST.formModalLayout}
          ref={(ref) => {
            this.form = ref;
          }}
        >
          <Row>
            <Col span={24}>
              {/* <UploadFile
                uploadUrl={uploadFileApi}
                downloadUrl={downloadFileApi}
                accept=".xls,.xlsx"
                onChange={(file, fileList) => { }}
              >上传文件</UploadFile> */}
            </Col>
            <Col span={24}>
              <FormItem
                label="可选基金"
                name="fundid"
                hasFeedback
                rules={[{ required: true, message: '请选择基金' }]}
              >
                <FetchSelect
                  getData={getAllFunds}
                  style={{ width: '100%' }}
                  dropdownMatchSelectWidth={false}
                  placeholder="请输入产品代码或名称搜索"
                  mode="multiple"
                >
                  {(item) => (
                    <FetchSelect.Option
                      key={item.fundode}
                      value={item.fundid}
                    >{`${item.fundshortname}${item.fundcode ? `[${item.fundcode}]` : ''}`}</FetchSelect.Option>
                  )}
                </FetchSelect>
              </FormItem>
            </Col>
            <Col span={24}>
              <FormItem
                label="评测日期"
                name="evaluateperiod"
                hasFeedback
                rules={[{ required: true, message: `请选择评测日期` }]}
              >
                <DatePicker style={{ width: '100%' }} plsaceholder="请选择评测日期" />
              </FormItem>
            </Col>
          </Row>
        </Form>
      </DragModal>
    );
  }
}

export default GenModal;
