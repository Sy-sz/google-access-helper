import { DictSelect, FetchTable, RangeDate } from '@cerdo/cerdo-design';
import { ListCard } from '@/common/component';
import { CaretUpOutlined } from '@ant-design/icons';
import { fn } from '@cerdo/cerdo-utils';
import { Col, Input, Form, Button, Modal, Table, Radio, message, Space } from 'antd';
import React, { Component, forwardRef } from 'react';
import { commonApi, downloadAntiMoneyEval, listAntiMoneyEval } from '@/common/axios';
import { downloadFileApi } from '@/common/axios/config';
import GenModal from './com/genModal';
import UploadModal from './com/uploadModal';
import moment from 'moment';
import SearchCard from '@/common/component/SearchCard';

const FormItem = Form.Item;

const STATUS_TYPE = {
  0: <span className="red">未评测</span>,
  1: <span className="orange">已评测,待复评</span>,
  2: <span className="green">已复评</span>,
};

const FILE_TYPE = {
  0: '初始化',
  1: '已评测',
  2: '已复评',
};

class AntiMoneyEval extends Component {
  constructor(props) {
    super(props);

    this.state = {
      genVisible: false,
      analyseVisible: false,
      downloadLoading: false,

      selectedRowKeys: [],
    };
    this.table = null;
    this.fundtypeRef = React.createRef();
    this.formRef = React.createRef();
  }

  getList = () => {
    return new Promise((resolve, reject) => {
      this.table.getFormParams(this.formRef.current, 'YYYY-MM-DD').then((values) => {
        console.log('values', values);
        listAntiMoneyEval({
          ...values,
        })
          .then((result) => {
            if (fn.checkResponse(result)) {
              resolve(result);
            }
            reject(null);
          })
          .finally(() => {});
      });
    });
  };

  handleSearchClick = () => {
    this.table.reloadAndReset();
  };

  handleReAnalyseClick = () => {
    this.setState({
      analyseTitle: '上传复评结果',
      analyseData: { filetype: '2' },
      analyseVisible: true,
    });
  };

  handleAnalyseClick = () => {
    this.setState({
      analyseTitle: '上传评测结果',
      analyseData: { filetype: '1' },
      analyseVisible: true,
    });
  };

  handleGenClick = () => {
    this.setState({ genVisible: true });
  };

  handleDownloadClick = () => {
    const { selectedRowKeys } = this.state;
    if (selectedRowKeys.length === 0) {
      message.warning('未选择任何项');
      return;
    }

    const FileTypeSelect = forwardRef((props, ref) => {
      const [form] = Form.useForm();
      const layout = {
        labelCol: { span: 6 },
        wrapperCol: { span: 16 },
      };
      return (
        <Form {...layout} style={{ marginLeft: -30, marginTop: 20 }} ref={ref} form={form}>
          <Form.Item
            name="filetype"
            rules={[{ required: true, message: '请选择文件状态' }]}
            initialValue="0"
            label="文件状态"
          >
            <Radio.Group>
              {Object.keys(FILE_TYPE).map((key) => (
                <Radio key={key} value={key}>
                  {FILE_TYPE[key]}
                </Radio>
              ))}
            </Radio.Group>
          </Form.Item>
        </Form>
      );
    });

    Modal.confirm({
      title: '请选择下载文件类型',
      content: <FileTypeSelect ref={this.fundtypeRef} />,
      width: 500,
      onOk: () => {
        return new Promise((resolve, reject) => {
          this.fundtypeRef.current
            .validateFields()
            .then((values) => {
              this.setState({ downloadLoading: true });
              downloadAntiMoneyEval({
                ids: selectedRowKeys.join(),
                filetype: values.filetype,
                filename: `反洗钱评测表_[${FILE_TYPE[`${values.filetype}`]}文件]_${moment().format(
                  'YYYY-MM-DD',
                )}.zip`,
              }).then((result) => {
                this.setState({ downloadLoading: false });
              });
              resolve();
            })
            .catch((err) => {
              reject(err);
            });
        });
      },
    });
  };

  expandedRowRender = (record) => {
    const columns = [
      {
        title: '文件状态',
        dataIndex: 'filetype',
        key: 'filetype',
        render: (text) => FILE_TYPE[text],
      },
      { title: '文件', dataIndex: 'filename', key: 'filename' },
      { title: '操作人', dataIndex: 'createuser', key: 'createuser' },
      { title: '操作时间', dataIndex: 'createtime', key: 'createtime' },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        render: (text, record) => {
          return (
            <Button
              type="link"
              onClick={() => {
                commonApi.downloadFile(record.fileid, record.filename, downloadFileApi);
              }}
            >
              下载
            </Button>
          );
        },
      },
    ];

    return (
      <Table
        columns={columns}
        style={{ width: 800 }}
        dataSource={record.antiMoneyEvalFileList || []}
        pagination={false}
        rowKey="fileid"
      />
    );
  };

  getColumns = () => {
    return [
      {
        title: '产品',
        dataIndex: 'fund',
        key: 'fund',
        width: 300,
        render: (text, record) =>
          `${record.fundname}${record.fundcode ? `[${record.fundcode}]` : ''}`,
      },
      { title: '评测日期', dataIndex: 'evaluateperiod', key: 'evaluateperiod', width: 100 },
      { title: '总得分', dataIndex: 'score', key: 'score', width: 100 },
      { title: '等级', dataIndex: 'risklevel', key: 'risklevel', width: 100 },
      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: (text) => STATUS_TYPE[text],
        width: 100,
      },
    ];
  };

  render() {
    const {
      selectedRowKeys,
      genVisible,
      analyseVisible,
      analyseData,
      analyseTitle,
      downloadLoading,
    } = this.state;
    const rowSelection = {
      columnWidth: 50,
      selectedRowKeys: selectedRowKeys,
      onChange: (selectedRowKeys) => {
        this.setState({ selectedRowKeys: selectedRowKeys });
      },
    };

    return (
      <div>
        <SearchCard
          expand
          bordered={false}
          ref={this.formRef}
          onSearch={this.handleSearchClick}
          onExpand={(expand) => this.table.setScrollY(expand ? 360 : 320)}
        >
          <Col span={8}>
            <FormItem label="关键词" name="keyword">
              <Input placeholder="请输入产品代码、名称搜索" />
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem label="评测日期" name="daterange">
              <RangeDate style={{ width: '100%' }} />
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem label="状态" name="status">
              <DictSelect showSearch={false} style={{ width: '100%' }} placeholder="请选择状态">
                {Object.keys(STATUS_TYPE).map((key) => (
                  <DictSelect.Option key={key} value={key}>
                    {STATUS_TYPE[key].props.children}
                  </DictSelect.Option>
                ))}
              </DictSelect>
            </FormItem>
          </Col>
        </SearchCard>
        <ListCard
          title="反洗钱评测列表"
          bordered={false}
          extra={
            <Space>
              <Button key="reanalyse" type="primary" onClick={this.handleReAnalyseClick}>
                上传复评结果
              </Button>
              <Button key="analyse" type="primary" onClick={this.handleAnalyseClick}>
                上传评测结果
              </Button>
              <Button
                key="download"
                type="primary"
                loading={downloadLoading}
                onClick={this.handleDownloadClick}
              >
                下载评测表
              </Button>
              <Button key="gen" type="primary" onClick={this.handleGenClick}>
                生成评测表
              </Button>
            </Space>
          }
        >
          <FetchTable
            size="small"
            showTools={false}
            rowKey="id"
            ref={(ref) => {
              this.table = ref;
            }}
            rowSelection={rowSelection}
            getList={this.getList}
            columns={this.getColumns()}
            expandable={{
              columnWidth: 30,
              expandIcon: (props) => (
                <CaretUpOutlined
                  className={`${props.expanded ? 'up' : 'down'}`}
                  onClick={(e) => props.onExpand(props.record, e)}
                />
              ),
              expandedRowRender: this.expandedRowRender,
              rowExpandable: (record) => (record.antiMoneyEvalFileList || []).length > 0,
            }}
            autoHeight={{ blankHeight: 200 }}
            scroll={{ y: `calc(100vh - 320px)` }}
          />
        </ListCard>

        <GenModal
          title="生成评测表"
          visible={genVisible}
          onOk={() => {
            this.setState({ genVisible: false }, () => {
              this.table.reload();
            });
          }}
          onCancel={() => this.setState({ genVisible: false })}
        />

        <UploadModal
          visible={analyseVisible}
          title={analyseTitle}
          data={analyseData}
          onOk={() => this.setState({ analyseVisible: false }, () => this.table.reload())}
          onCancel={() => this.setState({ analyseVisible: false })}
        />
      </div>
    );
  }
}

export default AntiMoneyEval;
