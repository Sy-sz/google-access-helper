import React, { Component } from 'react';
import {
  Card,
  Row,
  Col,
  Form,
  Input,
  Select,
  InputNumber,
  TimePicker,
  Button,
  Tag,
  Divider,
  DatePicker,
  Modal,
} from 'antd';
import {
  saveEvent,
  listEventRule,
  detaileEvent,
  listEventBaseDate,
  listEventFundSetting,
  listFundShare,
  listTemplateMg,
} from 'common/axios';
import moment from 'moment';
import { CONST, routeUtils, url } from '@cerdo/cerdo-utils';
import { DictSelect, FetchSelect, SearchSelect, UserDeptSelect } from '@cerdo/cerdo-design';
import QueueAnim from 'rc-queue-anim';

const FormItem = Form.Item;
const Option = Select.Option;

class ManageEdit extends Component {
  constructor(props) {
    super(props);
    this.state = {
      baseDate: null,
      submitLoading: false,
      currentRuleKey: null,
      currentRuleList: [],

      userDeptVisible: false,
      selectUsersKey: [],
      selectUsers: [],
      selectDeptsKey: [],
      selectDepts: [],
      selectPositionsKey: [],
      selectPositions: [],
      selectRolesKey: [],
      selectRoles: [],
    };
    this.params = {};
  }

  componentDidMount() {
    this.getUrlData();
  }

  getUrlData = () => {
    this.params = url.getAllQueryString();
    if (this.params.id) {
      this.initData(this.params.id);
    }
  };

  initData = (id) => {
    detaileEvent({ eventid: id }).then((res) => {
      if (res) {
        this.data = res.data;
        this.form &&
          this.form.setFieldsValue({
            eventname: this.data.eventname,
            eventtype: this.data.eventtype,
            importanceno: `${this.data.importanceno}`,
            rulecode: this.data.rulecode,

            fundkeyword: this.data.fundkeyword,
            basename: this.data.basename,
            funds:
              Array.isArray(this.data.funds) &&
              this.data.funds.map((a) => `${a.fundname}[${a.fundcode}]`),
            eventdesc: this.data.eventdesc,

            cycletype: `${this.data.cycletype}`,
            cyclevalue: this.data.cyclevalue,
            starttime: moment(this.data.starttime, 'HH:mm:ss'),
            endtime: moment(this.data.endtime, 'HH:mm:ss'),
            holidaydeal: `${this.data.holidaydeal}`,

            templateid: this.data.templateid,
            messagetype: this.data.messagetype ? this.data.messagetype.split(',') : undefined,
          });

        const ruleKey = [];
        const ruleList = [];
        this.data.ruleparam &&
          this.data.ruleparam.split(',').forEach((a) => {
            const arr = a.split(':');
            ruleKey.push(arr[0]);
            ruleList.push({ parameter: arr[0], value: arr[1] });
          });

        const selectUsersKey = [];
        const selectUsers = [];
        const selectDeptsKey = [];
        const selectDepts = [];
        const selectPositionsKey = [];
        const selectPositions = [];
        const selectRolesKey = [];
        const selectRoles = [];
        this.data.receiverlist &&
          this.data.receiverlist.forEach((item) => {
            switch (Number(item.objtype)) {
              case 1:
                selectUsersKey.push(item.id);
                selectUsers.push(item);
                break;
              case 2:
                selectDeptsKey.push(item.id);
                selectDepts.push(item);
                break;
              case 3:
                selectPositionsKey.push(item.id);
                selectPositions.push(item);
                break;
              case 4:
                selectRolesKey.push(item.id);
                selectRoles.push(item);
                break;
              default:
                break;
            }
          });

        this.setState({
          currentRuleKey: ruleKey.join(),
          currentRuleList: ruleList,

          selectUsersKey,
          selectUsers,
          selectDeptsKey,
          selectDepts,
          selectPositionsKey,
          selectPositions,
          selectRolesKey,
          selectRoles,
        });
      }
    });
  };

  handleRuleCodeClick = (value, option, data) => {
    const item = data.find((a) => a.rulecode === option.key);
    const currentRuleList = (item.rulekey || '')
      .split(',')
      .map((item) => ({ parameter: item, value: undefined }));
    this.setState({
      currentRuleKey: item.rulekey,
      currentRuleList,
    });
  };

  handleSubmit = () => {
    this.form.validateFields().then((values) => {
      console.log(values);
      const { currentRuleList, selectUsers, selectDepts, selectPositions, selectRoles } =
        this.state;
      const data = {
        ...this.data,
        ...values,
        eventid: this.params.id,
        ruleparam:
          currentRuleList &&
          currentRuleList
            .map((a) =>
              values[a.parameter]
                ? `${a.parameter}:${moment.isMoment(values[a.parameter]) || moment.isDate(values[a.parameter])
                  ? moment(values[a.parameter]).format('YYYYMMDD')
                  : values[a.parameter]
                }`
                : null,
            )
            .filter((a) => a)
            .join(),
        fundcode: values.funds && values.funds.map((a) => a.match(/(\d{6})/)[0]).join(),
        starttime: values.starttime ? moment(values.starttime).format('HH:mm:ss') : '',
        endtime: values.endtime ? moment(values.endtime).format('HH:mm:ss') : '',
        messagetype: values.messagetype.join(),
        receiverlist: [...selectUsers, ...selectDepts, ...selectPositions, ...selectRoles],
      };
      delete data.funds;
      delete data.baseData;
      delete data.startDate;
      delete data.endDate;
      delete data.vDate;
      delete data.n;

      const that = this;
      this.setState({ submitLoading: true });
      saveEvent(data).then((res) => {
        this.setState({ submitLoading: false });
        if (res) {
          Modal.confirm({
            title: '提交成功，是否跳转事件列表页？',
            onOk: () => {
              routeUtils.pushNew.call(that, '/app/pdt/calendar/manage');
            },
          });
        }
      });
    });
  };

  handleUserDeptSave = (
    selectUsersKey,
    selectUsers,
    selectDeptsKey,
    selectDepts,
    selectPositionsKey,
    selectPositions,
    selectRolesKey,
    selectRoles,
  ) => {
    this.setState({
      selectUsersKey,
      selectUsers,
      selectDeptsKey,
      selectDepts,
      selectPositionsKey,
      selectPositions,
      selectRolesKey,
      selectRoles,
      userDeptVisible: false,
    });
  };

  render() {
    const {
      submitLoading,
      currentRuleKey,
      currentRuleList,
      baseDate,

      userDeptVisible,
      selectUsersKey,
      selectUsers,
      selectDeptsKey,
      selectDepts,
      selectPositionsKey,
      selectPositions,
      selectRolesKey,
      selectRoles,
    } = this.state;
    return (
      <div>
        <Form
          scrollToFirstError
          {...CONST.formLayout}
          ref={(ref) => {
            this.form = ref;
          }}
        >
          <Card
            title="事件编辑"
            bordered={false}
            extra={
              <Button loading={submitLoading} type="primary" onClick={this.handleSubmit}>
                {submitLoading ? '提交中...' : '提交'}
              </Button>
            }
            bodyStyle={{ minHeight: 'calc(100vh - 200px)' }}
          >
            <Row>
              <Divider orientation="left" plain>
                基本信息
              </Divider>
              <Col span={8}>
                <FormItem
                  label="事件名称"
                  name="eventname"
                  hasFeedback
                  rules={[{ required: true, message: '请输入事件名称' }]}
                >
                  <Input style={{ width: '100%' }} placeholder="请输入事件名称" />
                </FormItem>
              </Col>
              <Col span={8}>
                <FormItem
                  label="事件类型"
                  name="eventtype"
                  hasFeedback
                  rules={[{ required: true, message: '请选择事件类型' }]}
                >
                  <Input style={{ width: '100%' }} placeholder="请选择事件类型" />
                </FormItem>
              </Col>
              <Col span={8}>
                <FormItem
                  label="重要程度"
                  name="importanceno"
                  hasFeedback
                  rules={[{ required: true, message: '请选择重要程度' }]}
                >
                  <DictSelect
                    style={{ width: '100%' }}
                    allowClear
                    placeholder="请选择重要程度"
                    dictid="ae90f3bd998f424a936bd0d2124929e7"
                  >
                    {(item) => (
                      <Option key={item.id} value={item.code}>
                        {item.name}
                      </Option>
                    )}
                  </DictSelect>
                </FormItem>
              </Col>

              <Col span={8}>
                <FormItem
                  label="事件规则"
                  name="rulecode"
                  hasFeedback
                  rules={[{ required: true, message: '请输入请事件规则' }]}
                >
                  <SearchSelect
                    getData={listEventRule}
                    style={{ width: '100%' }}
                    allowClear={false}
                    dropdownMatchSelectWidth={false}
                    optionFilterProp="name"
                    placeholder="请输入请事件规则"
                    onChange={this.handleRuleCodeClick}
                  >
                    {(item) => (
                      <SearchSelect.Option
                        key={item.rulecode}
                        value={item.rulecode}
                        name={item.rulename}
                      >
                        {item.rulename}
                      </SearchSelect.Option>
                    )}
                  </SearchSelect>
                </FormItem>
              </Col>
              <Col span={8}>
                <FormItem label="事件基金配置" name="fundkeyword" hasFeedback>
                  <SearchSelect
                    getData={listEventFundSetting}
                    style={{ width: '100%' }}
                    dropdownMatchSelectWidth={false}
                    optionFilterProp="name"
                    placeholder="请选择事件基金配置"
                  >
                    {(item) => (
                      <SearchSelect.Option key={item.fundkeyword} value={item.fundkeyword}>
                        {item.fundkeyword}
                      </SearchSelect.Option>
                    )}
                  </SearchSelect>
                </FormItem>
              </Col>
              <Col span={8}>
                <Form.Item
                  noStyle
                  shouldUpdate={(prevValues, currentValues) =>
                    prevValues.rulecode !== currentValues.rulecode ||
                    prevValues.fundkeyword !== currentValues.fundkeyword
                  }
                >
                  {({ getFieldValue }) => {
                    return (currentRuleKey || '').toLowerCase().includes('basedate') &&
                      getFieldValue('fundkeyword') ? (
                      <FormItem label="基准日" name="basename" hasFeedback>
                        <SearchSelect
                          getData={listEventBaseDate}
                          style={{ width: '100%' }}
                          placeholder="请选择基准日"
                          onChange={(value) => this.setState({ baseDate: value })}
                        >
                          {(item) => (
                            <SearchSelect.Option
                              key={item}
                              value={item}
                            >{`${item}`}</SearchSelect.Option>
                          )}
                        </SearchSelect>
                      </FormItem>
                    ) : null;
                  }}
                </Form.Item>
              </Col>
              <Col span={24}>
                <Form.Item
                  noStyle
                  shouldUpdate={(prevValues, currentValues) =>
                    prevValues.fundkeyword !== currentValues.fundkeyword
                  }
                >
                  {({ getFieldValue }) => {
                    return getFieldValue('fundkeyword') === '可选基金' ? (
                      <FormItem
                        {...CONST.formFullLayout}
                        label="可选基金"
                        name="funds"
                        hasFeedback
                        rules={[{ required: true, message: '请选择基金' }]}
                      >
                        <FetchSelect
                          getData={listFundShare}
                          style={{ width: '100%' }}
                          placeholder="请输入基金代码或名称搜索"
                          mode="multiple"
                        >
                          {(item) => (
                            <FetchSelect.Option
                              key={item.fundode}
                              value={`${item.fundname}[${item.fundcode}]`}
                            >{`${item.fundname}[${item.fundcode}]`}</FetchSelect.Option>
                          )}
                        </FetchSelect>
                      </FormItem>
                    ) : null;
                  }}
                </Form.Item>
              </Col>
              {currentRuleList && currentRuleList.length > 0 ? (
                <Col span={24}>
                  <FormItem {...CONST.formFullLayout} label="事件规则参数" required>
                    {Array.isArray(currentRuleList) &&
                      currentRuleList.map((item, index) => {
                        if ((item.parameter || '').toLowerCase().includes('date')) {
                          return (
                            <FormItem
                              style={{ display: 'inline-block', marginBottom: 0 }}
                              key={item.parameter}
                              name={item.parameter}
                              initialValue={item.value && moment(item.value)}
                              rules={[
                                {
                                  required: !(
                                    (item.parameter || '').toLowerCase() === 'basedate' && baseDate
                                  ),
                                  message: `请输入${item.parameter}`,
                                },
                              ]}
                            >
                              <DatePicker
                                disabled={
                                  (item.parameter || '').toLowerCase() === 'basedate' && baseDate
                                }
                                placeholder={
                                  (item.parameter || '').toLowerCase() === 'basedate' && baseDate
                                    ? this.form.getFieldValue('basename')
                                    : `请输入${item.parameter}`
                                }
                                style={{ marginRight: 5 }}
                              />
                            </FormItem>
                          );
                        }
                        return (
                          <FormItem
                            style={{ display: 'inline-block', marginBottom: 0 }}
                            key={item.parameter}
                            name={item.parameter}
                            rules={[{ required: true, message: `请输入${item.parameter}` }]}
                          >
                            <InputNumber
                              min={1}
                              step={1}
                              precision={0}
                              style={{ marginRight: 5 }}
                              placeholder={`请输入${item.parameter}`}
                            />
                          </FormItem>
                        );
                      })}
                  </FormItem>
                </Col>
              ) : null}
              <Col span={24}>
                <FormItem {...CONST.formFullLayout} label="事件描述" name="eventdesc" hasFeedback>
                  <Input.TextArea
                    autoSize={{ minRows: 3, maxRows: 20 }}
                    placeholder="请输入事件描述"
                  />
                </FormItem>
              </Col>

              <Divider orientation="left" plain>
                触发设置
              </Divider>
              <Col span={8}>
                <FormItem label="周期" required>
                  <FormItem
                    name="cyclevalue"
                    style={{ display: 'inline-block', width: '60%', marginBottom: 0 }}
                    hasFeedback
                    rules={[{ required: true, message: '请输入周期间隔' }]}
                  >
                    <InputNumber min={0} style={{ width: '100%' }} placeholder="请输入周期间隔" />
                  </FormItem>
                  <FormItem
                    name="cycletype"
                    style={{
                      display: 'inline-block',
                      width: 'calc(40% - 5px)',
                      marginBottom: 0,
                      marginLeft: 5,
                    }}
                    hasFeedback
                    rules={[{ required: true, message: '请选择周期' }]}
                  >
                    <DictSelect
                      style={{ width: '100%' }}
                      allowClear
                      placeholder="请选择周期"
                      dictid="8c024eaa23584966a291f69c041462ab"
                    >
                      {(item) => (
                        <Option key={item.id} value={item.code}>
                          {item.name}
                        </Option>
                      )}
                    </DictSelect>
                  </FormItem>
                </FormItem>
              </Col>
              <Col span={8}>
                <FormItem label="触发时间" required>
                  <FormItem
                    name="starttime"
                    style={{ display: 'inline-block', width: 'calc(50% - 2px)', marginBottom: 0 }}
                    hasFeedback
                    rules={[{ required: true, message: '请选择触发开始时间' }]}
                  >
                    <TimePicker style={{ width: '100%' }} placeholder="开始时间" />
                  </FormItem>
                  <FormItem
                    name="endtime"
                    style={{
                      display: 'inline-block',
                      width: 'calc(50% - 3px)',
                      marginBottom: 0,
                      marginLeft: 5,
                    }}
                    hasFeedback
                    rules={[{ required: true, message: '请选择触发结束时间' }]}
                  >
                    <TimePicker style={{ width: '100%' }} placeholder="结束时间" />
                  </FormItem>
                </FormItem>
              </Col>
              <Col span={8}>
                <FormItem
                  label="节假日处理方式"
                  name="holidaydeal"
                  hasFeedback
                  rules={[{ required: true, message: '请选择节假日处理方式' }]}
                >
                  <DictSelect
                    style={{ width: '100%' }}
                    allowClear
                    placeholder="请选择节假日处理方式"
                    dictid="fd857ec52aaa4497ba3c56baecc5afaa"
                  >
                    {(item) => (
                      <Option key={item.id} value={item.code}>
                        {item.name}
                      </Option>
                    )}
                  </DictSelect>
                </FormItem>
              </Col>
              <Divider orientation="left" plain>
                任务信息
              </Divider>
              <Col span={8}>
                <FormItem label="消息模板" required>
                  <FormItem
                    name="templateid"
                    style={{ width: 'calc(100% - 60px)', marginBottom: 0, display: 'inline-block' }}
                    hasFeedback
                    rules={[{ required: true, message: '请选择消息模板' }]}
                  >
                    <SearchSelect
                      getData={() =>
                        listTemplateMg({
                          templateid: 'e2c36cd096a3423c95af93c137f68c07',
                        }).then((result) => {
                          if (result && result.data) {
                            return { data: result.data.children };
                          }
                          return null;
                        })
                      }
                      style={{ width: '100%' }}
                      dropdownMatchSelectWidth={false}
                      optionFilterProp="name"
                      placeholder="请输入请选择消息类型"
                      onChange={(value, option) => {
                        if (option) {
                          // this.data.noticetypeid = option.key;
                          // this.data.noticetypename = option.name;
                        }
                      }}
                    >
                      {(item) => (
                        <SearchSelect.Option
                          key={item.templateid}
                          value={item.templateid}
                          name={item.label}
                        >
                          {item.label}
                        </SearchSelect.Option>
                      )}
                    </SearchSelect>
                  </FormItem>
                  <span className="ant-form-text" style={{ width: 60 }}>
                    <Button
                      type="link"
                      onClick={() => this.props.history.push('/app/pdt/doc/template')}
                    >
                      新增模板
                    </Button>
                  </span>
                </FormItem>
              </Col>
              <Col span={8}>
                <FormItem
                  label="消息类型"
                  name="messagetype"
                  hasFeedback
                  rules={[{ required: true, message: '请选择消息类型' }]}
                >
                  <DictSelect
                    style={{ width: '100%' }}
                    allowClear
                    placeholder="请选择消息类型"
                    dictid="b4df70fb93134a86a2ce3be99f62c8e9"
                    mode="multiple"
                  >
                    {(item) => (
                      <Option key={item.id} value={item.code}>
                        {item.name}
                      </Option>
                    )}
                  </DictSelect>
                </FormItem>
              </Col>
              <Col span={24}>
                <FormItem {...CONST.formFullLayout} label="接收对象" hasFeedback>
                  <Button
                    type="primary"
                    size="small"
                    onClick={() => this.setState({ userDeptVisible: true })}
                  >
                    选择
                  </Button>
                </FormItem>
              </Col>
              {(selectDepts.length > 0 ||
                selectUsers.length > 0 ||
                selectPositions.length > 0 ||
                selectRoles.length > 0) && (
                  <Col span={24}>
                    <FormItem {...CONST.formFullLayout} label="已选部门" style={{ marginBottom: 0 }}>
                      <QueueAnim type={['right', 'left']}>
                        {selectDepts.length > 0
                          ? selectDepts.map((item) => (
                            <Tag style={{ marginBottom: 5 }} key={item.id}>
                              {item.name}
                            </Tag>
                          ))
                          : '未选择'}
                      </QueueAnim>
                    </FormItem>
                    <FormItem {...CONST.formFullLayout} label="已选员工" style={{ marginBottom: 0 }}>
                      <QueueAnim type={['right', 'left']}>
                        {selectUsers.length > 0
                          ? selectUsers.map((item) => (
                            <Tag style={{ marginBottom: 5 }} key={item.id}>
                              {item.name}
                            </Tag>
                          ))
                          : '未选择'}
                      </QueueAnim>
                    </FormItem>
                    <FormItem {...CONST.formFullLayout} label="已选岗位" style={{ marginBottom: 0 }}>
                      <QueueAnim type={['right', 'left']}>
                        {selectPositions.length > 0
                          ? selectPositions.map((item) => (
                            <Tag style={{ marginBottom: 5 }} key={item.id}>
                              {item.name}
                            </Tag>
                          ))
                          : '未选择'}
                      </QueueAnim>
                    </FormItem>
                    <FormItem {...CONST.formFullLayout} label="已选角色" style={{ marginBottom: 0 }}>
                      <QueueAnim type={['right', 'left']}>
                        {selectRoles.length > 0
                          ? selectRoles.map((item) => (
                            <Tag style={{ marginBottom: 5 }} key={item.id}>
                              {item.name}
                            </Tag>
                          ))
                          : '未选择'}
                      </QueueAnim>
                    </FormItem>
                  </Col>
                )}
            </Row>
          </Card>
        </Form>
        <UserDeptSelect
          title="用户选择"
          visible={userDeptVisible}
          onSave={this.handleUserDeptSave}
          onCancel={() => this.setState({ userDeptVisible: false })}
          selectUserKeys={selectUsersKey}
          selectDeptKeys={selectDeptsKey}
          selectRoleKeys={selectRolesKey}
          selectPositionKeys={selectPositionsKey}
          singleMode={false}
          deptable
          userable
          roleable
          positionable
        />
      </div>
    );
  }
}
export default ManageEdit;
