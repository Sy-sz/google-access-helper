import React from 'react';

const Index = () => {
  return <div>页面已下架 :( </div>;
};

export default Index;

// import React, { Component } from 'react';
// import { Button, Col, Form, Input, Row, Select, message, Tag } from 'antd';
// import { listEvent, delEvent } from 'common/axios';
// import {
//   DictSelect,
//   SearchCard,
//   SearchButton,
//   FetchTable,
//   OperateButton,
// } from '@cerdo/cerdo-design';
// import { ListCard } from '@/common/component';
// import { CONST, routeUtils, fn } from '@cerdo/cerdo-utils';

// const FormItem = Form.Item;
// const Option = Select.Option;

// class Manage extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {};
//     this.params = {};
//   }

//   handleSearchClick = () => {
//     this.table.reloadAndReset();
//   };

//   getList = () => {
//     return new Promise((resolve, reject) => {
//       this.table.getFormParams(this).then((values) => {
//         listEvent({
//           ...values,
//         })
//           .then((result) => {
//             if (fn.checkResponse(result)) {
//               // if (result.code === 'C200') {
//               resolve(result);
//             }
//             reject(null);
//           })
//           .finally(() => {});
//       });
//     });
//   };

//   handleModalClick = () => {};

//   delEventData = (id) => {
//     delEvent({ eventid: id }, id).then((res) => {
//       if (res) {
//         message.success(`删除成功`, 1, () => {
//           this.table.reload();
//         });
//       }
//     });
//   };

//   getColumns = () => {
//     return [
//       { title: '事件名称', dataIndex: 'eventname', key: 'eventname' },
//       { title: '事件类型', dataIndex: 'eventtype', key: 'eventtype' },
//       { title: '事件规则', dataIndex: 'rulename', key: 'rulename' },
//       {
//         title: '消息类型',
//         dataIndex: 'messagetype',
//         key: 'messagetype',
//         render: (text) => {
//           return (text || '').split(',').map((a) => {
//             return <Tag key="tag">{['', '邮件', '短信', '系统消息'][Number(a)]}</Tag>;
//           });
//         },
//       },
//       { title: '事件描述', dataIndex: 'eventdesc', key: 'eventdesc' },
//       {
//         title: '重要程度',
//         dataIndex: 'importanceno',
//         key: 'importanceno',
//         render(text) {
//           return '★★★★★'.substr(0, Number(text));
//         },
//       },
//       {
//         title: '操作',
//         dataIndex: 'operation',
//         key: 'operation',
//         render: (text, record) => {
//           return (
//             <OperateButton
//               type="edit | delete"
//               onEdit={() => {
//                 routeUtils.pushNew.call(this, `/app/pdt/calendar/manageedit?id=${record.eventid}`);
//               }}
//               onDelete={() => {
//                 this.eventRemoveData(record.eventid);
//               }}
//             />
//           );
//         },
//       },
//     ];
//   };

//   render() {
//     return (
//       <div>
//         <SearchCard bordered={false}>
//           <Form
//             {...CONST.layout}
//             ref={(ref) => {
//               this.form = ref;
//             }}
//             onFinish={this.handleSearchClick}
//           >
//             <Row>
//               <Col span={8}>
//                 <FormItem label="事件名称" name="eventname">
//                   <Input allowClear placeholder="请输入事件名称搜索" />
//                 </FormItem>
//               </Col>
//               <Col span={8}>
//                 <FormItem label="事件类型" name="eventtype">
//                   <Input allowClear placeholder="请选择事件类型" />
//                 </FormItem>
//               </Col>
//               <SearchButton onReset={() => this.form.resetFields()} />
//               <Col span={8}>
//                 <FormItem label="重要程度" name="importanceno">
//                   <DictSelect
//                     style={{ width: '100%' }}
//                     allowClear
//                     placeholder="请选择重要程度"
//                     dictid="ae90f3bd998f424a936bd0d2124929e7"
//                   >
//                     {(item) => (
//                       <Option key={item.id} value={item.code}>
//                         {item.name}
//                       </Option>
//                     )}
//                   </DictSelect>
//                 </FormItem>
//               </Col>
//             </Row>
//           </Form>
//         </SearchCard>
//         <ListCard
//           title="事件管理列表"
//           bordered={false}
//           extra={
//             <Button
//               type="primary"
//               onClick={() => routeUtils.pushNew.call(this, '/app/pdt/calendar/manageedit')}
//             >
//               新增
//             </Button>
//           }
//         >
//           <FetchTable
//             size="small"
//             showTools={false}
//             rowKey="eventid"
//             ref={(ref) => {
//               this.table = ref;
//             }}
//             getList={this.getList}
//             columns={this.getColumns()}
//           />
//         </ListCard>
//       </div>
//     );
//   }
// }

// export default Manage;
