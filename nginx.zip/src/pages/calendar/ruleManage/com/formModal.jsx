import { Col, Form, Input, message, Row, Select } from 'antd';
import { saveRule, detailRule } from 'common/axios';
import React, { Component } from 'react';
import { CodeMirror, DragModal } from '@cerdo/cerdo-design';
import { CONST, eventCenter, storage, fn } from '@cerdo/cerdo-utils';

const FormItem = Form.Item;
const Option = Select.Option;

class FormModal extends Component {
  constructor() {
    super();
    this.state = {
      theme: '',
    };
  }

  componentDidMount() {
    this.setState({ theme: storage.getItem('theme') });
    this.themeEventId = eventCenter.subscribe('changeTheme', (eventName, valueObj) => {
      this.setState({ theme: valueObj.theme });
    });
  }

  shouldComponentUpdate(nextProps) {
    if (nextProps.visible && this.props.visible !== nextProps.visible) {
      nextProps.id && this.listAgencyDetailData(nextProps.id);
    }
    return true;
  }

  componentWillUnmount() {
    eventCenter.unsubscribe(this.themeEventId);
  }

  listAgencyDetailData = (id) => {
    detailRule({ rulecode: id }).then((result) => {
      if (fn.checkResponse(result)) {
        this.data = result.data;
        this.form.setFieldsValue({
          rulename: this.data.rulename,
          rulekey: (this.data.rulekey || '').split(','),
          rulesql: this.data.rulesql,
          ruledesc: this.data.ruledesc,
        });
      }
    });
  };

  saveRuleData = (data) => {
    saveRule(data).then((result) => {
      if (fn.checkResponse(result)) {
        message.success(`${this.props.title}成功`, 1.5, () => {
          this.setonCancel();
        });
      } else {
        message.error(`${this.props.title}失败，请重试！`);
      }
    });
  };

  setonCancel = () => {
    this.data = null;
    this.props.onCancel();
  };

  handleSubmit = () => {
    this.form.validateFields().then((values) => {
      this.ruleSaveData({
        ...this.data,
        ...values,
        rulekey: values.rulekey && values.rulekey.join(),
        rulesql: this.editor.getValue(),
      });
    });
  };

  render() {
    const { visible, title, theme } = this.props;

    return (
      <DragModal
        title={title}
        visible={visible}
        width={1000}
        maskClosable={false}
        destroyOnClose
        closable={false}
        onCancel={this.setonCancel}
        onOk={this.handleSubmit}
      >
        <Form
          {...CONST.formModalLayout}
          ref={(ref) => {
            this.form = ref;
          }}
        >
          <Row>
            <Col span={12}>
              <FormItem
                label="规则名称"
                name="rulename"
                hasFeedback
                rules={[{ required: true, message: '请输入规则名称' }]}
              >
                <Input style={{ width: '100%' }} placeholder="请输入规则名称" />
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="规则参数"
                name="rulekey"
                hasFeedback
                rules={[{ required: false, message: '请选择规则参数' }]}
              >
                <Select mode="tags" style={{ width: '100%' }} placeholder="请输入参数">
                  <Option value="baseDate">baseDate</Option>
                  <Option value="startDate">startDate</Option>
                  <Option value="endDate">endDate</Option>
                  <Option value="n">n</Option>
                </Select>
              </FormItem>
            </Col>
            <Col span={24}>
              <FormItem
                {...CONST.formModalFullLayout}
                label="规则描述"
                name="ruledesc"
                hasFeedback
                rules={[{ required: true, message: '请输入规则描述' }]}
              >
                <Input.TextArea
                  autoSize={{ minRows: 2, maxRows: 10 }}
                  placeholder="请输入规则描述"
                />
              </FormItem>
            </Col>
            <Col span={24}>
              <FormItem
                {...CONST.formModalFullLayout}
                label="规则SQL"
                name="rulesql"
                initialValue=""
                rules={[{ required: true, message: '请输入规则SQL' }]}
              >
                <CodeMirror
                  ref={(ref) => {
                    this.editor = ref;
                  }}
                  theme={theme === 'light' ? 'idea' : 'ayu-mirage'}
                  mode="text/x-sql"
                />
              </FormItem>
            </Col>
          </Row>
        </Form>
      </DragModal>
    );
  }
}

export default FormModal;
