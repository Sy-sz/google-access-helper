import React from 'react';

const Index = () => {
  return <div>页面已下架 :( </div>;
};

export default Index;

// import React, { Component } from 'react';
// import { Button, Col, Form, Input, Row, message, Tag } from 'antd';
// import { listEventRule, delRule } from 'common/axios';
// import FormModal from './com/formModal';
// import { SearchCard, SearchButton, FetchTable, OperateButton } from '@cerdo/cerdo-design';
// import { ListCard } from '@/common/component';
// import { CONST, fn } from '@cerdo/cerdo-utils';

// const FormItem = Form.Item;

// class RuleManage extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {};
//     this.params = {};
//   }

//   handleSearchClick = () => {
//     this.table.reloadAndReset();
//   };

//   getList = () => {
//     return new Promise((resolve, reject) => {
//       this.table.getFormParams(this).then((values) => {
//         listEventRule({
//           ...values,
//         })
//           .then((result) => {
//             if (fn.checkResponse(result)) {
//               // if (result.code === 'C200') {
//               resolve(result);
//             }
//             reject(null);
//           })
//           .finally(() => {});
//       });
//     });
//   };

//   handleModalClick = (type, id) => {
//     this.setState({
//       modalId: id,
//       modalTitle: type === 1 ? '修改规则' : '添加规则',
//       modalVisible: true,
//     });
//   };

//   delRuleData = (id) => {
//     delRule({ rulecode: id }, id).then((res) => {
//       if (res) {
//         message.success(`删除成功`, 1, () => {
//           this.table.reload();
//         });
//       }
//     });
//   };

//   getColumns = () => {
//     return [
//       { title: '规则编号', width: 80, sorter: true, dataIndex: 'rulecode', key: 'eventcode' },
//       { title: '规则名称', width: 200, sorter: true, dataIndex: 'rulename', key: 'eventname' },
//       {
//         title: '规则参数',
//         width: 200,
//         sorter: true,
//         dataIndex: 'rulekey',
//         key: 'rulekey',
//         render: (text) => (text || '').split(',').map((a) => <Tag key="tag">{a}</Tag>),
//       },
//       {
//         title: '规则SQL',
//         dataIndex: 'rulesql',
//         key: 'eventtype',
//         width: 400,
//         render: (text) => <pre>{text}</pre>,
//       },
//       {
//         title: '操作',
//         width: 100,
//         dataIndex: 'operation',
//         key: 'operation',
//         render: (text, record) => {
//           return (
//             <OperateButton
//               type="edit | delete"
//               onEdit={() => this.handleModalClick(1, record.rulecode)}
//               onDelete={() => this.ruleRemoveData(record.rulecode)}
//             />
//           );
//         },
//       },
//     ];
//   };

//   render() {
//     const { modalTitle, modalVisible, modalId } = this.state;
//     return (
//       <div>
//         <SearchCard bordered={false}>
//           <Form
//             {...CONST.layout}
//             ref={(ref) => {
//               this.form = ref;
//             }}
//             onFinish={this.handleSearchClick}
//           >
//             <Row>
//               <Col span={8}>
//                 <FormItem label="规则名称" name="rulename">
//                   <Input style={{ width: '100%' }} allowClear placeholder="请输入规则名称搜索" />
//                 </FormItem>
//               </Col>
//               <SearchButton onReset={() => this.form.resetFields()} />
//             </Row>
//           </Form>
//         </SearchCard>
//         <ListCard
//           title="规则管理列表"
//           bordered={false}
//           extra={
//             <Button type="primary" onClick={() => this.handleModalClick(0, null)}>
//               新增
//             </Button>
//           }
//         >
//           <FetchTable
//             size="small"
//             showTools={false}
//             rowKey="rulecode"
//             ref={(ref) => {
//               this.table = ref;
//             }}
//             getList={this.getList}
//             columns={this.getColumns()}
//           />
//         </ListCard>
//         <FormModal
//           title={modalTitle}
//           visible={modalVisible}
//           id={modalId}
//           onCancel={() =>
//             this.setState({ modalVisible: false }, () => {
//               this.table.reload();
//             })
//           }
//         />
//       </div>
//     );
//   }
// }

// export default RuleManage;
