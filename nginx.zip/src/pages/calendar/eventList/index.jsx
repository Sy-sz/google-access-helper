import React from 'react';

const Index = () => {
  return <div>页面已下架 :( </div>;
};

export default Index;

// import React, { Component } from 'react';
// import { Col, Form, Input, Row, Select } from 'antd';
// import { listEventTrack } from 'common/axios';
// import { DictSelect, SearchCard, SearchButton, FetchTable } from '@cerdo/cerdo-design';
// import { ListCard } from '@/common/component';
// import { CONST, fn } from '@cerdo/cerdo-utils';

// const FormItem = Form.Item;
// const Option = Select.Option;

// class EventList extends Component {
//   constructor() {
//     super();
//     this.state = {};
//     this.params = {};
//   }

//   handleSearchClick = () => {
//     this.table.reloadAndReset();
//   };

//   getList = () => {
//     return new Promise((resolve, reject) => {
//       this.table.getFormParams(this).then((values) => {
//         listEventTrack({
//           ...values,
//         })
//           .then((result) => {
//             if (fn.checkResponse(result)) {
//               resolve(result);
//             }
//             reject(null);
//           })
//           .finally(() => {});
//       });
//     });
//   };

//   getColumns = () => {
//     return [
//       { title: '事件名称', width: 120, dataIndex: 'eventname', key: 'eventname' },
//       { title: '事件类型', width: 120, dataIndex: 'eventtype', key: 'eventtype' },
//       {
//         title: '重要程度',
//         width: 120,
//         dataIndex: 'importanceno',
//         key: 'importanceno',
//         render(text) {
//           return '★★★★★'.substr(0, Number(text));
//         },
//       },
//       {
//         title: '基金',
//         width: 120,
//         dataIndex: 'fundcode',
//         key: 'fundcode',
//         render: (_, record) => record.fundcode && `${record.fundname}[${record.fundcode}]`,
//       },
//       { title: '执行结果', width: 80, dataIndex: 'jobstatus', key: 'jobstatus' },
//       {
//         title: '执行时间',
//         width: 120,
//         dataIndex: 'ruledate',
//         key: 'ruledate',
//       },
//     ];
//   };

//   render() {
//     return (
//       <div>
//         <SearchCard bordered={false}>
//           <Form
//             {...CONST.layout}
//             ref={(ref) => {
//               this.form = ref;
//             }}
//             onFinish={this.handleSearchClick}
//           >
//             <Row>
//               <Col span={8}>
//                 <FormItem label="事件名称" name="eventname">
//                   <Input allowClear placeholder="请输入事件名称搜索" />
//                 </FormItem>
//               </Col>
//               <Col span={8}>
//                 <FormItem label="事件类型" name="eventtype">
//                   <Input allowClear placeholder="请选择事件类型" />
//                 </FormItem>
//               </Col>
//               <Col span={8}>
//                 <FormItem label="重要程度" name="importanceno">
//                   <DictSelect
//                     style={{ width: '100%' }}
//                     allowClear
//                     placeholder="请选择重要程度"
//                     dictid="ae90f3bd998f424a936bd0d2124929e7"
//                   >
//                     {(item) => (
//                       <Option key={item.id} value={item.code}>
//                         {item.name}
//                       </Option>
//                     )}
//                   </DictSelect>
//                 </FormItem>
//               </Col>
//               <Col span={8}>
//                 <FormItem label="状态" name="eventstatus">
//                   <DictSelect
//                     style={{ width: '100%' }}
//                     allowClear
//                     placeholder="请选择状态"
//                     dictid="5f3cad1d1f1243f799d96af11815a67a"
//                   >
//                     {(item) => (
//                       <Option key={item.id} value={item.code}>
//                         {item.name}
//                       </Option>
//                     )}
//                   </DictSelect>
//                 </FormItem>
//               </Col>
//               <SearchButton onReset={() => this.form.resetFields()} />
//             </Row>
//           </Form>
//         </SearchCard>
//         <ListCard title="事件跟踪列表" bordered={false}>
//           <FetchTable
//             size="small"
//             showTools={false}
//             rowKey="jobid"
//             ref={(ref) => {
//               this.table = ref;
//             }}
//             getList={this.getList}
//             columns={this.getColumns()}
//           />
//         </ListCard>
//       </div>
//     );
//   }
// }

// export default EventList;
