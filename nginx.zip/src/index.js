import React from 'react';
import ReactDOM from 'react-dom';
import reportWebVitals from './reportWebVitals';
// import { Provider } from 'mobx-react';
import { ConfigProvider } from 'antd';
// 汉化
import zhCN from 'antd/lib/locale/zh_CN';
import App from './routes/index';
// 本地项目全局样式
import '@/styles';
// 全局状态管理
import store from './store';
// 表单组件
import { setup } from '@formily/antd-components';
import { useFormilyFix } from '@chinahorm/web-components/es/components/FixAntdComponents';

// @formily/antd-components 通过 `setup` 方法，可以快速置入内置的表单组件，免去维护全局`components`的工作。
setup();
useFormilyFix();
const { Provider } = store;

ReactDOM.render(
  <ConfigProvider locale={zhCN}>
    <Provider {...store}>
      <App />
    </Provider>
  </ConfigProvider>,
  document.getElementById('root'),
);

reportWebVitals();
