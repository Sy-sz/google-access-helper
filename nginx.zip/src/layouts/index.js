// 先从框架里边导入 defaultLayouts 文件
import defaultLayouts from '@cerdo/cerdo-scaffold/lib/__utils/defaultLayouts';
import cloneDeep from 'lodash/cloneDeep';

// 使用cloneDeep克隆默认layouts配置
const layouts = cloneDeep(defaultLayouts);

// 菜单重新排版这里展示示例是在应用访问的时候不展示一级菜单，其他方式自行探索
layouts.main.formatMenu = (menus) => {
  const menuTree = menus[0]?.children;
  if (menuTree) {
    localStorage.setItem('menus', JSON.stringify(menuTree));
  }
  return menuTree;
};

layouts.header.marketSale = () => [
  { name: '上交所', shortName: '上' },
  { name: '港交所', shortName: '港' },
  { name: '美交所', shortName: '美' },
];

// layouts.main.layoutInit = () => ({ layout: 'avatar' });

export default layouts;
